# app.R - reference app: API keys loaded from a local folder (Windows) with manual fallback and a sidebar status box.
# Run: shiny::runApp()   (from this folder). Reuse: copy R/*.R into another app and follow README.md.
library(shiny); library(shinydashboard)
for (f in list.files("R", pattern = "\\.R$", full.names = TRUE)) source(f, local = TRUE)

api <- ApiManager$new()   # one shared object for the whole app

ui <- dashboardPage(
  dashboardHeader(title = "API keys reference"),
  dashboardSidebar(
    sidebarMenu(id = "menu",
      menuItem("Home", tabName = "home", icon = icon("house")),
      menuItem("API Configuration", tabName = "api", icon = icon("key"))),
    api_status_ui("status")),
  dashboardBody(tabItems(
    tabItem("home", box(width = 12, title = "What this shows", status = "info", solidHeader = TRUE,
      tags$ol(
        tags$li("At start-up the app looks in ", tags$code(cred_dir_default), " (Windows) or in ", tags$code("LAT_CRED_DIR"),
                " for a BigQuery service-account .json and for ", tags$code("ap_claude_1_line.txt"), "."),
        tags$li("If it finds them it connects, and the sidebar turns green (Claude is amber until tested)."),
        tags$li("If not, or on another OS, the API Configuration tab lets you load the key by hand."),
        tags$li("Keys are never written anywhere; only the file path and a masked key are shown.")))),
    tabItem("api", fluidRow(bq_config_ui("bq"), claude_config_ui("claude")))
  )))

server <- function(input, output, session) {
  startup_keys(api)                 # FIRST: before any module that reads BigQuery or calls Claude
  bq_config_server("bq", api)
  claude_config_server("claude", api)
  api_status_server("status", api)
}

shinyApp(ui, server)
