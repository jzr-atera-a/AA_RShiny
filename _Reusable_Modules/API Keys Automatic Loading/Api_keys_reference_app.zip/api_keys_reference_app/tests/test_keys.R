# tests/test_keys.R - checks the key folder logic without Windows, real keys or network.
# Run from the app folder:  Rscript tests/test_keys.R
# BigQuery sign-in is replaced by a fake (fake_bq) so only the app's own logic is tested.
suppressMessages(library(shiny))
for (f in list.files("R", pattern = "\\.R$", full.names = TRUE)) source(f)
pass <- 0L; fail <- 0L
ok <- function(c, what) { if (isTRUE(c)) { pass <<- pass + 1L; cat("  ok  ", what, "\n") } else { fail <<- fail + 1L; cat("  FAIL", what, "\n") } }

FakeApi <- R6::R6Class("FakeApi", inherit = ApiManager, public = list(   # BigQuery sign-in faked: a key whose private_key is "bad" fails
  authenticate_bigquery = function(json_path = NULL, json_text = NULL) { j <- jsonlite::fromJSON(json_path); if (identical(j$private_key, "bad")) stop("invalid_grant")
    self$bq_authenticated <- TRUE; self$bq_key_label <- j$client_email; invisible(TRUE) }))
fake_api <- function() FakeApi$new()
sa <- function(project, key = "x") sprintf('{"type":"service_account","project_id":"%s","private_key":"%s","client_email":"svc@%s.iam"}', project, key, project)
mkdir <- function() { d <- tempfile("keys"); dir.create(d); d }

cat("Folder search\n")
Sys.unsetenv(c("LAT_CRED_DIR", "ATERA_BQ_KEY_FILE", "GOOGLE_APPLICATION_CREDENTIALS", "ANTHROPIC_API_KEY"))
if (.Platform$OS.type != "windows") ok(cred_dir() == "", "not Windows and no LAT_CRED_DIR: no folder searched")
d <- mkdir(); Sys.setenv(LAT_CRED_DIR = d); ok(cred_dir() == d, "LAT_CRED_DIR is used on any OS")
writeLines(sa("other"), file.path(d, "a_other.json")); Sys.sleep(1.1); writeLines(sa("atera-2"), file.path(d, "b_atera.json"))
writeLines(sa("newest"), file.path(d, "c_newest.json")); writeLines('{"hello":1}', file.path(d, "not_a_key.json"))
writeLines(c("", "  sk-ant-api03-ABCDEFGHIJKLMNOP  ", ""), file.path(d, "ap_claude_1_line.txt"))
lc <- local_credentials(project = "atera-2")
ok(basename(lc$json_path) == "b_atera.json", "the key for the app's project wins over a newer one")
ok(basename(local_credentials(project = "none")$json_path) == "c_newest.json", "no project match: the newest key")
ok(lc$claude_key == "sk-ant-api03-ABCDEFGHIJKLMNOP", "Claude key: first non-empty line, trimmed")
ok(mask_key(lc$claude_key) == "sk-ant-...MNOP", "the key is masked for display")
e <- mkdir(); ln <- local_credentials(e); ok(is.na(ln$json_path) && is.na(ln$claude_key) && length(ln$notes) == 2, "empty folder: nothing found, two notes")
ok(grepl("not found", local_credentials(file.path(e, "nope"))$notes), "missing folder: a note, no error")

cat("Start-up\n")
a <- fake_api(); out <- capture.output(st <- startup_keys(a))
ok(a$bq_authenticated && a$claude_authenticated, "both APIs connected from the folder")
ok(grepl("b_atera.json", st$bq) && is.na(a$claude_tested), "status names the file; Claude is loaded but not yet tested")
ok(!any(grepl("ABCDEFGHIJKLMNOP", out)), "the full Claude key never reaches the log")
writeLines(sa("atera-2", "bad"), file.path(d, "b_atera.json"))
a2 <- fake_api(); invisible(capture.output(st2 <- startup_keys(a2))); ok(!a2$bq_authenticated && isTRUE(st2$bq_failed), "a bad key: not connected, and the status says the connection failed")
Sys.setenv(LAT_CRED_DIR = e, ANTHROPIC_API_KEY = "sk-ant-env-key-123456")
a3 <- fake_api(); invisible(capture.output(st3 <- startup_keys(a3))); ok(a3$claude_authenticated && grepl("ANTHROPIC_API_KEY", st3$claude), "empty folder: falls back to the environment")
Sys.unsetenv("ANTHROPIC_API_KEY")

cat("Tabs (manual load still works)\n")
a4 <- fake_api(); invisible(capture.output(startup_keys(a4)))
kf <- tempfile(fileext = ".json"); writeLines(sa("atera-2"), kf)
testServer(bq_config_server, args = list(api = a4), { session$setInputs(project = "atera-2", dataset = "ds", file = list(datapath = kf), text = "", connect = 1)
  ok(a4$bq_authenticated, "BigQuery key loaded by hand in the tab") })
testServer(claude_config_server, args = list(api = a4), { session$setInputs(key = "sk-ant-typed-key-999999", model = "claude-haiku-5-5", save = 1)
  ok(a4$claude_api_key == "sk-ant-typed-key-999999" && a4$claude_model == "claude-haiku-5-5", "Claude key typed in the tab") })
testServer(api_status_server, args = list(api = a4), { h <- as.character(output$lights$html); ok(grepl("ready", h) && grepl("not tested", h), "sidebar: BigQuery ready, Claude loaded but not tested") })

cat(sprintf("\n%d passed, %d failed\n", pass, fail)); if (fail) quit(status = 1)
