# R/api_manager.R
# A minimal shared credentials object: one per app, passed to every module that needs BigQuery or Claude.
# Field and method names match the larger apps in this workspace (bq_authenticated, claude_authenticated,
# authenticate_bigquery(json_path =), set_claude_credentials()), so modules move between apps unchanged.

ApiManager <- R6::R6Class("ApiManager",
  public = list(
    bq_project_id = "atera-2", bq_dataset_id = "business_strategy", bq_authenticated = FALSE, bq_key_label = NULL,
    claude_api_key = NULL, claude_model = "claude-sonnet-5-5", claude_authenticated = FALSE, claude_tested = NA,

    set_bigquery_target = function(project_id, dataset_id) { self$bq_project_id <- project_id; self$bq_dataset_id <- dataset_id; invisible(self) },

    # json_path = a service-account file; json_text = its pasted contents (written to a temp file only for bq_auth)
    authenticate_bigquery = function(json_path = NULL, json_text = NULL) {
      if (is.null(json_path) && !is.null(json_text) && nzchar(trimws(json_text))) { json_path <- tempfile(fileext = ".json"); writeLines(json_text, json_path) }
      if (is.null(json_path)) stop("Provide a service-account JSON file or paste its contents.")
      j <- jsonlite::fromJSON(json_path)
      miss <- setdiff(c("type", "project_id", "private_key", "client_email"), names(j))
      if (length(miss)) stop("Missing JSON fields: ", paste(miss, collapse = ", "))
      self$bq_authenticated <- FALSE
      bigrquery::bq_auth(path = json_path, cache = FALSE)
      bigrquery::bq_project_datasets(self$bq_project_id)          # proves the key can reach the project
      self$bq_authenticated <- TRUE; self$bq_key_label <- j$client_email
      cat("[BigQuery] connected as", j$client_email, "to", self$bq_project_id, "\n")
      invisible(TRUE)
    },
    bq_query = function(sql) {
      if (!self$bq_authenticated) stop("BigQuery is not connected.")
      bigrquery::bq_table_download(bigrquery::bq_project_query(self$bq_project_id, sql))
    },

    # loading a key does not prove it works: test_claude() makes one tiny call
    set_claude_credentials = function(api_key, model = NULL) {
      self$claude_api_key <- trimws(api_key); if (!is.null(model) && nzchar(model)) self$claude_model <- model
      self$claude_authenticated <- nzchar(self$claude_api_key); self$claude_tested <- NA
      invisible(self)
    },
    call_claude = function(prompt, max_tokens = 200) {
      if (!self$claude_authenticated) stop("Claude is not set up.")
      r <- httr::POST("https://api.anthropic.com/v1/messages",
                      httr::add_headers(`x-api-key` = self$claude_api_key, `anthropic-version` = "2023-06-01", `content-type` = "application/json"),
                      body = jsonlite::toJSON(list(model = self$claude_model, max_tokens = max_tokens, messages = list(list(role = "user", content = prompt))), auto_unbox = TRUE),
                      encode = "raw", httr::timeout(60))
      p <- httr::content(r, as = "parsed", simplifyVector = FALSE)
      if (httr::status_code(r) >= 400) stop("Claude API error (HTTP ", httr::status_code(r), "): ", p$error$message %||% "")
      paste(vapply(Filter(function(b) identical(b$type, "text"), p$content), function(b) b$text, ""), collapse = "")
    },
    test_claude = function() {
      ok <- tryCatch({ self$call_claude("Reply with the single word OK.", 10); TRUE }, error = function(e) { cat("[Claude] test failed:", conditionMessage(e), "\n"); FALSE })
      self$claude_tested <- ok; ok
    }
  ))
