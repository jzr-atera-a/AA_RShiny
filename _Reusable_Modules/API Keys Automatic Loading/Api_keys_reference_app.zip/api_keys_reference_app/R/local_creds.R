# R/local_creds.R
# Find API keys in a local folder on the computer running the app. Copy this file as it is into any R Shiny app.
#
# Folder: C:/111_SecA/_q_api on Windows, or the folder named in the environment variable LAT_CRED_DIR on any OS.
# Expected files:
#   BigQuery : any *.json whose content has "type": "service_account" and a "private_key"
#              (several: the one whose project_id matches `project` wins, else the newest)
#   Claude   : ap_claude_1_line.txt   (first non-empty line = the Anthropic API key)
# Keys are only read here. They are never copied, written to BigQuery or printed: logs show the file path and a
# masked key at most.

cred_dir_default <- "C:/111_SecA/_q_api"

cred_dir <- function() {
  d <- Sys.getenv("LAT_CRED_DIR", "")
  if (nzchar(d)) d else if (.Platform$OS.type == "windows") cred_dir_default else ""
}

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0) y else x

local_credentials <- function(dir = cred_dir(), project = "") {
  out <- list(dir = dir, json_path = NA_character_, json_project = NA_character_, claude_key = NA_character_, notes = character(0))
  if (!nzchar(dir)) { out$notes <- "Not Windows: no local key folder is searched (set LAT_CRED_DIR to use one)."; return(out) }
  if (!dir.exists(dir)) { out$notes <- sprintf("Folder %s not found.", dir); return(out) }

  # BigQuery: service-account JSON files only (other .json files are ignored)
  js <- list.files(dir, pattern = "\\.json$", full.names = TRUE, ignore.case = TRUE)
  info <- lapply(js, function(f) {
    j <- tryCatch(jsonlite::fromJSON(f, simplifyVector = TRUE), error = function(e) NULL)
    if (is.list(j) && identical(j$type, "service_account") && !is.null(j$private_key))
      data.frame(path = f, project = j$project_id %||% "", mtime = as.numeric(file.mtime(f)), stringsAsFactors = FALSE) else NULL
  })
  info <- do.call(rbind, Filter(Negate(is.null), info))
  if (!is.null(info) && nrow(info)) {
    info <- info[order(info$project != project, -info$mtime), , drop = FALSE]
    out$json_path <- info$path[1]; out$json_project <- info$project[1]
    if (nrow(info) > 1) out$notes <- c(out$notes, sprintf("%d service-account keys found; using %s.", nrow(info), basename(info$path[1])))
  } else out$notes <- c(out$notes, sprintf("No service-account .json key in %s.", dir))

  # Claude: one line in ap_claude_1_line.txt
  kf <- file.path(dir, "ap_claude_1_line.txt")
  if (file.exists(kf)) {
    k <- trimws(readLines(kf, warn = FALSE)); k <- k[nzchar(k)]
    if (length(k)) out$claude_key <- k[1] else out$notes <- c(out$notes, "ap_claude_1_line.txt is empty.")
  } else out$notes <- c(out$notes, sprintf("No ap_claude_1_line.txt in %s.", dir))
  out
}

mask_key <- function(k) if (is.null(k) || is.na(k) || nchar(k) < 12) "" else paste0(substr(k, 1, 7), "...", substr(k, nchar(k) - 3, nchar(k)))
