# R/startup_keys.R
# Called once at the top of server(): connect from the local folder, then from environment variables.
# Order (the first source that works wins; each step is skipped if that API is already connected):
#   1. local folder (local_credentials())
#   2. environment: ATERA_BQ_KEY_FILE / GOOGLE_APPLICATION_CREDENTIALS (BigQuery), ANTHROPIC_API_KEY + CLAUDE_MODEL (Claude)
#   3. by hand in the API Configuration tabs (always available, also to switch to another key)
# Returns the status texts that the config tabs and the sidebar show; also kept in .GlobalEnv for other modules.

startup_keys <- function(api) {
  st <- list(bq = NULL, claude = NULL, bq_failed = FALSE, dir = cred_dir())
  lc <- tryCatch(local_credentials(project = api$bq_project_id), error = function(e) list(notes = conditionMessage(e)))
  if (length(lc$notes)) cat("[Keys]", paste(lc$notes, collapse = " "), "\n")

  if (!is.na(lc$json_path %||% NA) && !isTRUE(api$bq_authenticated)) {
    ok <- tryCatch({ api$authenticate_bigquery(json_path = lc$json_path); TRUE },
                   error = function(e) { cat("[BigQuery] key from", lc$json_path, "failed:", conditionMessage(e), "\n"); FALSE })
    st$bq <- if (ok) sprintf("Connected automatically with %s (found in %s).", basename(lc$json_path), lc$dir)
             else sprintf("A key was found (%s) but the connection failed: see the R console.", basename(lc$json_path))
    st$bq_failed <- !ok
  }
  if (!is.na(lc$claude_key %||% NA) && !isTRUE(api$claude_authenticated)) {
    m <- Sys.getenv("CLAUDE_MODEL", ""); api$set_claude_credentials(lc$claude_key, model = if (nzchar(m)) m else NULL)
    cat("[Claude] API key taken from", file.path(lc$dir, "ap_claude_1_line.txt"), "\n")   # the path only, never the key
    st$claude <- sprintf("Key loaded automatically from %s (%s). Press Test connection to check it.", file.path(lc$dir, "ap_claude_1_line.txt"), mask_key(lc$claude_key))
  }

  key <- Sys.getenv("ATERA_BQ_KEY_FILE", Sys.getenv("GOOGLE_APPLICATION_CREDENTIALS", ""))
  if (nzchar(key) && file.exists(key) && !isTRUE(api$bq_authenticated)) {
    ok <- tryCatch({ api$authenticate_bigquery(json_path = key); TRUE }, error = function(e) { cat("[BigQuery] environment key failed:", conditionMessage(e), "\n"); FALSE })
    if (ok) st$bq <- sprintf("Connected automatically with the key named in the environment (%s).", basename(key))
  }
  k <- Sys.getenv("ANTHROPIC_API_KEY", "")
  if (nzchar(k) && !isTRUE(api$claude_authenticated)) {
    m <- Sys.getenv("CLAUDE_MODEL", ""); api$set_claude_credentials(k, model = if (nzchar(m)) m else NULL)
    st$claude <- sprintf("Key loaded from ANTHROPIC_API_KEY (%s). Press Test connection to check it.", mask_key(k))
  }
  assign(".cred_status", st, envir = .GlobalEnv)
  st
}
cred_status <- function() tryCatch(get(".cred_status", envir = .GlobalEnv), error = function(e) list())
