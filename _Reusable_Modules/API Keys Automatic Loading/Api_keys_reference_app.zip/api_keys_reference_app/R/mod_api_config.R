# R/mod_api_config.R
# The two API Configuration tabs and the sidebar status box. The manual inputs (file / paste) are always there,
# so a key found automatically can still be replaced; the banner on top says where the current key came from.

banner <- function(ok, ...) tags$div(style = sprintf("background:%s; border:1px solid %s; color:%s; border-radius:8px; padding:8px 10px; margin-bottom:10px; font-size:12.5px;",
  if (ok) "#ecfdf5" else "#fffbeb", if (ok) "#a7f3d0" else "#fde68a", if (ok) "#065f46" else "#92400e"), icon(if (ok) "key" else "circle-info"), " ", ...)
not_found_text <- function(what) { d <- cred_status()$dir %||% ""
  if (nzchar(d)) sprintf("No %s found in %s: load it below.", what, d) else sprintf("This is not Windows, so no local key folder is searched: load the %s below.", what) }

# ---- BigQuery ----------------------------------------------------------------------------------------------
bq_config_ui <- function(id) { ns <- NS(id)
  box(title = "BigQuery", status = "primary", solidHeader = TRUE, width = 6,
    uiOutput(ns("auto")),
    textInput(ns("project"), "GCP project", "atera-2"), textInput(ns("dataset"), "Dataset", "business_strategy"),
    fileInput(ns("file"), "Service-account key (.json)", accept = ".json"),
    textAreaInput(ns("text"), "or paste its JSON", rows = 3),
    actionButton(ns("connect"), "Connect", icon = icon("plug"), class = "btn-primary"),
    actionButton(ns("test"), "Test query", icon = icon("play")), uiOutput(ns("msg"))) }

bq_config_server <- function(id, api) moduleServer(id, function(input, output, session) {
  msg <- reactiveVal(NULL)
  output$auto <- renderUI({ msg(); st <- cred_status()
    if (!is.null(st$bq)) banner(!isTRUE(st$bq_failed), st$bq, " You can still load another key below.") else banner(FALSE, not_found_text("service-account .json key")) })
  observeEvent(input$connect, {
    api$set_bigquery_target(trimws(input$project), trimws(input$dataset))
    r <- tryCatch({ api$authenticate_bigquery(json_path = input$file$datapath, json_text = input$text); list(TRUE, "Connected.") },
                  error = function(e) list(FALSE, conditionMessage(e)))
    updateTextAreaInput(session, "text", value = "")   # do not leave a key on screen
    msg(r) })
  observeEvent(input$test, { r <- tryCatch({ d <- api$bq_query("SELECT 1 AS ok"); list(TRUE, sprintf("Query ran (%d row).", nrow(d))) }, error = function(e) list(FALSE, conditionMessage(e))); msg(r) })
  output$msg <- renderUI({ m <- msg(); if (is.null(m)) return(NULL); tags$div(style = sprintf("margin-top:8px; color:%s;", if (m[[1]]) "#16a34a" else "#b91c1c"), m[[2]]) })
})

# ---- Claude ------------------------------------------------------------------------------------------------
claude_config_ui <- function(id) { ns <- NS(id)
  box(title = "Claude API", status = "primary", solidHeader = TRUE, width = 6,
    uiOutput(ns("auto")),
    passwordInput(ns("key"), "Anthropic API key", placeholder = "sk-ant-..."),
    selectInput(ns("model"), "Model", c("claude-sonnet-5-5", "claude-haiku-5-5", "claude-opus-5-5")),
    actionButton(ns("save"), "Save key", icon = icon("save"), class = "btn-primary"),
    actionButton(ns("test"), "Test connection", icon = icon("plug")), uiOutput(ns("msg"))) }

claude_config_server <- function(id, api) moduleServer(id, function(input, output, session) {
  msg <- reactiveVal(NULL)
  output$auto <- renderUI({ msg(); st <- cred_status()
    if (!is.null(st$claude)) banner(TRUE, st$claude, " You can still paste another key below.") else banner(FALSE, not_found_text("ap_claude_1_line.txt"))  })
  observeEvent(input$save, { if (!nzchar(input$key)) { msg(list(FALSE, "Paste a key first.")); return() }
    api$set_claude_credentials(input$key, input$model); updateTextInput(session, "key", value = "")
    msg(list(TRUE, sprintf("Key %s saved for this session.", mask_key(api$claude_api_key)))) })
  observeEvent(input$test, { if (!api$claude_authenticated) { msg(list(FALSE, "No key loaded.")); return() }
    ok <- withProgress(message = "Calling Claude...", api$test_claude()); msg(list(ok, if (ok) "Claude answered: the key works." else "The call failed: see the R console.")) })
  output$msg <- renderUI({ m <- msg(); if (is.null(m)) return(NULL); tags$div(style = sprintf("margin-top:8px; color:%s;", if (m[[1]]) "#16a34a" else "#b91c1c"), m[[2]]) })
})

# ---- sidebar box: green = ready, amber = key loaded but not proved, red = missing or failed ----------------------
api_status_ui <- function(id) { ns <- NS(id)
  tagList(
    tags$style(HTML(sprintf("#%s:empty::before { content: 'BigQuery: connecting...   Claude: connecting...'; color:#fbbf24; font-size:11.5px; }", ns("lights")))),
    tags$div(style = "padding:10px; background:#2c3e50; margin-top:6px;",
      tags$div(style = "color:#b2e0db; font-size:11px; font-weight:700; margin-bottom:4px;", "API CONNECTIONS"), uiOutput(ns("lights")))) }

api_status_server <- function(id, api) moduleServer(id, function(input, output, session) {
  output$lights <- renderUI({
    invalidateLater(3000)   # the api fields are plain R6 fields, not reactive: re-check every 3 s
    st <- cred_status()
    light <- function(name, col, txt) tags$div(style = "display:flex; gap:6px; margin:3px 0; font-size:11.5px; color:#ecf0f1;",
      tags$span(style = sprintf("display:inline-block; width:10px; height:10px; border-radius:50%%; background:%s; margin-top:3px; flex:none;", col)), tags$span(tags$b(name, ": "), txt))
    bq <- isTRUE(api$bq_authenticated); cl <- isTRUE(api$claude_authenticated); t <- api$claude_tested
    tagList(
      light("BigQuery", if (bq) "#22c55e" else "#ef4444", if (bq) "ready" else if (isTRUE(st$bq_failed)) "key found, connection failed" else "not connected: API Configuration"),
      light("Claude", if (cl && isTRUE(t)) "#22c55e" else if (cl && is.na(t)) "#fbbf24" else "#ef4444",
            if (!cl) "no key: API Configuration" else if (isTRUE(t)) "ready (tested)" else if (is.na(t)) "key loaded, not tested yet" else "test failed"))
  })
})
