# =============================================================================
# R/utils_api.R — APIManager R6 class
# =============================================================================
# Single shared object passed into every module server. Holds all credentials
# and provides all data-access methods. Keeps modules decoupled: they call
# api_manager$method() rather than importing each other.
#
# TO ADAPT THIS TEMPLATE:
#   1. Update BQ_PROJECT / BQ_DATASET / BQ_TABLE constants below
#   2. Replace call_llm() body with your chosen LLM provider's API call
#   3. Add domain-specific query methods following the bq_query() pattern
# =============================================================================

# ── ▶ CONFIGURE THESE for your project ────────────────────────────────────────
BQ_PROJECT   <- "your-gcp-project-id"      # GCP project ID
BQ_DATASET   <- "your_dataset"             # BigQuery dataset name
BQ_TABLE     <- "your_table"               # BigQuery table name
LLM_DEFAULT_MODEL   <- "claude-sonnet-4-6" # Default model string
LLM_DEFAULT_TOKENS  <- 16000               # Default max output tokens
LLM_DEFAULT_TIMEOUT <- 300                 # Request timeout in seconds
# ──────────────────────────────────────────────────────────────────────────────

APIManager <- R6::R6Class("APIManager",
  public = list(
    
    # ── BigQuery state ─────────────────────────────────────────────────────────
    bq_authenticated    = FALSE,
    bq_project_id       = BQ_PROJECT,
    bq_dataset_id       = BQ_DATASET,
    bq_table_id         = BQ_TABLE,
    bq_full_table_id    = NULL,
    
    # ── LLM state ──────────────────────────────────────────────────────────────
    llm_authenticated   = FALSE,
    llm_api_key         = NULL,
    llm_model           = LLM_DEFAULT_MODEL,
    llm_max_tokens      = LLM_DEFAULT_TOKENS,
    llm_timeout         = LLM_DEFAULT_TIMEOUT,
    
    # ── Reactive cross-module communication ────────────────────────────────────
    # state_trigger: any module can call trigger_state_update() after writing
    # data; all other modules observe this and refresh their dropdowns/tables.
    state_trigger       = NULL,
    # pending_parsed_text: lets the ingest module push generated text to the
    # browse/parse module without either knowing about the other.
    pending_parsed_text = NULL,
    
    # ── Initialise ─────────────────────────────────────────────────────────────
    initialize = function() {
      self$state_trigger       <- shiny::reactiveVal(0)
      self$pending_parsed_text <- shiny::reactiveVal("")
      self$bq_full_table_id    <- paste0(
        self$bq_project_id, ".", self$bq_dataset_id, ".", self$bq_table_id
      )
      cat("🔌 APIManager initialised\n")
    },
    
    # ── Broadcast a data-change event to all observers ─────────────────────────
    trigger_state_update = function() {
      n <- self$state_trigger() + 1
      self$state_trigger(n)
      cat("🔔 State trigger fired:", n, "\n")
    },
    
    # ── Cross-module text handoff ──────────────────────────────────────────────
    set_pending_text = function(text) {
      self$pending_parsed_text(text)
    },
    
    # ══ BigQuery methods ═══════════════════════════════════════════════════════
    
    set_bq_credentials = function(project, dataset, table) {
      self$bq_project_id    <- project
      self$bq_dataset_id    <- dataset
      self$bq_table_id      <- table
      self$bq_full_table_id <- paste0(project, ".", dataset, ".", table)
    },
    
    test_bq_connection = function() {
      cat("🔧 [bq] Testing connection to:", self$bq_full_table_id, "\n")
      job <- bigrquery::bq_project_query(
        self$bq_project_id,
        sprintf("SELECT COUNT(*) as n FROM `%s` LIMIT 1", self$bq_full_table_id)
      )
      result <- bigrquery::bq_table_download(job)
      self$bq_authenticated <- TRUE
      self$trigger_state_update()
      cat("✅ [bq] Connected. Row count:", result$n, "\n")
      return(result$n)
    },
    
    # Generic SELECT — use this as the basis for all domain query methods
    bq_query = function(query) {
      if (!self$bq_authenticated) stop("BigQuery not authenticated")
      job    <- bigrquery::bq_project_query(self$bq_project_id, query)
      bigrquery::bq_table_download(job)
    },
    
    # Get distinct values for cascade dropdowns (adapt field names to your schema)
    # ▶ TEMPLATE: replace 'category', 'subcategory', 'title', 'author' with your columns
    bq_get_taxonomy = function() {
      empty <- data.frame(category = character(), subcategory = character(),
                           title = character(), author = character(),
                           stringsAsFactors = FALSE)
      if (!self$bq_authenticated) return(empty)
      tryCatch({
        self$bq_query(sprintf(
          "SELECT DISTINCT category, subcategory, title, author
           FROM `%s`
           WHERE category IS NOT NULL
           ORDER BY category, subcategory, title",
          self$bq_full_table_id
        ))
      }, error = function(e) {
        cat("⚠️  [bq_get_taxonomy]:", e$message, "\n")
        empty
      })
    },
    
    # Append rows to the BigQuery table
    # ▶ TEMPLATE: update REQUIRED_COLS to match your schema
    bq_insert = function(df) {
      if (!self$bq_authenticated) stop("BigQuery not authenticated")
      
      # ▶ TEMPLATE: list ALL columns in the order your BQ table defines them
      REQUIRED_COLS <- c(
        "id", "created_at",
        "title", "author", "category", "subcategory",
        "chapter_or_item", "section",
        "main_content",
        "formula", "formula_explanation",
        "reference_url", "reference_description",
        "numeric_data", "numeric_data_description"
      )
      
      # Auto-assign id and timestamp
      existing_max <- tryCatch({
        res <- self$bq_query(sprintf("SELECT MAX(id) as max_id FROM `%s`", self$bq_full_table_id))
        if (is.na(res$max_id[1])) 0L else as.integer(res$max_id[1])
      }, error = function(e) 0L)
      
      df$id         <- seq(existing_max + 1L, existing_max + nrow(df))
      df$created_at <- as.character(Sys.time())
      
      # Fill any missing columns with empty string
      for (col in REQUIRED_COLS) {
        if (!col %in% names(df)) df[[col]] <- ""
      }
      
      # Reorder to match table schema
      df <- df[, REQUIRED_COLS, drop = FALSE]
      
      tbl <- bigrquery::bq_table(self$bq_project_id, self$bq_dataset_id, self$bq_table_id)
      bigrquery::bq_table_upload(tbl, df, write_disposition = "WRITE_APPEND")
      
      self$trigger_state_update()
      cat("✅ [bq_insert] Inserted", nrow(df), "rows\n")
    },
    
    # ══ LLM methods ════════════════════════════════════════════════════════════
    
    set_llm_credentials = function(api_key, model, max_tokens, timeout) {
      self$llm_api_key    <- api_key
      self$llm_model      <- model
      self$llm_max_tokens <- max_tokens
      self$llm_timeout    <- timeout
    },
    
    test_llm_connection = function() {
      cat("🔧 [llm] Testing connection, model:", self$llm_model, "\n")
      
      # ▶ TEMPLATE: this implementation targets Anthropic's Claude API.
      #   To switch to OpenAI, change the URL, headers, and body shape below.
      response <- httr::POST(
        url = "https://api.anthropic.com/v1/messages",
        httr::add_headers(
          "x-api-key"         = self$llm_api_key,
          "anthropic-version" = "2023-06-01",
          "content-type"      = "application/json"
        ),
        body = jsonlite::toJSON(list(
          model      = self$llm_model,
          max_tokens = 10L,
          messages   = list(list(role = "user", content = "Hi"))
        ), auto_unbox = TRUE),
        httr::timeout(30)
      )
      
      status <- httr::status_code(response)
      
      if (status == 200) {
        self$llm_authenticated <- TRUE
        self$trigger_state_update()
        cat("✅ [llm] Connected\n")
        return(TRUE)
      } else {
        parsed <- tryCatch(httr::content(response, "parsed"), error = function(e) NULL)
        detail <- if (!is.null(parsed$error$message)) parsed$error$message else paste("HTTP", status)
        self$llm_authenticated <- FALSE
        stop(paste("Connection failed:", detail))
      }
    },
    
    # Call the LLM and return list(text, stop_reason, truncated)
    # progress_callback: optional function(msg) for updating UI during long calls
    call_llm = function(prompt, max_tokens = NULL, progress_callback = NULL) {
      if (!self$llm_authenticated) stop("LLM not authenticated")
      
      tokens <- max_tokens %||% self$llm_max_tokens
      cat("🔧 [llm] Sending request | model:", self$llm_model,
          "| max_tokens:", tokens, "| timeout:", self$llm_timeout, "\n")
      
      if (!is.null(progress_callback)) progress_callback("Sending request to LLM...")
      
      tryCatch({
        response <- httr::POST(
          url = "https://api.anthropic.com/v1/messages",
          httr::add_headers(
            "x-api-key"         = self$llm_api_key,
            "anthropic-version" = "2023-06-01",
            "content-type"      = "application/json"
          ),
          body = jsonlite::toJSON(list(
            model      = self$llm_model,
            max_tokens = tokens,
            messages   = list(list(role = "user", content = prompt))
          ), auto_unbox = TRUE),
          encode  = "json",
          httr::timeout(self$llm_timeout)
        )
        
        status <- httr::status_code(response)
        cat("🔧 [llm] HTTP status:", status, "\n")
        
        if (status != 200) {
          err <- tryCatch(httr::content(response, "parsed"), error = function(e) NULL)
          msg <- if (!is.null(err$error$message)) err$error$message else paste("HTTP", status)
          stop(msg)
        }
        
        if (!is.null(progress_callback)) progress_callback("Parsing response...")
        
        result      <- httr::content(response, "parsed", encoding = "UTF-8")
        stop_reason <- result$stop_reason %||% "unknown"
        truncated   <- identical(stop_reason, "max_tokens")
        
        cat("✅ [llm] Done | stop_reason:", stop_reason,
            if (truncated) "(TRUNCATED)" else "", "\n")
        
        list(
          text       = result$content[[1]]$text,
          stop_reason = stop_reason,
          truncated  = truncated
        )
        
      }, error = function(e) {
        cat("❌ [llm] Error:", e$message, "\n")
        # Friendlier network error messages
        msg <- e$message
        if (grepl("timeout|timed out", msg, ignore.case = TRUE)) {
          stop("Request timed out — increase Timeout in LLM Config and try again")
        } else if (grepl("connection|network|peer|reset", msg, ignore.case = TRUE)) {
          stop(paste("Network error:", msg,
                     "\nThis usually means a firewall/proxy reset the connection.",
                     "Try reducing Max Tokens or use streaming mode."))
        }
        stop(msg)
      })
    }
  )
)
