# =============================================================================
# R/utils_common.R — Shared pure functions
# =============================================================================
# These functions have NO side effects and NO Shiny dependencies.
# They are called by multiple modules and tested independently.
#
# TO ADAPT THIS TEMPLATE:
#   1. Update parse_structured_text() field names to match your schema
#   2. Update build_llm_prompt() to describe your domain to the LLM
#   3. Update CATEGORY_SENTINEL / SUBCATEGORY_SENTINEL if you rename the levels
# =============================================================================

# ── SQL injection defence ──────────────────────────────────────────────────────
# ⚠️  BigQuery (GoogleSQL) escapes single quotes with BACKSLASH (\'),
#     NOT the ANSI SQL doubled-quote (''). Using '' here corrupts queries
#     on values like "Don't" or "O'Brien".
safe_sql_escape <- function(x) {
  gsub("'", "\\\\'", as.character(x))
}

# ── Blank/NA/N-A field detection ──────────────────────────────────────────────
# Used to skip rendering optional fields (formula, numeric_data, etc.)
# when they were stored as empty or "N/A".
has_real_value <- function(x) {
  if (is.null(x) || is.na(x)) return(FALSE)
  trimmed <- trimws(as.character(x))
  nchar(trimmed) > 0 && !tolower(trimmed) %in% c("n/a", "na")
}

# ── Sentinel values for "Add New" dropdown options ────────────────────────────
CATEGORY_SENTINEL    <- "__ADD_NEW_CATEGORY__"
SUBCATEGORY_SENTINEL <- "__ADD_NEW_SUBCATEGORY__"

# ── Metadata header helpers ───────────────────────────────────────────────────
# Accepts both the correct "[Value]" format and the malformed "[Label]: Value"
# format LLMs sometimes produce despite instructions.
is_metadata_line <- function(line) {
  t <- trimws(line)
  grepl("^\\[", t) && grepl("\\]", t)
}

extract_metadata_value <- function(line) {
  t     <- trimws(line)
  open  <- regexpr("\\[", t)[1]
  close <- regexpr("\\]", t)[1]
  if (open == -1 || close <= open) return(t)
  inner <- substr(t, open + 1, close - 1)
  after <- trimws(sub("^:", "", trimws(substr(t, close + 1, nchar(t)))))
  if (nchar(after) > 0) after else trimws(inner)
}

# ── Force-overwrite the metadata header ───────────────────────────────────────
# Replaces everything before the first [chapter_or_item]: line with a clean
# 4-line header built from known-correct values (the user's form inputs).
# Guarantees the parser always sees a clean header regardless of what the LLM
# actually wrote there.
# ▶ TEMPLATE: change "chapter_or_item" to whatever your item-level marker is
overwrite_metadata_header <- function(text, title, author, category, subcategory) {
  lines     <- strsplit(text, "\n")[[1]]
  item_idx  <- which(grepl("^\\s*\\[chapter_or_item\\]:", lines, ignore.case = TRUE))[1]
  
  if (is.na(item_idx)) return(text)  # Can't find marker — return unchanged
  
  header <- c(
    paste0("[", title, "]"),
    paste0("[", author, "]"),
    paste0("[", category, "]"),
    paste0("[", subcategory, "]"),
    ""
  )
  paste(c(header, lines[item_idx:length(lines)]), collapse = "\n")
}

# ── Force-blank optional fields ───────────────────────────────────────────────
# When the user opts out of formulas/numeric data, sets those fields to "N/A"
# regardless of what the LLM wrote.
# ▶ TEMPLATE: update field names to match your schema
blank_optional_fields <- function(text) {
  lines   <- strsplit(text, "\n")[[1]]
  BLANKS  <- c("formula", "formula_explanation", "numeric_data", "numeric_data_description")
  for (field in BLANKS) {
    pat         <- paste0("^(\\s*\\[", field, "\\]\\s*:)\\s*.*$")
    hits        <- grepl(pat, lines, ignore.case = TRUE)
    lines[hits] <- sub(pat, "\\1 N/A", lines[hits], ignore.case = TRUE)
  }
  paste(lines, collapse = "\n")
}

# ── Main parser ───────────────────────────────────────────────────────────────
# Converts the LLM's structured plain-text output into a data frame ready for
# bq_insert(). The text format is:
#
#   [Title]
#   [Author / Creator]
#   [Category]
#   [Subcategory]
#
#   [chapter_or_item]: Item 01: Item Title
#   [section]: All Sections
#   [main_content]: ...
#   [formula]: $$ ... $$ or N/A
#   [formula_explanation]: ... or N/A
#   [reference_url]: https://...
#   [reference_description]: ...
#   [numeric_data]: 75,90,60,80,85,70
#   [numeric_data_description]: Label1 (75), Label2 (90), ...
#
# ▶ TEMPLATE: rename field names and the FIELDS vector to match your schema
parse_structured_text <- function(text) {
  lines <- strsplit(text, "\n")[[1]]
  
  # ── Extract header metadata (first 4 bracketed lines) ──────────────────────
  title       <- ""
  author      <- ""
  category    <- ""
  subcategory <- ""
  meta_count  <- 0
  
  for (i in seq_len(min(15, length(lines)))) {
    line <- trimws(lines[i])
    if (is_metadata_line(line)) {
      meta_count <- meta_count + 1
      val <- extract_metadata_value(line)
      if (meta_count == 1) title       <- val
      if (meta_count == 2) author      <- val
      if (meta_count == 3) category    <- val
      if (meta_count == 4) subcategory <- val
      if (meta_count >= 4) break
    }
  }
  
  if (nchar(title) == 0) stop("Could not find title in text — check header format")
  
  # ── Extract item entries ────────────────────────────────────────────────────
  # ▶ TEMPLATE: "chapter_or_item" is the field that starts each new row.
  #   Change to whatever your item-level marker is (e.g. "event", "product").
  FIELDS <- c("chapter_or_item", "section", "main_content",
              "formula", "formula_explanation",
              "reference_url", "reference_description",
              "numeric_data", "numeric_data_description")
  
  rows        <- list()
  current_row <- list()
  
  for (line in lines) {
    trimmed <- trimws(line)
    matched <- FALSE
    
    for (field in FIELDS) {
      pat <- paste0("^\\[", field, "\\]:\\s*(.+)$")
      m   <- regmatches(trimmed, regexpr(pat, trimmed, perl = TRUE))
      if (length(m) > 0) {
        val <- sub(paste0("^\\[", field, "\\]:\\s*"), "", m, perl = TRUE)
        
        # Starting a new item when we hit the item-level marker
        if (field == "chapter_or_item" && length(current_row) > 0) {
          rows <- c(rows, list(current_row))
          current_row <- list()
        }
        
        current_row[[field]] <- val
        matched <- TRUE
        break
      }
    }
    
    # Multi-line main_content accumulation
    if (!matched && length(current_row) > 0 &&
        !is.null(current_row[["main_content"]]) &&
        nchar(trimmed) > 0 &&
        !grepl("^\\[", trimmed)) {
      current_row[["main_content"]] <- paste(current_row[["main_content"]], trimmed)
    }
  }
  
  if (length(current_row) > 0) rows <- c(rows, list(current_row))
  if (length(rows) == 0) stop("No item entries found in text")
  
  # ── Build data frame ────────────────────────────────────────────────────────
  df_list <- lapply(rows, function(r) {
    data.frame(
      title                   = title,
      author                  = author,
      category                = category,
      subcategory             = subcategory,
      chapter_or_item         = r[["chapter_or_item"]]         %||% "",
      section                 = r[["section"]]                 %||% "",
      main_content            = r[["main_content"]]            %||% "",
      formula                 = r[["formula"]]                 %||% "N/A",
      formula_explanation     = r[["formula_explanation"]]     %||% "N/A",
      reference_url           = r[["reference_url"]]           %||% "",
      reference_description   = r[["reference_description"]]   %||% "",
      numeric_data            = r[["numeric_data"]]            %||% "N/A",
      numeric_data_description = r[["numeric_data_description"]] %||% "N/A",
      stringsAsFactors = FALSE
    )
  })
  
  do.call(rbind, df_list)
}

# ── LLM prompt builder ────────────────────────────────────────────────────────
# ▶ TEMPLATE: customise the domain description, field list, and instructions
#   to match what you want the LLM to generate for your application.
build_llm_prompt <- function(title, author, category, subcategory,
                              include_optional = TRUE) {
  cat_text  <- if (nchar(category) > 0)    paste0("[", category, "]\n")    else "[General]\n"
  sub_text  <- if (nchar(subcategory) > 0) paste0("[", subcategory, "]\n") else "[General Subcategory]\n"
  
  if (include_optional) {
    optional_fields <- '[formula]: $$LaTeX expression$$ or N/A
[formula_explanation]: Explanation of the formula, or N/A
[numeric_data]: val1,val2,val3,val4,val5,val6  (0-100 range)
[numeric_data_description]: Label1 (val1), Label2 (val2), ...'
    optional_instructions <- '5. OPTIONAL FIELDS (include when relevant):
   - [formula]: use LaTeX syntax ($$display$$ or $inline$)
   - [numeric_data]: always exactly 6 comma-separated values 0–100
   - If not applicable, write N/A for both formula and numeric fields'
  } else {
    optional_fields <- '[formula]: N/A
[formula_explanation]: N/A
[numeric_data]: N/A
[numeric_data_description]: N/A'
    optional_instructions <- '5. OPTIONAL FIELDS: write N/A for formula and numeric fields for every entry'
  }
  
  paste0(
    'Generate a comprehensive structured analysis of "', title, '" by ', author,
    ' following this EXACT format:\n\n',
    
    'HEADER (4 lines exactly):\n',
    '[', title, ']\n',
    '[', author, ']\n',
    cat_text, sub_text, '\n',
    
    'THEN for each chapter / section / item use this EXACT pattern:\n',
    '[chapter_or_item]: Item 01: Item Title\n',
    '[section]: All Sections\n',
    '[main_content]: 100-200 word summary of this item\n',
    optional_fields, '\n',
    '[reference_url]: https://relevant-url.com\n',
    '[reference_description]: Brief description of what this URL contains\n\n',
    
    'RULES:\n',
    '1. Start item numbers with leading zero for 1-9 (Item 01, Item 02, ...)\n',
    '2. Separate items with ONE blank line\n',
    '3. NO markdown, NO # headers, NO bullet points\n',
    '4. Use EXACT bracket format shown above\n',
    optional_instructions, '\n\n',
    
    'Generate the complete structured analysis for "', title, '" by ', author, ' now.'
  )
}

# ── Shared cascade dropdown UI ────────────────────────────────────────────────
# Renders a Category + Subcategory dropdown pair with "+ Add New" options.
# Call genre_topic_dropdown_ui(ns) inside any module's UI function.
# ▶ TEMPLATE: rename labels to match your domain ("Genre", "City", "Type", etc.)
category_subcategory_ui <- function(ns, category_label = "Category",
                                     subcategory_label = "Subcategory") {
  tagList(
    selectInput(ns("category_select"), paste0(category_label, ": *"),
                choices = c("+ Add New" = CATEGORY_SENTINEL)),
    conditionalPanel(
      condition = sprintf("input['%s'] == '%s'", ns("category_select"), CATEGORY_SENTINEL),
      textInput(ns("new_category_text"), paste("New", category_label, "Name:"),
                placeholder = paste("e.g.,", category_label, "name"))
    ),
    selectInput(ns("subcategory_select"), paste0(subcategory_label, ": *"),
                choices = c("+ Add New" = SUBCATEGORY_SENTINEL)),
    conditionalPanel(
      condition = sprintf("input['%s'] == '%s'", ns("subcategory_select"), SUBCATEGORY_SENTINEL),
      textInput(ns("new_subcategory_text"), paste("New", subcategory_label, "Name:"),
                placeholder = paste("e.g.,", subcategory_label, "name"))
    )
  )
}

# ── Shared cascade server logic ───────────────────────────────────────────────
# Wires the reactive cascade. Call inside any moduleServer() body.
# Returns a reactive() yielding list(category, subcategory).
setup_category_cascade <- function(input, output, session, api_manager) {
  
  taxonomy <- reactive({
    api_manager$state_trigger()
    api_manager$bq_get_taxonomy()
  })
  
  observeEvent(taxonomy(), {
    tax  <- taxonomy()
    cats <- sort(unique(tax$category[nchar(trimws(tax$category)) > 0]))
    ch   <- c("+ Add New" = CATEGORY_SENTINEL, setNames(cats, cats))
    cur  <- isolate(input$category_select)
    updateSelectInput(session, "category_select", choices = ch,
                      selected = if (!is.null(cur) && cur %in% ch) cur else CATEGORY_SENTINEL)
  }, ignoreNULL = FALSE)
  
  observeEvent(input$category_select, {
    tax  <- taxonomy()
    if (is.null(input$category_select) || input$category_select == CATEGORY_SENTINEL) {
      updateSelectInput(session, "subcategory_select",
                        choices = c("+ Add New" = SUBCATEGORY_SENTINEL))
      return()
    }
    subs <- sort(unique(tax$subcategory[tax$category == input$category_select &
                                          nchar(trimws(tax$subcategory)) > 0]))
    ch <- c("+ Add New" = SUBCATEGORY_SENTINEL)
    if (length(subs) > 0) ch <- c(ch, setNames(subs, subs))
    updateSelectInput(session, "subcategory_select", choices = ch)
  }, ignoreInit = TRUE)
  
  reactive({
    cat_val <- if (identical(input$category_select, CATEGORY_SENTINEL))
      trimws(input$new_category_text %||% "") else input$category_select %||% ""
    sub_val <- if (identical(input$subcategory_select, SUBCATEGORY_SENTINEL))
      trimws(input$new_subcategory_text %||% "") else input$subcategory_select %||% ""
    list(category = cat_val, subcategory = sub_val)
  })
}
