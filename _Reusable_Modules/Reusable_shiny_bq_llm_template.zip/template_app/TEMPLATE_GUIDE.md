# Shiny Template App — Adaptation Guide

This is a minimal but fully working skeleton for building data-collection-and-visualisation apps using R Shiny, Google BigQuery, and an LLM API (Claude by default, OpenAI-swappable).

---

## Quick Start

```r
# 1. Install dependencies
install.packages(c(
  "shiny", "shinydashboard", "R6", "yaml", "purrr",
  "shinyjs", "httr", "jsonlite", "bigrquery",
  "DT", "plotly", "dplyr", "stringr", "tidyr"
))

# 2. Open the project folder in RStudio
# IMPORTANT: your working directory must be the project root
# (the folder containing app.R) or the CSS will not load.

# 3. Set up BigQuery (see schema.sql)

# 4. Update the three constants at the top of R/utils_api.R:
#    BQ_PROJECT, BQ_DATASET, BQ_TABLE

# 5. Run
shiny::runApp()
```

---

## File Map

```
template_app/
├── app.R                     Entry point — sources modules, wires server
├── global.R                  Package loading, UI definition, APIManager init
├── schema.sql                BigQuery CREATE TABLE DDL — adapt to your schema
├── TEMPLATE_GUIDE.md         This file
│
├── R/
│   ├── utils_api.R           APIManager R6: BigQuery + LLM methods
│   └── utils_common.R        Pure helpers: parser, prompt builder, SQL escape
│
├── modules/
│   ├── bigquery_auth/        JSON key upload + BQ connection
│   ├── llm_config/           LLM API key + model settings
│   ├── data_ingest/          AI generation + bulk paste + parse + upload
│   ├── browse_data/          Paginated DT table with category/subcategory filter
│   ├── visualizations/       Rich cards + Plotly chart + cascade dropdowns
│   └── about/                Static info tab
│
└── www/css/global.css        Shared CSS — viz-card boxes, status colours, badges
```

---

## Adapting to Your Domain — Step by Step

### Step 1: Update BigQuery identifiers

In `R/utils_api.R`, change the three constants at the top:

```r
BQ_PROJECT  <- "your-gcp-project-id"
BQ_DATASET  <- "your_dataset_name"
BQ_TABLE    <- "your_table_name"
```

### Step 2: Update the schema

Edit `schema.sql` to match your domain's columns. Common changes:
- Rename `title`/`author` to your primary identifiers (e.g. `event_name`/`organiser`)
- Rename `category`/`subcategory` to your classification levels (e.g. `city`/`event_type`)
- Rename `chapter_or_item` to your row-level unit (e.g. `event`, `product`, `paper`)
- Add domain-specific columns (e.g. `event_date`, `latitude`, `longitude`)
- Remove `formula`/`numeric_data` if not applicable to your domain

Run the updated SQL in BigQuery Console to create the table.

### Step 3: Update bq_insert() column list

In `R/utils_api.R`, update `REQUIRED_COLS` inside `bq_insert()` to match your schema exactly, in the same column order as your BigQuery table.

### Step 4: Update the taxonomy query

In `R/utils_api.R`, update `bq_get_taxonomy()` to select the correct columns:

```r
# Change category, subcategory, title, author to your column names
"SELECT DISTINCT category, subcategory, title, author FROM `%s` ..."
```

Also update the returned `empty` data frame to match.

### Step 5: Update the parser

In `R/utils_common.R`, update `parse_structured_text()`:
- Change the `FIELDS` vector to your field names
- The first field in `FIELDS` is the "item start" marker — change `chapter_or_item` to your row unit
- Update the `data.frame()` call at the bottom to your column names

### Step 6: Update the prompt builder

In `R/utils_common.R`, update `build_llm_prompt()` to describe your domain, your desired fields, and any domain-specific instructions to the LLM.

### Step 7: Update cascade dropdown labels

In `R/utils_common.R`, `category_subcategory_ui()` accepts `category_label` and `subcategory_label` arguments. Pass your domain's labels when calling it:

```r
# Example: events app
category_subcategory_ui(ns, category_label = "City", subcategory_label = "Event Type")
```

### Step 8: Customise the visualisation cards

In `modules/visualizations/server.R`, the HTML generation loop builds a `.viz-card` per item. The fields it references (`main_content`, `formula`, `reference_url`, `numeric_data`) map directly to your schema — update field names to match your columns.

For non-card visualisations (calendar, map, timeline), replace or add output blocks here and add the corresponding UI elements in `modules/visualizations/ui.R`.

---

## Switching LLM Provider

The template ships with Anthropic's Claude API. To switch to OpenAI:

1. In `R/utils_api.R`, update `test_llm_connection()` and `call_llm()`:
   - URL: `https://api.openai.com/v1/chat/completions`
   - Headers: `Authorization: Bearer <key>`, `Content-Type: application/json`
   - Body: `{ "model": "gpt-4o", "messages": [...], "max_tokens": ... }`
   - Response path: `result$choices[[1]]$message$content`
   - Stop reason path: `result$choices[[1]]$finish_reason` (`"stop"` = complete, `"length"` = truncated)

2. In `modules/llm_config/ui.R`, update the model dropdown choices.

---

## Adding a New Module

1. Create `modules/your_module/ui.R` with a `your_module_ui(id)` function
2. Create `modules/your_module/server.R` with a `your_module_server(id, api_manager)` function
3. Add `source("modules/your_module/ui.R")` and `source("modules/your_module/server.R")` to `app.R`
4. Add a `menuItem()` entry in the `sidebarMenu` in `global.R`
5. Add a `tabItem("your_module", your_module_ui("your_module"))` in the `tabItems` in `global.R`
6. Add `your_module_server("your_module", api_manager)` in the `server()` function in `app.R`

---

## Deploying to shinyapps.io

```r
library(rsconnect)
rsconnect::deployApp("path/to/template_app/")
```

**Critical:** every package used anywhere in the app must appear as a literal `library("pkg")` call in `global.R`. rsconnect's static scanner cannot detect packages loaded dynamically or via YAML. The block is already there — add any new packages you introduce.

**Embedded credentials (no upload prompt):** store the BigQuery service account JSON as a shinyapps.io environment variable:

```r
# In global.R, add before modules are sourced:
bq_json <- Sys.getenv("BQ_SERVICE_ACCOUNT_JSON")
if (nchar(bq_json) > 0) {
  tmp <- tempfile(fileext = ".json")
  writeLines(bq_json, tmp)
  bigrquery::bq_auth(path = tmp)
  api_manager$bq_authenticated <- TRUE
}
```

Set the variable in the shinyapps.io dashboard: App → Settings → Environment Variables.

---

## Key Patterns Reference

### state_trigger — broadcast data updates
```r
# After any write, fire this so all modules refresh:
api_manager$trigger_state_update()

# In any module that should refresh on new data:
observe({
  api_manager$state_trigger()   # dependency
  # ... re-query and update UI ...
})
```

### Cross-module text handoff
```r
# Push text from module A:
api_manager$set_pending_text(my_text)

# Receive in module B:
observeEvent(api_manager$pending_parsed_text(), {
  txt <- api_manager$pending_parsed_text()
  if (nchar(txt) > 0) updateTextAreaInput(session, "my_input", value = txt)
}, ignoreInit = TRUE)
```

### SQL escaping (BigQuery-specific)
```r
# Always escape user strings before SQL interpolation.
# BigQuery uses \' (backslash), NOT '' (doubled quote).
safe_val <- safe_sql_escape(input$user_string)
query <- sprintf("SELECT * FROM `%s` WHERE name = '%s'", table, safe_val)
```

### CSS working directory
The `www/css/global.css` file is served relative to the app root. If you see unstyled cards (no white boxes, no teal borders), your working directory is wrong. Fix:
```r
setwd("path/to/template_app")
shiny::runApp()
# or equivalently:
shiny::runApp("path/to/template_app")
```

---

## Example: Adapting to a City Events App

| Template field | Events equivalent |
|---|---|
| `title` | `event_name` |
| `author` | `organiser` |
| `category` | `city` |
| `subcategory` | `event_type` |
| `chapter_or_item` | `event_date` |
| `section` | `venue_name` |
| `main_content` | `description` |
| `reference_url` | `ticket_url` |
| `numeric_data` | `N/A` (remove) |
| New columns | `latitude`, `longitude`, `price_range` |

Visualisations tab: replace content cards with `leaflet` map markers coloured by `event_type`, and add a date-range slider filter.
