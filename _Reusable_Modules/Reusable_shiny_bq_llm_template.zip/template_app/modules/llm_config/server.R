# modules/llm_config/server.R

llm_config_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    save_to_manager <- function() {
      api_manager$set_llm_credentials(
        api_key    = input$api_key,
        model      = input$model,
        max_tokens = input$max_tokens,
        timeout    = input$timeout
      )
    }
    
    observeEvent(input$test_connection, {
      req(nchar(input$api_key) > 0)
      
      output$status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"), " Testing...")
      })
      
      save_to_manager()
      
      tryCatch({
        api_manager$test_llm_connection()
        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   " Connected — model: ", input$model)
        })
        showNotification("LLM connected!", type = "message")
      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " ", e$message)
        })
      })
    })
    
    observeEvent(input$save_credentials, {
      req(nchar(input$api_key) > 0)
      save_to_manager()
      showNotification("LLM credentials saved!", type = "message")
    })
    
    output$status <- renderUI({ tags$div() })
  })
}
