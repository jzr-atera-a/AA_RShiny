# modules/llm_config/ui.R
# ▶ TEMPLATE: update model choices if using a different provider

llm_config_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      box(title = "LLM API Configuration", status = "primary",
          solidHeader = TRUE, width = 12,
          
          p("Configure your Large Language Model API credentials for AI-powered data generation."),
          p(class = "text-muted",
            "Currently configured for Anthropic Claude. To switch to OpenAI, update ",
            "call_llm() and test_llm_connection() in R/utils_api.R."),
          
          fluidRow(
            column(6,
              passwordInput(ns("api_key"), "API Key:",
                            placeholder = "sk-ant-...  or  sk-..."),
              
              # ▶ TEMPLATE: update model list when providers retire old versions
              selectInput(ns("model"), "Model:",
                choices = c(
                  "Claude Sonnet 4.6 (Recommended)" = "claude-sonnet-4-6",
                  "Claude Opus 4.8 (Most Capable)"  = "claude-opus-4-8",
                  "Claude Haiku 4.5 (Fastest)"      = "claude-haiku-4-5-20251001"
                  # OpenAI example (update call_llm() too):
                  # "GPT-4o"                 = "gpt-4o",
                  # "GPT-4o Mini (Fastest)"  = "gpt-4o-mini"
                ),
                selected = "claude-sonnet-4-6"
              ),
              
              numericInput(ns("max_tokens"), "Max Output Tokens:",
                           value = 16000, min = 1000, max = 64000, step = 1000),
              
              numericInput(ns("timeout"), "Request Timeout (seconds):",
                           value = 300, min = 60, max = 1800, step = 30),
              
              div(class = "alert alert-info", style = "margin-top: 10px; font-size: 0.9em;",
                  tags$strong("Token / Timeout guidance:"), br(),
                  "Increase Max Tokens if generated content is missing its final items (truncation).",
                  br(),
                  "Increase Timeout for long generations. If you get network reset errors on long ",
                  "requests, consider chunking the request rather than increasing tokens further.")
            ),
            column(6,
              tags$div(style = "margin-top: 25px;",
                actionButton(ns("test_connection"), "Test Connection",
                             class = "btn-primary btn-lg", icon = icon("plug"),
                             style = "width: 100%; margin-bottom: 10px;"),
                actionButton(ns("save_credentials"), "Save Credentials",
                             class = "btn-success btn-lg", icon = icon("save"),
                             style = "width: 100%;")
              ),
              br(),
              uiOutput(ns("status"))
            )
          )
      )
    )
  )
}
