# modules/about/ui.R

about_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      box(title = "About This Template", status = "primary",
          solidHeader = TRUE, width = 12,
          
          h3("Modular R Shiny + BigQuery + LLM Template"),
          p("This is a reusable skeleton application. See ", tags$code("TEMPLATE_GUIDE.md"),
            " in the project root for full adaptation instructions."),
          
          h4("Architecture"),
          tags$ul(
            tags$li(tags$strong("app.R"), " — entry point, sources modules, wires server"),
            tags$li(tags$strong("global.R"), " — package loading, UI definition, APIManager instantiation"),
            tags$li(tags$strong("R/utils_api.R"), " — APIManager R6 class (BigQuery + LLM methods)"),
            tags$li(tags$strong("R/utils_common.R"), " — pure helper functions (parser, prompt builder, SQL escape)"),
            tags$li(tags$strong("modules/"), " — self-contained tabs (ui.R + server.R each)"),
            tags$li(tags$strong("www/css/global.css"), " — shared CSS including viz-card styles")
          ),
          
          h4("Adapting to Your Domain"),
          tags$ol(
            tags$li("Update ", tags$code("BQ_PROJECT"), ", ", tags$code("BQ_DATASET"), ", ",
                    tags$code("BQ_TABLE"), " constants at the top of ", tags$code("R/utils_api.R")),
            tags$li("Update ", tags$code("REQUIRED_COLS"), " in ", tags$code("bq_insert()"),
                    " to match your BigQuery table schema"),
            tags$li("Update field names in ", tags$code("parse_structured_text()"), " and ",
                    tags$code("build_llm_prompt()"), " in ", tags$code("R/utils_common.R")),
            tags$li("Rename dropdown labels in ", tags$code("category_subcategory_ui()"),
                    " to match your domain"),
            tags$li("Update ", tags$code("bq_get_taxonomy()"), " query column names in ",
                    tags$code("R/utils_api.R")),
            tags$li("Customise the visualisation cards in ",
                    tags$code("modules/visualizations/server.R"))
          ),
          
          h4("Key Patterns"),
          tags$ul(
            tags$li(tags$strong("state_trigger"), ": call ", tags$code("api_manager$trigger_state_update()"),
                    " after any write; all modules observing it auto-refresh"),
            tags$li(tags$strong("Cross-module text handoff"), ": use ",
                    tags$code("api_manager$set_pending_text()"), " to push text between tabs"),
            tags$li(tags$strong("SQL escaping"), ": always wrap user strings in ",
                    tags$code("safe_sql_escape()"), " — BigQuery uses backslash, not doubled quotes"),
            tags$li(tags$strong("rsconnect deployment"), ": every package must appear as a literal ",
                    tags$code("library()"), " call in ", tags$code("global.R"),
                    " for the static scanner to detect it")
          )
      )
    )
  )
}

# modules/about/server.R
about_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    # Static tab — no server logic needed
  })
}
