# modules/browse_data/server.R

browse_data_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    all_data <- reactiveVal(NULL)
    
    load_data <- function() {
      if (!api_manager$bq_authenticated) return(NULL)
      tryCatch({
        api_manager$bq_query(sprintf(
          "SELECT * FROM `%s` ORDER BY created_at DESC LIMIT 2000",
          api_manager$bq_full_table_id
        ))
      }, error = function(e) {
        cat("⚠️  [browse_data] Query error:", e$message, "\n"); NULL
      })
    }
    
    # Refresh when state_trigger fires (new data uploaded anywhere)
    observe({
      api_manager$state_trigger()
      df <- load_data()
      all_data(df)
      
      if (!is.null(df)) {
        cats <- c("All" = "", sort(unique(df$category[nchar(trimws(df$category)) > 0])))
        updateSelectInput(session, "filter_category", choices = cats)
      }
    })
    
    observeEvent(input$filter_category, {
      df <- all_data()
      if (is.null(df)) return()
      if (nchar(input$filter_category) > 0) {
        subs <- c("All" = "", sort(unique(
          df$subcategory[df$category == input$filter_category & nchar(trimws(df$subcategory)) > 0]
        )))
      } else {
        subs <- c("All" = "")
      }
      updateSelectInput(session, "filter_subcategory", choices = subs)
    })
    
    observeEvent(input$refresh_btn, {
      df <- load_data()
      all_data(df)
      showNotification("Data refreshed", type = "message")
    })
    
    filtered_data <- reactive({
      df <- all_data()
      if (is.null(df)) return(NULL)
      if (nchar(input$filter_category %||% "") > 0)
        df <- df[df$category == input$filter_category, ]
      if (nchar(input$filter_subcategory %||% "") > 0)
        df <- df[df$subcategory == input$filter_subcategory, ]
      df
    })
    
    output$record_count <- renderUI({
      df <- filtered_data()
      if (is.null(df)) return(tags$div(class = "status-info", "Connect BigQuery to view records"))
      tags$div(class = "status-success",
               tags$i(class = "fa fa-database"),
               sprintf(" %s records", format(nrow(df), big.mark = ",")))
    })
    
    output$data_table <- DT::renderDT({
      df <- filtered_data()
      req(!is.null(df) && nrow(df) > 0)
      DT::datatable(
        df,
        options = list(
          scrollX    = TRUE,
          pageLength = 15,
          order      = list(list(1, "desc"))
        ),
        rownames = FALSE,
        filter   = "top"
      )
    })
    
    output$download_csv <- downloadHandler(
      filename = function() paste0("data_export_", Sys.Date(), ".csv"),
      content  = function(file) {
        df <- filtered_data()
        if (!is.null(df)) write.csv(df, file, row.names = FALSE)
      }
    )
  })
}
