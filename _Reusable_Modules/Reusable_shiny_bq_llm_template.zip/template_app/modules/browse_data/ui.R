# modules/browse_data/ui.R

browse_data_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      box(title = "Browse Records", status = "info",
          solidHeader = TRUE, width = 12,
          
          fluidRow(
            column(3, selectInput(ns("filter_category"), "Category:",
                                  choices = c("All" = ""))),
            column(3, selectInput(ns("filter_subcategory"), "Subcategory:",
                                  choices = c("All" = ""))),
            column(3, br(), actionButton(ns("refresh_btn"), "Refresh",
                                         class = "btn-default", icon = icon("sync"))),
            column(3, br(), downloadButton(ns("download_csv"), "Download CSV",
                                            class = "btn-default"))
          ),
          
          br(),
          uiOutput(ns("record_count")),
          br(),
          DT::DTOutput(ns("data_table"))
      )
    )
  )
}
