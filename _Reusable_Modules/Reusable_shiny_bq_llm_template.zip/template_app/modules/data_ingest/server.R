# modules/data_ingest/server.R

data_ingest_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    generated_text <- reactiveVal("")
    parsed_data    <- reactiveVal(NULL)
    cat_sub        <- setup_category_cascade(input, output, session, api_manager)
    
    # ── Receive text pushed from the generate flow ─────────────────────────────
    observeEvent(api_manager$pending_parsed_text(), {
      txt <- api_manager$pending_parsed_text()
      if (nchar(txt) > 0) {
        updateTextAreaInput(session, "bulk_text", value = txt)
      }
    }, ignoreInit = TRUE)
    
    # ── Generate via LLM ───────────────────────────────────────────────────────
    observeEvent(input$generate_btn, {
      
      if (!api_manager$llm_authenticated) {
        showNotification("Configure LLM credentials first (LLM API Config tab)", type = "error")
        return()
      }
      
      cs <- cat_sub()
      
      if (nchar(input$item_title) == 0 || nchar(input$item_author) == 0) {
        showNotification("Enter Title and Author/Creator", type = "error"); return()
      }
      if (nchar(cs$category) == 0 || nchar(cs$subcategory) == 0) {
        showNotification("Select or enter Category and Subcategory", type = "error"); return()
      }
      
      cat("🖱️  [data_ingest] Generate clicked | title:", input$item_title,
          "| category:", cs$category, "\n")
      
      shinyjs::show("loading_spinner")
      output$gen_status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"),
                 " Generating content...")
      })
      
      prompt <- tryCatch(
        build_llm_prompt(input$item_title, input$item_author,
                          cs$category, cs$subcategory, input$include_optional),
        error = function(e) { NULL }
      )
      
      if (is.null(prompt)) {
        shinyjs::hide("loading_spinner")
        showNotification("Failed to build prompt", type = "error")
        return()
      }
      
      tryCatch({
        result <- api_manager$call_llm(
          prompt = prompt,
          progress_callback = function(msg) {
            output$gen_status <- renderUI({
              tags$div(class = "status-info",
                       tags$i(class = "fa fa-spinner fa-spin"), " ", msg)
            })
          }
        )
        
        # Force-overwrite header with known-correct values
        clean_text <- overwrite_metadata_header(
          result$text, input$item_title, input$item_author,
          cs$category, cs$subcategory
        )
        
        # If optional fields unchecked, blank them regardless of LLM output
        if (!isTRUE(input$include_optional)) {
          clean_text <- blank_optional_fields(clean_text)
        }
        
        generated_text(clean_text)
        shinyjs::hide("loading_spinner")
        
        truncation_note <- if (isTRUE(result$truncated)) {
          tags$span(style = "color: #e67e22; font-weight: bold;",
                    " ⚠️ Response truncated — increase Max Tokens and regenerate")
        } else NULL
        
        output$gen_status <- renderUI({
          tags$div(class = if (isTRUE(result$truncated)) "status-warning" else "status-success",
                   tags$i(class = if (isTRUE(result$truncated)) "fa fa-exclamation-triangle"
                          else "fa fa-check-circle"),
                   sprintf(" Generated %s characters", format(nchar(clean_text), big.mark=",")),
                   truncation_note)
        })
        
        showNotification("Content generated!", type = "message")
        
      }, error = function(e) {
        cat("❌ [data_ingest] Generation failed:", e$message, "\n")
        shinyjs::hide("loading_spinner")
        output$gen_status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Generation Failed — ", e$message)
        })
        showNotification(paste("Generation failed:", e$message), type = "error", duration = 15)
      })
    })
    
    # ── Preview generated text ─────────────────────────────────────────────────
    output$generated_text_preview <- renderText({
      txt <- generated_text()
      if (nchar(txt) == 0) return("")
      substr(txt, 1, 500)   # Show first 500 chars as preview
    })
    
    # ── Parse & upload directly ────────────────────────────────────────────────
    observeEvent(input$parse_upload_btn, {
      txt <- generated_text()
      if (nchar(txt) == 0) {
        showNotification("Nothing generated yet", type = "warning"); return()
      }
      tryCatch({
        df <- parse_structured_text(txt)
        api_manager$bq_insert(df)
        showNotification(sprintf("Uploaded %d rows to BigQuery!", nrow(df)), type = "message")
      }, error = function(e) {
        showNotification(paste("Upload failed:", e$message), type = "error")
      })
    })
    
    # ── Copy to bulk paste area ────────────────────────────────────────────────
    observeEvent(input$copy_to_bulk_btn, {
      txt <- generated_text()
      if (nchar(txt) == 0) {
        showNotification("Nothing generated yet", type = "warning"); return()
      }
      api_manager$set_pending_text(txt)
      updateTabItems(session$rootScope(), "sidebar_menu", selected = "data_ingest")
      showNotification("Copied to Bulk Import", type = "message")
    })
    
    # ── Bulk parse ─────────────────────────────────────────────────────────────
    observeEvent(input$parse_btn, {
      txt <- trimws(input$bulk_text)
      if (nchar(txt) == 0) {
        output$bulk_status <- renderUI({
          tags$div(class = "status-error", "Paste some text first")
        })
        return()
      }
      
      output$bulk_status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"), " Parsing...")
      })
      
      tryCatch({
        df <- parse_structured_text(txt)
        parsed_data(df)
        output$bulk_status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Parsed %d rows — review below then click Upload", nrow(df)))
        })
      }, error = function(e) {
        parsed_data(NULL)
        output$bulk_status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Parse error: ", e$message)
        })
      })
    })
    
    output$parsed_preview <- DT::renderDT({
      df <- parsed_data()
      req(!is.null(df))
      DT::datatable(df, options = list(scrollX = TRUE, pageLength = 5),
                    rownames = FALSE)
    })
    
    # ── Upload parsed data ─────────────────────────────────────────────────────
    observeEvent(input$upload_btn, {
      df <- parsed_data()
      if (is.null(df)) {
        showNotification("Parse the text first", type = "warning"); return()
      }
      if (!api_manager$bq_authenticated) {
        showNotification("BigQuery not connected", type = "error"); return()
      }
      tryCatch({
        api_manager$bq_insert(df)
        parsed_data(NULL)
        output$bulk_status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Uploaded %d rows!", nrow(df)))
        })
      }, error = function(e) {
        output$bulk_status <- renderUI({
          tags$div(class = "status-error", " Upload failed: ", e$message)
        })
      })
    })
    
    observeEvent(input$clear_btn, {
      updateTextAreaInput(session, "bulk_text", value = "")
      parsed_data(NULL)
      output$bulk_status <- renderUI({ tags$div() })
    })
    
    output$gen_status  <- renderUI({ tags$div() })
    output$bulk_status <- renderUI({ tags$div() })
  })
}
