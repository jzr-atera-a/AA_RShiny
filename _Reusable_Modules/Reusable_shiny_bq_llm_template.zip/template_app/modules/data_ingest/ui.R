# modules/data_ingest/ui.R
# ▶ TEMPLATE: this module handles both AI generation and manual bulk-paste.
#   Adapt the form fields to your domain.

data_ingest_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    
    # ── Section 1: AI Generation ───────────────────────────────────────────────
    fluidRow(
      box(title = "Generate via LLM", status = "primary",
          solidHeader = TRUE, width = 12, collapsible = TRUE,
          
          p("Fill in the details below and click Generate to have the LLM produce structured content."),
          
          fluidRow(
            column(6,
              # ▶ TEMPLATE: replace "Title" / "Author" with your domain's primary identifiers
              textInput(ns("item_title"),  "Title:",  placeholder = "e.g., My Subject"),
              textInput(ns("item_author"), "Author/Creator:", placeholder = "e.g., Author Name"),
              checkboxInput(ns("include_optional"),
                            "Include formulas and numeric metrics",
                            value = FALSE),
              p(class = "text-muted", style = "font-size: 0.85em; margin-top: -8px;",
                "Leave unchecked for content where formulas or metrics don't apply.")
            ),
            column(6,
              # Category/Subcategory cascade (populated from BigQuery)
              category_subcategory_ui(ns)
            )
          ),
          
          fluidRow(
            column(12,
              actionButton(ns("generate_btn"), "Generate Content",
                           class = "btn-success btn-lg", icon = icon("robot"),
                           style = "width: 100%;"),
              br(), br(),
              div(id = ns("loading_spinner"), style = "display:none; text-align:center;",
                  tags$i(class = "fa fa-spinner fa-spin fa-2x"),
                  tags$span(" Generating — this may take 1–3 minutes...", style = "margin-left: 10px;")),
              uiOutput(ns("gen_status"))
            )
          ),
          
          conditionalPanel(
            condition = sprintf("input['%s'] > 0", ns("generate_btn")),
            br(),
            fluidRow(
              column(6,
                actionButton(ns("parse_upload_btn"), "Parse & Upload to BigQuery",
                             class = "btn-primary", icon = icon("cloud-upload-alt"))
              ),
              column(6,
                actionButton(ns("copy_to_bulk_btn"), "Copy to Bulk Import",
                             class = "btn-default", icon = icon("copy"))
              )
            ),
            br(),
            verbatimTextOutput(ns("generated_text_preview"))
          )
      )
    ),
    
    # ── Section 2: Bulk Paste & Parse ─────────────────────────────────────────
    fluidRow(
      box(title = "Bulk Paste & Parse", status = "warning",
          solidHeader = TRUE, width = 12, collapsible = TRUE, collapsed = TRUE,
          
          p("Paste pre-formatted structured text (from the LLM or another source) and parse it into rows."),
          p(class = "text-muted",
            "Expected format: 4-line header ([Title], [Author], [Category], [Subcategory]) ",
            "followed by item entries. See TEMPLATE_GUIDE.md for the full format spec."),
          
          textAreaInput(ns("bulk_text"), NULL, height = "300px",
                        placeholder = "[My Title]\n[Author Name]\n[Category]\n[Subcategory]\n\n[chapter_or_item]: Item 01: First Item\n[section]: All Sections\n[main_content]: Content goes here..."),
          
          fluidRow(
            column(4, actionButton(ns("parse_btn"), "Parse",
                                   class = "btn-info btn-lg", icon = icon("cogs"),
                                   style = "width: 100%;")),
            column(4, actionButton(ns("upload_btn"), "Upload to BigQuery",
                                   class = "btn-success btn-lg", icon = icon("cloud-upload-alt"),
                                   style = "width: 100%;")),
            column(4, actionButton(ns("clear_btn"), "Clear",
                                   class = "btn-danger", icon = icon("trash"),
                                   style = "width: 100%;"))
          ),
          
          br(),
          uiOutput(ns("bulk_status")),
          br(),
          DT::DTOutput(ns("parsed_preview"))
      )
    )
  )
}
