# modules/bigquery_auth/ui.R

bigquery_auth_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      box(title = "BigQuery Authentication", status = "primary",
          solidHeader = TRUE, width = 12,
          
          p("Upload your Google Cloud service account JSON key to connect to BigQuery."),
          p(class = "text-muted",
            "💡 For production deployments, store the JSON as an environment variable ",
            "on shinyapps.io instead of requiring upload. See TEMPLATE_GUIDE.md."),
          
          fluidRow(
            column(6,
              fileInput(ns("json_file"), "Service Account JSON Key:",
                        accept = ".json", placeholder = "No file selected"),
              
              # ▶ TEMPLATE: pre-fill with your project defaults
              textInput(ns("project_id"), "GCP Project ID:",
                        value = BQ_PROJECT, placeholder = "your-gcp-project-id"),
              textInput(ns("dataset_id"), "Dataset Name:",
                        value = BQ_DATASET, placeholder = "your_dataset"),
              textInput(ns("table_id"), "Table Name:",
                        value = BQ_TABLE,   placeholder = "your_table")
            ),
            column(6,
              tags$div(style = "margin-top: 25px;",
                actionButton(ns("test_connection"), "Test Connection",
                             class = "btn-primary btn-lg", icon = icon("plug"),
                             style = "width: 100%; margin-bottom: 10px;"),
                actionButton(ns("save_credentials"), "Save Credentials",
                             class = "btn-success btn-lg", icon = icon("save"),
                             style = "width: 100%;")
              ),
              tags$br(),
              uiOutput(ns("status"))
            )
          )
      )
    )
  )
}
