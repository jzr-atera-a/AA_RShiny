# modules/bigquery_auth/server.R

bigquery_auth_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    observeEvent(input$test_connection, {
      req(input$json_file)
      
      output$status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"), " Connecting...")
      })
      
      tryCatch({
        bigrquery::bq_auth(path = input$json_file$datapath)
        api_manager$set_bq_credentials(
          input$project_id, input$dataset_id, input$table_id
        )
        row_count <- api_manager$test_bq_connection()
        
        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Connected — %s rows in table", format(row_count, big.mark = ",")))
        })
        showNotification("BigQuery connected!", type = "message")
        
      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Connection failed: ", e$message)
        })
      })
    })
    
    observeEvent(input$save_credentials, {
      req(input$json_file)
      tryCatch({
        bigrquery::bq_auth(path = input$json_file$datapath)
        api_manager$set_bq_credentials(
          input$project_id, input$dataset_id, input$table_id
        )
        api_manager$bq_authenticated <- TRUE
        showNotification("Credentials saved!", type = "message")
      }, error = function(e) {
        showNotification(paste("Error:", e$message), type = "error")
      })
    })
    
    output$status <- renderUI({ tags$div() })
  })
}
