# modules/visualizations/server.R

visualizations_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    ns       <- session$ns
    viz_data <- reactiveVal(NULL)
    
    # ── Taxonomy cascade: Category → Subcategory → Item ───────────────────────
    viz_taxonomy <- reactive({
      api_manager$state_trigger()
      if (!api_manager$bq_authenticated) return(
        data.frame(category=character(), subcategory=character(),
                   title=character(), author=character(), stringsAsFactors=FALSE)
      )
      tryCatch(api_manager$bq_get_taxonomy(), error = function(e) {
        data.frame(category=character(), subcategory=character(),
                   title=character(), author=character(), stringsAsFactors=FALSE)
      })
    })
    
    observeEvent(viz_taxonomy(), {
      tax   <- viz_taxonomy()
      cats  <- sort(unique(tax$category[nchar(trimws(tax$category)) > 0]))
      cur   <- isolate(input$viz_category)
      sel   <- if (!is.null(cur) && cur %in% cats) cur else if (length(cats)) cats[1] else ""
      updateSelectInput(session, "viz_category",
                        choices = if (length(cats)) setNames(cats,cats) else c("(no data)"=""),
                        selected = sel)
    }, ignoreNULL = FALSE)
    
    observeEvent(input$viz_category, {
      tax  <- viz_taxonomy()
      subs <- sort(unique(tax$subcategory[
        tax$category == input$viz_category & nchar(trimws(tax$subcategory)) > 0]))
      updateSelectInput(session, "viz_subcategory",
                        choices = if (length(subs)) setNames(subs,subs) else c("(none)"=""))
    }, ignoreInit = TRUE)
    
    observeEvent(input$viz_subcategory, {
      tax  <- viz_taxonomy()
      sub  <- tax[tax$category == input$viz_category &
                    tax$subcategory == input$viz_subcategory, ]
      sub  <- unique(sub[, c("title","author")])
      if (nrow(sub) == 0) {
        updateSelectInput(session, "viz_item", choices = c("(no items)"="")); return()
      }
      labels  <- paste0(sub$title, " — ", sub$author)
      updateSelectInput(session, "viz_item", choices = setNames(sub$title, labels))
    }, ignoreInit = TRUE)
    
    # ── Load visualisation data ────────────────────────────────────────────────
    observeEvent(input$load_viz, {
      req(nchar(input$viz_item %||% "") > 0, input$viz_item != "(no items)")
      
      output$status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"), " Loading data...")
      })
      
      safe_item <- safe_sql_escape(input$viz_item)
      
      tryCatch({
        # ▶ TEMPLATE: adapt WHERE clause to your schema's identifier columns
        base_query <- sprintf(
          "SELECT * FROM `%s` WHERE title = '%s' ORDER BY chapter_or_item",
          api_manager$bq_full_table_id, safe_item
        )
        
        data <- api_manager$bq_query(base_query)
        
        if (nrow(data) == 0) {
          output$status <- renderUI({
            tags$div(class = "status-warning", "No data found for this item")
          })
          return()
        }
        
        # Section filter update
        sections <- unique(data$section[nchar(trimws(data$section)) > 0])
        updateSelectInput(session, "viz_section",
                          choices = c("All" = "all", setNames(sections, sections)))
        
        viz_data(data)
        
        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Loaded %d entries", nrow(data)))
        })
        
        # ── Value boxes ──────────────────────────────────────────────────────
        output$vbox_total <- renderValueBox({
          valueBox(nrow(data), "Total Entries", icon = icon("list"), color = "blue")
        })
        output$vbox_sections <- renderValueBox({
          valueBox(length(unique(data$section)), "Sections",
                   icon = icon("bookmark"), color = "green")
        })
        
        # Average numeric metric (skip N/A rows)
        avg_num <- tryCatch({
          nums <- unlist(lapply(data$numeric_data, function(x) {
            if (!has_real_value(x)) return(NULL)
            suppressWarnings(as.numeric(unlist(strsplit(as.character(x), ","))))
          }))
          if (length(nums) == 0) NA else round(mean(nums, na.rm = TRUE), 1)
        }, error = function(e) NA)
        
        output$vbox_avg <- renderValueBox({
          if (is.na(avg_num))
            valueBox("N/A", "Avg Metric", icon = icon("chart-line"), color = "light-blue")
          else
            valueBox(avg_num, "Avg Metric", icon = icon("chart-line"), color = "yellow")
        })
        
        output$vbox_date <- renderValueBox({
          d <- tryCatch(as.Date(substr(data$created_at[1], 1, 10)), error = function(e) NA)
          valueBox(if (is.na(d)) "—" else format(d, "%d %b %Y"),
                   "First Added", icon = icon("calendar"), color = "purple")
        })
        
        # ── Item header card ─────────────────────────────────────────────────
        output$item_header <- renderUI({
          HTML(sprintf(
            '<div class="item-header-card">
               <h2>%s</h2>
               <p class="item-meta">
                 <span class="meta-badge">%s</span>
                 <span class="meta-badge">%s</span>
                 <span class="meta-badge secondary">%s</span>
               </p>
             </div>',
            htmltools::htmlEscape(data$title[1]),
            htmltools::htmlEscape(data$author[1]),
            htmltools::htmlEscape(data$category[1]),
            htmltools::htmlEscape(data$subcategory[1])
          ))
        })
        
        # ── Rich content cards ───────────────────────────────────────────────
        output$content_cards <- renderUI({
          d    <- viz_data()
          req(!is.null(d))
          
          # Apply section filter
          if (!is.null(input$viz_section) && input$viz_section != "all") {
            d <- d[d$section == input$viz_section, ]
          }
          
          items    <- unique(d$chapter_or_item)
          parts    <- c()
          
          for (item_name in items) {
            item_data <- d[d$chapter_or_item == item_name, ]
            
            parts <- c(parts, sprintf('<div class="viz-card">'))
            parts <- c(parts, sprintf(
              '<div class="chapter-title"><i class="fa fa-bookmark"></i> %s</div>',
              htmltools::htmlEscape(item_name)
            ))
            
            for (i in seq_len(nrow(item_data))) {
              row <- item_data[i, ]
              
              # Section tag
              parts <- c(parts, sprintf(
                '<div class="section-tag">%s</div>',
                htmltools::htmlEscape(as.character(row$section))
              ))
              
              # Main content
              parts <- c(parts, sprintf(
                '<div class="details-text">%s</div>',
                htmltools::htmlEscape(as.character(row$main_content))
              ))
              
              # Formula (only if has real value)
              if (has_real_value(row$formula)) {
                parts <- c(parts, '<div class="formula-box">')
                parts <- c(parts, '<h5><i class="fa fa-calculator"></i> Formula:</h5>')
                parts <- c(parts, sprintf(
                  '<div class="formula-display">%s</div>',
                  as.character(row$formula)    # LaTeX rendered by MathJax
                ))
                if (has_real_value(row$formula_explanation)) {
                  parts <- c(parts, sprintf(
                    '<p class="formula-note">%s</p>',
                    htmltools::htmlEscape(as.character(row$formula_explanation))
                  ))
                }
                parts <- c(parts, '</div>')
              }
              
              # Reference link
              if (has_real_value(row$reference_url)) {
                parts <- c(parts, '<div class="reference-box">')
                parts <- c(parts, '<h5><i class="fa fa-link"></i> Reference:</h5>')
                parts <- c(parts, sprintf(
                  '<a href="%s" target="_blank">%s <i class="fa fa-external-link-alt"></i></a>',
                  htmltools::htmlEscape(as.character(row$reference_url)),
                  htmltools::htmlEscape(as.character(row$reference_url))
                ))
                if (has_real_value(row$reference_description)) {
                  parts <- c(parts, sprintf(
                    '<p style="margin-top:6px; color:#555;">%s</p>',
                    htmltools::htmlEscape(as.character(row$reference_description))
                  ))
                }
                parts <- c(parts, '</div>')
              }
              
              # Numeric metrics bar
              if (has_real_value(row$numeric_data)) {
                nums <- suppressWarnings(
                  as.numeric(unlist(strsplit(as.character(row$numeric_data), ",")))
                )
                if (length(nums) > 0) {
                  # Label extraction
                  labels <- if (has_real_value(row$numeric_data_description)) {
                    raw <- as.character(row$numeric_data_description)
                    lbls <- trimws(unlist(strsplit(raw, ",")))
                    lbls <- sub("\\s*\\(.*\\)$", "", lbls)  # strip (value) suffix
                    lbls
                  } else paste("Metric", seq_along(nums))
                  
                  parts <- c(parts, '<div class="metrics-row">')
                  for (j in seq_along(nums)) {
                    lbl <- if (j <= length(labels)) labels[j] else paste("M", j)
                    parts <- c(parts, sprintf(
                      '<div class="metric-box">
                         <div class="metric-label">%s</div>
                         <div class="metric-value">%s</div>
                         <div class="metric-bar"><div class="metric-bar-fill" style="width:%s%%"></div></div>
                       </div>',
                      htmltools::htmlEscape(lbl),
                      nums[j],
                      min(nums[j], 100)
                    ))
                  }
                  parts <- c(parts, '</div>')
                }
              }
              
              # Separator between sections of same item
              if (i < nrow(item_data)) {
                parts <- c(parts, '<hr class="section-divider">')
              }
            }
            
            parts <- c(parts, '</div>')  # close viz-card
          }
          
          # Trigger MathJax re-render after DOM update
          parts <- c(parts,
            '<script>if(typeof MathJax!=="undefined"){MathJax.Hub.Queue(["Typeset",MathJax.Hub]);}</script>'
          )
          
          HTML(paste(parts, collapse = ""))
        })
        
        # ── Conditional numeric chart section ────────────────────────────────
        has_nums <- any(sapply(data$numeric_data, has_real_value))
        
        output$numeric_chart_section <- renderUI({
          if (!has_nums) return(NULL)
          fluidRow(
            box(title = "Numeric Metrics Across Entries", status = "warning",
                solidHeader = TRUE, width = 12, collapsible = TRUE,
                plotly::plotlyOutput(ns("numeric_chart"), height = "450px"))
          )
        })
        
        output$numeric_chart <- plotly::renderPlotly({
          d <- viz_data(); req(!is.null(d))
          
          chart_rows <- list()
          for (i in seq_len(nrow(d))) {
            row <- d[i, ]
            if (!has_real_value(row$numeric_data)) next
            nums <- suppressWarnings(
              as.numeric(unlist(strsplit(as.character(row$numeric_data), ",")))
            )
            
            labels <- if (has_real_value(row$numeric_data_description)) {
              raw  <- as.character(row$numeric_data_description)
              lbls <- trimws(unlist(strsplit(raw, ",")))
              sub("\\s*\\(.*\\)$", "", lbls)
            } else paste("Metric", seq_along(nums))
            
            for (j in seq_along(nums)) {
              chart_rows[[length(chart_rows)+1]] <- data.frame(
                entry  = paste0("E", i),
                metric = if (j <= length(labels)) labels[j] else paste("M",j),
                value  = nums[j],
                stringsAsFactors = FALSE
              )
            }
          }
          
          if (length(chart_rows) == 0) {
            return(plotly::plot_ly() %>% plotly::layout(title = "No numeric data"))
          }
          
          chart_df <- do.call(rbind, chart_rows)
          plotly::plot_ly(chart_df, x = ~entry, y = ~value, color = ~metric,
                          type = "scatter", mode = "lines+markers") %>%
            plotly::layout(
              title  = "Numeric Metrics",
              xaxis  = list(title = "Entry"),
              yaxis  = list(title = "Value (0–100)")
            )
        })
        
      }, error = function(e) {
        cat("❌ [visualizations] Error:", e$message, "\n")
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Error: ", e$message)
        })
      })
    })
    
    # ── Defaults before any item is loaded ────────────────────────────────────
    output$status              <- renderUI({ tags$div() })
    output$item_header         <- renderUI({ tags$div() })
    output$content_cards       <- renderUI({ tags$div() })
    output$numeric_chart_section <- renderUI({ tags$div() })
    output$numeric_chart       <- plotly::renderPlotly({ plotly::plot_ly() })
    output$vbox_total    <- renderValueBox(valueBox("—","Total Entries",icon=icon("list"),    color="blue"))
    output$vbox_sections <- renderValueBox(valueBox("—","Sections",    icon=icon("bookmark"),color="green"))
    output$vbox_avg      <- renderValueBox(valueBox("—","Avg Metric",  icon=icon("chart-line"),color="yellow"))
    output$vbox_date     <- renderValueBox(valueBox("—","First Added", icon=icon("calendar"),color="purple"))
  })
}
