# modules/visualizations/ui.R
# ▶ TEMPLATE: this tab shows rich cards + an optional chart.
#   The viz-card CSS class provides the white-card-with-teal-border styling.
#   See www/css/global.css for the full style definitions.

visualizations_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    
    # ── Selector row ──────────────────────────────────────────────────────────
    fluidRow(
      box(title = "Select Data to Visualise", status = "primary",
          solidHeader = TRUE, width = 12,
          
          p("Use the cascade to filter down to the item you want, then click Load."),
          
          fluidRow(
            column(3, selectInput(ns("viz_category"),    "Category:",    choices = NULL)),
            column(3, selectInput(ns("viz_subcategory"), "Subcategory:", choices = NULL)),
            column(3, selectInput(ns("viz_item"),        "Item:",        choices = NULL)),
            column(3, selectInput(ns("viz_section"),     "Section Filter:",
                                  choices = c("All" = "all")))
          ),
          fluidRow(
            column(12,
              actionButton(ns("load_viz"), "Load Visualisation",
                           class = "btn-success btn-lg", icon = icon("chart-bar"),
                           style = "width: 100%;")
            )
          ),
          br(),
          uiOutput(ns("status"))
      )
    ),
    
    # ── Overview value boxes ───────────────────────────────────────────────────
    fluidRow(
      box(title = "Overview", status = "info",
          solidHeader = TRUE, width = 12, collapsible = TRUE,
          htmlOutput(ns("item_header")),
          fluidRow(
            column(3, valueBoxOutput(ns("vbox_total"),   width = 12)),
            column(3, valueBoxOutput(ns("vbox_sections"),width = 12)),
            column(3, valueBoxOutput(ns("vbox_avg"),     width = 12)),
            column(3, valueBoxOutput(ns("vbox_date"),    width = 12))
          )
      )
    ),
    
    # ── Rich content cards ─────────────────────────────────────────────────────
    fluidRow(
      box(title = "Content Breakdown", status = "success",
          solidHeader = TRUE, width = 12, collapsible = TRUE,
          htmlOutput(ns("content_cards"))
      )
    ),
    
    # ── Optional numeric chart (only shown when data has numeric_data) ─────────
    uiOutput(ns("numeric_chart_section"))
  )
}
