# =============================================================================
# global.R — App-wide initialisation
# =============================================================================
# This file runs ONCE when the app starts. It:
#   1. Loads all required packages (literal library() calls required for
#      rsconnect/shinyapps.io static dependency detection)
#   2. Sources shared utility files
#   3. Creates the single shared APIManager R6 instance
#
# ⚠️  MULTI-USER NOTE: api_manager is shared across all sessions.
#     For multi-user deployments, move `api_manager <- APIManager$new()`
#     inside server() in app.R so each session is isolated.
# =============================================================================

# ── Core framework ────────────────────────────────────────────────────────────
suppressPackageStartupMessages({
  library(shiny)
  library(shinydashboard)
  library(R6)
  library(yaml)
  library(purrr)
})

# ── DEPLOYMENT: explicit declarations for rsconnect dependency scanner ────────
# rsconnect can only detect packages referenced as literal library() calls or
# pkg::fn() references. Dynamic loading (library(pkg, character.only=TRUE))
# is invisible to it, so shinyapps.io silently skips those packages.
# Every package used anywhere in the app must appear here.
suppressPackageStartupMessages({
  library(shinyjs)
  library(httr)
  library(jsonlite)
  library(bigrquery)
  library(DT)
  library(plotly)
  library(dplyr)
  library(stringr)
  library(tidyr)
})

# ── Null-coalescing operator ───────────────────────────────────────────────────
`%||%` <- function(a, b) if (!is.null(a) && length(a) > 0 && !is.na(a[1])) a else b

# ── Source shared utilities ────────────────────────────────────────────────────
source("R/utils_api.R")
source("R/utils_common.R")

# ── Initialise shared API manager ─────────────────────────────────────────────
# Holds all credentials and provides BigQuery + LLM methods used by every module
if (exists("api_manager")) rm(api_manager)
api_manager <- APIManager$new()

cat("\n╔══════════════════════════════════════╗\n")
cat("║  SHINY TEMPLATE APP - STARTING       ║\n")
cat("╚══════════════════════════════════════╝\n\n")

# ── Build the dashboard UI (sourced once here so modules can reference it) ────
ui <- dashboardPage(
  skin = "blue",
  
  dashboardHeader(
    title = span(icon("database"), "DataApp Template"),
    titleWidth = 260
  ),
  
  dashboardSidebar(
    width = 260,
    sidebarMenu(
      id = "sidebar_menu",
      menuItem("BigQuery Auth",     tabName = "bigquery_auth",  icon = icon("key")),
      menuItem("LLM API Config",    tabName = "llm_config",     icon = icon("robot")),
      menuItem("Ingest Data",       tabName = "data_ingest",    icon = icon("cloud-upload-alt")),
      menuItem("Browse Records",    tabName = "browse_data",    icon = icon("table")),
      menuItem("Visualisations",    tabName = "visualizations", icon = icon("chart-bar")),
      menuItem("About",             tabName = "about",          icon = icon("info-circle"))
    )
  ),
  
  dashboardBody(
    # shinyjs MUST be called here — required for show()/hide() in modules
    shinyjs::useShinyjs(),
    
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "css/global.css"),
      tags$meta(charset = "UTF-8"),
      # MathJax for LaTeX formula rendering
      tags$script(src = "https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-AMS-MML_HTMLorMML"),
      tags$script(HTML("
        if (typeof MathJax !== 'undefined') {
          MathJax.Hub.Config({
            tex2jax: {
              inlineMath: [['$','$'], ['\\\\(','\\\\)']],
              displayMath: [['$$','$$'], ['\\\\[','\\\\]']],
              processEscapes: true
            }
          });
        }
      "))
    ),
    
    tabItems(
      tabItem("bigquery_auth",  bigquery_auth_ui("bigquery_auth")),
      tabItem("llm_config",     llm_config_ui("llm_config")),
      tabItem("data_ingest",    data_ingest_ui("data_ingest")),
      tabItem("browse_data",    browse_data_ui("browse_data")),
      tabItem("visualizations", visualizations_ui("visualizations")),
      tabItem("about",          about_ui("about"))
    )
  )
)
