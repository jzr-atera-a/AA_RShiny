# =============================================================================
# app.R — Entry point
# =============================================================================
# Sources all modules then wires the server. The UI is defined in global.R
# so all module UI functions are available when it runs.
# =============================================================================

# ── Source modules ─────────────────────────────────────────────────────────────
source("global.R")
source("modules/bigquery_auth/ui.R")
source("modules/bigquery_auth/server.R")
source("modules/llm_config/ui.R")
source("modules/llm_config/server.R")
source("modules/data_ingest/ui.R")
source("modules/data_ingest/server.R")
source("modules/browse_data/ui.R")
source("modules/browse_data/server.R")
source("modules/visualizations/ui.R")
source("modules/visualizations/server.R")
source("modules/about/ui.R")
source("modules/about/server.R")

# ── Server ─────────────────────────────────────────────────────────────────────
server <- function(input, output, session) {
  bigquery_auth_server("bigquery_auth",  api_manager)
  llm_config_server(   "llm_config",     api_manager)
  data_ingest_server(  "data_ingest",    api_manager)
  browse_data_server(  "browse_data",    api_manager)
  visualizations_server("visualizations", api_manager)
  about_server(        "about",          api_manager)
}

shinyApp(ui = ui, server = server)
