-- =============================================================================
-- BigQuery Table Schema Template
-- =============================================================================
-- Run this in BigQuery Console (or via bq CLI) to create the table.
-- ▶ TEMPLATE: replace `your-project.your_dataset.your_table` with your IDs.
--   Rename/add/remove columns to match your domain.
-- =============================================================================

CREATE TABLE IF NOT EXISTS `your-project.your_dataset.your_table` (
  -- Auto-assigned by bq_insert() at upload time
  id                        INT64,
  created_at                STRING,

  -- Primary identifiers (▶ rename to match your domain)
  title                     STRING,
  author                    STRING,

  -- Hierarchical classification (drives cascade dropdowns)
  category                  STRING,   -- top level   e.g. "Business"
  subcategory               STRING,   -- second level e.g. "Entrepreneurship"

  -- Item-level fields (one row per item/chapter/event/etc.)
  chapter_or_item           STRING,   -- e.g. "Chapter 01: Introduction"
  section                   STRING,   -- e.g. "All Sections"
  main_content              STRING,   -- 100-200 word body text

  -- Optional enrichment fields (stored as "N/A" when not applicable)
  formula                   STRING,   -- LaTeX string e.g. "$$E = mc^2$$"
  formula_explanation       STRING,
  reference_url             STRING,
  reference_description     STRING,
  numeric_data              STRING,   -- comma-separated e.g. "75,90,60,80,85,70"
  numeric_data_description  STRING    -- labels e.g. "Difficulty (75), Importance (90), ..."
);

-- =============================================================================
-- Useful queries for development / debugging
-- =============================================================================

-- Count rows
-- SELECT COUNT(*) FROM `your-project.your_dataset.your_table`;

-- Distinct taxonomy
-- SELECT DISTINCT category, subcategory, title, author
-- FROM `your-project.your_dataset.your_table`
-- ORDER BY category, subcategory, title;

-- Latest 20 rows
-- SELECT * FROM `your-project.your_dataset.your_table`
-- ORDER BY created_at DESC LIMIT 20;

-- All rows for a specific item (note: BigQuery uses \' not '' for apostrophes)
-- SELECT * FROM `your-project.your_dataset.your_table`
-- WHERE title = 'My Title'
-- ORDER BY chapter_or_item;
