# ============================================================================
# MI BIBLIOTECA DE APUNTES - SERVER
# ============================================================================

parte_tesis_choices <- function(tm) {
  caps <- tm$chapters()
  c("Ninguna en particular" = "",
    "Introducción" = "Introducción",
    if (length(caps)) setNames(sprintf("Capítulo %d. %s", seq_along(caps), vapply(caps, function(c) c$titulo %||% "", "")),
                               sprintf("Capítulo %d. %s", seq_along(caps), vapply(caps, function(c) c$titulo %||% "", ""))),
    "Conclusiones" = "Conclusiones", "Bibliografía" = "Bibliografía")
}

# One apunte as a card (like the viz-card chapter cards of the Book Summary suite)
lib_card <- function(r, ns, lib = NULL) {
  tags_v <- trimws(strsplit(r$etiquetas, ",")[[1]]); tags_v <- tags_v[nzchar(tags_v)]
  div(class = paste("lib-card", if (r$importante) "star", if (r$aplicado) "done"),
      div(class = "lib-card-head",
          span(class = "lib-card-title", if (r$importante) "⭐ ", r$titulo),
          span(class = "fb-time", fmt_fecha(r$creado))),
      div(class = "lib-card-meta",
          span(class = "fb-tag", names(LIB_TIPOS)[LIB_TIPOS == r$tipo] %||% r$tipo),
          if (nzchar(r$parte_tesis)) span(class = "fb-tag green", "Para: ", r$parte_tesis),
          if (r$aplicado) span(class = "fb-tag grey", "✔ Ya lo apliqué"),
          lapply(tags_v, function(t) span(class = "special-tag", t))),
      div(class = "fb-body", md_html(r$contenido)),
      if (nzchar(r$para_tesis)) div(class = "info-box-tpl lib-para", tags$b("Para mi tesis: "), r$para_tesis),
      if (!is.null(lib) && nzchar(r$refs)) refs_box(lib$get_refs(r$refs)),
      if (nzchar(r$fuente) || nzchar(r$url)) div(class = "reference-box lib-ref",
          if (nzchar(r$fuente)) div(icon("book"), " ", r$fuente),
          if (nzchar(r$url) && grepl("^https?://", r$url)) div(icon("link"), " ", tags$a(href = r$url, target = "_blank", r$url))),
      if (nzchar(r$nota)) div(class = "fb-q", tags$b("Mi nota: "), r$nota),
      div(class = "fb-actions",
          js_btn(if (r$importante) " Quitar ⭐" else " Importante", ns("cardEvt"), r$id, "star", if (r$importante) "btn-default" else "btn-warning", icon_name = "star"),
          js_btn(if (r$aplicado) " Marcar como pendiente" else " Ya lo apliqué", ns("cardEvt"), r$id, "done", "btn-default", icon_name = "check"),
          js_btn(" Editar / mover", ns("cardEvt"), r$id, "edit", "btn-primary", icon_name = "edit"),
          js_btn("", ns("cardEvt"), r$id, "delete", "btn-default", title = "Borrar", icon_name = "trash")))
}

# Preview list (with check boxes) of parsed apuntes before saving
lib_preview_ui <- function(ns, df, input_id, save_id, lib = NULL) {
  temas <- unique(df$tema)
  tagList(
    div(class = "places-ok", sprintf("✔ Se encontraron %d apuntes para “%s › %s”. Desmarque los que no quiera guardar.",
                                    nrow(df), df$categoria[1], if (length(temas) > 1) sprintf("%d temas", length(temas)) else temas)),
    checkboxGroupInput(ns(input_id), NULL, width = "100%", selected = as.character(seq_len(nrow(df))),
      choiceNames = lapply(seq_len(nrow(df)), function(i) div(class = "lib-prev",
        div(class = "lib-prev-top", if (length(temas) > 1) span(class = "fb-tag green", df$tema[i]), span(class = "fb-tag", df$topico[i]), tags$b(" ", df$titulo[i])),
        div(class = "lib-prev-text", df$contenido[i]),
        if (nzchar(df$para_tesis[i])) div(class = "wm-hint", tags$b("Para mi tesis: "), df$para_tesis[i]),
        if (!is.null(lib) && "refs" %in% names(df) && nzchar(df$refs[i])) {
          rr <- lib$get_refs(df$refs[i]); lapply(seq_len(nrow(rr)), function(k) ref_line(rr[k, ], compact = TRUE))
        } else if (nzchar(df$fuente[i])) div(class = "wm-hint", icon("book"), " ", df$fuente[i]) else div(class = "ref-line bad", span(class = "ref-badge bad", "Sin fuente")))),
      choiceValues = as.character(seq_len(nrow(df)))),
    actionButton(ns(save_id), "Guardar los marcados en mi biblioteca", class = "btn-success btn-big", icon = icon("save"), style = "width: 100%;"))
}

biblioteca_server <- function(id, tm, parent_session) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    lib <- function() tm$lib
    setup_common(input, parent_session)

    gen_tax <- setup_lib_cascade(input, session, tm, "gen_", levels = 2)
    add_tax <- setup_lib_cascade(input, session, tm, "add_", levels = 3)
    imp_tax <- setup_lib_cascade(input, session, tm, "imp_", levels = 2)
    setup_lib_cascade(input, session, tm, "ed_", levels = 3)

    ref_choices <- function() { rf <- lib()$refs; setNames(rf$id, paste(ifelse(rf$estado == "sin_verificar", "⚠", "✔"), rf$clave, substr(rf$titulo, 1, 60))) }

    # ============================================================ 1. EXPLORE
    want <- reactiveVal(NULL)   # filters requested by a click in the index

    observe({
      tm$lib_trigger(); w <- want()
      cats <- sort(unique(lib()$rows$categoria))
      cur <- isolate(input$ex_cat)
      sel <- if (!is.null(w)) w$cat else if (!is.null(cur) && cur %in% cats) cur else LIB_ALL
      updateSelectInput(session, "ex_cat", choices = c("Todas" = LIB_ALL, setNames(cats, cats)), selected = sel)
    })
    observe({
      tm$lib_trigger(); w <- want()
      cat <- input$ex_cat %||% LIB_ALL
      temas <- if (cat == LIB_ALL) character() else lib()$temas(cat)
      cur <- isolate(input$ex_tema)
      sel <- if (!is.null(w) && w$tema %in% temas) w$tema else if (!is.null(cur) && cur %in% temas) cur else LIB_ALL
      updateSelectInput(session, "ex_tema", choices = c("Todos" = LIB_ALL, setNames(temas, temas)), selected = sel)
    })
    observe({
      tm$lib_trigger(); w <- want()
      cat <- input$ex_cat %||% LIB_ALL; tema <- input$ex_tema %||% LIB_ALL
      tops <- if (cat == LIB_ALL || tema == LIB_ALL) character() else lib()$topicos(cat, tema)
      cur <- isolate(input$ex_top)
      sel <- if (!is.null(w) && w$top %in% tops) w$top else if (!is.null(cur) && cur %in% tops) cur else LIB_ALL
      updateSelectInput(session, "ex_top", choices = c("Todos" = LIB_ALL, setNames(tops, tops)), selected = sel)
    })
    observe({   # release the request once the three selects show it
      w <- want(); req(!is.null(w))
      if (identical(input$ex_cat, w$cat) && identical(input$ex_tema, w$tema) && identical(input$ex_top, w$top)) want(NULL)
    })
    observe({
      tm$lib_trigger()
      tg <- lib()$all_tags(); cur <- isolate(input$ex_tag)
      updateSelectInput(session, "ex_tag", choices = c("Todas" = "", setNames(tg, tg)), selected = if (!is.null(cur) && cur %in% tg) cur else "")
      updateSelectizeInput(session, "addTags", choices = tg, selected = isolate(input$addTags))
      updateSelectizeInput(session, "addRefs", choices = ref_choices(), selected = isolate(input$addRefs))
    })

    observeEvent(input$showAll, {
      want(list(cat = LIB_ALL, tema = LIB_ALL, top = LIB_ALL))
      updateTextInput(session, "q", value = ""); updateCheckboxInput(session, "onlyStar", value = FALSE)
    })
    observeEvent(input$treeEvt, {
      p <- strsplit(input$treeEvt$id, "||", fixed = TRUE)[[1]]
      want(list(cat = p[1], tema = p[2] %||% LIB_ALL, top = p[3] %||% LIB_ALL))
    })

    output$tree <- renderUI({
      tm$lib_trigger()
      tax <- lib()$taxonomy()
      if (!nrow(tax)) return(div(class = "empty-state small", "Todavía no hay apuntes. Empiece en “2. Pedir apuntes a Claude” o “3. Agregar un apunte”."))
      tagList(lapply(unique(tax$categoria), function(cat) {
        tc <- tax[tax$categoria == cat, ]
        tags$details(class = "lib-tree-cat", open = NA,
          tags$summary(span("📂 ", cat), span(class = "lib-count", sum(tc$n))),
          js_btn(" Ver toda la categoría", ns("treeEvt"), cat, "go", "btn-link lib-tree-link"),
          lapply(unique(tc$tema), function(tema) {
            tt <- tc[tc$tema == tema, ]
            tags$details(class = "lib-tree-tema", open = NA,
              tags$summary(span("📁 ", tema), span(class = "lib-count", sum(tt$n))),
              lapply(seq_len(nrow(tt)), function(i)
                js_btn(tagList("📄 ", tt$topico[i], span(class = "lib-count", tt$n[i])), ns("treeEvt"),
                       paste(cat, tema, tt$topico[i], sep = "||"), "go", "lib-tree-top")))
          }))
      }))
    })

    shown <- reactive({
      tm$lib_trigger()
      lib()$filter(input$ex_cat %||% LIB_ALL, input$ex_tema %||% LIB_ALL, input$ex_top %||% LIB_ALL,
                   q = input$q, solo_importantes = input$onlyStar, ocultar_aplicados = input$hideDone,
                   etiqueta = input$ex_tag %||% "", tipo = input$ex_tipo %||% "")
    })

    output$cards <- renderUI({
      r <- shown()
      if (!nrow(r)) return(tagList(div(class = "empty-state", if (nrow(lib()$rows)) "Ningún apunte coincide con la búsqueda." else "Su biblioteca está vacía todavía."), uiOutput(ns("thesisHits"))))
      out <- list()
      for (cat in unique(r$categoria)) {
        rc <- r[r$categoria == cat, ]
        for (tema in unique(rc$tema)) {
          rt <- rc[rc$tema == tema, ]
          out[[length(out) + 1]] <- div(class = "lib-group",
            div(class = "lib-group-title", icon("folder-open"), sprintf(" %s › %s", cat, tema), span(class = "lib-count", nrow(rt))),
            lapply(unique(rt$topico), function(top) {
              rp <- rt[rt$topico == top, ]
              div(class = "lib-topic", div(class = "lib-topic-title", "📄 ", top),
                  lapply(seq_len(nrow(rp)), function(i) lib_card(rp[i, ], ns, lib())))
            }))
        }
      }
      tagList(div(class = "wm-hint", sprintf("Mostrando %d apunte(s).", nrow(r))), out, uiOutput(ns("thesisHits")))
    })

    output$stats <- renderUI({
      tm$lib_trigger()
      r <- lib()$rows
      div(class = "stat-row",
          stat_tile("Apuntes", fmt_int(nrow(r)), sprintf("⭐ %d importantes · ✔ %d aplicados", sum(r$importante), sum(r$aplicado)), "green"),
          stat_tile("Categorías", length(unique(r$categoria)), "Los cajones con apuntes", "purple"),
          stat_tile("Temas", nrow(unique(r[, c("categoria", "tema")])), "Las carpetas", "orange"),
          stat_tile("Tópicos", nrow(unique(r[, c("categoria", "tema", "topico")])), "Las hojas", ""))
    })

    # ---------------------------------------------------- card actions + edit modal
    editing <- reactiveVal(NULL)
    observeEvent(input$cardEvt, {
      e <- input$cardEvt; r <- lib()$get(e$id); if (!nrow(r)) return()
      if (e$action == "star") lib()$update(e$id, importante = !r$importante)
      else if (e$action == "done") lib()$update(e$id, aplicado = !r$aplicado)
      else if (e$action == "delete") {
        editing(e$id)
        showModal(modalDialog(title = "¿Borrar este apunte?", p(tags$b(r$titulo)),
          p("Se borra de la biblioteca y su archivo. Si solo ya lo usó, mejor márquelo con “Ya lo apliqué”."),
          footer = tagList(modalButton("Cancelar"), actionButton(ns("delOk"), "Sí, borrar", class = "btn-danger")), easyClose = TRUE))
      } else if (e$action == "edit") {
        editing(e$id)
        tg <- lib()$all_tags(); sel_tags <- trimws(strsplit(r$etiquetas, ",")[[1]])
        showModal(modalDialog(title = "Editar o mover el apunte", size = "l", easyClose = TRUE,
          fluidRow(
            column(5, lib_cascade_ui(ns, "ed_", 3, lib(), list(categoria = r$categoria, tema = r$tema, topico = r$topico)),
                   selectInput(ns("edTipo"), "Origen:", choices = LIB_TIPOS, selected = r$tipo, width = "100%"),
                   selectInput(ns("edParte"), "Para qué parte de la tesis:", choices = unique(c(parte_tesis_choices(tm), r$parte_tesis)), selected = r$parte_tesis, width = "100%"),
                   selectizeInput(ns("edTags"), "Etiquetas:", choices = unique(c(tg, sel_tags[nzchar(sel_tags)])), selected = sel_tags[nzchar(sel_tags)],
                                  multiple = TRUE, width = "100%", options = list(create = TRUE)),
                   checkboxInput(ns("edStar"), "⭐ Importante", r$importante),
                   checkboxInput(ns("edDone"), "✔ Ya lo apliqué", r$aplicado)),
            column(7, textInput(ns("edTitulo"), "Título:", value = r$titulo, width = "100%"),
                   textAreaInput(ns("edContenido"), "Apunte:", value = r$contenido, rows = 9, width = "100%"),
                   textAreaInput(ns("edParaTesis"), "Para mi tesis:", value = r$para_tesis, rows = 2, width = "100%"),
                   selectizeInput(ns("edRefs"), "Referencias:", choices = ref_choices(), selected = lib()$split_ids(r$refs), multiple = TRUE, width = "100%"),
                   textAreaInput(ns("edNota"), "Mi nota:", value = r$nota, rows = 2, width = "100%"))),
          footer = tagList(modalButton("Cancelar"), actionButton(ns("edSave"), "Guardar cambios", class = "btn-success", icon = icon("save")))))
      }
    })
    observeEvent(input$delOk, { removeModal(); lib()$delete(editing()); showNotification("Apunte borrado", type = "message") })
    observeEvent(input$edSave, {
      t <- read_lib_cascade(input, "ed_")
      if (!nzchar(t$categoria) || !nzchar(t$tema) || !nzchar(t$topico)) { showNotification("Falta categoría, tema o tópico.", type = "warning"); return() }
      if (!nzchar(trimws(input$edTitulo))) { showNotification("Falta el título.", type = "warning"); return() }
      lib()$update(editing(), categoria = t$categoria, tema = t$tema, topico = t$topico, titulo = trimws(input$edTitulo),
                   contenido = input$edContenido, para_tesis = trimws(input$edParaTesis),
                   refs = paste(input$edRefs %||% character(), collapse = ", "), nota = trimws(input$edNota), tipo = input$edTipo, parte_tesis = input$edParte %||% "",
                   etiquetas = paste(input$edTags %||% character(), collapse = ", "),
                   importante = isTRUE(input$edStar), aplicado = isTRUE(input$edDone))
      removeModal(); showNotification("✔ Apunte guardado", type = "message")
    })

    view_name <- function(ext) paste0("Mis_apuntes_", format(Sys.time(), "%Y%m%d_%H%M"), ext)
    output$dlViewMd <- downloadHandler(view_name(".md"), function(file) write_utf8(lib()$to_markdown(shown()), file))
    output$dlViewDocx <- downloadHandler(view_name(".docx"), function(file) {
      if (is.null(export_docx(lib()$to_markdown(shown()), file))) write_utf8(lib()$to_markdown(shown()), file)
    })

    # ============================================================ 2. GENERATE (Claude)
    gen_df <- reactiveVal(NULL)
    gen_ctx <- reactiveVal(NULL)     # categoria, tema and the n -> reference id map of the last answer
    parse_gen <- function(text) {
      g <- gen_ctx(); if (is.null(g)) return()
      df <- tryCatch(parse_apuntes_text(text, g$categoria, g$tema), error = function(e) { showNotification(conditionMessage(e), type = "error", duration = 8); NULL })
      if (!is.null(df)) {
        # "[refs]: 1, 3" -> ids of the references registered (and verified) for this answer
        df$refs <- vapply(df$refs_n, function(x) {
          n <- regmatches(x, gregexpr("\\d+", x))[[1]]
          paste(unique(unlist(g$map[n])), collapse = ", ")
        }, character(1))
        df$fuente <- ""
      }
      gen_df(df)
    }
    run_generation <- function(tipo, peticion, categoria, tema, n = 5, libro = "", autor = "") {
      prompt <- prompt_library(tipo, peticion, categoria, tema, n, libro, autor)
      fb <- run_claude(session, tm, function() tm$ask(prompt, tab = "biblioteca", key = "biblioteca", action = "library",
                                                      title = paste("Apuntes:", tema), store = FALSE,
                                                      max_tokens = max(tm$claude$max_tokens, 8000)),
                       message = "Claude está buscando fuentes y preparando sus apuntes…")
      if (is.null(fb)) return(FALSE)
      gen_ctx(list(categoria = categoria, tema = tema, map = fb$ref_map))
      txt <- overwrite_lib_header(fb$messages[[2]]$content, categoria, tema)
      updateTextAreaInput(session, "genRaw", value = txt)
      parse_gen(txt)
      if (isTRUE(fb$search_unavailable)) showNotification("La búsqueda web no está activada en la cuenta de Claude: las fuentes se comprobaron solo en catálogos.", type = "warning", duration = 10)
      TRUE
    }
    observeEvent(input$generate, {
      t <- gen_tax()
      marco <- input$genTipo == "marco"
      if (marco) t <- list(categoria = LIB_MARCO, tema = "General")
      if (!nzchar(t$categoria) || !nzchar(t$tema)) { showNotification("Elija o escriba la categoría y el tema.", type = "warning"); return() }
      if (input$genTipo == "libro" && !nzchar(trimws(input$genLibro))) { showNotification("Escriba el título del libro.", type = "warning"); return() }
      if (!input$genTipo %in% c("libro", "marco") && !nzchar(trimws(input$genPeticion))) { showNotification("Describa qué quiere aprender.", type = "warning"); return() }
      run_generation(input$genTipo, trimws(input$genPeticion), t$categoria, t$tema, input$genN, trimws(input$genLibro), trimws(input$genAutor))
    })
    observeEvent(input$genReparse, parse_gen(input$genRaw))
    output$genPreview <- renderUI({
      df <- gen_df(); tm$lib_trigger()
      if (is.null(df)) return(div(class = "empty-state small", "Aquí aparecerán los apuntes de Claude, con sus fuentes ya comprobadas, para que los revise antes de guardarlos."))
      lib_preview_ui(ns, df, "genPick", "genSave", lib())
    })
    observeEvent(input$genSave, {
      df <- gen_df(); pick <- as.integer(input$genPick %||% character())
      if (!length(pick)) { showNotification("No hay apuntes marcados.", type = "warning"); return() }
      df <- df[pick, , drop = FALSE]; df$tipo <- "claude"
      lib()$add(df)
      gen_df(NULL); updateTextAreaInput(session, "genRaw", value = "")
      want(list(cat = df$categoria[1], tema = if (length(unique(df$tema)) > 1) LIB_ALL else df$tema[1], top = LIB_ALL))
      updateTabsetPanel(session, "subtabs", selected = if (df$categoria[1] == LIB_MARCO) "marco" else "explorar")
      showNotification(sprintf("✔ %d apunte(s) guardados en %s › %s", nrow(df), df$categoria[1], df$tema[1]), type = "message", duration = 6)
    })

    # ============================================================ 3. ADD ONE
    output$addParteUI <- renderUI({
      tm$proj_trigger()
      selectInput(ns("addParte"), "¿Para qué parte de la tesis? (opcional)", choices = parte_tesis_choices(tm),
                  selected = isolate(input$addParte), width = "100%")
    })
    observeEvent(input$addSave, {
      t <- add_tax()
      if (!nzchar(t$categoria) || !nzchar(t$tema) || !nzchar(t$topico)) { showNotification("Elija o escriba la categoría, el tema y el tópico.", type = "warning"); return() }
      if (!nzchar(trimws(input$addTitulo)) || !nzchar(trimws(input$addContenido))) { showNotification("Escriba el título y el apunte.", type = "warning"); return() }
      lib()$add(data.frame(categoria = t$categoria, tema = t$tema, topico = t$topico, titulo = trimws(input$addTitulo),
                           contenido = input$addContenido, para_tesis = trimws(input$addParaTesis),
                           refs = paste(input$addRefs %||% character(), collapse = ", "), tipo = input$addTipo, parte_tesis = input$addParte %||% "",
                           etiquetas = paste(input$addTags %||% character(), collapse = ", "), importante = isTRUE(input$addStar),
                           stringsAsFactors = FALSE))
      updateTextInput(session, "addTitulo", value = ""); updateSelectizeInput(session, "addRefs", selected = character())
      for (f in c("addContenido", "addParaTesis")) updateTextAreaInput(session, f, value = "")
      updateCheckboxInput(session, "addStar", value = FALSE)
      showNotification(sprintf("✔ Guardado en %s › %s › %s", t$categoria, t$tema, t$topico), type = "message", duration = 6)
    })

    # ============================================================ 4. IMPORT
    imp_df <- reactiveVal(NULL)
    observeEvent(input$impParse, {
      t <- imp_tax()
      use <- isTRUE(input$impUseCascade)
      df <- tryCatch(parse_apuntes_text(input$impText, if (use) t$categoria else "", if (use) t$tema else ""),
                     error = function(e) { showNotification(conditionMessage(e), type = "error", duration = 8); NULL })
      if (!is.null(df) && isTRUE(attr(df, "missing_header"))) {
        if (!nzchar(t$categoria) || !nzchar(t$tema)) { showNotification("El texto no trae [Categoría] y [Tema]: elíjalos abajo.", type = "warning", duration = 8); return() }
        df$categoria[!nzchar(df$categoria)] <- t$categoria; df$tema[!nzchar(df$tema)] <- t$tema
      }
      imp_df(df)
    })
    observeEvent(input$impClear, { updateTextAreaInput(session, "impText", value = ""); imp_df(NULL) })
    output$impPreview <- renderUI({
      df <- imp_df()
      if (is.null(df)) return(div(class = "empty-state small", "Pegue el texto y presione “Leer el texto”."))
      lib_preview_ui(ns, df, "impPick", "impSave")
    })
    observeEvent(input$impSave, {
      df <- imp_df(); pick <- as.integer(input$impPick %||% character())
      if (!length(pick)) { showNotification("No hay apuntes marcados.", type = "warning"); return() }
      df <- df[pick, , drop = FALSE]; df$tipo <- "importado"
      lib()$add(df); imp_df(NULL)
      showNotification(sprintf("✔ %d apunte(s) importados", nrow(df)), type = "message")
    })

    # ============================================================ 5. TABLE
    tb_rows <- reactive({ tm$lib_trigger(); lib()$filter(q = input$tbQ) })
    output$tbInfo <- renderUI(div(class = "wm-hint", sprintf("%d apunte(s). La tabla completa también está en biblioteca.csv.", nrow(tb_rows()))))
    output$table <- renderTable({
      r <- tb_rows(); if (!nrow(r)) return(NULL)
      data.frame(Fecha = substr(r$creado, 1, 10), `Categoría` = r$categoria, Tema = r$tema, `Tópico` = r$topico,
                 `Título` = r$titulo, `⭐` = ifelse(r$importante, "⭐", ""), `✔` = ifelse(r$aplicado, "✔", ""),
                 Origen = names(LIB_TIPOS)[match(r$tipo, LIB_TIPOS)], Etiquetas = r$etiquetas, check.names = FALSE)
    }, striped = TRUE, hover = TRUE, width = "100%", na = "")
    output$dlCsv <- downloadHandler(function() paste0("biblioteca_", format(Sys.Date(), "%Y%m%d"), ".csv"), function(file) {
      con <- file(file, open = "wb"); on.exit(close(con)); writeBin(as.raw(c(0xEF, 0xBB, 0xBF)), con)
      utils::write.csv(lib()$rows[, setdiff(LIB_FIELDS, "archivo")], con, row.names = FALSE, fileEncoding = "UTF-8")
    })
    output$dlAllDocx <- downloadHandler(function() paste0("Mi_biblioteca_", format(Sys.Date(), "%Y%m%d"), ".docx"), function(file) {
      md <- lib()$to_markdown(lib()$filter(), "Mi biblioteca de apuntes")
      if (is.null(export_docx(md, file))) write_utf8(md, file)
    })
    observeEvent(input$openLib, {
      if (!open_in_file_manager(lib()$dir())) showNotification(paste("Ábrala desde el explorador:", lib()$dir()), type = "warning", duration = 10)
    })

    # ============================================================ 6. ABOUT
    output$libPath <- renderUI({ tm$lib_trigger(); div(tags$b("Carpeta: "), div(class = "folder-path", lib()$dir())) })
    observeEvent(input$rebuild, {
      showModal(modalDialog(title = "¿Reconstruir el índice?",
        p("La app volverá a leer todos los archivos .md de la carpeta de la biblioteca y rehará el índice (biblioteca.json, biblioteca.csv e INDICE.md)."),
        footer = tagList(modalButton("Cancelar"), actionButton(ns("rebuildOk"), "Sí, reconstruir", class = "btn-primary")), easyClose = TRUE))
    })
    observeEvent(input$rebuildOk, {
      removeModal()
      n <- lib()$rebuild_from_files()
      showNotification(sprintf("✔ Índice reconstruido: %d apuntes", n), type = "message", duration = 6)
    })

    # ============================================================ SEARCH ALSO INSIDE THE THESIS
    output$thesisHits <- renderUI({
      q <- trimws(input$q %||% ""); tm$proj_trigger()
      if (nchar(q) < 3) return(NULL)
      words <- strsplit(ref_norm(q), " ")[[1]]
      secs <- c(lapply(INTRO_PARTS, function(p) list(lab = paste("Introducción ›", p$titulo), tab = "introduccion", txt = tm$get_text(p$key))),
                lapply(seq_along(tm$chapters()), function(i) { c <- tm$chapters()[[i]]
                  list(lab = sprintf("Capítulo %d. %s", i, c$titulo), tab = "capitulos", txt = tm$get_text(tm$chapter_key(c$id))) }),
                lapply(CONCL_PARTS, function(p) list(lab = paste("Conclusiones ›", p$titulo), tab = "conclusion", txt = tm$get_text(p$key))),
                list(list(lab = "Bosquejo", tab = "bosquejo", txt = tm$outline_text())))
      hits <- Filter(function(s) nzchar(s$txt) && all(vapply(words, function(w) grepl(w, ref_norm(s$txt), fixed = TRUE), logical(1))), secs)
      if (!length(hits)) return(NULL)
      div(class = "lib-group",
          div(class = "lib-group-title", icon("file-alt"), " También aparece en mi tesis", span(class = "lib-count", length(hits))),
          lapply(hits, function(h) {
            pos <- regexpr(words[1], ref_norm(h$txt), fixed = TRUE)
            snip <- substr(h$txt, max(1, pos - 80), pos + 160)
            div(class = "version-row", tags$b(h$lab), div(class = "version-preview", "…", snip, "…"),
                js_btn(" Ir a esa parte", ns("goThesis"), h$tab, "go", "btn-default btn-sm", icon_name = "arrow-right"))
          }))
    })
    observeEvent(input$goThesis, go_to_tab(parent_session, input$goThesis$id))

    # ============================================================ 2. MARCO TEÓRICO
    marco_rows <- reactive({ tm$lib_trigger(); r <- lib()$rows; r[r$categoria == LIB_MARCO, , drop = FALSE] })
    marco_status <- function(r) {
      lapply(unique(r$tema), function(tema) {
        rt <- r[r$tema == tema, , drop = FALSE]
        rf <- lib()$get_refs(unique(unlist(lapply(rt$refs, lib()$split_ids))))
        ok <- sum(rf$estado %in% c("verificada", "manual")); bad <- sum(rf$estado == "sin_verificar")
        mine <- sum(rt$tipo == "propio" | nzchar(rt$nota))
        solid <- nrow(rt) >= 3 && ok >= 3 && bad == 0 && mine >= 1
        list(tema = tema, n = nrow(rt), mine = mine, ok = ok, bad = bad,
             light = if (solid) "🟢" else if (nrow(rt) >= 2 && ok >= 1) "🟡" else "🔴",
             falta = c(if (nrow(rt) < 3) sprintf("%d apunte(s) más", 3 - nrow(rt)), if (ok < 3) sprintf("%d fuente(s) verificada(s) más", 3 - ok),
                       if (bad > 0) sprintf("revisar %d fuente(s) ⚠", bad), if (mine < 1) "una nota suya"))
      })
    }
    output$mtBanner <- renderUI({
      tm$proj_trigger(); t <- tm$chosen(); o <- tm$outline()
      if (is.null(t) && !nzchar(o$pregunta %||% "")) return(div(class = "places-pending", icon("star"),
        " Para un marco teórico a su medida, primero elija su tema (Mis ideas y temas) y escriba su pregunta (Bosquejo)."))
      div(class = "suggest-banner", HTML(sprintf("⭐ <b>Mi tema:</b> %s%s", htmltools::htmlEscape(t$titulo %||% "(sin elegir)"),
          if (nzchar(o$pregunta %||% "")) paste0(" &nbsp;·&nbsp; <b>Mi pregunta:</b> ", htmltools::htmlEscape(o$pregunta)) else "")))
    })
    output$mtTable <- renderUI({
      r <- marco_rows()
      if (!nrow(r)) return(div(class = "empty-state small", HTML("Todavía no hay apuntes en la categoría <b>Marco teórico</b>.<br>Presione “1. Proponer el mapa de mi marco teórico”.")))
      st <- marco_status(r)
      tagList(lapply(st, function(s) div(class = "mt-row",
        div(class = "mt-light", s$light),
        div(class = "mt-body",
            div(class = "mt-tema", s$tema),
            div(class = "mt-nums", sprintf("%d apuntes · %d con nota mía · ✔ %d fuentes verificadas%s", s$n, s$mine, s$ok,
                                           if (s$bad) sprintf(" · ⚠ %d sin verificar", s$bad) else "")),
            if (length(s$falta)) div(class = "mt-falta", "Falta: ", paste(s$falta, collapse = "; "), ".") else div(class = "status-ok", "Sólido")),
        div(class = "mt-btns",
            js_btn(" Ver", ns("mtEvt"), s$tema, "see", "btn-default", icon_name = "eye"),
            js_btn(" Profundizar", ns("mtEvt"), s$tema, "more", "btn-primary", icon_name = "plus")))))
    })
    observeEvent(input$mtEvt, {
      tema <- input$mtEvt$id
      if (input$mtEvt$action == "see") {
        want(list(cat = LIB_MARCO, tema = tema, top = LIB_ALL)); updateTabsetPanel(session, "subtabs", selected = "explorar")
      } else {
        have <- paste(unique(marco_rows()$topico[marco_rows()$tema == tema]), collapse = "; ")
        ok <- run_generation("panorama", paste0(tema, " (para el marco teórico de mi tesis). Ya tengo estos tópicos, no los repitas: ", have,
                                                 ". Dame autores clave con sus obras, debates y aplicación a México."), LIB_MARCO, tema, 4)
        if (isTRUE(ok)) updateTabsetPanel(session, "subtabs", selected = "generar")
      }
    })
    observeEvent(input$mtMap, {
      if (is.null(tm$chosen()) && tm$outline_pct() == 0) { showNotification("Primero elija su tema o llene algo del bosquejo.", type = "warning", duration = 7); return() }
      ok <- run_generation("marco", "", LIB_MARCO, "General", 5)
      if (isTRUE(ok)) updateTabsetPanel(session, "subtabs", selected = "generar")
    })
    marco_digest <- function(verified_only = FALSE) {
      r <- marco_rows(); out <- character()
      for (tema in unique(r$tema)) {
        rt <- r[r$tema == tema, , drop = FALSE]
        out <- c(out, paste0("\n## TEMA: ", tema))
        for (i in seq_len(nrow(rt))) out <- c(out, sprintf("- [%s] %s: %s%s", rt$topico[i], rt$titulo[i], substr(gsub("\\s+", " ", rt$contenido[i]), 1, 500),
                                                           if (nzchar(rt$nota[i])) paste0(" | NOTA DE LA AUTORA: ", rt$nota[i]) else ""))
      }
      rf <- lib()$get_refs(unique(unlist(lapply(r$refs, lib()$split_ids))))
      if (verified_only) rf <- rf[rf$estado %in% c("verificada", "manual"), , drop = FALSE]
      c(out, "\n## FUENTES DE MI BIBLIOTECA",
        if (nrow(rf)) sprintf("- %s %s", ifelse(rf$estado == "sin_verificar", "[SIN VERIFICAR]", "[VERIFICADA]"), gsub("\\*", "", rf$harvard)) else "(ninguna)")
    }
    observeEvent(input$mtReview, {
      if (!nrow(marco_rows())) { showNotification("Todavía no hay apuntes de marco teórico.", type = "warning"); return() }
      prompt <- paste0("Revisa la solidez de mi MARCO TEÓRICO como lo haría un sinodal. Estos son mis apuntes y fuentes:\n",
                       clip_text(paste(marco_digest(), collapse = "\n"), 20000),
                       "\n\nDime: 1) si los conceptos responden a mi pregunta de investigación; 2) qué conceptos, autores u obras fundamentales FALTAN ",
                       "(búscalos en la web y cítalos); 3) debates o posturas contrarias que debo considerar; 4) cómo conectar las teorías que estudié en los 70 ",
                       "con los enfoques actuales; 5) qué fuentes marcadas [SIN VERIFICAR] debo comprobar o cambiar; 6) siguiente paso.")
      run_claude(session, tm, function() tm$ask(prompt, tab = "biblioteca", key = "marco", action = "marco", title = "Revisión de mi marco teórico",
                                                max_tokens = max(tm$claude$max_tokens, 6000)),
                 message = "Claude está revisando su marco teórico y buscando fuentes…")
    })
    observeEvent(input$mtDraft, {
      if (nrow(marco_rows()) < 3) { showNotification("Junte al menos 3 apuntes de marco teórico antes de redactar.", type = "warning", duration = 7); return() }
      prompt <- paste0("Con MIS apuntes, dame una GUÍA para redactar el marco teórico de mi tesis (no lo redactes por mí). ",
                       "Usa ÚNICAMENTE las fuentes marcadas [VERIFICADA] de la lista; no agregues ninguna otra fuente.\n",
                       clip_text(paste(marco_digest(verified_only = TRUE), collapse = "\n"), 20000),
                       "\n\nEntrega: 1) el orden de secciones y subtítulos; 2) para cada sección, qué apuntes usar, qué idea central defender y qué cita Harvard ",
                       "(de las verificadas) la sostiene; 3) las frases de enlace entre secciones; 4) un párrafo de EJEMPLO para la apertura, marcado como ejemplo; ",
                       "5) lo que todavía me falta leer o anotar antes de escribir.")
      run_claude(session, tm, function() tm$ask(prompt, tab = "biblioteca", key = "marco", action = "marco_draft", title = "Guía para redactar mi marco teórico",
                                                search = FALSE, max_tokens = max(tm$claude$max_tokens, 6000)),
                 message = "Claude está preparando la guía de redacción…")
    })
    feedback_panel_server(input, output, session, tm, tab = "biblioteca", keys_fun = reactive("marco"), output_id = "mtfb",
                          empty_msg = "Aquí aparecerán la revisión y la guía de Claude.")

    # ============================================================ 5. REFERENCES
    output$refStats <- renderUI({
      tm$lib_trigger(); rf <- lib()$refs
      ok <- sum(rf$estado %in% c("verificada", "manual")); bad <- sum(rf$estado == "sin_verificar")
      div(class = "stat-row",
          stat_tile("Referencias", nrow(rf), "En formato Harvard", "purple"),
          stat_tile("✔ Verificadas", ok, "Se pueden usar en la tesis", "green", if (nrow(rf)) 100 * ok / nrow(rf)),
          stat_tile("⚠ Sin verificar", bad, if (bad) "No usar hasta comprobarlas" else "¡Ninguna!", if (bad) "red" else "green"))
    })
    refs_shown <- reactive({
      tm$lib_trigger(); rf <- lib()$refs
      if (identical(input$refFilter, "ok")) rf <- rf[rf$estado %in% c("verificada", "manual"), , drop = FALSE]
      if (identical(input$refFilter, "bad")) rf <- rf[rf$estado == "sin_verificar", , drop = FALSE]
      q <- ref_norm(input$refQ %||% "")
      if (nzchar(q)) rf <- rf[grepl(q, ref_norm(paste(rf$harvard, rf$titulo)), fixed = TRUE), , drop = FALSE]
      rf[order(ref_norm(rf$harvard)), , drop = FALSE]
    })
    output$refList <- renderUI({
      rf <- refs_shown()
      if (!nrow(rf)) return(div(class = "empty-state small", if (nrow(lib()$refs)) "Ninguna referencia con ese filtro." else
        "Todavía no hay referencias. Aparecen solas cuando Claude cita una fuente, o agréguelas a la derecha."))
      tagList(lapply(seq_len(nrow(rf)), function(i) {
        r <- rf[i, ]; ok <- r$estado %in% c("verificada", "manual"); used <- lib()$refs_used_by(r$id)
        div(class = paste("ref-card", if (ok) "ok" else "bad"),
            ref_line(r),
            div(class = "ref-meta", span(class = "fb-tag", names(REF_TIPOS)[REF_TIPOS == r$tipo] %||% r$tipo),
                span(class = "wm-hint", sprintf(" Cita en el texto: %s · usada en %d apunte(s)", r$clave, used))),
            div(class = "fb-actions",
                if (!ok) js_btn(" Comprobar otra vez", ns("refEvt"), r$id, "check", "btn-primary btn-sm", icon_name = "sync"),
                if (!ok) js_btn(" La revisé yo: sí existe", ns("refEvt"), r$id, "manual", "btn-success btn-sm", icon_name = "check"),
                js_btn(" Editar", ns("refEvt"), r$id, "edit", "btn-default btn-sm", icon_name = "edit"),
                js_btn("", ns("refEvt"), r$id, "delete", "btn-default btn-sm", title = "Borrar", icon_name = "trash")))
      }))
    })
    ref_editing <- reactiveVal(NULL)
    observeEvent(input$refEvt, {
      e <- input$refEvt; r <- lib()$get_refs(e$id); if (!nrow(r)) return()
      if (e$action == "check") {
        withProgress(message = "Comprobando la fuente…", value = 0.5, lib()$update_ref(e$id, reverify = TRUE))
        r2 <- lib()$get_refs(e$id)
        showNotification(if (r2$estado == "verificada") paste("✔ Verificada en", r2$verificada_por) else "Sigue sin poder comprobarse.",
                         type = if (r2$estado == "verificada") "message" else "warning", duration = 6)
      } else if (e$action == "manual") {
        ref_editing(e$id)
        showModal(modalDialog(title = "¿Usted comprobó esta fuente?", div(class = "big-message", p(md_inline(r$harvard)),
          p("Márquela solo si tuvo el libro, artículo o documento en sus manos o lo encontró en una biblioteca, librería o sitio oficial.")),
          textInput(ns("manualWhere"), "¿Dónde la comprobó? (opcional)", width = "100%", placeholder = "p. ej. Biblioteca Clavigero, la tengo en casa…"),
          footer = tagList(modalButton("Cancelar"), actionButton(ns("manualOk"), "Sí, existe: marcarla ✔", class = "btn-success")), easyClose = TRUE))
      } else if (e$action == "edit") {
        ref_editing(e$id)
        showModal(modalDialog(title = "Editar referencia", size = "l", easyClose = TRUE,
          fluidRow(column(4, selectInput(ns("erTipo"), "Tipo:", choices = REF_TIPOS, selected = r$tipo, width = "100%")),
                   column(5, textInput(ns("erAutores"), "Autor(es):", value = r$autores, width = "100%")),
                   column(3, textInput(ns("erAnio"), "Año:", value = r$anio, width = "100%"))),
          textInput(ns("erTitulo"), "Título:", value = r$titulo, width = "100%"),
          textInput(ns("erContenedor"), "Revista o libro que lo contiene:", value = r$contenedor, width = "100%"),
          fluidRow(column(4, textInput(ns("erLugar"), "Ciudad:", value = r$lugar, width = "100%")),
                   column(4, textInput(ns("erEditorial"), "Editorial:", value = r$editorial, width = "100%")),
                   column(2, textInput(ns("erVolumen"), "Volumen:", value = r$volumen, width = "100%")),
                   column(2, textInput(ns("erPaginas"), "Páginas:", value = r$paginas, width = "100%"))),
          fluidRow(column(8, textInput(ns("erUrl"), "Enlace:", value = r$url, width = "100%")),
                   column(4, textInput(ns("erDoi"), "DOI:", value = r$doi, width = "100%"))),
          div(class = "wm-hint", "Al guardar, la app vuelve a comprobar la fuente con los datos corregidos."),
          footer = tagList(modalButton("Cancelar"), actionButton(ns("erSave"), "Guardar y comprobar", class = "btn-success"))))
      } else if (e$action == "delete") {
        ref_editing(e$id)
        showModal(modalDialog(title = "¿Borrar esta referencia?", p(md_inline(r$harvard)),
          p(sprintf("Está ligada a %d apunte(s); se quitará de ellos.", lib()$refs_used_by(r$id))),
          footer = tagList(modalButton("Cancelar"), actionButton(ns("refDelOk"), "Sí, borrar", class = "btn-danger")), easyClose = TRUE))
      }
    })
    observeEvent(input$manualOk, {
      removeModal()
      lib()$update_ref(ref_editing(), estado = "manual", verificada_por = "La autora",
                       detalle = paste("Comprobada por la autora.", trimws(input$manualWhere %||% "")), verificada_fecha = now_str())
      showNotification("✔ Marcada como revisada por usted", type = "message")
    })
    observeEvent(input$erSave, {
      removeModal()
      withProgress(message = "Comprobando la fuente…", value = 0.5,
        lib()$update_ref(ref_editing(), tipo = input$erTipo, autores = trimws(input$erAutores), anio = trimws(input$erAnio),
                         titulo = trimws(input$erTitulo), contenedor = trimws(input$erContenedor), lugar = trimws(input$erLugar),
                         editorial = trimws(input$erEditorial), volumen = trimws(input$erVolumen), paginas = trimws(input$erPaginas),
                         url = trimws(input$erUrl), doi = trimws(input$erDoi), reverify = TRUE))
      showNotification("✔ Referencia guardada", type = "message")
    })
    observeEvent(input$refDelOk, { removeModal(); lib()$delete_ref(ref_editing()) })
    observeEvent(input$nrSave, {
      if (!nzchar(trimws(input$nrTitulo))) { showNotification("Escriba al menos el título.", type = "warning"); return() }
      map <- withProgress(message = "Comprobando la fuente…", value = 0.5, lib()$register_refs(list(list(
        tipo = input$nrTipo, autores = input$nrAutores, anio = input$nrAnio, titulo = input$nrTitulo, contenedor = input$nrContenedor,
        editorial = input$nrEditorial, lugar = input$nrLugar, url = input$nrUrl))))
      r <- lib()$get_refs(unname(map))
      for (f in c("nrAutores", "nrAnio", "nrLugar", "nrTitulo", "nrContenedor", "nrEditorial", "nrUrl")) updateTextInput(session, f, value = "")
      showNotification(if (r$estado == "verificada") paste("✔ Guardada y verificada en", r$verificada_por) else
        "Guardada, pero no se pudo comprobar. Si usted la tiene, márquela con “La revisé yo”.", type = if (r$estado == "verificada") "message" else "warning", duration = 8)
    })
    observeEvent(input$refCheckAll, {
      bad <- lib()$refs$id[lib()$refs$estado == "sin_verificar"]
      if (!length(bad)) { showNotification("No hay referencias sin verificar.", type = "message"); return() }
      withProgress(message = "Comprobando las fuentes…", value = 0, {
        for (k in seq_along(bad)) { setProgress(k / length(bad), detail = sprintf("%d de %d", k, length(bad))); lib()$update_ref(bad[k], reverify = TRUE) }
      })
      showNotification(sprintf("Listo: quedan %d sin verificar.", sum(lib()$refs$estado == "sin_verificar")), type = "message", duration = 6)
    })
    observeEvent(input$refToThesis, {
      ok <- lib()$bibliography()
      if (!nrow(ok)) { showNotification("Todavía no hay referencias verificadas.", type = "warning"); return() }
      showModal(modalDialog(title = "Pasar las fuentes verificadas a la Bibliografía de la tesis",
        div(class = "big-message", p(sprintf("Se agregarán %d fuentes verificadas a “Conclusiones → 7. Bibliografía y fuentes”, en orden alfabético.", nrow(ok))),
            p("Lo que ya tenga escrito ahí se conserva (antes se guarda una versión). Las fuentes ⚠ sin verificar no se pasan.")),
        footer = tagList(modalButton("Cancelar"), actionButton(ns("refToThesisOk"), "Sí, pasarlas", class = "btn-success")), easyClose = TRUE))
    })
    observeEvent(input$refToThesisOk, {
      removeModal()
      new <- gsub("\\*", "", lib()$bibliography()$harvard)
      old <- trimws(strsplit(tm$get_text("concl_biblio"), "\n")[[1]]); old <- old[nzchar(old)]
      all <- c(old, new[!ref_norm(new) %in% ref_norm(old)])
      all <- all[order(ref_norm(all))]
      tm$snapshot("concl_biblio", "antes de pasar las referencias verificadas")
      tm$set_text("concl_biblio", paste(all, collapse = "\n\n"))
      bump(tm$load_trigger)
      showNotification(sprintf("✔ La bibliografía de la tesis tiene ahora %d fuentes.", length(all)), type = "message", duration = 6)
    })
    output$dlBib <- downloadHandler(function() paste0("Bibliografia_Harvard_", format(Sys.Date(), "%Y%m%d"), ".docx"), function(file) {
      md <- paste(c("# Bibliografía", "", paste0(lib()$bibliography()$harvard, "\n")), collapse = "\n")
      if (is.null(export_docx(md, file))) write_utf8(md, file)
    })
  })
}
