# ============================================================================
# MI BIBLIOTECA DE APUNTES - UI
# Same flow as the "Book Summary" suite (Generate → Bulk import → Add single →
# Browse → Visualizations → About), adapted to the elderly user and to local files.
# ============================================================================

biblioteca_ui <- function(id) {
  ns <- NS(id)
  div(
    class = "explorer-tabs",
    tabsetPanel(
      id = ns("subtabs"), type = "tabs", selected = "explorar",

      # ------------------------------------------------------------ 1. Explore (Visualizations)
      tabPanel(
        title = "1. Explorar mis apuntes", value = "explorar", icon = icon("folder-tree"),
        uiOutput(ns("stats")),
        fluidRow(
          column(4,
            box(title = tagList(icon("sitemap"), " Índice"), status = "primary", solidHeader = TRUE, width = NULL,
                p(class = "wm-hint", "Presione un tópico para ver sus apuntes."),
                actionButton(ns("showAll"), "Ver todos los apuntes", class = "btn-default", icon = icon("layer-group"), style = "width: 100%; margin-bottom: 10px;"),
                uiOutput(ns("tree")))),
          column(8,
            box(title = tagList(icon("search"), " Buscar y filtrar"), status = "primary", solidHeader = TRUE, width = NULL,
                fluidRow(
                  column(4, selectInput(ns("ex_cat"), "📂 Categoría:", choices = c("Todas" = LIB_ALL), width = "100%")),
                  column(4, selectInput(ns("ex_tema"), "📁 Tema:", choices = c("Todos" = LIB_ALL), width = "100%")),
                  column(4, selectInput(ns("ex_top"), "📄 Tópico:", choices = c("Todos" = LIB_ALL), width = "100%"))),
                fluidRow(
                  column(6, textInput(ns("q"), "Buscar palabras:", width = "100%", placeholder = "p. ej. municipio, Cosío Villegas, APA…")),
                  column(3, selectInput(ns("ex_tag"), "Etiqueta:", choices = c("Todas" = ""), width = "100%")),
                  column(3, selectInput(ns("ex_tipo"), "Origen:", choices = c("Todos" = "", LIB_TIPOS), width = "100%"))),
                div(class = "lib-checks",
                    checkboxInput(ns("onlyStar"), "⭐ Solo los importantes", FALSE),
                    checkboxInput(ns("hideDone"), "Ocultar los que ya apliqué ✔", FALSE)),
                div(class = "editor-buttons",
                    downloadButton(ns("dlViewDocx"), "Descargar lo que estoy viendo (Word)", class = "btn-success"),
                    downloadButton(ns("dlViewMd"), "… en texto (.md)", class = "btn-default"))),
            uiOutput(ns("cards"))))
      ),

      # ------------------------------------------------------------ 2. Theoretical framework
      tabPanel(
        title = "2. Mi marco teórico", value = "marco", icon = icon("landmark"),
        uiOutput(ns("mtBanner")),
        fluidRow(
          column(7,
            box(title = tagList(icon("clipboard-check"), " ¿Qué tan sólido está mi marco teórico?"), status = "primary", solidHeader = TRUE, width = NULL,
                p(class = "lead-text", "El marco teórico son los conceptos y autores con los que usted mira su problema. Aquí se arma con los apuntes de la categoría ",
                  tags$b("Marco teórico"), ": cada ", tags$b("tema"), " es un concepto o teoría."),
                uiOutput(ns("mtTable")),
                div(class = "reference-box",
                    tags$b("Un tema está sólido 🟢 cuando tiene:"),
                    tags$ul(class = "guide-list",
                            tags$li("al menos 3 apuntes (definición, autores, debate o aplicación a su caso);"),
                            tags$li("al menos 3 fuentes verificadas ✔ (ninguna sin verificar ⚠);"),
                            tags$li("al menos 1 nota suya: qué piensa usted y cómo lo usará."))))),
          column(5,
            box(title = tagList(icon("robot"), " Claude le ayuda"), status = "success", solidHeader = TRUE, width = NULL,
                div(class = "claude-actions",
                    actionButton(ns("mtMap"), "1. Proponer el mapa de mi marco teórico", class = "btn-primary btn-big", icon = icon("sitemap")),
                    actionButton(ns("mtReview"), "2. Revisar qué le falta", class = "btn-success btn-big", icon = icon("search")),
                    actionButton(ns("mtDraft"), "3. Guía para redactarlo con mis apuntes", class = "btn-default btn-big", icon = icon("pen"))),
                div(class = "wm-hint", "Claude busca en la web y cita en Harvard; la app comprueba cada fuente. Para redactar solo usa sus fuentes verificadas.")),
            box(title = "Comentarios de Claude", status = "info", solidHeader = TRUE, width = NULL, uiOutput(ns("mtfb")))))
      ),

      # ------------------------------------------------------------ 3. Ask Claude (Generate)
      tabPanel(
        title = "3. Pedir apuntes a Claude", value = "generar", icon = icon("robot"),
        fluidRow(
          column(5,
            box(title = tagList(icon("magic"), " ¿Qué quiere aprender u organizar?"), status = "primary", solidHeader = TRUE, width = NULL,
                radioButtons(ns("genTipo"), "Tipo de apuntes:", choices = LIB_GEN_TIPOS, selected = "concepto"),
                conditionalPanel(sprintf("input['%s'] == 'libro'", ns("genTipo")),
                  textInput(ns("genLibro"), "Título del libro:", width = "100%", placeholder = "p. ej. El sistema político mexicano"),
                  textInput(ns("genAutor"), "Autor:", width = "100%", placeholder = "p. ej. Daniel Cosío Villegas")),
                textAreaInput(ns("genPeticion"), "Describa con sus palabras:", rows = 3, width = "100%",
                              placeholder = "p. ej. El presidencialismo mexicano en los años 70"),
                sliderInput(ns("genN"), "¿Cuántos tópicos?", min = 3, max = 10, value = 5, step = 1, width = "100%"),
                tags$hr(),
                p(tags$b("¿Dónde se guardarán?"), " Elija o cree la categoría y el tema. Claude pondrá los tópicos."),
                lib_cascade_ui(ns, "gen_", levels = 2),
                actionButton(ns("generate"), "Pedir los apuntes a Claude", class = "btn-success btn-big", icon = icon("paper-plane"), style = "width: 100%;"))),
          column(7,
            box(title = tagList(icon("eye"), " Revise antes de guardar"), status = "success", solidHeader = TRUE, width = NULL,
                uiOutput(ns("genPreview")),
                tags$details(class = "fb-history",
                  tags$summary("Ver o corregir el texto que mandó Claude"),
                  textAreaInput(ns("genRaw"), NULL, rows = 12, width = "100%"),
                  actionButton(ns("genReparse"), "Volver a leer el texto", class = "btn-default", icon = icon("sync"))))))
      ),

      # ------------------------------------------------------------ 4. Add one
      tabPanel(
        title = "4. Agregar un apunte", value = "agregar", icon = icon("plus"),
        fluidRow(
          column(5,
            box(title = "¿Dónde va?", status = "primary", solidHeader = TRUE, width = NULL,
                lib_cascade_ui(ns, "add_", levels = 3),
                selectInput(ns("addTipo"), "Origen:", choices = LIB_TIPOS, selected = "lectura", width = "100%"),
                uiOutput(ns("addParteUI")),
                selectizeInput(ns("addTags"), "Etiquetas (opcional):", choices = NULL, multiple = TRUE, width = "100%",
                               options = list(create = TRUE, placeholder = "Escriba y presione Enter")),
                checkboxInput(ns("addStar"), "⭐ Marcar como importante", FALSE))),
          column(7,
            box(title = "El apunte", status = "primary", solidHeader = TRUE, width = NULL,
                textInput(ns("addTitulo"), "Título:", width = "100%"),
                textAreaInput(ns("addContenido"), "Apunte:", rows = 8, width = "100%",
                              placeholder = "Lo que leí, aprendí o pensé…"),
                textAreaInput(ns("addParaTesis"), "¿Cómo lo puedo usar en mi tesis? (opcional)", rows = 2, width = "100%"),
                selectizeInput(ns("addRefs"), "Fuente(s) de mi lista de referencias:", choices = NULL, multiple = TRUE, width = "100%",
                               options = list(placeholder = "Elija la referencia; si no está, agréguela en la pestaña 5. Referencias")),
                actionButton(ns("addSave"), "Guardar en mi biblioteca", class = "btn-success btn-big", icon = icon("save"), style = "width: 100%;"))))
      ),

      # ------------------------------------------------------------ 5. References
      tabPanel(
        title = "5. Referencias", value = "refs", icon = icon("bookmark"),
        uiOutput(ns("refStats")),
        fluidRow(
          column(8,
            box(title = tagList(icon("bookmark"), " Mis referencias (formato Harvard)"), status = "primary", solidHeader = TRUE, width = NULL,
                fluidRow(
                  column(5, radioButtons(ns("refFilter"), NULL, inline = TRUE, selected = "all",
                                         choices = c("Todas" = "all", "✔ Verificadas" = "ok", "⚠ Sin verificar" = "bad"))),
                  column(7, textInput(ns("refQ"), NULL, width = "100%", placeholder = "Buscar autor, título…"))),
                uiOutput(ns("refList")))),
          column(4,
            box(title = "Bibliografía para la tesis", status = "success", solidHeader = TRUE, width = NULL,
                p("Solo entran las fuentes ", tags$b("verificadas ✔"), ", en orden alfabético."),
                actionButton(ns("refToThesis"), "Pasarlas a la Bibliografía de mi tesis", class = "btn-success btn-big", icon = icon("arrow-right"), style = "width: 100%; white-space: normal;"),
                br(), br(),
                downloadButton(ns("dlBib"), "Descargar bibliografía (Word)", class = "btn-primary", style = "width: 100%;"),
                br(), br(),
                actionButton(ns("refCheckAll"), "Volver a comprobar las ⚠", class = "btn-default", icon = icon("sync"), style = "width: 100%;")),
            box(title = "Agregar una referencia mía", status = "primary", solidHeader = TRUE, width = NULL, collapsible = TRUE, collapsed = TRUE,
                selectInput(ns("nrTipo"), "Tipo:", choices = REF_TIPOS, width = "100%"),
                textInput(ns("nrAutores"), "Autor(es): Apellido, N.", width = "100%", placeholder = "Cosío Villegas, D."),
                fluidRow(column(4, textInput(ns("nrAnio"), "Año:", width = "100%")),
                         column(8, textInput(ns("nrLugar"), "Ciudad:", width = "100%"))),
                textInput(ns("nrTitulo"), "Título:", width = "100%"),
                textInput(ns("nrContenedor"), "Revista o libro que lo contiene:", width = "100%"),
                textInput(ns("nrEditorial"), "Editorial / institución:", width = "100%"),
                textInput(ns("nrUrl"), "Enlace (si es de internet):", width = "100%"),
                actionButton(ns("nrSave"), "Comprobar y guardar", class = "btn-success", icon = icon("check"), style = "width: 100%;")),
            box(title = "Cómo se comprueba una fuente", status = "info", solidHeader = TRUE, width = NULL, collapsible = TRUE,
                tags$ul(class = "guide-list",
                        tags$li(HTML("<b>Libros:</b> se buscan en Open Library, Google Books y Crossref (título y autor).")),
                        tags$li(HTML("<b>Artículos:</b> se buscan en Crossref (o por su DOI).")),
                        tags$li(HTML("<b>Páginas web:</b> el enlace debe venir de la búsqueda web de Claude, o abrir y coincidir con el título.")),
                        tags$li(HTML("<b>⚠ Sin verificar</b> no significa que sea falsa: significa que la app no la encontró. Búsquela usted (biblioteca, librería) y, si existe, márquela con “La revisé yo”.")),
                        tags$li("Aun verificada, lea la fuente antes de citarla: la app comprueba que existe, no lo que dice en cada página.")))))
      ),

      # ------------------------------------------------------------ 6. More: import, table, how it works
      tabPanel(
        title = "6. Más: tabla, importar y ayuda", value = "mas", icon = icon("ellipsis-h"),
        box(title = "Todos mis apuntes", status = "primary", solidHeader = TRUE, width = 12,
            fluidRow(
              column(6, textInput(ns("tbQ"), "Buscar:", width = "100%")),
              column(6, div(class = "editor-buttons", style = "margin-top: 26px;",
                            downloadButton(ns("dlCsv"), "Tabla (Excel .csv)", class = "btn-primary"),
                            downloadButton(ns("dlAllDocx"), "Todo en Word", class = "btn-success"),
                            actionButton(ns("openLib"), "Abrir la carpeta", class = "btn-default", icon = icon("folder-open"))))),
            uiOutput(ns("tbInfo")),
            div(class = "lib-table", tableOutput(ns("table")))),
        tags$h3(class = "lib-section", icon("file-import"), " Importar apuntes desde un texto"),
        fluidRow(
          column(6,
            box(title = "Pegue apuntes con el formato de corchetes", status = "primary", solidHeader = TRUE, width = NULL,
                div(class = "reference-box",
                    tags$b("Formato:"),
                    tags$pre(class = "lib-format", "[Categoría]\n[Tema]\n\n[topico]: …\n[titulo]: …\n[apunte]: …\n[fuente]: … o N/A\n[url]: … o N/A\n[para_mi_tesis]: …\n\n[topico]: … (siguiente apunte)")),
                textAreaInput(ns("impText"), NULL, rows = 14, width = "100%"),
                checkboxInput(ns("impUseCascade"), "Usar la categoría y el tema de abajo (en lugar de los del texto)", FALSE),
                lib_cascade_ui(ns, "imp_", levels = 2),
                fluidRow(
                  column(6, actionButton(ns("impParse"), "Leer el texto", class = "btn-primary btn-big", icon = icon("cogs"), style = "width: 100%;")),
                  column(6, actionButton(ns("impClear"), "Borrar el cuadro", class = "btn-default btn-big", icon = icon("eraser"), style = "width: 100%;"))))),
          column(6,
            box(title = "Vista previa", status = "success", solidHeader = TRUE, width = NULL, uiOutput(ns("impPreview"))))),
        tags$h3(class = "lib-section", icon("info-circle"), " Cómo funciona la biblioteca"),
        fluidRow(
          column(6,
            box(title = "Su biblioteca, como un archivero", status = "primary", solidHeader = TRUE, width = NULL,
                div(class = "lib-levels-explain",
                    div(class = "dimension-display", tags$b("📂 Categoría = el cajón"), br(), "Un área grande: Teoría política, Historia política de México, Mi tesis…"),
                    div(class = "dimension-display", tags$b("📁 Tema = la carpeta dentro del cajón"), br(), "p. ej. El Estado posrevolucionario."),
                    div(class = "dimension-display", tags$b("📄 Tópico = la hoja"), br(), "p. ej. El partido hegemónico 1946–1988."),
                    div(class = "dimension-display", tags$b("📝 Apunte"), br(), "Lo escrito en la hoja: texto, fuente, cómo usarlo en la tesis, ⭐ importante, ✔ ya lo apliqué, etiquetas y su nota.")),
                tags$ul(class = "guide-list",
                        tags$li(HTML("Los apuntes llegan de <b>Claude</b> (pestaña 3, o las respuestas de cualquier sección), de lo que usted <b>escribe</b> (pestaña 4 o el botón “📝 Anotar” de arriba) o de un <b>texto pegado</b>.")),
                        tags$li("Todo se guarda al momento en la carpeta de trabajo, en archivos que se pueden abrir sin la app.")))),
          column(6,
            box(title = "Dónde quedan los archivos", status = "info", solidHeader = TRUE, width = NULL,
                uiOutput(ns("libPath")),
                tags$pre(class = "lib-format", "biblioteca/\n  INDICE.md            ← índice con enlaces\n  biblioteca.json      ← índice completo (lo usa la app)\n  biblioteca.csv       ← la tabla para Excel\n  Teoría política/\n    El Estado/\n      Partido hegemónico/\n        2026-11-12_Título_123456.md"),
                p("Cada apunte es un archivo ", tags$code(".md"), " con sus datos al principio. Si el índice se perdiera, se puede reconstruir a partir de esos archivos:"),
                actionButton(ns("rebuild"), "Reconstruir el índice desde los archivos", class = "btn-default", icon = icon("tools"))))
        )
      )
    )
  )
}
