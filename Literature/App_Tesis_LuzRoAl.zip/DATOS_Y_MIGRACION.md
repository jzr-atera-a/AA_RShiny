# Mi Tesis — Datos guardados y cómo pasarlos a versiones nuevas

> Para la persona que administra la app **y para el chat de Claude que haga la siguiente versión**.
> Versión de la app que escribió este documento: **1.3.0** · formato de datos: **2**.

## 1. Dónde vive cada cosa

**Carpeta de la app → `data/`** (ajustes de esta computadora)

| Archivo | Contenido |
|---|---|
| `config.json` | Ajustes del administrador: carpeta de trabajo (`work_folder`), autor, modelo de Claude, búsqueda web, última pestaña (`last_tab`), destino de las respuestas por sección (`lib_dest`). |
| `.claude_key` | La clave de Claude (solo si se marcó “Recordar la clave”). **No compartir.** |
| `usage.json`, `app.log`, `lanzador.log` | Contadores y registros. |

**Carpeta de trabajo** (la elige el administrador; por defecto `data/mi_tesis/`) — **aquí está toda la tesis**

| Archivo / carpeta | Contenido |
|---|---|
| `proyecto.json` | Ideas, tema elegido, bosquejo, textos de la tesis (`sections`) y conversaciones con Claude (`feedback`). Campos `version` (formato) y `app_version`. |
| `biblioteca/biblioteca.json` | Todos los apuntes: `{formato_version, app_version, apuntes:[…]}`. |
| `biblioteca/referencias.json` | Todas las referencias: `{formato_version, app_version, referencias:[…]}`. |
| `biblioteca/<Categoría>/<Tema>/<Tópico>/*.md` | Un archivo por apunte, con sus datos al principio (YAML). El índice se puede reconstruir desde ellos. |
| `biblioteca/INDICE.md`, `biblioteca.csv`, `BIBLIOGRAFIA_HARVARD.md` | Copias legibles; se rehacen solas. |
| `textos/`, `retroalimentacion/`, `versiones/`, `respaldos/`, `exportar/` | Copias legibles, versiones, respaldos diarios y la tesis exportada. |

## 2. Cómo pasar los datos a una versión nueva (para el administrador)

Cualquiera de estas tres formas funciona; elija **una**:

1. **Encima (la más fácil).** Descomprima el ZIP de la versión nueva **sobre la carpeta de la versión anterior** y acepte reemplazar archivos. La carpeta `data/` no viene en el ZIP, así que nada de lo guardado se toca.
2. **Carpeta nueva + instalador.** Descomprima en una carpeta nueva y dé doble clic a `CREAR_ACCESO_DIRECTO.bat`: pregunta por la carpeta anterior y copia su `data/` completa.
3. **Desde la app.** En la versión nueva: **Administrador → Traer datos de una versión anterior** → elija la carpeta de la app anterior, su carpeta `data` o su carpeta de trabajo. La app muestra lo que encontró y ofrece:
   - **Sumar** (recomendado): agrega lo que falta y no borra nada. Los identificadores (`id`) se conservan, así que no se duplica aunque se repita. Si un texto existe en los dos lados, se conserva el de aquí y el importado queda en *Ver versiones anteriores*.
   - **Reemplazar**: usa los datos importados; antes hace un respaldo y renombra la biblioteca actual a `biblioteca_antes_de_importar_…`.

Antes de cualquier cambio: **Administrador → Hacer respaldo ahora**. Si la carpeta de trabajo está fuera de la app (por ejemplo en Documentos), basta con que la versión nueva apunte a la misma carpeta.

## 3. Reglas para quien programe la siguiente versión

Estas reglas son las que hacen que los datos viejos siempre abran:

1. **Nunca renombrar ni borrar un campo** de `proyecto.json`, `biblioteca.json` o `referencias.json`. Si un campo deja de usarse, se deja.
2. **Solo agregar campos, con valor por defecto.** Los apuntes se leen con `LibraryManager$normalize()` y las referencias con `normalize_refs()`: cualquier campo de `LIB_FIELDS` / `REF_FIELDS` que falte se rellena solo (`""` o `FALSE`). El proyecto se lee sobre `empty_project()`, que pone lo que falte.
3. **Si cambia el significado de un dato**, subir `PROJECT_FORMAT` (en `R/utils_thesis.R`) o `LIB_FORMAT` (en `R/utils_library.R`) y agregar el paso de conversión en `migrate_project()` (o en `normalize()`), del tipo `if (v < 3) { … }`. Nunca quitar los pasos anteriores.
4. **Los lectores aceptan todos los formatos anteriores.** `read_rows_file()` lee tanto el formato 1 (lista simple) como el 2 (objeto con `apuntes` / `referencias`). Si se crea un formato 3, este lector debe seguir leyendo 1 y 2.
5. **Los `id` no cambian nunca** (`ap…`, `ref…`, `fb…`, `idea…`, `c…`). Son lo que une apuntes ↔ referencias (`refs`), apuntes ↔ respuestas de Claude e ideas (`origen`), y capítulos ↔ sus textos (`sections$cap_<id>`).
6. **Subir `APP_VERSION`** en `global.R` en cada versión (se guarda en cada archivo y se muestra al importar).
7. **Probar la migración**: `scripts`/pruebas deben incluir abrir datos de la versión anterior e importarlos con “Sumar” dos veces (la segunda no debe agregar nada). La prueba actual crea datos con formato 1 y verifica ambas cosas.
8. `data/` **nunca va dentro del ZIP** que se entrega.

### Historial de formatos

| Formato | Versión de la app | Cambios |
|---|---|---|
| 1 | 1.0 – 1.2 | `proyecto.json` (`version: 1`); `biblioteca.json` como lista simple de apuntes. |
| 2 | 1.3.0 | `biblioteca.json` y `referencias.json` como objetos con `formato_version`; apuntes con el campo nuevo `refs` (ids de referencias); respuestas de Claude con `refs`, `ref_map`, `searches`; `config.json` con `web_search`, `max_searches`, `last_tab`, `lib_dest`. |

## 4. Referencias: qué significa cada estado

| Estado | Significado | ¿Va a la bibliografía de la tesis? |
|---|---|---|
| `verificada` | La app encontró la fuente fuera de Claude: Crossref (DOI o artículo), Open Library / Google Books (libro), el enlace salió de la búsqueda web de Claude, o el enlace abre y su título coincide. Se guarda dónde (`verificada_por`, `evidencia`). | Sí |
| `manual` | La autora la comprobó (“La revisé yo”). | Sí |
| `sin_verificar` | La app no la encontró. Puede existir, pero no debe usarse hasta comprobarla. | No |

La app comprueba que la fuente **existe**; no comprueba lo que dice en cada página. Antes de citar, hay que leer la fuente.
