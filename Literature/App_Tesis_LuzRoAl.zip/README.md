# 📘 Mi Tesis — Ciencias Políticas y Administración Pública (IBERO) · R Shiny, modular

An app that guides an elderly graduate of the IBERO's **Ciencias Políticas y Administración Pública** degree
(1979–80 study plan) step by step to write the thesis that completes the degree, with feedback from **Claude**.
The whole interface is in **Mexican Spanish** (usted form). This README stays in English for whoever maintains it.

Same modular architecture and purple look as the *Travel Photo Selector* (module registry + `ModuleLoader`,
one shared R6 manager, `www/css/global.css`, bundled easy-to-read fonts). The Claude connection follows the
`APIManager` of *Modular_db_books_llm* (httr POST to the Messages API, configurable model / max tokens / timeout,
friendly error messages), extended with a system prompt, multi-turn follow-ups and usage counters.

## Quick start
```r
setwd("path/to/App_Tesis_LuzRoAl")
source("install_packages.R", encoding = "UTF-8")   # once
shiny::runApp(launch.browser = TRUE)
```
1. **Conexión con Claude**: paste the API key (console.anthropic.com), press **Probar conexión**. Tick “Recordar la clave” to keep it on this computer (`data/.claude_key`), or set the environment variable `ANTHROPIC_API_KEY`.
2. **Administrador** (code **718**): choose the **work folder** (e.g. *Documentos/Mi tesis*), the author's name and generation.
3. The user follows the sidebar from top to bottom.

## Windows desktop app (no RStudio)
For a Windows 10/11 computer that **already has R** (the installer can add missing packages):
1. Unzip the app in its final folder (e.g. `C:\Mi Tesis`), or on top of the folder used with RStudio.
2. Double-click **`CREAR_ACCESO_DIRECTO.bat`** once (if Windows warns: *More info → Run anyway*). It:
   unblocks the files, picks the R that has all packages (`lanzador\ruta_R.txt`), offers to bring the saved
   `data\` from the folder used with RStudio (shows a summary: ideas, chapters, chosen topic, work folder), and
   creates the **Mi Tesis** icon on the desktop and in the Start menu.
3. Double-click the icon: a “Abriendo Mi Tesis…” notice, R starts hidden, the app opens in its own Edge/Chrome
   window (app mode). Double-clicking again while open just shows the window. **Closing the window stops R**
   (8 s grace so a page reload does not close it). `Abrir Mi Tesis.bat` is a backup of the icon.

Files: `iniciar_app.R` (desktop start, fixed port **7719** on 127.0.0.1, log in `data\lanzador.log`),
`lanzador\comun.ps1` (port, title, package list), `lanzador\abrir_app.ps1` (what the icon runs),
`lanzador\instalar_acceso_directo.ps1` (installer), `lanzador\mi_tesis.ico`.
`app.R` only stops itself when `APP_STANDALONE=1`, so RStudio works exactly as before.
If it does not open, send `data\lanzador.log`.

## Version 1.3.0 — one hierarchy, verified Harvard references, marco teórico, data migration
* **One hierarchy for everything** (Categoría › Tema › Tópico): Claude answers, the user's own notes (header button **📝 Anotar**, from any tab), ideas (synced automatically to *Mi tesis › Mis ideas y temas*) and library apuntes. The search box of *Explorar* also looks inside the thesis text.
* **References** (`R/utils_refs.R`): every Claude request that may use sources carries a system rule to cite in **Harvard** and to end with a machine-readable `<referencias>[…]</referencias>` block. The app strips the block, **verifies each source outside Claude** and stores it in `biblioteca/referencias.json`, linked to answers and apuntes (`refs`):
  books → Open Library, then Google Books, then Crossref · articles/DOI → Crossref · web pages → the URL must come from Claude's own web search results of that answer, or open and match the title. Unverified sources are shown ⚠ everywhere, never go to the thesis bibliography, and can be re-checked, edited or marked “La revisé yo”.
* **Claude web search** (server tool `web_search_20250305`, `max_uses` from Administrador): used for library notes, sources, questions, ideas and the marco teórico; handles `pause_turn`; if the organisation has web search disabled (400) the app answers without it and says so.
* **Mi biblioteca → Mi marco teórico**: Claude proposes the map (concepts = Temas), a traffic-light per concept (≥3 apuntes, ≥3 verified sources, none unverified, ≥1 own note), “Profundizar”, a sinodal-style review, and a writing guide that may only use verified sources.
* **Mi biblioteca → Referencias**: list with badges, add own reference (checked on save), “Pasarlas a la Bibliografía de mi tesis” (verified only), Word download. `BIBLIOGRAFIA_HARVARD.md` is rewritten on every change.
* **Data format + migration**: see **`DATOS_Y_MIGRACION.md`** (where data lives, three ways to carry it to a new version, rules for the next developer). Administrador → *Traer datos de una versión anterior* (merge without duplicates, or replace with backup). `tests/` holds offline tests for the reference checks, Harvard formatting, old-format import and the web-search client.

## Navigation and Claude answers
* The **Claude connection is not a user tab**: it lives inside **Administrador → Conexión con Claude** (registry `show_in_menu: false`; the module server still runs).
* The app opens on the **first user tab** the first time, and afterwards on the **tab that was open when the app was closed** (saved in `data/config.json → last_tab` on every tab change and when the window closes; if it was Administrador, it opens the first user tab).
* Every section that receives Claude answers has a box **“¿Dónde guardo las respuestas de Claude?”** with Categoría › Tema › Tópico menus (“+ Nueva…” options, like the books app). With **Guardar automáticamente** ticked (default) every new answer goes straight into Mi biblioteca there, and follow-up questions update that apunte. In Introducción/Capítulos/Conclusiones the Tópico can be “✎ La parte que estoy escribiendo”. The choice is remembered per section (`config.json → lib_dest`).

## Tabs (sidebar order = `modules/_module_registry.yml`)
| Tab | What it does |
|---|---|
| **Conexión con Claude** | API key, model (Sonnet 5.5 default, Opus 5.5, Haiku 5.5, Sonnet 4.6 or any typed model id), max tokens, timeout, test, remember key, usage counters (calls / tokens), a box to try a question. The header shows “Claude conectado / sin conectar”. |
| **Cómo escribir una buena tesis** | 5 sub-tabs: **Mi avance** (overall %, step-by-step route with “Ir” buttons, “Ya leí la guía”), **La carrera: ayer y hoy** (1979–80 plan axes vs. the 2026 plan by semester, IBERO features, graduate profile, “bridge” ideas that can be added to *Mis ideas*), **Una buena tesis** (criteria, thesis types, common mistakes, the family example), **Estructura, método y fuentes** (parts, length targets, APA examples, method, Mexican sources), **Pregúntele a Claude** (honest AI use + free/quick questions). |
| **Mis ideas y temas** | Idea cards (title, description, personal experience, related subjects from both plans, status). Per idea: Claude's opinion, follow-up conversation, edit, delete, **Elegir como mi tema**. “Que Claude me sugiera temas” returns 5 topics (JSON) that can be added as ideas. |
| **Bosquejo de la tesis** | Title, question, hypothesis, general/specific objectives, justification, theoretical framework, method, scope, plus a chapter list (add / reorder / remove; chapter ids keep their texts). Claude can **propose a full outline from the chosen topic** (JSON → “Usar esta propuesta”) or **review** it. Autosaves. |
| **Introducción** | 8 parts (context, question, objectives, hypothesis, justification, framework, method, structure), each with guidance and an orientative word target. |
| **Capítulos** | One editor per chapter of the outline (target words per chapter set by the admin). Extra button: **Sugerir fuentes**. |
| **Conclusiones** | 6 parts + bibliography. Extra button: **¿Responden a mi introducción?** (compares intro vs. conclusions). |
| **Mi biblioteca de apuntes** | Local-file version of the *Book Summary* suite of BooksNetworksStrategySixS (BigQuery → files on the PC). Hierarchy **Categoría › Tema › Tópico › apunte** with “+ Nueva…” cascades (like Genre/Topic). Sub-tabs: **Explorar** (index tree, cascade filters, word search without accents, ⭐ / ✔ / tag / origin filters, cards grouped like the chapter cards, edit/move, export view to Word/.md), **Pedir apuntes a Claude** (concept, overview, book by chapters, sources → fixed bracket format → preview with check boxes → save), **Agregar un apunte**, **Importar texto** (bracket format parser), **Tabla y descargas** (CSV for Excel, all in Word, open folder), **Cómo funciona** (rebuild index from files). Every Claude comment card in the app also has **Guardar en mi biblioteca**. Files: `biblioteca/biblioteca.json` (index), `biblioteca.csv`, `INDICE.md`, and one `.md` per apunte under `Categoría/Tema/Tópico/` (YAML header, so the index can be rebuilt). |
| **Administrador** (code 718) | Work folder (browse or type; copy current work there or open a thesis already there; open in Explorer/Finder), thesis data, Claude feedback style (brief / detailed / strict examiner), send topic+outline as context, extra instructions for Claude, chapter word target, autosave delay, **screen size 80–150 %**, **build the full thesis** (.docx with `officer`, printable .html, .md), backups (now / restore), change admin code, project summary, **Bloquear Administrador**. |

Writing tabs share `R/writing_module.R`: big part “pills” (✎ started, ✔ target reached), autosave ~2 s after typing stops,
“Guardar ahora”, **versions** (save / restore; a snapshot is always taken before a correction or restore),
Claude buttons (**Revisar mi texto**, **Ayúdeme a empezar o a seguir**, **Corregir ortografía y estilo** → “Usar esta versión corregida”),
free question box and the list of Claude's comments with **Seguir conversando** (Claude remembers that thread).

Every Claude request carries a shared system prompt (`R/prompts.R`): tutor (not author) role, Mexican Spanish with *usted*,
the user's background (1979–80 plan) vs. today's plan, citation style, feedback style, admin's extra instructions and — if enabled — the chosen topic and outline.

## Where things are saved
App folder `data/`: `config.json` (admin settings), `.claude_key` (only if remembered), `usage.json`, `app.log`.

Work folder (default `data/mi_tesis/`, chosen in Administrador):
```
proyecto.json        everything (ideas, outline, texts, Claude conversations)
textos/              readable .md copy of each part (rewritten on every save)
retroalimentacion/   every Claude answer as .md
versiones/           saved versions of each part
respaldos/           automatic daily copy + "Hacer respaldo ahora"
exportar/            the full thesis (.docx / .html / .md)
```

## Structure
```
App_Tesis_LuzRoAl/
├── app.R  global.R  install_packages.R  README.md  DATOS_Y_MIGRACION.md  INSTRUCCIONES_WINDOWS.txt  tests/
├── iniciar_app.R  CREAR_ACCESO_DIRECTO.bat  Abrir Mi Tesis.bat
├── lanzador/ comun.ps1  abrir_app.ps1  instalar_acceso_directo.ps1  mi_tesis.ico
├── R/ module_loader.R  utils_common.R  utils_refs.R (Harvard + verification)  utils_library.R (LibraryManager R6)  content_ibero.R  utils_claude.R (ClaudeClient R6)
│      prompts.R  utils_thesis.R (ThesisManager R6)  ui_helpers.R  writing_module.R
├── modules/_module_registry.yml
│   ├── claude_api/ guia_tesis/ ideas/ bosquejo/ introduccion/ capitulos/ conclusion/ biblioteca/ admin_settings/   (ui.R + server.R)
└── www/css/global.css  www/js/app.js  www/fonts/ (Atkinson Hyperlegible, Andika, Lexend + OFL licences)
```

## Testing without a key
`Sys.setenv(TESIS_MOCK_CLAUDE = "1")` before `runApp()` makes Claude return canned answers (for trying the flow offline). Remove it for real use.

## Notes
* Study-plan content: IBERO degree page/brochure (2026 plan) and Biblioteca Francisco Xavier Clavigero, *Historia de las Carreras de la IBERO (1943–2021)* (1979–80 focus). Graduation options and AI-use rules must be confirmed with the IBERO coordination; the app says so.
* Model ids can be changed without code: choose “Otro modelo” in Conexión con Claude.
