@echo off
title Crear acceso directo - Mi Tesis
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0lanzador\instalar_acceso_directo.ps1"
if errorlevel 1 pause
