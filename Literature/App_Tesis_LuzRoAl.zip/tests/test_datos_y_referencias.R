# Run from the app folder:  Rscript tests/test_datos_y_referencias.R   (no internet or Claude key needed)
suppressMessages({library(shiny); library(R6); library(jsonlite); library(httr)})
`%||%` <- function(x, y) if (is.null(x) || length(x) == 0) y else x
APP_VERSION <- "test"
for (f in c("utils_common","content_ibero","utils_refs","utils_library","utils_claude","prompts","utils_thesis")) source(paste0("R/",f,".R"), encoding="UTF-8")
ok <- function(name, cond) cat(if (isTRUE(cond)) "PASS" else "FAIL", "-", name, "\n")

# ---- fixtures shaped like the real services
mock <- function(url, query, as_json) {
  if (grepl("openlibrary.org/search.json", url)) {
    if (grepl("sistema pol", query$title, ignore.case = TRUE)) return(list(status = 200, body = list(numFound = 1, docs = list(list(
      key = "/works/OL123W", title = "El sistema político mexicano", author_name = list("Daniel Cosío Villegas"), first_publish_year = 1972,
      isbn = list("9789682700040"), publisher = list("Joaquín Mortiz"))))))
    if (grepl("presidencialismo", query$title, ignore.case = TRUE)) return(list(status = 200, body = list(numFound = 1, docs = list(list(
      key = "/works/OL999W", title = "El presidencialismo mexicano", author_name = list("Jorge Carpizo"), first_publish_year = 1978)))))
    return(list(status = 200, body = list(numFound = 0, docs = list())))
  }
  if (grepl("googleapis.com/books", url)) return(list(status = 200, body = list(totalItems = 0)))
  if (grepl("api.crossref.org/works/10.1234", url)) return(list(status = 200, body = list(message = list(title = list("A totally different paper about fish"), DOI = "10.1234/x"))))
  if (grepl("api.crossref.org/works$", url)) {
    if (grepl("gobernanza", query$query.bibliographic, ignore.case = TRUE)) return(list(status = 200, body = list(message = list(items = list(
      list(DOI = "10.5555/abc", title = list("La gobernanza hoy: 10 textos de referencia"), author = list(list(family = "Aguilar", given = "Luis F.")),
           `container-title` = list("Gestión y Política Pública"), publisher = "CIDE", type = "journal-article"))))))
    return(list(status = 200, body = list(message = list(items = list()))))
  }
  if (grepl("ine.mx/historia-ok", url)) return(list(status = 200, body = "<html><head><title>Historia del Instituto Nacional Electoral</title></head></html>"))
  if (grepl("ine.mx/otra", url)) return(list(status = 200, body = "<html><head><title>Aviso de privacidad</title></head></html>"))
  list(status = 404, body = NULL)
}
options(tesis.http_mock = mock)
R <- function(...) { r <- setNames(as.list(rep("", length(REF_FIELDS))), REF_FIELDS); x <- list(...); for (n in names(x)) r[[n]] <- x[[n]]; r }

v <- verify_reference(R(tipo="libro", autores="Cosío Villegas, D.", anio="1972", titulo="El sistema político mexicano"))
ok("real book -> verificada (Open Library)", v$estado == "verificada" && v$verificada_por == "Open Library" && v$isbn == "9789682700040")
v <- verify_reference(R(tipo="libro", autores="Pérez, A.", anio="1999", titulo="Teoría crítica del Estado administrador mexicano"))
ok("invented book -> sin_verificar", v$estado == "sin_verificar")
v <- verify_reference(R(tipo="libro", autores="Gómez, R.", anio="1978", titulo="El presidencialismo mexicano"))
ok("right title, wrong author -> sin_verificar", v$estado == "sin_verificar")
v <- verify_reference(R(tipo="articulo", autores="Aguilar, L. F.", anio="2010", titulo="La gobernanza hoy: 10 textos de referencia"))
ok("article -> verificada (Crossref) + DOI filled", v$estado == "verificada" && v$doi == "10.5555/abc")
v <- verify_reference(R(tipo="articulo", autores="Aguilar, L.", anio="2010", titulo="Un artículo sobre gobernanza", doi="10.1234/x"))
ok("DOI of another paper -> sin_verificar", v$estado == "sin_verificar" && grepl("otro título", v$detalle))
v <- verify_reference(R(tipo="web", autores="INE", anio="2024", titulo="Historia del INE", url="https://www.ine.mx/sobre/"), "https://ine.mx/sobre", "Historia - INE")
ok("URL returned by Claude's web search -> verificada", v$estado == "verificada" && v$verificada_por == "Búsqueda web de Claude")
v <- verify_reference(R(tipo="web", autores="INE", titulo="Historia del Instituto Nacional Electoral", url="https://www.ine.mx/historia-ok"))
ok("URL opens and title matches -> verificada", v$estado == "verificada" && v$verificada_por == "Enlace comprobado")
v <- verify_reference(R(tipo="web", autores="INE", titulo="Historia del Instituto Nacional Electoral", url="https://www.ine.mx/otra"))
ok("URL opens but other page -> sin_verificar", v$estado == "sin_verificar")
v <- verify_reference(R(tipo="web", autores="X", titulo="Página que no existe", url="https://example.org/nada"))
ok("URL 404 -> sin_verificar", v$estado == "sin_verificar" && grepl("404", v$detalle))

h <- format_harvard(R(tipo="libro", autores="Cosío Villegas, D.", anio="1972", titulo="El sistema político mexicano", lugar="México", editorial="Joaquín Mortiz"))
ok(paste("Harvard book:", h), h == "Cosío Villegas, D. (1972) *El sistema político mexicano*. México: Joaquín Mortiz.")
h <- format_harvard(R(tipo="articulo", autores="Aguilar, L. F.", anio="2010", titulo="La gobernanza hoy", contenedor="Gestión y Política Pública", volumen="19(2)", paginas="5-36", doi="10.5555/abc"))
ok(paste("Harvard article:", h), grepl("^Aguilar, L. F. \\(2010\\) ‘La gobernanza hoy’, \\*Gestión y Política Pública\\*, 19\\(2\\), pp. 5-36. doi: 10.5555/abc.$", h))
h <- format_harvard(R(tipo="web", autores="Instituto Nacional Electoral", anio="", titulo="Historia", url="https://ine.mx/h", creado="2026-11-12 10:00:00"))
ok(paste("Harvard web:", h), h == "Instituto Nacional Electoral (s.f.) *Historia*. Disponible en: https://ine.mx/h (Consultado: 12 de noviembre de 2026).")
ok("in-text key", ref_key(R(autores="Cosío Villegas, D.", anio="1972")) == "(Cosío Villegas, 1972)")

x <- extract_refs_block('Texto (Carpizo, 1978).\n\n**Referencias**\n\n<referencias>\n[{"n":1,"tipo":"libro","autores":"Carpizo, J.","anio":"1978","titulo":"El presidencialismo mexicano"}]\n</referencias>')
ok("block extracted and removed (with stray heading)", length(x$refs) == 1 && x$text == "Texto (Carpizo, 1978).")
x <- extract_refs_block("Sin fuentes.\n<referencias>\n[]\n</referencias>")
ok("empty block", length(x$refs) == 0 && x$text == "Sin fuentes.")
x <- extract_refs_block('Cortado <referencias>[{"n":1,"titulo":"A","autores":"B, C."}')
ok("truncated block does not break", is.list(x$refs) && !grepl("referencias", x$text))

df <- parse_apuntes_text("[Marco teórico]\n[General]\n\n[tema]: El Estado\n[topico]: Definición\n[titulo]: Qué es\n[apunte]: Línea uno (Weber, 1922).\nlínea dos.\n[refs]: 1, 2\n[para_mi_tesis]: Base.\n\n[tema]: Gobernanza\n[topico]: Autores\n[titulo]: Quiénes\n[apunte]: Texto.\n[refs]: N/A\n\n<referencias>[]</referencias>")
ok("parser: 2 apuntes, tema per apunte, refs numbers, multi-line", nrow(df) == 2 && identical(df$tema, c("El Estado", "Gobernanza")) && df$refs_n[1] == "1, 2" && grepl("línea dos", df$contenido[1]) && df$refs_n[2] == "")

# ---- registry: dedup, map, storage, old formats
d <- tempfile(); dir.create(d)
tm <- ThesisManager$new(d)
m <- tm$lib$register_refs(list(list(n = 1, tipo = "libro", autores = "Cosío Villegas, D.", anio = "1972", titulo = "El sistema político mexicano"),
                               list(n = 2, tipo = "libro", autores = "Pérez, A.", anio = "1999", titulo = "Libro que nadie conoce del todo")))
m2 <- tm$lib$register_refs(list(list(n = 7, tipo = "libro", autores = "Cosío Villegas, Daniel", anio = "1972", titulo = "El sistema político mexicano")))
ok("registry: 2 stored, same book reused", nrow(tm$lib$refs) == 2 && m2[["7"]] == m[["1"]])
ok("bibliography keeps only verified", nrow(tm$lib$bibliography()) == 1 && nrow(tm$lib$refs[tm$lib$refs$estado == "sin_verificar", ]) == 1)
tm$lib$add(data.frame(categoria = "Marco teórico", tema = "El Estado", topico = "Def", titulo = "T", contenido = "C", refs = paste(m, collapse = ", "), stringsAsFactors = FALSE))
tm2 <- ThesisManager$new(d)
ok("reload: apunte + refs + link survive", nrow(tm2$lib$rows) == 1 && nrow(tm2$lib$refs) == 2 && nrow(tm2$lib$get_refs(tm2$lib$rows$refs[1])) == 2)
ok("files written", all(file.exists(file.path(tm$lib$dir(), c("biblioteca.json", "referencias.json", "BIBLIOGRAFIA_HARVARD.md", "INDICE.md")))))
ok("format version stamped", jsonlite::read_json(file.path(tm$lib$dir(), "biblioteca.json"))$formato_version == 2)

# old version 1.2 data (bare array, no refs field, project version 1) must import
old <- tempfile(); dir.create(file.path(old, "data", "mi_tesis", "biblioteca"), recursive = TRUE)
write_json(list(list(id = "apOLD1", creado = "2026-11-01 10:00:00", categoria = "Teoría política", tema = "X", topico = "Y", titulo = "Viejo", contenido = "Texto viejo", tipo = "claude", importante = TRUE)),
           file.path(old, "data", "mi_tesis", "biblioteca", "biblioteca.json"), auto_unbox = TRUE)
write_json(list(version = 1, updated = "2026-11-01 10:00:00", ideas = list(list(id = "ideaOLD", titulo = "Idea vieja", descripcion = "d")), chosen_idea = "ideaOLD",
                outline = list(titulo = "Título viejo", chapters = list(list(id = "c1", titulo = "Cap viejo", descripcion = ""))),
                sections = list(intro_contexto = list(text = "Contexto viejo"), cap_c1 = list(text = "Capítulo viejo")),
                feedback = list(list(id = "fbOLD", tab = "ideas", key = "ideaOLD", action = "idea", title = "t", time = "2026-11-01 10:00:00",
                                     messages = list(list(role = "user", content = "q"), list(role = "assistant", content = "a"))))),
           file.path(old, "data", "mi_tesis", "proyecto.json"), auto_unbox = TRUE)
tm2$set_text("intro_contexto", "Mi contexto nuevo")
f <- tm2$find_import(old)
ok("find_import from app folder", !is.null(f) && f$resumen$apuntes == 1 && f$resumen$ideas == 1)
n <- tm2$import_from(f, "merge")
ok("merge: idea, apunte, comment, chapter text in; my text kept, old one as version",
   n$ideas == 1 && n$apuntes == 1 && n$comentarios == 1 && n$versiones == 1 && tm2$get_text("intro_contexto") == "Mi contexto nuevo" &&
   tm2$get_text("cap_c1") == "Capítulo viejo" && length(tm2$chapters()) == 1 && "apOLD1" %in% tm2$lib$rows$id && isTRUE(tm2$lib$rows$importante[tm2$lib$rows$id == "apOLD1"]))
ok("idea synced into library", any(tm2$lib$rows$origen == "ideaOLD"))
n2 <- tm2$import_from(f, "merge")
ok("second merge adds nothing (no duplicates)", n2$ideas == 0 && n2$apuntes == 0 && n2$comentarios == 0)
tm3 <- ThesisManager$new(tempfile()); n3 <- tm3$import_from(tm3$find_import(file.path(old, "data")), "replace")
ok("replace from data/ folder", tm3$outline()$titulo == "Título viejo" && nrow(tm3$lib$rows) >= 1)
