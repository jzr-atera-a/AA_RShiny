# Run from the app folder:  Rscript tests/test_cliente_claude.R   (no internet or Claude key needed)
suppressMessages({library(R6); library(jsonlite); library(httr)})
`%||%` <- function(x, y) if (is.null(x) || length(x) == 0) y else x
source("R/utils_claude.R", encoding = "UTF-8")
ok <- function(name, cond) cat(if (isTRUE(cond)) "PASS" else "FAIL", "-", name, "\n")
cl <- ClaudeClient$new(); cl$mock <- FALSE; cl$set_credentials(api_key = "sk-test"); cl$connected <- TRUE
calls <- list()
resp1 <- fromJSON('{"role":"assistant","stop_reason":"pause_turn","usage":{"input_tokens":10,"output_tokens":5},"content":[
 {"type":"text","text":"Voy a buscar. "},
 {"type":"server_tool_use","id":"srvtoolu_1","name":"web_search","input":{"query":"presidencialismo mexicano Carpizo"}},
 {"type":"web_search_tool_result","tool_use_id":"srvtoolu_1","content":[
   {"type":"web_search_result","url":"https://archivos.juridicas.unam.mx/libro","title":"El presidencialismo mexicano - UNAM","encrypted_content":"Eqgf...","page_age":"2020"}]}]}', simplifyVector = FALSE)
resp2 <- fromJSON('{"role":"assistant","stop_reason":"end_turn","usage":{"input_tokens":20,"output_tokens":30,"server_tool_use":{"web_search_requests":1}},"content":[
 {"type":"text","text":"Según la fuente, "},
 {"type":"text","text":"el Ejecutivo concentraba el poder","citations":[{"type":"web_search_result_location","url":"https://archivos.juridicas.unam.mx/libro","title":"El presidencialismo mexicano - UNAM","cited_text":"..."},
                                                                      {"type":"web_search_result_location","url":"https://www.ine.mx/h","title":"INE","cited_text":"..."}]},
 {"type":"text","text":" (Carpizo, 1978).\\n\\n<referencias>[]</referencias>"},
 {"type":"web_search_tool_result","tool_use_id":"srvtoolu_2","content":{"type":"web_search_tool_result_error","error_code":"max_uses_exceeded"}}]}', simplifyVector = FALSE)
unlockBinding("post", cl)
cl$post <- function(body) { calls[[length(calls) + 1]] <<- body; if (length(calls) == 1) resp1 else resp2 }
r <- cl$chat(system = "s", messages = list(list(role = "user", content = "hola")), web_search = TRUE, max_searches = 3)
ok("tool sent with max_uses", calls[[1]]$tools[[1]]$type == "web_search_20250305" && calls[[1]]$tools[[1]]$max_uses == 3L)
ok("pause_turn resumed with the assistant blocks unchanged", length(calls) == 2 && identical(calls[[2]]$messages[[2]]$content, resp1$content) &&
   calls[[2]]$messages[[2]]$content[[3]]$content[[1]]$encrypted_content == "Eqgf...")
ok("text fragments joined without breaks", r$text == "Voy a buscar. Según la fuente, el Ejecutivo concentraba el poder (Carpizo, 1978).\n\n<referencias>[]</referencias>")
ok("search urls = results + citations, unique; error block ignored", identical(r$search$urls, c("https://archivos.juridicas.unam.mx/libro", "https://www.ine.mx/h")) && r$search$n == 1)
ok("usage summed", r$usage$input_tokens == 30 && r$usage$output_tokens == 35)
# the JSON really sent keeps the blocks intact
js <- toJSON(calls[[2]], auto_unbox = TRUE, null = "null")
ok("request JSON round-trips blocks", grepl('"encrypted_content":"Eqgf..."', js, fixed = TRUE) && grepl('"tool_use_id":"srvtoolu_1"', js, fixed = TRUE))
# web search disabled for the organisation -> answer without it
calls <- list()
cl$post <- function(body) { calls[[length(calls) + 1]] <<- body
  if (!is.null(body$tools)) { e <- simpleError("x"); e$status <- 400L; e$detail <- "Web search is not enabled for this organization"; stop(e) }
  list(content = list(list(type = "text", text = "Sin búsqueda.")), stop_reason = "end_turn", usage = list(input_tokens = 1, output_tokens = 1)) }
r <- cl$chat(messages = list(list(role = "user", content = "hola")), web_search = TRUE)
ok("fallback without tool, flagged unavailable", r$text == "Sin búsqueda." && isTRUE(r$search$unavailable) && length(calls) == 2 && is.null(calls[[2]]$tools))
cl$post <- function(body) { e <- simpleError("La clave de Claude no es válida."); e$status <- 401L; e$detail <- "invalid x-api-key"; stop(e) }
ok("other errors still surface", inherits(tryCatch(cl$chat(messages = list(list(role = "user", content = "h")), web_search = TRUE), error = function(e) e), "error"))
