# ============================================================================
# GLOBAL CONFIGURATION
# ============================================================================

cat("\n═══ MI TESIS - INITIALIZING ═══\n\n")

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0) y else x

APP_VERSION <- "1.3.0"     # shown in Administrador and written into every data file

# Core packages (always required)
suppressPackageStartupMessages({
  library(shiny)
  library(shinydashboard)
  library(R6)
  library(yaml)
  library(jsonlite)
  library(httr)
})

# Source utility files
source("R/module_loader.R", encoding = "UTF-8")
source("R/utils_common.R", encoding = "UTF-8")
source("R/content_ibero.R", encoding = "UTF-8")
source("R/utils_claude.R", encoding = "UTF-8")
source("R/prompts.R", encoding = "UTF-8")
source("R/utils_refs.R", encoding = "UTF-8")
source("R/utils_library.R", encoding = "UTF-8")
source("R/utils_thesis.R", encoding = "UTF-8")
source("R/ui_helpers.R", encoding = "UTF-8")
source("R/writing_module.R", encoding = "UTF-8")

# UI Factory Function
create_ui <- function(module_loader, tm = NULL) {
  enabled_modules <- Filter(function(m) !identical(m$module$show_in_menu, FALSE), module_loader$get_enabled_modules())
  tabnames <- vapply(enabled_modules, function(m) m$module$menu$tabname, character(1))
  start_tab <- if (!is.null(tm)) tm$start_tab(tabnames) else tabnames[1]

  all_tabs <- list()
  for (module in enabled_modules) {
    module_id <- module$module$id
    ui_function_name <- paste0(module_id, "_ui")
    tabname <- module$module$menu$tabname
    if (exists(ui_function_name, envir = .GlobalEnv)) {
      ui_function <- get(ui_function_name, envir = .GlobalEnv)
      all_tabs[[length(all_tabs) + 1]] <- tabItem(tabName = tabname, ui_function(module_id))
      # bootstrap shows the first tabItem; mark the remembered one as active instead
      if (identical(tabname, start_tab)) all_tabs[[length(all_tabs)]]$attribs$class <- "tab-pane active"
      else all_tabs[[length(all_tabs)]]$attribs$class <- "tab-pane"
    }
  }

  all_menu_items <- lapply(enabled_modules, function(module) {
    menu_info <- module$module$menu
    menuItem(menu_info$label, tabName = menu_info$tabname, icon = icon(menu_info$icon),
             selected = identical(menu_info$tabname, start_tab))
  })

  zoom <- if (!is.null(tm)) tm$font_scale() else 100

  dashboardPage(
    skin = "purple",
    title = "Mi Tesis",

    dashboardHeader(
      title = "📘 Mi Tesis",
      titleWidth = 300,
      tags$li(class = "dropdown", actionLink("quickNote", tagList(icon("pen"), " Anotar"), class = "header-note",
                                             title = "Guardar una nota mía en la biblioteca")),
      tags$li(class = "dropdown", uiOutput("header_status", inline = TRUE))
    ),

    dashboardSidebar(
      width = 300,
      tags$head(
        tags$meta(name = "viewport", content = "width=device-width, initial-scale=1"),
        tags$script(HTML("document.documentElement.lang = 'es-MX';")),
        tags$link(rel = "stylesheet", type = "text/css", href = "css/global.css"),
        tags$script(src = "js/app.js"),
        tags$style(HTML(sprintf(":root { --app-zoom: %s; }", zoom / 100))),
        tags$style(HTML("
          .main-header .navbar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; }
          .main-header .logo { background: linear-gradient(135deg, #5a67d8 0%, #6b46a1 100%) !important; font-size: 22px !important; }
          .main-sidebar { background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%) !important; }
          .sidebar-menu > li.active > a { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; }
          .content-wrapper { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%) !important; }
          .box { border-radius: 12px !important; box-shadow: 0 4px 20px rgba(0,0,0,0.08) !important; }
          .box-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; color: white !important; }
          .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; }
          .btn-success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%) !important; }
        "))
      ),
      sidebarMenu(
        id = "sidebar_menu",
        do.call(tagList, all_menu_items)
      ),
      uiOutput("sidebar_progress")
    ),

    dashboardBody(
      do.call(tabItems, all_tabs)
    )
  )
}

# Server Factory Function
create_server <- function(module_loader, tm, session, input, output) {
  enabled_modules <- module_loader$get_enabled_modules()
  cat("Initializing", length(enabled_modules), "module server(s)...\n")

  # Small overall-progress widget under the sidebar menu (shared by every tab)
  output$sidebar_progress <- renderUI({
    tm$proj_trigger(); tm$cfg_trigger()
    p <- tm$progress()
    div(class = "side-progress",
        div(class = "side-progress-title", "Avance de mi tesis"),
        div(class = "side-progress-pct", paste0(p$overall, " %")),
        div(class = "stat-bar", div(style = sprintf("width: %s%%;", p$overall))),
        div(class = "side-progress-note", p$next_step))
  })

  output$header_status <- renderUI({
    tm$claude_trigger()
    if (tm$claude$connected) {
      span(class = "header-pill ok", icon("robot"), " Claude conectado")
    } else {
      span(class = "header-pill off", icon("robot"), " Claude sin conectar")
    }
  })

  # "📝 Anotar": a note of the user from any tab, filed in the same Categoría › Tema › Tópico hierarchy
  setup_lib_cascade(input, session, tm, "qn_", levels = 3)
  observeEvent(input$quickNote, {
    tab <- input$sidebar_menu %||% ""
    d <- tm$config$lib_dest[[tab]] %||% list()
    top <- "Mis notas"
    rf <- tm$lib$refs
    showModal(modalDialog(title = "📝 Anotar en mi biblioteca", size = "l", easyClose = TRUE,
      fluidRow(
        column(5, tags$b("¿Dónde la guardo?"),
               lib_cascade_ui(function(x) x, "qn_", 3, tm$lib, list(categoria = d$categoria %||% "Mi tesis",
                              tema = d$tema %||% (TAB_TOPICS[[tab]] %||% "Mis notas"), topico = top))),
        column(7, textInput("qn_titulo", "Título de la nota:", width = "100%"),
               textAreaInput("qn_texto", "Mi nota:", rows = 7, width = "100%", placeholder = "Lo que pienso, leí o quiero recordar…"),
               selectizeInput("qn_refs", "Fuente(s) de mi lista de referencias (opcional):", multiple = TRUE, width = "100%",
                              choices = setNames(rf$id, paste(rf$clave, substr(rf$titulo, 1, 60))),
                              options = list(placeholder = "Elija si la nota viene de una lectura")),
               checkboxInput("qn_star", "⭐ Importante", FALSE))),
      footer = tagList(modalButton("Cancelar"), actionButton("qn_save", "Guardar la nota", class = "btn-success", icon = icon("save")))))
  })
  observeEvent(input$qn_save, {
    t <- read_lib_cascade(input, "qn_")
    if (!nzchar(t$categoria) || !nzchar(t$tema) || !nzchar(t$topico)) { showNotification("Elija o escriba la categoría, el tema y el tópico.", type = "warning"); return() }
    if (!nzchar(trimws(input$qn_texto %||% ""))) { showNotification("Escriba su nota.", type = "warning"); return() }
    ttl <- trimws(input$qn_titulo %||% ""); if (!nzchar(ttl)) ttl <- substr(trimws(input$qn_texto), 1, 60)
    tm$lib$add(data.frame(categoria = t$categoria, tema = t$tema, topico = t$topico, titulo = ttl, contenido = trimws(input$qn_texto),
                          tipo = "propio", refs = paste(input$qn_refs %||% character(), collapse = ", "),
                          importante = isTRUE(input$qn_star), stringsAsFactors = FALSE))
    removeModal()
    showNotification(sprintf("📝 Nota guardada en %s › %s › %s", t$categoria, t$tema, t$topico), type = "message", duration = 6)
  })

  # Remember the open tab (saved on every change and when the window closes)
  observeEvent(input$sidebar_menu, tm$remember_tab(input$sidebar_menu), ignoreInit = TRUE)
  session$onSessionEnded(function() isolate(tm$remember_tab(input$sidebar_menu)))

  for (module in enabled_modules) {
    module_id <- module$module$id
    server_function_name <- paste0(module_id, "_server")
    if (exists(server_function_name, envir = .GlobalEnv)) {
      server_function <- get(server_function_name, envir = .GlobalEnv)
      server_function(module_id, tm, session)
    }
  }
  cat("✓ All module servers initialized\n")
}

cat("✓ Global configuration complete\n\n")
