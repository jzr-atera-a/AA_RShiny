# ============================================================================
# MI BIBLIOTECA DE APUNTES - LibraryManager (R6)
#
# Local-file version of the "Book Summary" suite of BooksNetworksStrategySixS:
#   BigQuery table book_summaries  ->  biblioteca/biblioteca.json  (one row per apunte)
#   genre > topic > book > chapter ->  Categoría > Tema > Tópico > apunte
#   bq_get_books_taxonomy()        ->  taxonomy()  (DISTINCT categoria, tema, topico + counts)
#   bq_insert_books()              ->  add()       (ids, timestamps)
#   parse_summary_text()           ->  parse_apuntes_text()  (same bracket format idea)
#   state_trigger_books()          ->  tm$lib_trigger()      (refreshes every module)
#
# Files in <carpeta de trabajo>/biblioteca/   (the PC index, readable without the app)
#   biblioteca.json                      master index (all rows)
#   biblioteca.csv                       same rows as a table (opens in Excel)
#   INDICE.md                            hierarchical table of contents with links
#   <Categoría>/<Tema>/<Tópico>/AAAA-MM-DD_<título>_<id>.md
#                                        one file per apunte (YAML header + text);
#                                        the index can be rebuilt from these files
# ============================================================================

LIB_NEW <- "__NUEVO__"
LIB_ALL <- "__TODAS__"

# Starting drawers (always offered even when empty); they mirror the degree
LIB_MARCO <- "Marco teórico"
LIB_SEED <- c(LIB_MARCO, "Teoría política", "Historia política de México", "Administración pública",
              "Políticas públicas", "Sistema político y elecciones", "Metodología y fuentes", "Mi tesis")

LIB_TIPOS <- c("Respuesta de Claude" = "claude", "Resumen de lectura" = "lectura",
               "Idea o nota mía" = "propio", "Importado" = "importado")

LIB_FIELDS <- c("id", "creado", "actualizado", "categoria", "tema", "topico", "titulo", "contenido",
                "fuente", "url", "para_tesis", "tipo", "parte_tesis", "etiquetas", "nota",
                "importante", "aplicado", "origen", "refs", "archivo")

# Version of the data format written to disk. RULES FOR FUTURE VERSIONS (see DATOS_Y_MIGRACION.md):
#   never rename or delete a field; only ADD fields with a default (normalize() fills them when
#   reading older files); raise this number when the meaning of stored data changes and add the
#   conversion step to migrate_*().
LIB_FORMAT <- 2

# Safe folder / file name for Windows, Mac and Linux (keeps accents)
safe_name <- function(x, max = 45) {
  x <- gsub('[<>:"/\\\\|?*\\x01-\\x1f]', " ", x %||% "", perl = TRUE)
  x <- gsub("\\s+", " ", trimws(x))
  x <- gsub("[. ]+$", "", substr(x, 1, max))
  if (!nzchar(x)) "Sin nombre" else x
}
slug <- function(x, max = 40) gsub(" ", "_", safe_name(x, max))

empty_lib <- function() {
  df <- as.data.frame(setNames(replicate(length(LIB_FIELDS), character(), simplify = FALSE), LIB_FIELDS),
                      stringsAsFactors = FALSE)
  df$importante <- logical(); df$aplicado <- logical()
  df
}

LibraryManager <- R6::R6Class(
  "LibraryManager",
  public = list(
    tm = NULL,
    rows = NULL,
    refs = NULL,      # bibliographic references (R/utils_refs.R)

    initialize = function(tm) { self$tm <- tm; self$load() },
    refs_file = function() file.path(self$dir(), "referencias.json"),

    dir = function() file.path(self$tm$work_dir(), "biblioteca"),
    index_file = function() file.path(self$dir(), "biblioteca.json"),
    bump = function() bump(self$tm$lib_trigger),

    # ------------------------------------------------------------ load / save
    load = function() {
      dir.create(self$dir(), showWarnings = FALSE, recursive = TRUE)
      df <- empty_lib()
      if (file.exists(self$index_file())) {
        x <- tryCatch(jsonlite::fromJSON(self$index_file(), simplifyVector = TRUE),
                      error = function(e) { self$tm$log("biblioteca.json: ", conditionMessage(e)); NULL })
        if (is.list(x) && !is.data.frame(x) && !is.null(x$apuntes)) x <- x$apuntes   # format 2: {formato_version, apuntes}
        if (is.data.frame(x) && nrow(x)) df <- self$normalize(x)                     # format 1: bare array
      }
      self$rows <- df
      rf <- empty_refs()
      if (file.exists(self$refs_file())) {
        x <- tryCatch(jsonlite::fromJSON(self$refs_file(), simplifyVector = TRUE)$referencias, error = function(e) NULL)
        if (is.data.frame(x) && nrow(x)) rf <- self$normalize_refs(x)
      }
      self$refs <- rf
      self$bump()
      invisible(self)
    },

    normalize = function(x) {
      for (f in LIB_FIELDS) if (!f %in% names(x)) x[[f]] <- if (f %in% c("importante", "aplicado")) FALSE else ""
      x <- x[, LIB_FIELDS, drop = FALSE]
      for (f in setdiff(LIB_FIELDS, c("importante", "aplicado"))) { v <- as.character(x[[f]]); v[is.na(v)] <- ""; x[[f]] <- v }
      for (f in c("importante", "aplicado")) { v <- as.logical(x[[f]]); v[is.na(v)] <- FALSE; x[[f]] <- v }
      x
    },

    normalize_refs = function(x) {
      for (f in REF_FIELDS) if (!f %in% names(x)) x[[f]] <- ""
      x <- x[, REF_FIELDS, drop = FALSE]
      for (f in REF_FIELDS) { v <- as.character(x[[f]]); v[is.na(v)] <- ""; x[[f]] <- v }
      x$estado[!x$estado %in% names(REF_ESTADOS)] <- "sin_verificar"
      x
    },

    save = function() {
      dir.create(self$dir(), showWarnings = FALSE, recursive = TRUE)
      safe_write(self$index_file(), function(p) jsonlite::write_json(
        list(formato_version = LIB_FORMAT, app_version = APP_VERSION, guardado = now_str(), apuntes = self$rows),
        p, pretty = TRUE, auto_unbox = TRUE, dataframe = "rows"))
      safe_write(self$refs_file(), function(p) jsonlite::write_json(
        list(formato_version = LIB_FORMAT, app_version = APP_VERSION, guardado = now_str(), referencias = self$refs),
        p, pretty = TRUE, auto_unbox = TRUE, dataframe = "rows"))
      tryCatch(write_utf8(self$bibliography_md(), file.path(self$dir(), "BIBLIOGRAFIA_HARVARD.md")),
               error = function(e) self$tm$log("bibliografia: ", conditionMessage(e)))
      tryCatch({
        safe_write(file.path(self$dir(), "biblioteca.csv"), function(p) {
          con <- file(p, open = "wb"); on.exit(close(con))
          writeBin(as.raw(c(0xEF, 0xBB, 0xBF)), con)          # BOM so Excel shows accents
          utils::write.csv(self$rows[, setdiff(LIB_FIELDS, "archivo")], con, row.names = FALSE, fileEncoding = "UTF-8")
        })
        self$write_index_md()
      }, error = function(e) self$tm$log("biblioteca csv/indice: ", conditionMessage(e)))
      self$bump()
      invisible(TRUE)
    },

    # ------------------------------------------------------------ one file per apunte
    rel_path = function(r) {
      file.path(safe_name(r$categoria), safe_name(r$tema), safe_name(r$topico),
                sprintf("%s_%s_%s.md", substr(r$creado, 1, 10), slug(r$titulo), substr(r$id, nchar(r$id) - 5, nchar(r$id))))
    },
    write_md = function(r) {
      rel <- self$rel_path(r)
      full <- file.path(self$dir(), rel)
      dir.create(dirname(full), showWarnings = FALSE, recursive = TRUE)
      meta <- as.list(r[, setdiff(LIB_FIELDS, c("archivo", "contenido")), drop = FALSE])
      meta <- lapply(meta, function(v) if (is.logical(v)) isTRUE(v) else as.character(v))
      body <- c("---", sub("\n$", "", yaml::as.yaml(c(meta, list(contenido = r$contenido)))), "---", "",
                paste0("# ", r$titulo), "",
                sprintf("*%s › %s › %s*", r$categoria, r$tema, r$topico), "",
                r$contenido,
                if (nzchar(r$para_tesis)) c("", "## Para mi tesis", "", r$para_tesis),
                if (nzchar(r$refs)) { rr <- self$get_refs(r$refs); c("", "## Referencias (Harvard)", "",
                    sprintf("- %s %s", ifelse(rr$estado %in% c("verificada", "manual"), "✔", "⚠ SIN VERIFICAR —"), rr$harvard)) },
                if (nzchar(r$fuente)) c("", paste0("**Fuente:** ", r$fuente)),
                if (nzchar(r$url)) c("", paste0("**Enlace:** ", r$url)),
                if (nzchar(r$nota)) c("", paste0("**Mi nota:** ", r$nota)))
      write_utf8(body, full)
      rel
    },
    remove_md = function(rel) {
      if (!nzchar(rel %||% "")) return()
      f <- file.path(self$dir(), rel)
      if (file.exists(f)) unlink(f)
      # remove empty folders upwards (Tópico, Tema, Categoría)
      d <- dirname(f)
      for (i in 1:3) {
        if (normalizePath(d, mustWork = FALSE) == normalizePath(self$dir(), mustWork = FALSE)) break
        if (dir.exists(d) && !length(list.files(d, all.files = TRUE, no.. = TRUE))) unlink(d, recursive = TRUE)
        d <- dirname(d)
      }
    },

    # ------------------------------------------------------------ CRUD
    get = function(id) self$rows[self$rows$id == id, , drop = FALSE],

    # df: data.frame with at least categoria, tema, topico, titulo, contenido
    add = function(df) {
      if (!nrow(df)) return(character())
      df <- self$normalize(df)
      now <- now_str()
      ids <- character()
      for (i in seq_len(nrow(df))) {
        r <- df[i, , drop = FALSE]
        r$id <- new_id("ap"); r$creado <- now; r$actualizado <- now
        for (f in c("categoria", "tema", "topico", "titulo")) if (!nzchar(trimws(r[[f]]))) r[[f]] <- if (f == "titulo") substr(r$contenido, 1, 60) else "General"
        r$archivo <- self$write_md(r)
        self$rows <- rbind(self$rows, r)
        ids <- c(ids, r$id)
        Sys.sleep(0.002)
      }
      self$save()
      self$tm$log("Biblioteca: ", length(ids), " apunte(s) agregados")
      ids
    },

    update = function(id, ...) {
      i <- which(self$rows$id == id); if (!length(i)) return(invisible(FALSE))
      vals <- list(...)
      old_file <- self$rows$archivo[i]
      for (n in names(vals)) self$rows[[n]][i] <- vals[[n]]
      self$rows$actualizado[i] <- now_str()
      r <- self$rows[i, , drop = FALSE]
      new_rel <- self$rel_path(r)
      if (!identical(new_rel, old_file)) self$remove_md(old_file)
      self$rows$archivo[i] <- self$write_md(r)
      self$save()
      invisible(TRUE)
    },

    delete = function(id) {
      i <- which(self$rows$id == id); if (!length(i)) return(invisible(FALSE))
      self$remove_md(self$rows$archivo[i])
      self$rows <- self$rows[-i, , drop = FALSE]
      self$save()
      invisible(TRUE)
    },

    # Rename a whole Categoría or Tema (moves every apunte and its file)
    rename = function(level, old, new, categoria = NULL) {
      sel <- self$rows[[level]] == old
      if (!is.null(categoria)) sel <- sel & self$rows$categoria == categoria
      ids <- self$rows$id[sel]
      for (id in ids) do.call(self$update, c(list(id = id), setNames(list(new), level)))
      length(ids)
    },

    from_feedback = function(fb_id) self$rows$id[self$rows$origen == fb_id],

    # ------------------------------------------------------------ references
    split_ids = function(x) { v <- trimws(unlist(strsplit(x %||% "", ","))); v[nzchar(v)] },
    get_refs = function(ids) {
      ids <- if (length(ids) == 1) self$split_ids(ids) else ids
      self$refs[match(intersect(ids, self$refs$id), self$refs$id), , drop = FALSE]
    },
    ref_dedup_key = function(r) {
      if (nzchar(r$doi %||% "")) return(paste0("doi:", tolower(r$doi)))
      paste(paste(first_surname(r$autores), collapse = ""), r$anio %||% "", paste(utils::head(ref_tokens(r$titulo), 6), collapse = " "))
    },
    # entries: list of lists from Claude's <referencias> block (or one manual entry).
    # Returns a named character vector  n -> id.  Known references are reused (and re-checked if unverified).
    register_refs = function(entries, search_urls = character(), search_titles = character(), progress = NULL) {
      map <- character()
      existing_keys <- if (nrow(self$refs)) vapply(seq_len(nrow(self$refs)), function(i) self$ref_dedup_key(as.list(self$refs[i, ])), "") else character()
      for (k in seq_along(entries)) {
        e <- entries[[k]]
        r <- setNames(as.list(rep("", length(REF_FIELDS))), REF_FIELDS)
        for (f in intersect(names(e), REF_FIELDS)) r[[f]] <- trimws(paste(unlist(e[[f]]), collapse = " "))
        r$tipo <- if (r$tipo %in% REF_TIPOS) r$tipo else if (nzchar(r$url) && !nzchar(r$editorial)) "web" else "libro"
        r$anio <- regmatches(r$anio, regexpr("\\d{4}", r$anio)) %||% ""
        if (!length(r$anio)) r$anio <- ""
        if (is.function(progress)) progress(sprintf("Comprobando la fuente %d de %d: %s", k, length(entries), substr(r$titulo, 1, 50)))
        key <- self$ref_dedup_key(r)
        i <- match(key, existing_keys)
        if (!is.na(i) && self$refs$estado[i] != "sin_verificar") { map[as.character(e$n %||% k)] <- self$refs$id[i]; next }
        v <- verify_reference(r, search_urls, search_titles)
        for (f in names(v)) r[[f]] <- v[[f]]
        if (is.na(i)) {
          r$id <- new_id("ref"); r$creado <- now_str(); Sys.sleep(0.002)
          r$harvard <- format_harvard(r); r$clave <- ref_key(r)
          self$refs <- rbind(self$refs, as.data.frame(r, stringsAsFactors = FALSE))
          existing_keys <- c(existing_keys, key)
        } else {
          r$id <- self$refs$id[i]; r$creado <- self$refs$creado[i]
          r$harvard <- format_harvard(r); r$clave <- ref_key(r)
          for (f in REF_FIELDS) self$refs[[f]][i] <- r[[f]]
        }
        map[as.character(e$n %||% k)] <- r$id
      }
      if (length(entries)) self$save()
      map
    },
    update_ref = function(id, ..., reverify = FALSE) {
      i <- match(id, self$refs$id); if (is.na(i)) return(invisible(FALSE))
      vals <- list(...)
      for (n in names(vals)) self$refs[[n]][i] <- vals[[n]]
      r <- as.list(self$refs[i, ])
      if (reverify) { v <- verify_reference(r); for (f in names(v)) r[[f]] <- v[[f]] }
      r$harvard <- format_harvard(r); r$clave <- ref_key(r)
      for (f in REF_FIELDS) self$refs[[f]][i] <- r[[f]]
      self$save(); invisible(TRUE)
    },
    delete_ref = function(id) {
      self$refs <- self$refs[self$refs$id != id, , drop = FALSE]
      for (i in which(grepl(id, self$rows$refs, fixed = TRUE)))
        self$rows$refs[i] <- paste(setdiff(self$split_ids(self$rows$refs[i]), id), collapse = ", ")
      self$save()
    },
    refs_used_by = function(id) sum(grepl(id, self$rows$refs, fixed = TRUE)),
    # Bibliography in Harvard order. verified_only = TRUE leaves the unverified ones out.
    bibliography = function(ids = NULL, verified_only = TRUE) {
      r <- if (is.null(ids)) self$refs else self$get_refs(ids)
      if (verified_only) r <- r[r$estado %in% c("verificada", "manual"), , drop = FALSE]
      r[order(ref_norm(r$harvard)), , drop = FALSE]
    },
    bibliography_md = function() {
      ok <- self$bibliography(); bad <- self$refs[self$refs$estado == "sin_verificar", , drop = FALSE]
      c("# Bibliografía (formato Harvard)", "", sprintf("*Actualizada: %s*", fmt_fecha(now_str())), "",
        "## Fuentes verificadas", "", if (nrow(ok)) paste0("- ", ok$harvard) else "(ninguna todavía)", "",
        "## SIN VERIFICAR — no usar en la tesis hasta comprobarlas", "",
        if (nrow(bad)) paste0("- ⚠ ", bad$harvard, " — ", bad$detalle) else "(ninguna)")
    },

    # ------------------------------------------------------------ taxonomy (like bq_get_books_taxonomy)
    taxonomy = function() {
      r <- self$rows
      if (!nrow(r)) return(data.frame(categoria = character(), tema = character(), topico = character(), n = integer()))
      agg <- stats::aggregate(list(n = rep(1L, nrow(r))), by = list(categoria = r$categoria, tema = r$tema, topico = r$topico), FUN = sum)
      agg[order(agg$categoria, agg$tema, agg$topico), ]
    },
    categorias = function() {
      used <- unique(self$rows$categoria)
      c(LIB_SEED, sort(setdiff(used, LIB_SEED)))
    },
    temas = function(cat) sort(unique(self$rows$tema[self$rows$categoria == cat])),
    topicos = function(cat, tema) sort(unique(self$rows$topico[self$rows$categoria == cat & self$rows$tema == tema])),
    all_tags = function() {
      t <- unlist(strsplit(self$rows$etiquetas, ",")); t <- trimws(t)
      sort(unique(t[nzchar(t)]))
    },

    # ------------------------------------------------------------ search / filter
    filter = function(categoria = LIB_ALL, tema = LIB_ALL, topico = LIB_ALL, q = "", solo_importantes = FALSE,
                      ocultar_aplicados = FALSE, etiqueta = "", tipo = "") {
      r <- self$rows
      if (!nrow(r)) return(r)
      keep <- rep(TRUE, nrow(r))
      if (!identical(categoria, LIB_ALL) && nzchar(categoria %||% "")) keep <- keep & r$categoria == categoria
      if (!identical(tema, LIB_ALL) && nzchar(tema %||% "")) keep <- keep & r$tema == tema
      if (!identical(topico, LIB_ALL) && nzchar(topico %||% "")) keep <- keep & r$topico == topico
      if (isTRUE(solo_importantes)) keep <- keep & r$importante
      if (isTRUE(ocultar_aplicados)) keep <- keep & !r$aplicado
      if (nzchar(etiqueta %||% "")) keep <- keep & vapply(strsplit(r$etiquetas, ","), function(t) etiqueta %in% trimws(t), logical(1))
      if (nzchar(tipo %||% "")) keep <- keep & r$tipo == tipo
      q <- trimws(q %||% "")
      if (nzchar(q)) {
        norm <- function(x) tolower(iconv(x, "UTF-8", "ASCII//TRANSLIT", sub = ""))
        hay <- norm(paste(r$titulo, r$contenido, r$fuente, r$para_tesis, r$nota, r$etiquetas, r$categoria, r$tema, r$topico))
        for (w in strsplit(norm(q), "\\s+")[[1]]) keep <- keep & grepl(w, hay, fixed = TRUE)
      }
      out <- r[keep, , drop = FALSE]
      out[order(out$categoria, out$tema, out$topico, !out$importante, out$creado), , drop = FALSE]
    },

    # ------------------------------------------------------------ index files
    write_index_md = function() {
      r <- self$rows
      lines <- c("# Índice de mi biblioteca de apuntes", "",
                 sprintf("*Actualizado: %s · %d apuntes · ⭐ %d importantes · ✔ %d ya aplicados*",
                         fmt_fecha(now_str()), nrow(r), sum(r$importante), sum(r$aplicado)), "")
      if (nrow(r)) {
        r <- r[order(r$categoria, r$tema, r$topico, r$creado), ]
        for (cat in unique(r$categoria)) {
          rc <- r[r$categoria == cat, ]
          lines <- c(lines, sprintf("## %s  (%d)", cat, nrow(rc)), "")
          for (tema in unique(rc$tema)) {
            rt <- rc[rc$tema == tema, ]
            lines <- c(lines, sprintf("### %s  (%d)", tema, nrow(rt)), "")
            for (top in unique(rt$topico)) {
              rp <- rt[rt$topico == top, ]
              lines <- c(lines, sprintf("**%s**", top), "")
              for (i in seq_len(nrow(rp))) {
                x <- rp[i, ]
                marks <- paste0(if (x$importante) "⭐ " else "", if (x$aplicado) "✔ " else "")
                tags <- if (nzchar(x$etiquetas)) paste0(" · ", x$etiquetas) else ""
                lines <- c(lines, sprintf("- %s[%s](<%s>) — %s%s", marks, x$titulo, gsub("\\\\", "/", x$archivo),
                                          substr(x$creado, 1, 10), tags))
              }
              lines <- c(lines, "")
            }
          }
        }
      } else lines <- c(lines, "Todavía no hay apuntes.")
      write_utf8(lines, file.path(self$dir(), "INDICE.md"))
    },

    # Rebuild biblioteca.json from the .md files (if the index was lost or files were copied by hand)
    rebuild_from_files = function() {
      files <- list.files(self$dir(), pattern = "\\.md$", recursive = TRUE, full.names = TRUE)
      files <- files[basename(files) != "INDICE.md"]
      out <- list()
      for (f in files) {
        txt <- readLines(f, encoding = "UTF-8", warn = FALSE)
        if (length(txt) < 3 || txt[1] != "---") next
        end <- which(txt == "---")[2]; if (is.na(end)) next
        meta <- tryCatch(yaml::yaml.load(paste(txt[2:(end - 1)], collapse = "\n")), error = function(e) NULL)
        if (is.null(meta) || is.null(meta$titulo)) next
        meta <- lapply(meta, function(v) if (is.null(v)) "" else v)
        meta$archivo <- substring(normalizePath(f, winslash = "/"), nchar(normalizePath(self$dir(), winslash = "/")) + 2)
        out[[length(out) + 1]] <- as.data.frame(meta[intersect(names(meta), LIB_FIELDS)], stringsAsFactors = FALSE)
      }
      df <- if (length(out)) self$normalize(do.call(rbind, lapply(out, self$normalize))) else empty_lib()
      df <- df[!duplicated(df$id), , drop = FALSE]
      self$rows <- df
      self$save()
      nrow(df)
    },

    # ------------------------------------------------------------ export (Markdown -> Word / HTML)
    to_markdown = function(r, title = "Mis apuntes") {
      lines <- c(paste0("# ", title), "", sprintf("%d apuntes · %s", nrow(r), format(Sys.Date(), "%d/%m/%Y")), "")
      for (cat in unique(r$categoria)) {
        lines <- c(lines, paste0("## ", cat), "")
        rc <- r[r$categoria == cat, ]
        for (tema in unique(rc$tema)) {
          lines <- c(lines, paste0("### ", tema), "")
          rt <- rc[rc$tema == tema, ]
          for (i in seq_len(nrow(rt))) {
            x <- rt[i, ]
            lines <- c(lines, sprintf("**%s%s — %s**", if (x$importante) "⭐ " else "", x$topico, x$titulo), "",
                       gsub("(?m)^#+\\s*", "", x$contenido, perl = TRUE), "",
                       if (nzchar(x$para_tesis)) c(paste0("Para mi tesis: ", x$para_tesis), ""),
                       if (nzchar(x$fuente)) c(paste0("Fuente: ", x$fuente), ""),
                       if (nzchar(x$nota)) c(paste0("Mi nota: ", x$nota), ""))
          }
        }
      }
      paste(lines, collapse = "\n")
    }
  )
)

# ---------------------------------------------------------------------------
# Claude: generate apuntes in a fixed bracket format (like generate_summary_prompt)
# ---------------------------------------------------------------------------
LIB_GEN_TIPOS <- c(
  "Explicar un concepto o una teoría" = "concepto",
  "Panorama de un tema (sus partes principales)" = "panorama",
  "Resumir un libro por capítulos" = "libro",
  "Sugerir fuentes y lecturas" = "fuentes",
  "Marco teórico de mi tesis (conceptos, autores y debates)" = "marco"
)

prompt_library <- function(tipo, peticion, categoria, tema, n = 5, libro = "", autor = "") {
  que <- switch(tipo,
    concepto = paste0("Explica de forma clara el concepto o teoría: ", peticion, ". Divide la explicación en ", n, " tópicos (definición, autores, evolución, críticas, aplicación a México, etc.)."),
    panorama = paste0("Da un panorama del tema: ", peticion, ". Divídelo en ", n, " tópicos principales."),
    libro = paste0("Resume el libro \"", libro, "\"", if (nzchar(autor)) paste0(" de ", autor) else "", " por capítulos (un tópico por capítulo o grupo de capítulos, máximo ", max(n, 12), ").",
                   if (nzchar(peticion)) paste0(" Enfoque: ", peticion) else ""),
    marco = paste0("Construye el mapa del MARCO TEÓRICO de mi tesis (usa el tema y el bosquejo del contexto)",
                   if (nzchar(peticion)) paste0("; enfoque: ", peticion) else "", ". Identifica de 3 a 5 conceptos o teorías centrales; cada uno es un TEMA ",
                   "(pon la línea [tema]: … en cada apunte). Para cada tema da de 2 a 3 tópicos entre: definición y origen, autores clave y sus obras, ",
                   "debate o críticas, y cómo se aplica a mi caso (México). En total unos ", max(8, n * 2), " apuntes. ",
                   "Incluye tanto clásicos (los que se leían en los años 70: marxismo, funcionalismo, teoría del Estado) como enfoques actuales."),
    fuentes = paste0("Sugiere ", n, " fuentes (libros, artículos, documentos oficiales, bases de datos, archivos) para estudiar: ", peticion, ". Un tópico por fuente."))
  paste0(
    que, "\n\n",
    "Son apuntes para mi biblioteca de tesis. Responde EXACTAMENTE con este formato, sin Markdown, sin # y sin texto antes o después:\n\n",
    "[", categoria, "]\n[", tema, "]\n\n",
    if (tipo == "marco") "[tema]: concepto o teoría (la carpeta)\n" else "",
    "[topico]: nombre corto del tópico", if (tipo == "libro") " (p. ej. Capítulo 01: título)" else "", "\n",
    "[titulo]: título del apunte (máx. 12 palabras)\n",
    "[apunte]: explicación de 80 a 180 palabras en un solo párrafo\n",
    "[refs]: números de las referencias del bloque <referencias> que sustentan este apunte (p. ej. 1, 3), o N/A\n",
    "[para_mi_tesis]: una o dos frases sobre cómo puedo usar esto en mi tesis\n\n",
    "Reglas: separa cada apunte con UNA línea en blanco; numera capítulos con dos dígitos (01, 02…); ",
    "dentro de [apunte] cita en estilo Harvard (Apellido, año); después del último apunte pon el bloque <referencias> ",
    "con todas las fuentes numeradas (campo n). Un apunte sin fuente comprobable lleva [refs]: N/A y lo dice en el texto."
  )
}

# Force the first two bracket lines to the known Categoría / Tema (like overwrite_metadata_header)
overwrite_lib_header <- function(text, categoria, tema) {
  lines <- strsplit(text, "\n")[[1]]
  first <- which(grepl("^\\s*\\[topico\\]\\s*:", lines, ignore.case = TRUE))[1]
  if (is.na(first)) return(text)
  paste(c(paste0("[", categoria, "]"), paste0("[", tema, "]"), "", lines[first:length(lines)]), collapse = "\n")
}

# Parse bracket text -> data.frame of apuntes (like parse_summary_text); continuation lines are kept
parse_apuntes_text <- function(text, categoria = "", tema = "") {
  text <- sub("(?s)<referencias>.*$", "", text, perl = TRUE)      # the references block is handled apart
  lines <- strsplit(gsub("\r", "", text), "\n")[[1]]
  header <- character()
  for (ln in head(lines, 12)) {
    l <- trimws(ln)
    if (grepl("^\\[[^]]+\\]$", l)) header <- c(header, gsub("^\\[|\\]$", "", l))
    if (length(header) == 2) break
  }
  if (length(header) >= 1 && !nzchar(categoria)) categoria <- header[1]
  if (length(header) >= 2 && !nzchar(tema)) tema <- header[2]
  keymap <- c(topico = "topico", "tópico" = "topico", titulo = "titulo", "título" = "titulo", apunte = "contenido",
              fuente = "fuente", url = "url", para_mi_tesis = "para_tesis", refs = "refs_n", tema = "tema")
  entries <- list(); cur <- list(); last <- NULL
  flush <- function() {
    if (!is.null(cur$contenido) || !is.null(cur$titulo)) entries[[length(entries) + 1]] <<- cur
    cur <<- list(); last <<- NULL
  }
  for (ln in lines) {
    l <- trimws(ln)
    m <- regmatches(l, regexec("^\\[([^]]+)\\]\\s*:\\s*(.*)$", l))[[1]]
    if (length(m) == 3) {
      key <- keymap[tolower(m[2])]
      if (is.na(key)) next
      if (key %in% c("tema", "topico") && (!is.null(cur$contenido) || !is.null(cur$titulo) || (key == "topico" && !is.null(cur$topico)))) flush()
      val <- m[3]; if (toupper(val) %in% c("N/A", "NA")) val <- ""
      cur[[key]] <- val; last <- key
    } else if (nzchar(l) && !is.null(last) && last %in% c("contenido", "para_tesis") && !grepl("^\\[[^]]+\\]$", l)) {
      cur[[last]] <- paste(cur[[last]], l, sep = "\n")
    }
  }
  flush()
  if (!length(entries)) stop("No encontré apuntes en el texto. Cada apunte debe empezar con [topico]: …")
  df <- do.call(rbind, lapply(entries, function(e) data.frame(
    categoria = categoria, tema = if (nzchar(e$tema %||% "")) e$tema else tema, topico = e$topico %||% "General",
    titulo = e$titulo %||% (e$topico %||% "Apunte"), refs_n = e$refs_n %||% "",
    contenido = e$contenido %||% "", fuente = e$fuente %||% "", url = e$url %||% "", para_tesis = e$para_tesis %||% "",
    stringsAsFactors = FALSE)))
  if (!nzchar(categoria) || !nzchar(tema)) attr(df, "missing_header") <- TRUE
  df
}

# ---------------------------------------------------------------------------
# 3-level cascade Categoría > Tema > Tópico with "+ Nueva/Nuevo" (like genre_topic_dropdown_ui)
# ---------------------------------------------------------------------------
lib_cascade_ui <- function(ns, prefix, levels = 3, lib = NULL, defaults = list(), top_extra = NULL) {
  id <- function(x) ns(paste0(prefix, x))
  pick <- function(choices, want, new_label) {
    ch <- c(setNames(LIB_NEW, new_label), setNames(choices, choices))
    sel <- if (!is.null(want) && nzchar(want)) { if (want %in% choices) want else LIB_NEW } else if (length(choices)) choices[1] else LIB_NEW
    list(ch = ch, sel = sel, text = if (identical(sel, LIB_NEW)) want %||% "" else "")
  }
  cats <- if (!is.null(lib)) lib$categorias() else character()
  c1 <- pick(cats, defaults$categoria, "+ Nueva categoría…")
  temas <- if (!is.null(lib) && c1$sel != LIB_NEW) lib$temas(c1$sel) else character()
  c2 <- pick(temas, defaults$tema, "+ Nuevo tema…")
  tops <- if (!is.null(lib) && c1$sel != LIB_NEW && c2$sel != LIB_NEW) lib$topicos(c1$sel, c2$sel) else character()
  c3 <- pick(c(unname(top_extra), tops), defaults$topico, "+ Nuevo tópico…")
  if (length(top_extra)) { lab <- c3$ch; m <- match(top_extra, lab); names(lab)[m] <- names(top_extra); c3$ch <- lab }
  cond <- function(x) sprintf("input['%s'] == '%s'", id(x), LIB_NEW)
  tagList(
    div(class = "lib-cascade",
      div(class = "lib-level",
          selectInput(id("cat"), "📂 Categoría (el cajón):", choices = c1$ch, selected = c1$sel, width = "100%"),
          conditionalPanel(cond("cat"), textInput(id("cat_new"), NULL, value = c1$text, width = "100%", placeholder = "Nombre de la nueva categoría"))),
      div(class = "lib-level",
          selectInput(id("tema"), "📁 Tema (la carpeta):", choices = c2$ch, selected = c2$sel, width = "100%"),
          conditionalPanel(cond("tema"), textInput(id("tema_new"), NULL, value = c2$text, width = "100%", placeholder = "Nombre del nuevo tema"))),
      if (levels >= 3) div(class = "lib-level",
          selectInput(id("top"), "📄 Tópico (la hoja):", choices = c3$ch, selected = c3$sel, width = "100%"),
          conditionalPanel(cond("top"), textInput(id("top_new"), NULL, value = c3$text, width = "100%", placeholder = "Nombre del nuevo tópico")))
    )
  )
}

# Server side of lib_cascade_ui (like setup_genre_topic_cascade). Returns reactive list(categoria, tema, topico)
setup_lib_cascade <- function(input, session, tm, prefix, levels = 3, top_extra = NULL) {
  id <- function(x) paste0(prefix, x)
  keep_or <- function(cur, choices, fallback) if (!is.null(cur) && cur %in% c(LIB_NEW, choices)) cur else fallback

  observe({
    tm$lib_trigger()
    cats <- tm$lib$categorias()
    cur <- isolate(input[[id("cat")]])
    updateSelectInput(session, id("cat"), choices = c("+ Nueva categoría…" = LIB_NEW, setNames(cats, cats)),
                      selected = keep_or(cur, cats, cats[1]))
  })
  observe({
    tm$lib_trigger()
    cat <- input[[id("cat")]]; req(!is.null(cat))
    temas <- if (cat == LIB_NEW) character() else tm$lib$temas(cat)
    cur <- isolate(input[[id("tema")]])
    updateSelectInput(session, id("tema"), choices = c("+ Nuevo tema…" = LIB_NEW, setNames(temas, temas)),
                      selected = keep_or(cur, temas, if (length(temas)) temas[1] else LIB_NEW))
  })
  if (levels >= 3) observe({
    tm$lib_trigger()
    cat <- input[[id("cat")]]; tema <- input[[id("tema")]]; req(!is.null(cat), !is.null(tema))
    tops <- if (cat == LIB_NEW || tema == LIB_NEW) character() else tm$lib$topicos(cat, tema)
    cur <- isolate(input[[id("top")]])
    updateSelectInput(session, id("top"), choices = c("+ Nuevo tópico…" = LIB_NEW, top_extra, setNames(tops, tops)),
                      selected = keep_or(cur, c(unname(top_extra), tops), if (length(top_extra)) unname(top_extra)[1] else if (length(tops)) tops[1] else LIB_NEW))
  })

  reactive({
    val <- function(x) {
      s <- input[[id(x)]] %||% ""
      if (identical(s, LIB_NEW)) trimws(input[[id(paste0(x, "_new"))]] %||% "") else s
    }
    list(categoria = val("cat"), tema = val("tema"), topico = if (levels >= 3) val("top") else "")
  })
}

# Read the cascade values once (for modals, where no observers are attached)
read_lib_cascade <- function(input, prefix) {
  val <- function(x) {
    s <- input[[paste0(prefix, x)]] %||% ""
    if (identical(s, LIB_NEW)) trimws(input[[paste0(prefix, x, "_new")]] %||% "") else s
  }
  list(categoria = val("cat"), tema = val("tema"), topico = val("top"))
}
