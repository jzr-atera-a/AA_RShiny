# ============================================================================
# REFERENCIAS BIBLIOGRÁFICAS: formato Harvard + verificación
#
# Rule of the app: a reference is shown as ✔ VERIFICADA only when the app itself
# found evidence outside of Claude that the source exists:
#   - DOI / article  -> Crossref           (api.crossref.org)
#   - book           -> Open Library       (openlibrary.org), then Google Books, then Crossref
#   - web page       -> the exact URL was returned by Claude's web search in that answer,
#                       or the app opened the URL and the page title matches
#   - the user       -> "La revisé yo" (estado = manual)
# Everything else stays ⚠ SIN VERIFICAR, is clearly marked everywhere and is left out
# of the bibliography that goes to the thesis.
#
# Claude must end every answer with a machine-readable block:
#   <referencias>[{"n":1,"tipo":"libro","autores":"Carpizo, J.","anio":"1978","titulo":"…", …}]</referencias>
# The app removes the block from the text, verifies each entry and stores it in
# biblioteca/referencias.json (linked to the apuntes through their ids).
# ============================================================================

REF_FIELDS <- c("id", "creado", "tipo", "autores", "anio", "titulo", "contenedor", "editorial", "lugar",
                "volumen", "paginas", "url", "doi", "isbn", "harvard", "clave",
                "estado", "verificada_por", "evidencia", "detalle", "verificada_fecha")
REF_TIPOS <- c("Libro" = "libro", "Capítulo de libro" = "capitulo", "Artículo de revista" = "articulo",
               "Página web" = "web", "Documento oficial" = "documento_oficial")
REF_ESTADOS <- c(verificada = "✔ Verificada", manual = "✔ Revisada por mí", sin_verificar = "⚠ Sin verificar")

empty_refs <- function() as.data.frame(setNames(replicate(length(REF_FIELDS), character(), simplify = FALSE), REF_FIELDS), stringsAsFactors = FALSE)

# ------------------------------------------------------------------ text helpers
ref_norm <- function(x) {
  x <- tolower(iconv(x %||% "", "UTF-8", "ASCII//TRANSLIT", sub = ""))
  gsub("\\s+", " ", trimws(gsub("[^a-z0-9 ]", " ", x)))
}
REF_STOP <- c("el", "la", "los", "las", "de", "del", "en", "y", "un", "una", "the", "of", "and", "in", "a", "an", "para", "por", "con", "al", "su", "to", "on", "for")
ref_tokens <- function(x) { t <- strsplit(ref_norm(x), " ")[[1]]; unique(t[nchar(t) > 1 & !t %in% REF_STOP]) }

# How well a found title matches the wanted one (0..1): share of the wanted words that appear in
# the found title (0 when the found title is mostly about something else)
title_match <- function(wanted, found) {
  a <- ref_tokens(wanted); b <- ref_tokens(found)
  if (!length(a) || !length(b)) return(0)
  inter <- length(intersect(a, b))
  if (inter / length(b) < 0.4) return(0)      # the found title is about something much wider
  inter / length(a)
}
first_surname <- function(autores) {
  a <- trimws(strsplit(autores %||% "", ";| y | and |&")[[1]][1] %||% "")
  s <- trimws(strsplit(a, ",")[[1]][1] %||% a)
  ref_tokens(s)
}
author_match <- function(autores, found_authors) {
  s <- first_surname(autores)
  if (!length(s)) return(TRUE)                       # institutional / no author given
  any(s %in% ref_tokens(paste(found_authors, collapse = " ")))
}
norm_url <- function(u) sub("/+$", "", sub("^https?://(www\\.)?", "", tolower(trimws(sub("#.*$", "", u %||% "")))))

# ------------------------------------------------------------------ Harvard
ref_key <- function(r) {
  s <- trimws(strsplit(r$autores %||% "", ",")[[1]][1] %||% "")
  if (!nzchar(s)) s <- paste(utils::head(strsplit(r$titulo %||% "", " ")[[1]], 3), collapse = " ")
  n_aut <- length(strsplit(r$autores %||% "", ";| y | and |&")[[1]])
  sprintf("(%s%s, %s)", s, if (n_aut > 2) " et al." else "", if (nzchar(r$anio %||% "")) r$anio else "s.f.")
}
fecha_larga <- function(d = Sys.Date()) {
  meses <- c("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
  lt <- as.POSIXlt(d); sprintf("%d de %s de %d", lt$mday, meses[lt$mon + 1], lt$year + 1900)
}
# Harvard reference in Spanish. Markdown: *cursivas* for the title of the book / journal / page
format_harvard <- function(r) {
  g <- function(f) trimws(r[[f]] %||% "")
  aut <- if (nzchar(g("autores"))) g("autores") else if (nzchar(g("editorial"))) g("editorial") else "Anónimo"
  anio <- if (nzchar(g("anio"))) g("anio") else "s.f."
  dot <- function(x) if (nzchar(x)) paste0(sub("[.]+$", "", x), ".") else ""
  pub <- paste0(if (nzchar(g("lugar"))) paste0(g("lugar"), ": ") else "", g("editorial"))
  d <- tryCatch(as.Date(substr(g("creado"), 1, 10)), error = function(e) NA)
  if (is.na(d)) d <- Sys.Date()
  where <- if (nzchar(g("doi"))) paste0(" doi: ", g("doi"), ".")
           else if (nzchar(g("url"))) sprintf(" Disponible en: %s (Consultado: %s).", g("url"), fecha_larga(d))
           else ""
  out <- switch(g("tipo"),
    articulo = sprintf("%s (%s) ‘%s’, *%s*%s%s.", aut, anio, sub("[.]+$", "", g("titulo")), g("contenedor"),
                       if (nzchar(g("volumen"))) paste0(", ", g("volumen")) else "", if (nzchar(g("paginas"))) paste0(", pp. ", g("paginas")) else ""),
    capitulo = sprintf("%s (%s) ‘%s’, en *%s*. %s%s", aut, anio, sub("[.]+$", "", g("titulo")), g("contenedor"), dot(pub),
                       if (nzchar(g("paginas"))) paste0(" pp. ", g("paginas"), ".") else ""),
    libro = sprintf("%s (%s) *%s*. %s", aut, anio, sub("[.]+$", "", g("titulo")), dot(pub)),
    sprintf("%s (%s) *%s*. %s", aut, anio, sub("[.]+$", "", g("titulo")), if (!identical(aut, g("editorial"))) dot(g("editorial")) else ""))
  gsub("\\s+", " ", trimws(paste0(trimws(out), where)))
}

# ------------------------------------------------------------------ parse Claude's block
REF_INSTRUCTIONS <- function(search_on) paste0(
  "\n=== REFERENCIAS (obligatorio, estilo Harvard) ===\n",
  "- Toda idea, dato o definición tomada de una fuente lleva cita Harvard en el texto: (Apellido, año) o (Apellido, año, p. X).\n",
  if (search_on) "- Tienes búsqueda web: ÚSALA para encontrar y confirmar las fuentes antes de citarlas (catálogos de bibliotecas, editoriales, revistas académicas, sitios oficiales .gob.mx, universidades). Prefiere fuentes académicas y oficiales.\n" else "",
  "- Solo puedes citar: (a) páginas que encontraste con la búsqueda web en ESTA respuesta, con su URL exacta tal como apareció; ",
  "(b) libros o artículos cuya existencia conoces con total seguridad (autor, título y año exactos).\n",
  "- Si no estás completamente seguro de una fuente, NO la cites: di «falta fuente» y sugiere dónde buscarla. Nunca inventes autores, títulos, años, páginas, DOI, ISBN ni enlaces.\n",
  "- Termina SIEMPRE tu respuesta con este bloque exacto (JSON válido; si no citaste nada, deja []):\n",
  "<referencias>\n[{\"n\":1,\"tipo\":\"libro|capitulo|articulo|web|documento_oficial\",\"autores\":\"Apellido, N. y Apellido, N.\",\"anio\":\"1978\",",
  "\"titulo\":\"\",\"contenedor\":\"revista o libro que lo contiene (si aplica)\",\"editorial\":\"\",\"lugar\":\"\",\"volumen\":\"\",\"paginas\":\"\",\"url\":\"\",\"doi\":\"\",\"isbn\":\"\"}]\n</referencias>\n",
  "- No escribas una lista de referencias en ningún otro lugar: la aplicación la arma en formato Harvard y comprueba cada fuente; las que no pueda comprobar se marcan como «sin verificar».\n")

# Returns list(text = answer without the block, refs = list of entries)
extract_refs_block <- function(text) {
  m <- regmatches(text, regexpr("(?s)<referencias>.*?(</referencias>|$)", text, perl = TRUE))
  if (!length(m)) return(list(text = text, refs = list()))
  inner <- sub("(?s)^<referencias>\\s*", "", sub("\\s*</referencias>$", "", m, perl = TRUE), perl = TRUE)
  refs <- tryCatch(jsonlite::fromJSON(inner, simplifyVector = FALSE), error = function(e) extract_json(inner) %||% list())
  if (!is.null(refs$titulo)) refs <- list(refs)
  refs <- Filter(function(r) is.list(r) && nzchar(trimws(as.character(r$titulo %||% ""))), refs)
  clean <- trimws(sub("(?s)<referencias>.*?(</referencias>|$)", "", text, perl = TRUE))
  clean <- trimws(sub("(?si)\\n+#{0,4}\\s*\\**referencias\\**:?\\s*$", "", clean, perl = TRUE))
  list(text = clean, refs = refs)
}

# ------------------------------------------------------------------ HTTP (mockable for tests)
http_get <- function(url, query = NULL, as_json = TRUE, timeout = 12) {
  mock <- getOption("tesis.http_mock")
  if (is.function(mock)) return(mock(url, query, as_json))
  res <- tryCatch(httr::GET(url, query = query, httr::timeout(timeout),
                            httr::user_agent("MiTesis/1.3 (R httr; verificacion de referencias)")),
                  error = function(e) NULL)
  if (is.null(res)) return(list(status = 0, body = NULL))
  body <- tryCatch(if (as_json) jsonlite::fromJSON(httr::content(res, "text", encoding = "UTF-8"), simplifyVector = FALSE)
                   else httr::content(res, "text", encoding = "UTF-8"), error = function(e) NULL)
  list(status = httr::status_code(res), body = body)
}

# ------------------------------------------------------------------ verifiers. Each returns NULL or
# list(por, evidencia, detalle, fill = list(fields to complete when empty))
verify_crossref_doi <- function(r) {
  doi <- sub("^https?://(dx\\.)?doi\\.org/", "", trimws(r$doi))
  x <- http_get(paste0("https://api.crossref.org/works/", utils::URLencode(doi, reserved = FALSE)))
  it <- x$body$message
  if (x$status != 200 || is.null(it)) return(NULL)
  ttl <- paste(unlist(it$title), collapse = " ")
  if (title_match(r$titulo, ttl) < 0.6) return(list(fail = sprintf("El DOI existe pero corresponde a otro título: «%s».", substr(ttl, 1, 90))))
  list(por = "Crossref (DOI)", evidencia = paste0("https://doi.org/", doi), detalle = paste0("Registro: ", substr(ttl, 1, 120)),
       fill = list(contenedor = paste(unlist(it$`container-title`), collapse = " "), editorial = it$publisher %||% ""))
}
verify_crossref_search <- function(r, min_match = 0.85) {
  q <- paste(r$titulo, paste(first_surname(r$autores), collapse = " "))
  x <- http_get("https://api.crossref.org/works", list(query.bibliographic = q, rows = 5,
                select = "DOI,title,author,issued,container-title,publisher,type,URL"))
  for (it in x$body$message$items %||% list()) {
    ttl <- paste(unlist(it$title), collapse = " ")
    aut <- vapply(it$author %||% list(), function(a) paste(a$family %||% "", a$name %||% ""), "")
    if (title_match(r$titulo, ttl) >= min_match && author_match(r$autores, aut)) {
      return(list(por = "Crossref", evidencia = paste0("https://doi.org/", it$DOI), detalle = paste0("Registro: ", substr(ttl, 1, 120)),
                  fill = list(doi = it$DOI %||% "", contenedor = paste(unlist(it$`container-title`), collapse = " "), editorial = it$publisher %||% "")))
    }
  }
  NULL
}
verify_openlibrary <- function(r) {
  x <- http_get("https://openlibrary.org/search.json", list(title = r$titulo, author = paste(first_surname(r$autores), collapse = " "),
                limit = 5, fields = "key,title,subtitle,author_name,first_publish_year,isbn,publisher"))
  docs <- x$body$docs %||% list()
  if (!length(docs)) {          # some records lack the author: try with the title only
    x <- http_get("https://openlibrary.org/search.json", list(title = r$titulo, limit = 5,
                  fields = "key,title,subtitle,author_name,first_publish_year,isbn,publisher"))
    docs <- x$body$docs %||% list()
  }
  for (d in docs) {
    ttl <- paste(d$title %||% "", d$subtitle %||% "")
    if (title_match(r$titulo, ttl) >= 0.75 && author_match(r$autores, unlist(d$author_name))) {
      return(list(por = "Open Library", evidencia = paste0("https://openlibrary.org", d$key),
                  detalle = sprintf("Registro: %s — %s%s", d$title, paste(unlist(d$author_name), collapse = ", "),
                                    if (!is.null(d$first_publish_year)) paste0(" (1.ª publicación: ", d$first_publish_year, ")") else ""),
                  fill = list(isbn = (unlist(d$isbn) %||% "")[1], editorial = (unlist(d$publisher) %||% "")[1])))
    }
  }
  NULL
}
verify_googlebooks <- function(r) {
  s <- paste(first_surname(r$autores), collapse = " ")
  x <- http_get("https://www.googleapis.com/books/v1/volumes",
                list(q = paste0("intitle:", r$titulo, if (nzchar(s)) paste0(" inauthor:", s) else ""), maxResults = 5))
  for (it in x$body$items %||% list()) {
    v <- it$volumeInfo
    ttl <- paste(v$title %||% "", v$subtitle %||% "")
    if (title_match(r$titulo, ttl) >= 0.75 && author_match(r$autores, unlist(v$authors))) {
      ids <- v$industryIdentifiers %||% list()
      return(list(por = "Google Books", evidencia = v$infoLink %||% it$selfLink %||% "",
                  detalle = sprintf("Registro: %s — %s", v$title, paste(unlist(v$authors), collapse = ", ")),
                  fill = list(isbn = if (length(ids)) ids[[1]]$identifier %||% "" else "", editorial = v$publisher %||% "")))
    }
  }
  NULL
}
# A web page: opens and its <title>/<h1> shares the words of the reference title
verify_url <- function(r, search_urls = character(), search_titles = character()) {
  u <- trimws(r$url)
  if (!grepl("^https?://", u)) return(list(fail = "El enlace no es una dirección web válida."))
  hit <- match(norm_url(u), norm_url(search_urls))
  if (!is.na(hit)) {
    return(list(por = "Búsqueda web de Claude", evidencia = u,
                detalle = paste0("La página apareció en los resultados de la búsqueda: «", substr(search_titles[hit] %||% "", 1, 100), "»."), fill = list()))
  }
  x <- http_get(u, as_json = FALSE, timeout = 15)
  if (x$status == 0) return(list(fail = "No se pudo abrir el enlace (sin conexión o el sitio no respondió)."))
  if (x$status >= 400) return(list(fail = sprintf("El enlace no abre (error %s).", x$status)))
  html <- substr(x$body %||% "", 1, 200000)
  page_title <- paste(regmatches(html, regexpr("(?is)<title[^>]*>.*?</title>", html, perl = TRUE)),
                      regmatches(html, regexpr("(?is)<h1[^>]*>.*?</h1>", html, perl = TRUE)))
  page_title <- gsub("<[^>]+>", " ", page_title)
  a <- ref_tokens(r$titulo); b <- ref_tokens(paste(page_title, collapse = " "))
  if (length(a) && length(intersect(a, b)) / length(a) >= 0.5) {
    return(list(por = "Enlace comprobado", evidencia = u, detalle = paste0("La página abre y su título coincide: «", substr(trimws(page_title[1]), 1, 100), "»."), fill = list()))
  }
  list(fail = "El enlace abre, pero el título de la página no coincide con la referencia. Revísela usted.")
}

# Offline stand-in for automated tests (TESIS_MOCK_CLAUDE=1): titles with "inventado" are not found
verify_mock <- function(r) {
  if (grepl("inventad", r$titulo, ignore.case = TRUE)) return(list(fail = "No se encontró en Open Library, Google Books ni Crossref."))
  list(por = "Open Library", evidencia = "https://openlibrary.org/works/OL000W", detalle = "Registro de prueba", fill = list())
}

# Main entry: r is a one-row list. Returns the fields estado / verificada_por / evidencia / detalle (+ completed fields)
verify_reference <- function(r, search_urls = character(), search_titles = character()) {
  r <- lapply(r, function(v) trimws(as.character(v %||% "")))
  res <- NULL; fails <- character()
  try_it <- function(f, ...) {
    if (!is.null(res)) return()
    out <- tryCatch(f(r, ...), error = function(e) NULL)
    if (!is.null(out$fail)) fails <<- c(fails, out$fail) else if (!is.null(out)) res <<- out
  }
  if (identical(Sys.getenv("TESIS_MOCK_CLAUDE"), "1") && !is.function(getOption("tesis.http_mock"))) {
    try_it(verify_mock)
  } else {
    if (nzchar(r$doi)) try_it(verify_crossref_doi)
    if (r$tipo %in% c("libro", "capitulo")) {
      if (r$tipo == "capitulo" && nzchar(r$contenedor)) { rb <- r; rb$titulo <- r$contenedor; if (is.null(res)) res <- tryCatch(verify_openlibrary(rb), error = function(e) NULL) }
      try_it(verify_openlibrary); try_it(verify_googlebooks); try_it(verify_crossref_search)
    } else if (r$tipo == "articulo") {
      try_it(verify_crossref_search)
    }
    if (nzchar(r$url)) try_it(verify_url, search_urls, search_titles)
    if (is.null(res) && !(r$tipo %in% c("libro", "capitulo", "articulo"))) { try_it(verify_crossref_search); try_it(verify_openlibrary) }
  }
  if (!is.null(res)) {
    out <- list(estado = "verificada", verificada_por = res$por, evidencia = res$evidencia %||% "", detalle = res$detalle %||% "",
                verificada_fecha = now_str())
    for (f in names(res$fill)) if (!nzchar(r[[f]] %||% "") && nzchar(res$fill[[f]] %||% "")) out[[f]] <- res$fill[[f]]
    return(out)
  }
  list(estado = "sin_verificar", verificada_por = "", evidencia = "",
       detalle = if (length(fails)) paste(unique(fails), collapse = " ") else
         "No se encontró en Open Library, Google Books ni Crossref. Puede ser una fuente real que no está en esos catálogos: búsquela usted antes de usarla.",
       verificada_fecha = now_str())
}

# One reference as a UI line with its badge
ref_line <- function(r, compact = FALSE) {
  ok <- r$estado %in% c("verificada", "manual")
  div(class = paste("ref-line", if (ok) "ok" else "bad"),
      span(class = paste("ref-badge", if (ok) "ok" else "bad"), REF_ESTADOS[[r$estado]] %||% r$estado),
      span(class = "ref-text", md_inline(r$harvard)),
      if (!compact && ok && nzchar(r$evidencia) && grepl("^https?://", r$evidencia))
        tags$a(class = "ref-ev", href = r$evidencia, target = "_blank", title = r$detalle, icon("external-link-alt"), " ", r$verificada_por),
      if (!compact && !ok) div(class = "ref-why", icon("exclamation-triangle"), " ", r$detalle, " ", tags$b("No la use en la tesis hasta comprobarla.")))
}
md_inline <- function(x) HTML(gsub("\\*(.+?)\\*", "<i>\\1</i>", htmltools::htmlEscape(x %||% "")))
