# ============================================================================
# UI HELPERS shared by the modules
#   - run_claude(): calls Claude with a progress message and friendly errors
#   - feedback cards + panel server (list, follow-up questions, delete, use correction)
#   - js_btn(): button that sends {id, action} to Shiny (see www/js/app.js)
# ============================================================================

# Button that fires input[[input_id]] = list(id, action) through app.js
js_btn <- function(label, input_id, id, action, class = "btn-default", title = NULL, icon_name = NULL) {
  tags$button(type = "button", class = paste("btn js-evt", class), title = title,
              `data-input` = input_id, `data-id` = id, `data-action` = action,
              if (!is.null(icon_name)) icon(icon_name), label)
}

go_to_tab <- function(parent_session, tab) {
  shinydashboard::updateTabItems(parent_session, "sidebar_menu", selected = tab)
}

# Modal shown when Claude is not ready
claude_not_ready_modal <- function(ns, msg) {
  showModal(modalDialog(
    title = "Falta conectar a Claude",
    div(class = "big-message", p(msg),
        p("La conexión la hace el administrador en la pestaña ", tags$b("Administrador → Conexión con Claude"), "."),
        p("Si usted no es el administrador, avísele (por ejemplo, a Paco).")),
    footer = tagList(modalButton("Cerrar"),
                     actionButton(ns("goto_claude"), "Ir a Administrador", class = "btn-primary")),
    easyClose = TRUE
  ))
}

# Runs fn() (which calls Claude) with a progress bar. Returns its value, or NULL on error.
run_claude <- function(session, tm, fn, message = "Claude está leyendo y pensando…") {
  ns <- session$ns
  if (!tm$claude$has_key() || !tm$claude$connected) {
    claude_not_ready_modal(ns, if (!tm$claude$has_key()) "Todavía no hay una clave de Claude guardada." else "Claude todavía no está conectado.")
    return(NULL)
  }
  withProgress(message = message, detail = "Esto puede tardar entre 10 segundos y un par de minutos.", value = 0.3, {
    tryCatch({
      out <- fn()
      setProgress(1)
      out
    }, error = function(e) {
      tm$log("Claude error: ", conditionMessage(e))
      showModal(modalDialog(
        title = "No se pudo obtener la respuesta de Claude",
        div(class = "big-message", p(conditionMessage(e))),
        footer = modalButton("Entendido"), easyClose = TRUE
      ))
      NULL
    })
  })
}

ACTION_LABELS <- c(review = "Revisión", start = "Cómo empezar / seguir", correct = "Corrección de estilo",
                   question = "Pregunta", sources = "Fuentes sugeridas", idea = "Opinión sobre la idea",
                   topics = "Temas sugeridos", library = "Apuntes", marco = "Marco teórico", marco_draft = "Guía de redacción", outline_review = "Revisión del bosquejo",
                   outline_propose = "Bosquejo propuesto", coherence = "Coherencia introducción–conclusiones")

# One stored Claude answer (with its follow-up conversation)
feedback_card <- function(fb, input_id, show_part = FALSE, in_lib = FALSE, refs = NULL) {
  msgs <- fb$messages
  answers <- which(vapply(msgs, function(m) identical(m$role, "assistant"), logical(1)))
  last <- msgs[[answers[length(answers)]]]$content
  is_correct <- identical(fb$action, "correct")
  shown <- if (is_correct) {
    corr <- extract_tag(last, "texto_corregido")
    rest <- sub("(?s)<texto_corregido>.*?</texto_corregido>", "", last, perl = TRUE)
    tagList(if (!is.null(corr)) div(class = "corrected-text", corr), md_html(rest))
  } else md_html(last)

  # earlier turns of the conversation (follow-up questions)
  history <- NULL
  if (length(msgs) > 2) {
    turns <- msgs[3:(length(msgs) - 1)]
    history <- tags$details(class = "fb-history",
      tags$summary(sprintf("Ver la conversación completa (%d mensajes)", length(msgs))),
      div(md_html(msgs[[2]]$content)),
      lapply(turns, function(m) div(class = if (m$role == "user") "fb-q" else "fb-a",
                                    if (m$role == "user") tagList(tags$b("Usted preguntó: "), m$content) else md_html(m$content))))
    q <- msgs[[length(msgs) - 1]]$content
    shown <- tagList(div(class = "fb-q", tags$b("Usted preguntó: "), q), shown)
  }

  div(class = paste("fb-card", paste0("fb-", fb$action)),
      div(class = "fb-head",
          span(class = "fb-tag", ACTION_LABELS[[fb$action]] %||% fb$action),
          span(class = "fb-title", fb$title),
          span(class = "fb-time", fmt_fecha(fb$time))),
      div(class = "fb-body", shown),
      refs_box(refs, fb),
      history,
      div(class = "fb-actions",
          if (is_correct) js_btn(" Usar esta versión corregida", input_id, fb$id, "use", "btn-success", icon_name = "check"),
          js_btn(" Seguir conversando", input_id, fb$id, "followup", "btn-primary", icon_name = "comments"),
          if (in_lib) js_btn(" Ya está en mi biblioteca", input_id, fb$id, "library", "btn-default lib-saved", icon_name = "book")
          else js_btn(" Guardar en mi biblioteca", input_id, fb$id, "library", "btn-warning", icon_name = "book"),
          js_btn(" Borrar", input_id, fb$id, "delete", "btn-default fb-del", icon_name = "trash")))
}

# Server side of a feedback list. keys_fun(): reactive returning the feedback keys to show (NULL = all of the tab).
# on_use(fb, corrected_text): called when the user accepts a corrected text.
feedback_panel_server <- function(input, output, session, tm, tab, keys_fun, output_id = "feedback",
                                  on_use = NULL, empty_msg = "Aquí aparecerán los comentarios de Claude.",
                                  part_fun = NULL) {
  ns <- session$ns
  lib_dest_server(input, output, session, tm, tab, output_id, part_fun)
  evt <- paste0(output_id, "_evt")
  current_fb <- reactiveVal(NULL)

  output[[output_id]] <- renderUI({
    tm$fb_trigger(); tm$proj_trigger()
    fbs <- tm$feedback_for(keys = keys_fun(), tab = tab)
    if (!length(fbs)) return(div(class = "empty-state small", empty_msg))
    tm$lib_trigger()
    tagList(lapply(fbs, function(fb) feedback_card(fb, input_id = ns(evt), in_lib = length(tm$lib$from_feedback(fb$id)) > 0,
                                                    refs = tm$lib$get_refs(unlist(fb$refs)))))
  })

  lb <- paste0(output_id, "_lb_")
  setup_lib_cascade(input, session, tm, lb, levels = 3)

  observeEvent(input[[evt]], {
    e <- input[[evt]]
    i <- tm$feedback_index(e$id)
    if (is.na(i)) return()
    fb <- tm$project$feedback[[i]]
    if (identical(e$action, "delete")) {
      current_fb(fb$id)
      showModal(modalDialog(title = "¿Borrar este comentario?",
                            p("Se quita de la lista. (La copia en la carpeta “retroalimentacion” se conserva.)"),
                            footer = tagList(modalButton("Cancelar"),
                                             actionButton(ns(paste0(output_id, "_del_ok")), "Sí, borrar", class = "btn-danger")),
                            easyClose = TRUE))
    } else if (identical(e$action, "followup")) {
      current_fb(fb$id)
      showModal(modalDialog(
        title = "Seguir conversando con Claude", size = "l", easyClose = TRUE,
        p(class = "wm-hint", "Claude recuerda esta conversación. Escriba su pregunta o comentario:"),
        textAreaInput(ns(paste0(output_id, "_fu_text")), NULL, rows = 5, width = "100%",
                      placeholder = "Por ejemplo: ¿Me puede dar un ejemplo de cómo delimitar mejor el periodo?"),
        footer = tagList(modalButton("Cancelar"),
                         actionButton(ns(paste0(output_id, "_fu_send")), "Enviar a Claude", class = "btn-success btn-big", icon = icon("paper-plane")))
      ))
    } else if (identical(e$action, "library")) {
      current_fb(fb$id)
      tema_def <- TAB_TOPICS[[fb$tab]] %||% "Preguntas generales"
      top_def <- if (grepl(" — ", fb$title, fixed = TRUE)) sub("^.*? — ", "", fb$title) else ACTION_LABELS[[fb$action]] %||% "General"
      ttl <- sub(" — .*$", "", fb$title)
      ya <- length(tm$lib$from_feedback(fb$id)) > 0
      showModal(modalDialog(
        title = "📚 Guardar esta respuesta en mi biblioteca", size = "l", easyClose = TRUE,
        if (ya) div(class = "places-pending", "Esta respuesta ya está guardada en su biblioteca. Si la guarda otra vez quedará repetida."),
        fluidRow(
          column(6, lib_cascade_ui(ns, lb, 3, tm$lib, list(categoria = "Mi tesis", tema = tema_def, topico = top_def))),
          column(6,
            textInput(ns(paste0(lb, "titulo")), "Título del apunte:", value = ttl, width = "100%"),
            selectizeInput(ns(paste0(lb, "tags")), "Etiquetas (opcional):", choices = tm$lib$all_tags(), multiple = TRUE,
                           width = "100%", options = list(create = TRUE, placeholder = "Escriba y presione Enter")),
            textAreaInput(ns(paste0(lb, "nota")), "Mi nota (opcional):", rows = 2, width = "100%",
                          placeholder = "p. ej. Usar en el capítulo 2"),
            checkboxInput(ns(paste0(lb, "star")), "⭐ Marcar como importante", FALSE))),
        footer = tagList(modalButton("Cancelar"),
                         actionButton(ns(paste0(output_id, "_lb_save")), "Guardar en mi biblioteca", class = "btn-success", icon = icon("save")))))
    } else if (identical(e$action, "use") && !is.null(on_use)) {
      last <- fb$messages[[length(fb$messages)]]$content
      corr <- extract_tag(last, "texto_corregido")
      if (is.null(corr)) { showNotification("No se encontró el texto corregido en la respuesta.", type = "error"); return() }
      current_fb(fb$id)
      showModal(modalDialog(title = "¿Usar la versión corregida?",
        div(class = "big-message",
            p("Su texto actual se reemplazará por la versión corregida de Claude."),
            p("Antes se guarda una copia de su texto actual en ", tags$b("Versiones"), ", así que puede regresar a él.")),
        footer = tagList(modalButton("Cancelar"),
                         actionButton(ns(paste0(output_id, "_use_ok")), "Sí, usar la versión corregida", class = "btn-success")),
        easyClose = TRUE))
    }
  })

  observeEvent(input[[paste0(output_id, "_del_ok")]], {
    removeModal(); tm$delete_feedback(current_fb())
  })

  observeEvent(input[[paste0(output_id, "_fu_send")]], {
    q <- trimws(input[[paste0(output_id, "_fu_text")]] %||% "")
    if (!nzchar(q)) { showNotification("Escriba primero su pregunta.", type = "warning"); return() }
    removeModal()
    run_claude(session, tm, function() tm$follow_up(current_fb(), q))
  })

  observeEvent(input[[paste0(output_id, "_lb_save")]], {
    i <- tm$feedback_index(current_fb()); if (is.na(i)) return()
    fb <- tm$project$feedback[[i]]
    t <- read_lib_cascade(input, lb)
    if (!nzchar(t$categoria) || !nzchar(t$tema) || !nzchar(t$topico)) { showNotification("Elija o escriba la categoría, el tema y el tópico.", type = "warning"); return() }
    tm$lib$add(data.frame(categoria = t$categoria, tema = t$tema, topico = t$topico,
                          titulo = trimws(input[[paste0(lb, "titulo")]] %||% fb$title), contenido = fb_content(fb),
                          tipo = "claude", origen = fb$id, refs = paste(unlist(fb$refs), collapse = ", "),
                          nota = trimws(input[[paste0(lb, "nota")]] %||% ""),
                          etiquetas = paste(input[[paste0(lb, "tags")]] %||% character(), collapse = ", "),
                          importante = isTRUE(input[[paste0(lb, "star")]]),
                          parte_tesis = PART_FROM_TAB[[fb$tab]] %||% "", stringsAsFactors = FALSE))
    removeModal()
    showNotification(sprintf("📚 Guardado en %s › %s › %s", t$categoria, t$tema, t$topico), type = "message", duration = 6)
  })

  observeEvent(input[[paste0(output_id, "_use_ok")]], {
    removeModal()
    i <- tm$feedback_index(current_fb()); if (is.na(i)) return()
    fb <- tm$project$feedback[[i]]
    corr <- extract_tag(fb$messages[[length(fb$messages)]]$content, "texto_corregido")
    on_use(fb, corr)
  })

  invisible(NULL)
}

# References of an answer (Harvard) with their verification badge
refs_box <- function(refs, fb = NULL, title = "Referencias (Harvard)") {
  searched <- if (!is.null(fb) && (fb$searches %||% 0) > 0) span(class = "ref-note", icon("search"), sprintf(" Claude buscó %d vez/veces en la web", fb$searches))
              else if (!is.null(fb) && isTRUE(fb$search_unavailable)) span(class = "ref-note bad", icon("exclamation-triangle"), " La búsqueda web no está activada en la cuenta de Claude")
  if (is.null(refs) || !nrow(refs)) return(if (!is.null(searched)) div(class = "fb-refs", searched))
  bad <- sum(refs$estado == "sin_verificar")
  div(class = "fb-refs",
      div(class = "fb-refs-title", icon("book"), " ", title, searched),
      lapply(seq_len(nrow(refs)), function(i) ref_line(refs[i, ])),
      if (bad) div(class = "ref-warning", icon("exclamation-triangle"),
                   sprintf(" %d fuente(s) no se pudieron comprobar. No las use en la tesis hasta revisarlas usted (Mi biblioteca → Referencias).", bad)))
}

# Text of a stored Claude conversation as it goes into the library
fb_content <- function(fb) {
  msgs <- fb$messages
  answers <- which(vapply(msgs, function(m) identical(m$role, "assistant"), logical(1)))
  contenido <- if (length(answers) > 1) paste(vapply(answers, function(k) {
    q <- if (k > 1) msgs[[k - 1]]$content else ""
    paste0(if (k > 2) paste0("**Pregunta:** ", q, "\n\n") else "", msgs[[k]]$content)
  }, character(1)), collapse = "\n\n---\n\n") else msgs[[answers[1]]]$content
  trimws(sub("(?s)<texto_corregido>.*?</texto_corregido>", "", contenido, perl = TRUE))
}

# ---------------------------------------------------------------------------
# "¿Dónde guardo las respuestas de Claude de esta sección?"
# Categoría / Tema / Tópico menus (like the Genre/Topic menus of the books app) shown in every
# section that receives Claude answers. With "Guardar automáticamente" ticked, each new answer
# of the section goes straight to Mi biblioteca there; follow-up questions update that apunte.
# The choice is remembered per section (config$lib_dest).
# ---------------------------------------------------------------------------
LIB_PART <- "__PARTE__"

lib_dest_ui <- function(ns, output_id = "feedback") uiOutput(ns(paste0(output_id, "_dest")))

lib_dest_server <- function(input, output, session, tm, tab, output_id, part_fun = NULL) {
  ns <- session$ns
  pre <- paste0(output_id, "_d_")
  top_extra <- if (!is.null(part_fun)) c("✎ La parte que estoy escribiendo" = LIB_PART) else NULL
  setup_lib_cascade(input, session, tm, pre, levels = 3, top_extra = top_extra)

  saved <- function() tm$config$lib_dest[[tab]] %||% list()
  output[[paste0(output_id, "_dest")]] <- renderUI({
    d <- isolate(saved())
    defaults <- list(categoria = d$categoria %||% "Mi tesis", tema = d$tema %||% (TAB_TOPICS[[tab]] %||% "Preguntas generales"),
                     topico = d$topico %||% (if (!is.null(part_fun)) LIB_PART else "Preguntas"))
    tags$details(class = "lib-dest", open = if (is.null(d$auto)) NA else NULL,
      tags$summary(icon("book"), " ¿Dónde guardo las respuestas de Claude? ", uiOutput(ns(paste0(output_id, "_dest_sum")), inline = TRUE)),
      checkboxInput(ns(paste0(pre, "auto")), HTML("<b>Guardar automáticamente</b> cada respuesta de esta sección en mi biblioteca"),
                    value = !identical(d$auto, FALSE)),
      lib_cascade_ui(ns, pre, 3, isolate(tm$lib), defaults, top_extra = top_extra),
      div(class = "wm-hint", "Si no marca la casilla, puede guardar cada respuesta con su botón “Guardar en mi biblioteca”."))
  })

  dest <- reactive({
    v <- read_lib_cascade(input, pre)
    list(auto = isTRUE(input[[paste0(pre, "auto")]]), categoria = v$categoria, tema = v$tema, topico = v$topico)
  })
  resolve <- function(d) {
    if (identical(d$topico, LIB_PART) && !is.null(part_fun)) d$topico <- tryCatch(part_fun(), error = function(e) "General")
    d
  }
  output[[paste0(output_id, "_dest_sum")]] <- renderUI({
    d <- dest(); if (!nzchar(d$categoria)) return(NULL)
    top <- if (identical(d$topico, LIB_PART)) "(la parte que escribo)" else d$topico
    span(class = if (d$auto) "lib-dest-on" else "lib-dest-off",
         if (d$auto) sprintf("→ %s › %s › %s", d$categoria, d$tema, top) else "(solo con el botón)")
  })

  # remember the choice for this section
  observeEvent(dest(), {
    d <- dest(); if (!nzchar(d$categoria) || is.null(input[[paste0(pre, "auto")]])) return()
    if (!identical(d, saved()[names(d)])) { tm$config$lib_dest[[tab]] <- d; tm$save_config() }
  }, ignoreInit = TRUE)

  # watch for new answers (and follow-ups) of this section
  count_msgs <- function() {
    fbs <- Filter(function(f) identical(f$tab, tab), tm$project$feedback %||% list())
    setNames(vapply(fbs, function(f) length(f$messages), integer(1)), vapply(fbs, function(f) f$id, ""))
  }
  seen <- reactiveVal(isolate(count_msgs()))
  observeEvent(tm$fb_trigger(), {
    now <- count_msgs(); old <- seen(); seen(now)
    d <- resolve(isolate(dest()))
    for (id in names(now)) {
      fb <- tm$project$feedback[[tm$feedback_index(id)]]
      in_lib <- tm$lib$from_feedback(id)
      if (!(id %in% names(old))) {                         # a new answer
        if (!d$auto || !nzchar(d$categoria) || !nzchar(d$tema) || !nzchar(d$topico) || length(in_lib)) next
        tm$lib$add(data.frame(categoria = d$categoria, tema = d$tema, topico = d$topico, titulo = sub(" — .*$", "", fb$title),
                              contenido = fb_content(fb), tipo = "claude", origen = id, refs = paste(unlist(fb$refs), collapse = ", "),
                              parte_tesis = PART_FROM_TAB[[tab]] %||% "", stringsAsFactors = FALSE))
        showNotification(sprintf("📚 Guardado en su biblioteca: %s › %s › %s", d$categoria, d$tema, d$topico), type = "message", duration = 5)
      } else if (now[[id]] > old[[id]] && length(in_lib)) {   # follow-up: update the saved apunte
        for (ap in in_lib) tm$lib$update(ap, contenido = fb_content(fb), refs = paste(unlist(fb$refs), collapse = ", "))
      }
    }
  }, ignoreInit = TRUE)
}

# Default Tema / thesis part when saving a Claude answer from each tab
TAB_TOPICS <- list(claude_api = "Preguntas generales", guia_tesis = "Cómo hacer la tesis", ideas = "Mis ideas y temas",
                   bosquejo = "Bosquejo", introduccion = "Introducción", capitulos = "Capítulos", conclusion = "Conclusiones")
PART_FROM_TAB <- list(introduccion = "Introducción", conclusion = "Conclusiones")

# Observers every module needs once (the "go to Claude tab" button of the modal above)
setup_common <- function(input, parent_session) {
  observeEvent(input$goto_claude, { removeModal(); go_to_tab(parent_session, "admin_settings") })
}

# "Ask Claude anything" box
ask_box_ui <- function(ns, id = "ask", placeholder = "Escriba aquí su pregunta para Claude…", rows = 3) {
  div(class = "ask-box",
      textAreaInput(ns(paste0(id, "_text")), "Pregúntele a Claude:", rows = rows, width = "100%", placeholder = placeholder),
      actionButton(ns(paste0(id, "_send")), "Preguntar", class = "btn-primary btn-big", icon = icon("paper-plane"),
                   style = "width: 100%;"))
}
