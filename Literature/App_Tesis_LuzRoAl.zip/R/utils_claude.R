# ============================================================================
# CLAUDE CLIENT - R6 CLASS
# Same approach as APIManager in Modular_db_books_llm (httr POST to the
# Messages API, configurable model / max tokens / timeout, friendly errors),
# extended with: system prompt, multi-turn messages, usage counters and
# messages in Spanish.
# ============================================================================

CLAUDE_URL <- "https://api.anthropic.com/v1/messages"

CLAUDE_MODELS <- c(
  "Claude Sonnet 5.5 (recomendado: rápido y muy bueno)" = "claude-sonnet-5-5",
  "Claude Opus 5.5 (el más capaz, más lento)" = "claude-opus-5-5",
  "Claude Haiku 5.5 (el más rápido y económico)" = "claude-haiku-5-5",
  "Claude Sonnet 4.6 (versión anterior)" = "claude-sonnet-4-6",
  "Otro modelo (escribirlo abajo)" = "__other__"
)

ClaudeClient <- R6::R6Class(
  "ClaudeClient",
  public = list(
    api_key = NULL,
    model = "claude-sonnet-5-5",
    max_tokens = 4000,
    timeout = 300,
    connected = FALSE,
    last_error = NULL,
    last_test = NULL,
    calls = 0L,
    tokens_in = 0,
    tokens_out = 0,
    searches = 0L,
    mock = FALSE,          # TRUE only for offline testing (env var TESIS_MOCK_CLAUDE=1)

    initialize = function() {
      self$mock <- identical(Sys.getenv("TESIS_MOCK_CLAUDE"), "1")
    },

    set_credentials = function(api_key = NULL, model = NULL, max_tokens = NULL, timeout = NULL) {
      if (!is.null(api_key)) {
        key <- trimws(api_key)
        if (!identical(key, self$api_key)) self$connected <- FALSE
        self$api_key <- key
      }
      if (!is.null(model) && nzchar(model)) self$model <- model
      if (!is.null(max_tokens) && !is.na(max_tokens)) self$max_tokens <- as.integer(max_tokens)
      if (!is.null(timeout) && !is.na(timeout)) self$timeout <- as.integer(timeout)
      invisible(self)
    },

    has_key = function() !is.null(self$api_key) && nzchar(self$api_key),

    masked_key = function() {
      if (!self$has_key()) return("(sin clave)")
      k <- self$api_key
      paste0(substr(k, 1, 10), "…", substr(k, max(1, nchar(k) - 3), nchar(k)))
    },

    # Short call to check key + model
    test = function() {
      res <- self$chat(system = "Responde solo con la palabra: listo",
                       messages = list(list(role = "user", content = "Prueba de conexión.")),
                       max_tokens = 20, require_connected = FALSE)
      self$connected <- TRUE
      self$last_test <- Sys.time()
      res
    },

    # One POST to the Messages API. Returns the parsed body or stops with a message in Spanish.
    post = function(body) {
      response <- tryCatch(
        httr::POST(
          url = CLAUDE_URL,
          httr::add_headers(
            "x-api-key" = self$api_key,
            "anthropic-version" = "2023-06-01",
            "content-type" = "application/json"
          ),
          body = jsonlite::toJSON(body, auto_unbox = TRUE, null = "null"),
          encode = "raw",
          httr::timeout(self$timeout)
        ),
        error = function(e) {
          msg <- conditionMessage(e)
          self$last_error <- msg
          if (grepl("timeout|timed out", msg, ignore.case = TRUE)) {
            stop(sprintf("Claude tardó más de %s segundos en responder. Intente de nuevo, o aumente el tiempo de espera en Administrador → Conexión con Claude.", self$timeout))
          }
          stop(paste0("No se pudo conectar con Claude. Revise que la computadora tenga internet. (Detalle: ", msg, ")"))
        }
      )

      status <- httr::status_code(response)
      # simplifyVector = FALSE keeps every content block exactly as received (needed to resume pause_turn)
      parsed <- tryCatch(jsonlite::fromJSON(httr::content(response, "text", encoding = "UTF-8"), simplifyVector = FALSE),
                         error = function(e) NULL)

      if (status != 200) {
        detail <- if (is.list(parsed) && !is.null(parsed$error$message)) parsed$error$message else paste("HTTP", status)
        self$last_error <- detail
        if (status %in% c(401, 403)) self$connected <- FALSE
        msg <- switch(as.character(status),
          "400" = paste0("Claude no pudo procesar la solicitud. (Detalle: ", detail, ")"),
          "401" = "La clave de Claude no es válida. Revísela en Administrador → Conexión con Claude.",
          "403" = "Esta clave no tiene permiso para usar ese modelo. Pruebe con otro modelo.",
          "404" = paste0("No se encontró el modelo “", self$model, "”. Elija otro modelo en Administrador → Conexión con Claude."),
          "429" = "Se hicieron demasiadas solicitudes seguidas. Espere un minuto e intente de nuevo.",
          "500" = "Claude tuvo un problema de su lado. Intente de nuevo en unos minutos.",
          "529" = "Claude está muy ocupado en este momento. Intente de nuevo en unos minutos.",
          paste0("Claude respondió con un error. (Detalle: ", detail, ")")
        )
        e <- simpleError(msg); e$status <- status; e$detail <- detail
        stop(e)
      }
      parsed
    },

    # messages: list(list(role = "user"/"assistant", content = "..."))
    # web_search = TRUE adds Anthropic's web search tool (server tool web_search_20250305): Claude searches
    # the web and the pages it really found come back in web_search_tool_result blocks and in citations.
    # Returns list(text, usage, model, search = list(urls, titles, n, unavailable))
    chat = function(system = NULL, messages, max_tokens = NULL, require_connected = TRUE,
                    web_search = FALSE, max_searches = 5) {
      if (!self$has_key()) stop("Todavía no hay una clave de Claude. Escríbala en Administrador → Conexión con Claude.")
      if (require_connected && !self$connected)
        stop("Claude todavía no está conectado. Presione “Probar conexión” en Administrador → Conexión con Claude.")

      tokens <- as.integer(max_tokens %||% self$max_tokens)

      if (isTRUE(self$mock)) return(self$mock_reply(system, messages, web_search))

      body <- list(model = self$model, max_tokens = tokens, messages = messages)
      if (!is.null(system) && nzchar(system)) body$system <- system
      if (isTRUE(web_search)) body$tools <- list(list(type = "web_search_20250305", name = "web_search",
                                                      max_uses = as.integer(max_searches),
                                                      user_location = list(type = "approximate", country = "MX", timezone = "America/Mexico_City")))

      unavailable <- FALSE
      parsed <- tryCatch(self$post(body), error = function(e) {
        # Web search switched off for the organisation (400 "web search is not enabled") or not accepted
        # by the chosen model: answer without it instead of failing; the references stay "sin verificar".
        if (isTRUE(web_search) && identical(e$status, 400L) && grepl("web.?search|tool", e$detail %||% "", ignore.case = TRUE)) {
          unavailable <<- TRUE
          body$tools <- NULL
          return(self$post(body))
        }
        stop(e)
      })

      # A long search turn can pause: send the assistant blocks back unchanged to continue (max 4 times)
      blocks <- parsed$content %||% list()
      usage <- list(input_tokens = parsed$usage$input_tokens %||% 0, output_tokens = parsed$usage$output_tokens %||% 0)
      n <- 0
      while (identical(parsed$stop_reason, "pause_turn") && n < 4) {
        n <- n + 1
        body$messages <- c(messages, list(list(role = "assistant", content = blocks)))
        parsed <- self$post(body)
        blocks <- c(blocks, parsed$content %||% list())
        usage$input_tokens <- usage$input_tokens + (parsed$usage$input_tokens %||% 0)
        usage$output_tokens <- usage$output_tokens + (parsed$usage$output_tokens %||% 0)
      }

      if (!length(blocks)) stop("Claude respondió vacío. Intente de nuevo.")

      # Text: with citations the answer arrives split in several text blocks -> join them as they are
      texts <- vapply(blocks, function(b) if (identical(b$type, "text")) b$text %||% "" else "", character(1))
      text <- trimws(paste(texts, collapse = ""))

      # Pages really returned by the search engine + pages cited
      urls <- character(); titles <- character(); searches <- 0L
      for (b in blocks) {
        if (identical(b$type, "web_search_tool_result") && is.list(b$content) && is.null(b$content$type)) {
          searches <- searches + 1L
          for (r in b$content) if (identical(r$type, "web_search_result")) { urls <- c(urls, r$url %||% ""); titles <- c(titles, r$title %||% "") }
        }
        if (identical(b$type, "text")) for (ci in b$citations %||% list()) { urls <- c(urls, ci$url %||% ""); titles <- c(titles, ci$title %||% "") }
      }
      keep <- nzchar(urls) & !duplicated(urls)

      self$calls <- self$calls + 1L
      self$tokens_in <- self$tokens_in + usage$input_tokens
      self$tokens_out <- self$tokens_out + usage$output_tokens
      self$searches <- self$searches + searches
      self$last_error <- NULL
      if (identical(parsed$stop_reason, "max_tokens")) {
        text <- paste0(text, "\n\n*(La respuesta se cortó porque llegó al máximo de extensión. Puede aumentar “Extensión máxima de respuesta” en Administrador → Conexión con Claude.)*")
      }
      list(text = text, usage = usage, model = parsed$model %||% self$model,
           search = list(urls = urls[keep], titles = titles[keep], n = searches, unavailable = unavailable))
    },

    # Offline stand-in used only for automated testing
    mock_reply = function(system, messages, web_search = FALSE) {
      last <- messages[[length(messages)]]$content
      refs_on <- grepl("<referencias>", system %||% "", fixed = TRUE)
      refs_block <- if (refs_on) paste0("\n\n<referencias>\n[",
        "{\"n\":1,\"tipo\":\"libro\",\"autores\":\"Carpizo, J.\",\"anio\":\"1978\",\"titulo\":\"El presidencialismo mexicano\",\"editorial\":\"Siglo XXI\",\"lugar\":\"México\"},",
        "{\"n\":2,\"tipo\":\"web\",\"autores\":\"Instituto Nacional Electoral\",\"anio\":\"2024\",\"titulo\":\"Historia del INE\",\"url\":\"https://www.ine.mx/sobre-el-ine/historia/\"},",
        "{\"n\":3,\"tipo\":\"libro\",\"autores\":\"Pérez, A.\",\"anio\":\"1999\",\"titulo\":\"Un libro inventado sobre el Estado\",\"editorial\":\"Editorial X\"}]\n</referencias>") else ""
      search <- list(urls = if (web_search) "https://www.ine.mx/sobre-el-ine/historia/" else character(),
                     titles = if (web_search) "Historia - Instituto Nacional Electoral" else character(), n = as.integer(web_search), unavailable = FALSE)
      Sys.sleep(0.3)
      self$calls <- self$calls + 1L
      txt <- if (grepl("[para_mi_tesis]:", last, fixed = TRUE)) {
        paste0("[X]\n[Y]\n\n",
               "[topico]: Definición\n[titulo]: Qué es el presidencialismo\n[apunte]: Sistema donde el Ejecutivo concentra el poder.\nSegunda línea del apunte.\n[refs]: 1\n[para_mi_tesis]: Base del marco teórico.\n\n",
               "[topico]: Facultades metaconstitucionales\n[titulo]: Los poderes más allá de la Constitución\n[apunte]: El presidente designaba sucesor y gobernadores (Pérez, 1999).\n[refs]: 1, 3\n[para_mi_tesis]: Capítulo 2.\n\n",
               "[topico]: Crisis y cambio\n[titulo]: El fin del presidencialismo fuerte\n[apunte]: Desde 1997 el Congreso equilibra al Ejecutivo.\n[refs]: 2\n[para_mi_tesis]: Conclusiones.")
      } else if (grepl("FORMATO_JSON_BOSQUEJO", last)) {
        '{"titulo":"Del Estado administrador a la gerencia pública en México (1980–2026)","pregunta":"¿Cómo cambió la administración pública federal mexicana entre 1980 y 2026?","hipotesis":"La administración pública pasó de un modelo centralizado a uno gerencial, sin perder rasgos del Estado posrevolucionario.","objetivo_general":"Analizar la transformación de la administración pública federal entre 1980 y 2026.","objetivos_especificos":["Describir el modelo de 1980","Identificar las reformas clave","Evaluar sus resultados"],"justificacion":"Testimonio de una generación formada en el plan 1979–80.","marco_teorico":"Teoría del Estado, nueva gerencia pública, institucionalismo.","metodologia":"Análisis histórico-documental con entrevistas.","alcances":"Administración pública federal; 1980–2026.","capitulos":[{"titulo":"Marco teórico: del Estado a la gerencia","descripcion":"Conceptos y autores."},{"titulo":"El Estado administrador (1970–1982)","descripcion":"Contexto y estructura."},{"titulo":"Las reformas (1982–2000)","descripcion":"Ajuste y modernización."},{"titulo":"Gerencia pública y alternancia (2000–2026)","descripcion":"Nuevos modelos."}]}'
      } else if (grepl("FORMATO_JSON_TEMAS", last)) {
        '[{"titulo":"El municipio mexicano de 1983 a hoy","descripcion":"La reforma al artículo 115 y sus efectos.","por_que":"Une gobierno local y su experiencia."},{"titulo":"Paridad de género en la administración pública","descripcion":"De 1980 a la paridad en todo.","por_que":"Tema actual con raíz histórica."}]'
      } else if (grepl("<texto_corregido>", last, fixed = TRUE)) {
        paste0("<texto_corregido>", sub("(?s).*<texto>\\s*(.*?)\\s*</texto>.*", "\\1", last, perl = TRUE), " (corregido)</texto_corregido>\n\n**Cambios:** se corrigieron acentos.")
      } else {
        "## Comentarios\n\n**Lo que funciona bien:** el tema es claro y tiene relevancia (Carpizo, 1978).\n\n**Lo que conviene mejorar:**\n\n1. Delimitar el periodo.\n2. Precisar la pregunta.\n\n**Siguiente paso:** escriba la pregunta en una sola frase."
      }
      if (!grepl("FORMATO_JSON", last)) txt <- paste0(txt, refs_block)
      list(text = txt, usage = list(input_tokens = 100, output_tokens = 80), model = "mock", search = search)
    }
  )
)
