﻿# ============================================================================
# MI TESIS - lo que ejecuta el ícono del escritorio
# ============================================================================
$ErrorActionPreference = 'Stop'
$lanzadorDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $lanzadorDir 'comun.ps1')
$appDir = Get-AppDir -LanzadorDir $lanzadorDir
Add-Type -AssemblyName System.Windows.Forms, System.Drawing

# Ya estaba abierta: solo volver a mostrar la ventana
if (Test-AppReady) { Open-AppWindow; exit 0 }

$rscript = Get-Rscript -LanzadorDir $lanzadorDir
if (-not $rscript) {
  Show-Message -Icon 'Error' -Text "No encontré R en esta computadora.`nVuelva a correr CREAR_ACCESO_DIRECTO en:`n$appDir"
  exit 1
}

# R escondido; la ruta va por variable de entorno (espacios, acentos y & no se rompen)
$env:APP_DIR = $appDir; $env:APP_PORT = "$($script:AppPort)"; $env:APP_STANDALONE = '1'
Start-Process -FilePath $rscript -ArgumentList ('"' + (Join-Path $appDir 'iniciar_app.R') + '"') `
              -WorkingDirectory $appDir -WindowStyle Hidden      # sin redirecciones: el log lo hace R

# Aviso "Abriendo... espere" mientras R arranca (sin emojis: WinForms los dibuja como cuadros)
$form = New-Object System.Windows.Forms.Form
$form.Text = $script:AppTitulo
$form.Size = New-Object System.Drawing.Size(520, 220)
$form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'
$form.ControlBox = $false; $form.TopMost = $true
$form.BackColor = [System.Drawing.Color]::FromArgb(102, 126, 234)
$ico = Join-Path $lanzadorDir 'mi_tesis.ico'
if (Test-Path -LiteralPath $ico) { $form.Icon = New-Object System.Drawing.Icon($ico) }
$label = New-Object System.Windows.Forms.Label
$label.Text = "Abriendo $($script:AppTitulo)...`n`nPor favor espere un momento."
$label.Font = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
$label.ForeColor = [System.Drawing.Color]::White; $label.Dock = 'Fill'; $label.TextAlign = 'MiddleCenter'
$form.Controls.Add($label); $form.Show(); [System.Windows.Forms.Application]::DoEvents()

$ok = $false; $limite = (Get-Date).AddSeconds(120)
while ((Get-Date) -lt $limite) {
  for ($i = 0; $i -lt 5; $i++) { Start-Sleep -Milliseconds 200; [System.Windows.Forms.Application]::DoEvents() }
  if (Test-AppReady) { $ok = $true; break }
}
$form.Close()

if ($ok) { Open-AppWindow } else {
  $log = Join-Path $appDir 'data\lanzador.log'
  $tail = if (Test-Path -LiteralPath $log) { (Get-Content -LiteralPath $log -Tail 8 -Encoding UTF8) -join "`n" } else { '' }
  Show-Message -Icon 'Warning' -Text "La app tardó demasiado en abrir. Intente otra vez.`nSi sigue, mande este archivo:`n$log`n`n$tail"
}
