﻿# ============================================================================
# MI TESIS - funciones compartidas del lanzador de Windows
# (Windows PowerShell 5.1; guardado en UTF-8 con BOM)
# ============================================================================

$script:AppPort   = 7719
$script:AppUrl    = "http://127.0.0.1:$($script:AppPort)/"
$script:AppTitulo = 'Mi Tesis'                    # texto del <title> de la app
$script:Paquetes  = @('shiny','shinydashboard','R6','yaml','jsonlite','httr','shinyFiles','fs')
$script:Opcionales = @('officer')                 # solo para exportar a Word (.docx)

function Get-AppDir { param([string]$LanzadorDir) Split-Path -Parent $LanzadorDir }

# Todas las instalaciones de R (registro + Program Files + instalación por usuario), la más nueva primero
function Get-RscriptCandidates {
  $list = New-Object System.Collections.Generic.List[string]
  foreach ($key in 'HKLM:\SOFTWARE\R-core\R','HKCU:\SOFTWARE\R-core\R','HKLM:\SOFTWARE\WOW6432Node\R-core\R') {
    try {
      $ip = (Get-ItemProperty -Path $key -ErrorAction Stop).InstallPath
      if ($ip) {
        $exe = Join-Path $ip 'bin\Rscript.exe'
        if ((Test-Path -LiteralPath $exe) -and -not $list.Contains($exe)) { $list.Add($exe) }
      }
    } catch { }
  }
  $dirs = @()
  foreach ($b in @("$env:ProgramFiles\R", "$env:LOCALAPPDATA\Programs\R", "${env:ProgramFiles(x86)}\R")) {
    if ($b -and (Test-Path -LiteralPath $b)) {
      $dirs += Get-ChildItem -LiteralPath $b -Directory -Filter 'R-*' -ErrorAction SilentlyContinue
    }
  }
  $dirs | Sort-Object -Descending -Property @{ Expression = {
      try { [version](($_.Name -replace '^R-','') -replace '[^0-9.]','') } catch { [version]'0.0' } } } |
    ForEach-Object {
      $exe = Join-Path $_.FullName 'bin\Rscript.exe'
      if ((Test-Path -LiteralPath $exe) -and -not $list.Contains($exe)) { $list.Add($exe) }
    }
  return $list
}

# Primero el R guardado por el instalador (ruta_R.txt); si no, el primero encontrado
function Get-Rscript {
  param([string]$LanzadorDir)
  $saved = Join-Path $LanzadorDir 'ruta_R.txt'
  if (Test-Path -LiteralPath $saved) {
    $p = (Get-Content -LiteralPath $saved -Raw -Encoding UTF8).Trim()
    if ($p -and (Test-Path -LiteralPath $p)) { return $p }
  }
  $c = Get-RscriptCandidates
  if ($c.Count -gt 0) { return $c[0] }
  return $null
}

# Paquetes que le faltan a un R (lista vacía = tiene todo)
function Get-MissingPackages {
  param([string]$Rscript, [string[]]$Lista = $script:Paquetes)
  $vec = "c('" + ($Lista -join "','") + "')"
  $expr = "p <- $vec; f <- p[!vapply(p, requireNamespace, logical(1), quietly = TRUE)]; cat('FALTAN:', paste(f, collapse = ','))"
  $line = (& $Rscript -e $expr 2>$null | Where-Object { $_ -like 'FALTAN:*' } | Select-Object -Last 1)
  if (-not $line) { return @('(no se pudo revisar)') }
  $rest = ($line -replace '^FALTAN:\s*','').Trim()
  if (-not $rest) { return @() }
  return $rest.Split(',')
}

# ¿Está lista ESTA app en el puerto? (responde 200 y la página contiene el título)
function Test-AppReady {
  try {
    $r = Invoke-WebRequest -Uri $script:AppUrl -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop
    return ($r.StatusCode -eq 200 -and $r.Content -match [regex]::Escape("<title>$($script:AppTitulo)</title>"))
  } catch { return $false }
}

# Ventana propia: Edge o Chrome en modo app; si no hay, el navegador por defecto
function Open-AppWindow {
  $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
            "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") |
          Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
  $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
              "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
              "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") |
            Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
  $b = if ($edge) { $edge } elseif ($chrome) { $chrome } else { $null }
  if ($b) { Start-Process -FilePath $b -ArgumentList @("--app=$($script:AppUrl)", '--start-maximized') }
  else { Start-Process $script:AppUrl }
}

function Show-Message {
  param([string]$Text, [string]$Title = $script:AppTitulo, [string]$Icon = 'Information')
  Add-Type -AssemblyName System.Windows.Forms
  [void][System.Windows.Forms.MessageBox]::Show($Text, $Title, 'OK', $Icon)
}

# Resumen de lo guardado en una carpeta data\ (para el instalador)
function Get-DataSummary {
  param([string]$DataDir)
  $cfgFile = Join-Path $DataDir 'config.json'
  $work = Join-Path $DataDir 'mi_tesis'
  $autor = ''
  if (Test-Path -LiteralPath $cfgFile) {
    try {
      $cfg = Get-Content -LiteralPath $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($cfg.work_folder) { $work = $cfg.work_folder -replace '/', '\' }
      if ($cfg.author_name) { $autor = $cfg.author_name }
    } catch { }
  }
  $res = [ordered]@{ Carpeta = $work; Existe = (Test-Path -LiteralPath $work); Autor = $autor
                     Ideas = 0; Tema = ''; Capitulos = 0; Comentarios = 0; Guardado = '' }
  $prj = Join-Path $work 'proyecto.json'
  if (Test-Path -LiteralPath $prj) {
    try {
      $p = Get-Content -LiteralPath $prj -Raw -Encoding UTF8 | ConvertFrom-Json
      $res.Ideas = @($p.ideas).Count
      $res.Capitulos = @($p.outline.chapters).Count
      $res.Comentarios = @($p.feedback).Count
      $res.Guardado = $p.updated
      if ($p.chosen_idea) { $t = @($p.ideas) | Where-Object { $_.id -eq $p.chosen_idea } | Select-Object -First 1
                            if ($t) { $res.Tema = $t.titulo } }
    } catch { }
  }
  return $res
}
