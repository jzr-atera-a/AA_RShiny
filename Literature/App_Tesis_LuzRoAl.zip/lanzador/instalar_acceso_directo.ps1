﻿# ============================================================================
# MI TESIS - instalador del acceso directo (se corre UNA vez con CREAR_ACCESO_DIRECTO.bat)
#   1. Desbloquea los archivos que vienen de un ZIP descargado
#   2. Elige el R que tiene todos los paquetes (lo guarda en ruta_R.txt)
#   3. Trae los datos guardados de la carpeta que se usaba con RStudio
#   4. Crea el ícono en el escritorio y en el menú Inicio
# ============================================================================
$ErrorActionPreference = 'Stop'
$lanzadorDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $lanzadorDir 'comun.ps1')
$appDir = Get-AppDir -LanzadorDir $lanzadorDir
$dataDir = Join-Path $appDir 'data'
$ico = Join-Path $lanzadorDir 'mi_tesis.ico'
$lanzador = Join-Path $lanzadorDir 'abrir_app.ps1'
Add-Type -AssemblyName System.Windows.Forms

function Paso([string]$t) { Write-Host ''; Write-Host "=== $t ===" -ForegroundColor Cyan }
function Ok([string]$t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Aviso([string]$t){ Write-Host "  [!] $t" -ForegroundColor Yellow }
function Mal([string]$t)  { Write-Host "  [X] $t" -ForegroundColor Red }

Write-Host ''
Write-Host '  MI TESIS - Crear acceso directo en el escritorio' -ForegroundColor Magenta
Write-Host "  Carpeta de la app: $appDir"

# ---------------------------------------------------------------- 1. Unblock
Paso '1. Desbloquear archivos'
try { Get-ChildItem -LiteralPath $appDir -Recurse -File | Unblock-File; Ok 'Archivos desbloqueados' }
catch { Aviso "No se pudieron desbloquear todos los archivos: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 2. R with packages
Paso '2. Buscar R con los paquetes de la app'
$candidatos = @(Get-RscriptCandidates)
if ($candidatos.Count -eq 0) {
  Mal 'No se encontró R en esta computadora.'
  Show-Message -Icon 'Error' -Text "No se encontró R en esta computadora.`nInstale R (https://cran.r-project.org) y vuelva a correr CREAR_ACCESO_DIRECTO."
  Read-Host 'Presione Enter para cerrar'
  exit 1
}
$elegido = $null
foreach ($r in $candidatos) {
  $faltan = @(Get-MissingPackages -Rscript $r)
  if ($faltan.Count -eq 0) { Ok "R con todo lo necesario: $r"; $elegido = $r; break }
  Aviso "$r -> faltan: $($faltan -join ', ')"
}
if (-not $elegido) {
  $r = $candidatos[0]
  $resp = Read-Host "Ningún R tiene todos los paquetes. ¿Instalarlos ahora en $r ? Se necesita internet (S/N)"
  if ($resp -match '^[sS]') {
    Push-Location $appDir
    & $r (Join-Path $appDir 'install_packages.R')
    Pop-Location
    $faltan = @(Get-MissingPackages -Rscript $r)
    if ($faltan.Count -eq 0) { Ok 'Paquetes instalados'; $elegido = $r }
    else { Mal "Siguen faltando: $($faltan -join ', ')" }
  }
}
if (-not $elegido) {
  Mal 'No se puede continuar sin los paquetes. Abra RStudio y corra install_packages.R.'
  Read-Host 'Presione Enter para cerrar'
  exit 1
}
Set-Content -LiteralPath (Join-Path $lanzadorDir 'ruta_R.txt') -Value $elegido -Encoding UTF8
$opc = @(Get-MissingPackages -Rscript $elegido -Lista $script:Opcionales)
if ($opc.Count -gt 0) { Aviso "Opcional: falta '$($opc -join ', ')' (solo para exportar la tesis a Word). Lo instala install_packages.R." }

# ---------------------------------------------------------------- 3. Saved data
Paso '3. Datos guardados'
function Tiene-Datos([string]$d) {
  (Test-Path -LiteralPath (Join-Path $d 'config.json')) -or (Test-Path -LiteralPath (Join-Path $d 'mi_tesis\proyecto.json'))
}
if (Tiene-Datos $dataDir) {
  Ok 'Esta carpeta ya tiene datos guardados: se usan tal cual (no se copia nada).'
} else {
  $resp = Read-Host '¿Ya usaba Mi Tesis en RStudio desde OTRA carpeta y quiere traer lo guardado? (S/N)'
  if ($resp -match '^[sS]') {
    $copiado = $false
    while (-not $copiado) {
      $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
      $dlg.Description = 'Elija la carpeta de Mi Tesis que usaba con RStudio (la que tiene app.R y la carpeta data)'
      $dlg.ShowNewFolderButton = $false
      if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Aviso 'No se eligió carpeta: se empieza sin datos.'; break }
      $origenData = Join-Path $dlg.SelectedPath 'data'
      if ((Split-Path -Leaf $dlg.SelectedPath) -eq 'data') { $origenData = $dlg.SelectedPath }
      if (-not (Tiene-Datos $origenData)) {
        Aviso "En $($dlg.SelectedPath) no hay datos de Mi Tesis (data\config.json o data\mi_tesis\proyecto.json)."
        $otra = Read-Host '¿Elegir otra carpeta? (S/N)'
        if ($otra -notmatch '^[sS]') { break } else { continue }
      }
      New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
      Copy-Item -Path (Join-Path $origenData '*') -Destination $dataDir -Recurse -Force
      Get-ChildItem -LiteralPath $origenData -Force -File | Where-Object { $_.Name -like '.*' } |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $dataDir -Force }   # .claude_key
      $lg = Join-Path $dataDir 'lanzador.log'; if (Test-Path -LiteralPath $lg) { Remove-Item -LiteralPath $lg -Force }
      Ok "Datos copiados de: $origenData"
      $copiado = $true
    }
  } else { Ok 'Se empieza con una tesis nueva.' }
}
if (Tiene-Datos $dataDir) {
  $s = Get-DataSummary -DataDir $dataDir
  Write-Host ''
  Write-Host '  Resumen de lo guardado:'
  if ($s.Autor) { Write-Host "    Autor/a:            $($s.Autor)" }
  Write-Host "    Carpeta de trabajo: $($s.Carpeta)"
  if ($s.Existe) { Ok 'La carpeta de trabajo existe en esta computadora' }
  else { Aviso 'La carpeta de trabajo NO existe aquí. Elíjala otra vez en Administrador -> Carpeta de trabajo.' }
  Write-Host "    Ideas: $($s.Ideas)   Capítulos: $($s.Capitulos)   Comentarios de Claude: $($s.Comentarios)"
  if ($s.Tema) { Write-Host "    Tema elegido: $($s.Tema)" }
  if ($s.Guardado) { Write-Host "    Último guardado: $($s.Guardado)" }
}

# ---------------------------------------------------------------- 4. Shortcuts
Paso '4. Crear accesos directos'
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$shell = New-Object -ComObject WScript.Shell
function New-AppShortcut([string]$path) {
  $sc = $shell.CreateShortcut($path)
  $sc.TargetPath = $ps
  $sc.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$lanzador`""
  $sc.WorkingDirectory = $appDir
  $sc.WindowStyle = 7                      # minimizado: casi no se ve PowerShell
  if (Test-Path -LiteralPath $ico) { $sc.IconLocation = "$ico,0" }
  $sc.Description = "Abrir $($script:AppTitulo)"
  $sc.Save()
}
try {
  New-AppShortcut (Join-Path ([Environment]::GetFolderPath('Desktop'))  "$($script:AppTitulo).lnk")   # OneDrive-safe
  Ok 'Ícono en el escritorio'
  New-AppShortcut (Join-Path ([Environment]::GetFolderPath('Programs')) "$($script:AppTitulo).lnk")   # menú Inicio
  Ok 'Ícono en el menú Inicio'
} catch {
  Mal "No se pudo crear el acceso directo: $($_.Exception.Message)"
  Aviso "Puede usar 'Abrir Mi Tesis.bat' dentro de la carpeta de la app."
}

Write-Host ''
Write-Host '  Listo. Desde ahora abra la app con el ícono "Mi Tesis" del escritorio.' -ForegroundColor Green
Write-Host '  Para cerrarla, solo cierre la ventana.'
Write-Host '  Importante: use solo ESTA carpeta (también si la abre en RStudio).' -ForegroundColor Yellow
$abrir = Read-Host '¿Abrirla ahora? (S/N)'
if ($abrir -match '^[sS]') {
  Start-Process -FilePath $ps -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$lanzador`"")
}
exit 0
