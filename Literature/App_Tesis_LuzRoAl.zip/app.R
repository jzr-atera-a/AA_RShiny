# ============================================================================
# MI TESIS - CIENCIAS POLÍTICAS Y ADMINISTRACIÓN PÚBLICA (IBERO)
# Modular architecture - Entry point
# ============================================================================

cat("\n╔═══════════════════════════════════════════════════════════╗\n")
cat("║        MI TESIS (CPyAP IBERO) - STARTING APPLICATION       ║\n")
cat("╚═══════════════════════════════════════════════════════════╝\n\n")

# Load global configuration
source("global.R", encoding = "UTF-8")

# Initialize module loader
cat("📦 Initializing Module Loader...\n")
module_loader <- ModuleLoader$new()
module_loader$print()

# Load packages for enabled modules
cat("📚 Loading packages...\n")
module_loader$load_packages()

# Source module files
cat("🔧 Loading module code...\n")
module_loader$source_modules()

# Shared state + persistence (like PhotoManager / APIManager in the templates)
cat("🗂  Initializing Thesis Manager...\n")
thesis_manager <- ThesisManager$new(data_dir = "data")
thesis_manager$print()

cat("\n✅ Initialization complete!\n")
cat("🚀 Launching Shiny application...\n\n")

# Desktop mode (Windows icon → lanzador/abrir_app.ps1 → iniciar_app.R sets APP_STANDALONE=1):
# when the last window is closed, R stops by itself. In RStudio nothing changes.
STANDALONE <- identical(Sys.getenv("APP_STANDALONE"), "1")
.ventanas <- new.env()
.ventanas$abiertas <- 0L

shinyApp(
  ui = function(req) create_ui(module_loader, thesis_manager),   # per visit: opens the last tab used
  server = function(input, output, session) {
    create_server(module_loader, thesis_manager, session, input, output)

    if (STANDALONE) .ventanas$abiertas <- .ventanas$abiertas + 1L

    session$onSessionEnded(function() {
      cat("\n🧹 Cleaning up session resources...\n")
      gc(verbose = FALSE)
      cat("✅ Session cleanup complete\n")

      if (STANDALONE) {
        .ventanas$abiertas <- .ventanas$abiertas - 1L
        later::later(function() {                   # 'later' comes with shiny
          if (.ventanas$abiertas <= 0L) {
            cat(format(Sys.time()), "- Window closed: stopping the app\n")
            shiny::stopApp()
          }
        }, delay = 8)                               # 8 s: reloading the page does NOT close the app
      }
    })
  }
)
