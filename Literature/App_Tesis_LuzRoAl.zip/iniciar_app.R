# ============================================================================
# MI TESIS - DESKTOP START (used by the Windows icon, see lanzador/abrir_app.ps1)
#
# - Takes the app folder from the APP_DIR variable (or from this script's path)
# - Writes everything R prints to data/lanzador.log (R runs hidden)
# - Runs on 127.0.0.1 and a fixed port, WITHOUT opening a browser
#   (the launcher opens its own window in Edge/Chrome "app mode")
#
# By hand (for testing):  Rscript iniciar_app.R
# ============================================================================

app_dir <- Sys.getenv("APP_DIR")
if (!nzchar(app_dir)) {
  f <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  app_dir <- if (length(f)) dirname(normalizePath(f[1])) else getwd()
}
app_dir <- normalizePath(app_dir, winslash = "/")
setwd(app_dir)
dir.create("data", showWarnings = FALSE)

log_con <- file("data/lanzador.log", open = "wt", encoding = "UTF-8")
sink(log_con); sink(log_con, type = "message")

port <- as.integer(Sys.getenv("APP_PORT", "7719"))
Sys.setenv(APP_STANDALONE = "1")
cat(format(Sys.time()), "- Iniciando Mi Tesis | carpeta:", app_dir, "| R:", R.version.string, "| puerto:", port, "\n")

tryCatch(shiny::runApp(app_dir, port = port, host = "127.0.0.1", launch.browser = FALSE),
         error = function(e) cat("\nERROR:", conditionMessage(e), "\n"))

cat(format(Sys.time()), "- La app se cerró.\n")
sink(type = "message"); sink(); close(log_con)
