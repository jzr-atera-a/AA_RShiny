# modules/route_optimizer.R
# Route Optimizer Module - Single File (UI + Server)

route_optimizer_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      box(
        title = "Route Selection", 
        status = "primary", 
        solidHeader = TRUE, 
        width = 6,
        
        h4("Select Origin and Destination"),
        
        selectInput(ns("originAddress"), "Origin:",
                    choices = c(
                      "Judge Business School, Cambridge England",
                      "North Cambridge, Cambridge England",
                      "Cambridge West, Cambridge England",
                      "Addenbrooke's Hospital, Cambridge England"
                    ),
                    selected = "Judge Business School, Cambridge England"),
        
        selectInput(ns("destinationAddress"), "Destination:",
                    choices = c(
                      "Petersfield, Cambridge England",
                      "Chesterton, Cambridge England",
                      "Teversham, Cambridge England",
                      "Girton, Cambridge England"
                    ),
                    selected = "Petersfield, Cambridge England"),
        
        br(),
        
        numericInput(ns("numChargingPoints"), "Number of Charging Points:",
                     value = 3, min = 1, max = 10, step = 1),
        
        p(class = "text-muted", 
          "The system will find nearest charging points and calculate optimal route."),
        
        br(),
        
        actionButton(ns("calculateRoute"), "Calculate Optimal Route", 
                     class = "btn-success", 
                     icon = icon("route"),
                     width = "100%"),
        
        br(), br(),
        uiOutput(ns("routeStatus"))
      ),
      
      box(
        title = "Route Information", 
        status = "info", 
        solidHeader = TRUE, 
        width = 6,
        
        conditionalPanel(
          condition = paste0("output['", ns("routeCalculated"), "']"),
          h5("Route Summary:"),
          verbatimTextOutput(ns("routeSummary")),
          br(),
          h5("Nearest Charging Points:"),
          verbatimTextOutput(ns("chargingPointsInfo")),
          br(),
          actionButton(ns("viewMap"), "View Route Map", 
                       class = "btn-info", 
                       icon = icon("map"),
                       width = "100%"),
          br(), br(),
          actionButton(ns("sendToSimulator"), "Send to Simulator", 
                       class = "btn-success", 
                       icon = icon("paper-plane"),
                       width = "100%")
        ),
        
        conditionalPanel(
          condition = paste0("!output['", ns("routeCalculated"), "']"),
          div(style = "text-align: center; padding: 50px;",
              icon("info-circle", style = "font-size: 48px; color: #95a5a6;"),
              h4("No Route Calculated", style = "color: #7f8c8d; margin-top: 20px;"),
              p("Select addresses and click Calculate.", style = "color: #95a5a6;")
          )
        )
      )
    )
  )
}

route_optimizer_server <- function(id, api_manager, session) {
  
  moduleServer(id, function(input, output, session) {
    
    route_calculated <- reactiveVal(FALSE)
    route_data <- reactiveVal(NULL)
    nearest_points <- reactiveVal(NULL)
    start_coords <- reactiveVal(NULL)
    end_coords <- reactiveVal(NULL)
    
    observeEvent(input$calculateRoute, {
      
      if (is.null(api_manager) || !api_manager$bq_authenticated) {
        output$routeStatus <- renderUI({
          div(class = "status-error", h5("❌ Not Connected"), p("Connect BigQuery first"))
        })
        return()
      }
      
      if (is.null(api_manager$network_data)) {
        output$routeStatus <- renderUI({
          div(class = "status-error", h5("❌ No Network"), p("Download network first"))
        })
        return()
      }
      
      withProgress(message = 'Calculating...', value = 0, {
        
        tryCatch({
          
          incProgress(0.2, detail = "Geocoding")
          origin_result <- getbb(input$originAddress, format_out = "sf_polygon")
          dest_result <- getbb(input$destinationAddress, format_out = "sf_polygon")
          if (is.null(origin_result) || is.null(dest_result)) stop("Geocoding failed")
          
          origin_coords_sf <- st_centroid(origin_result)
          dest_coords_sf <- st_centroid(dest_result)
          start_coords(st_coordinates(origin_coords_sf)[1,])
          end_coords(st_coordinates(dest_coords_sf)[1,])
          
          incProgress(0.4, detail = "Finding points")
          charging_points <- api_manager$get_charging_points()
          if (is.null(charging_points) || nrow(charging_points) == 0) stop("No charging points")
          
          charging_proj <- st_transform(charging_points, crs = 27700)
          start_proj <- st_transform(origin_coords_sf, crs = 27700)
          distances <- st_distance(charging_proj, start_proj)
          charging_points$distance <- as.numeric(distances)
          
          nearest <- charging_points %>% arrange(distance) %>% head(input$numChargingPoints)
          nearest_points(nearest)
          
          incProgress(0.6, detail = "Routing")
          graph <- api_manager$network_data$graph
          shortest_length <- Inf
          best_charge_point <- NULL
          
          for (i in 1:nrow(nearest)) {
            charge_coords <- st_coordinates(st_geometry(nearest[i,]))
            dist_to <- tryCatch(dodgr_dists(graph, from = start_coords(), to = charge_coords)[1], error = function(e) Inf)
            dist_from <- tryCatch(dodgr_dists(graph, from = charge_coords, to = end_coords())[1], error = function(e) Inf)
            total <- dist_to + dist_from
            if (!is.na(total) && !is.infinite(total) && total < shortest_length) {
              shortest_length <- total
              best_charge_point <- i
            }
          }
          
          if (is.null(best_charge_point)) stop("No valid route")
          
          incProgress(0.9, detail = "Done")
          route_data(list(length = shortest_length, charge_point_index = best_charge_point))
          route_calculated(TRUE)
          
          if (!is.null(api_manager)) {
            api_manager$route_info <- list(
              route_data = route_data(), 
              nearest_points = nearest_points(),
              start_coords = start_coords(), 
              end_coords = end_coords(),
              origin_address = input$originAddress, 
              destination_address = input$destinationAddress
            )
            api_manager$trigger_route_update()
          }
          
          output$routeStatus <- renderUI({
            div(class = "status-success", h5("✓ Success"), 
                p(paste("Distance:", round(shortest_length/1000, 2), "km")))
          })
          showNotification("Route ready!", type = "message", duration = 3)
          
        }, error = function(e) {
          route_calculated(FALSE)
          output$routeStatus <- renderUI({
            div(class = "status-error", h5("✗ Failed"), p(as.character(e$message)))
          })
          showNotification(paste("Error:", e$message), type = "error", duration = 10)
        })
      })
    })
    
    output$routeSummary <- renderText({
      if (!route_calculated() || is.null(route_data())) return("No route")
      paste("Origin:", input$originAddress, 
            "\nDestination:", input$destinationAddress, 
            "\nDistance:", round(route_data()$length/1000, 2), "km")
    })
    
    output$chargingPointsInfo <- renderText({
      if (is.null(nearest_points())) return("No points")
      np <- nearest_points()
      paste(sapply(1:nrow(np), function(i) {
        sel <- if (!is.null(route_data()) && i == route_data()$charge_point_index) " ✓" else ""
        sprintf("%d. %.2f km%s", i, np[i,]$distance/1000, sel)
      }), collapse = "\n")
    })
    
    output$routeCalculated <- reactive({ route_calculated() })
    outputOptions(output, "routeCalculated", suspendWhenHidden = FALSE)
    
    observeEvent(input$viewMap, {
      updateTabItems(session, "sidebar_menu", "route_map")
    })
    
    observeEvent(input$sendToSimulator, {
      if (!route_calculated() || is.null(route_data())) {
        showNotification("Please calculate a route first", type = "warning", duration = 5)
        return()
      }
      
      scenario <- api_manager$route_to_scenario(
        api_manager$route_info,
        conditions = list(
          road_type = "auto",
          traffic = "moderate_congestion",
          weather = "clear"
        )
      )
      
      if (!is.null(scenario)) {
        current_scenarios <- api_manager$get_scenarios()
        if (is.null(current_scenarios)) {
          current_scenarios <- list()
        }
        current_scenarios[[length(current_scenarios) + 1]] <- scenario
        
        api_manager$load_omniverse_scenarios(current_scenarios)
        
        updateTabItems(session, "sidebar_menu", "omniverse_connection")
        
        showNotification(
          "✓ Route sent to simulation! Check Omniverse Connection tab.",
          type = "message",
          duration = 8
        )
      }
    })
  })
}
