# modules/route_map.R
# Route Map Module - Single File (UI + Server)

route_map_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      box(
        title = "Interactive Route Map", 
        status = "primary", 
        solidHeader = TRUE, 
        width = 12,
        
        leafletOutput(ns("routeMap"), height = 600),
        
        br(),
        
        div(class = "map-legend",
            h5("Legend:"),
            p(icon("play", style = "color: green;"), " Start Point"),
            p(icon("battery-half", style = "color: orange;"), " Charging Points"),
            p(icon("battery-full", style = "color: #00A39A;"), " Selected Charging Point"),
            p(icon("stop", style = "color: red;"), " End Point"),
            p(icon("minus", style = "color: blue;"), " Route Path")
        )
      )
    )
  )
}

route_map_server <- function(id, api_manager, session) {
  
  moduleServer(id, function(input, output, session) {
    
    output$routeMap <- renderLeaflet({
      
      observe({
        api_manager$route_trigger()
      })
      
      route_info <- api_manager$route_info
      
      if (is.null(route_info)) {
        return(
          leaflet() %>%
            addTiles() %>%
            setView(lng = 0.1218, lat = 52.2053, zoom = 10) %>%
            addControl(
              html = "<div style='background: white; padding: 10px; border-radius: 5px;'>
                      <h4>No Route Calculated</h4>
                      <p>Calculate a route in the Route Optimizer tab first.</p>
                      </div>",
              position = "topright"
            )
        )
      }
      
      tryCatch({
        
        route_data <- route_info$route_data
        nearest_points <- route_info$nearest_points
        start_coords <- route_info$start_coords
        end_coords <- route_info$end_coords
        
        map <- leaflet() %>%
          addTiles() %>%
          addMarkers(
            lng = start_coords[1],
            lat = start_coords[2],
            icon = makeIcon(
              iconUrl = "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png",
              iconWidth = 25,
              iconHeight = 41
            ),
            popup = paste("<b>Start:</b>", route_info$origin_address)
          ) %>%
          addMarkers(
            lng = end_coords[1],
            lat = end_coords[2],
            icon = makeIcon(
              iconUrl = "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png",
              iconWidth = 25,
              iconHeight = 41
            ),
            popup = paste("<b>End:</b>", route_info$destination_address)
          )
        
        for (i in 1:nrow(nearest_points)) {
          point <- nearest_points[i,]
          coords <- st_coordinates(st_geometry(point))
          
          is_selected <- (!is.null(route_data) && i == route_data$charge_point_index)
          
          icon_url <- if (is_selected) {
            "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-violet.png"
          } else {
            "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-orange.png"
          }
          
          map <- map %>%
            addMarkers(
              lng = coords[1],
              lat = coords[2],
              icon = makeIcon(
                iconUrl = icon_url,
                iconWidth = 25,
                iconHeight = 41
              ),
              popup = paste(
                "<b>Charging Point", i, if(is_selected) "(SELECTED)" else "", "</b><br>",
                "Distance from start:", round(point$distance/1000, 2), "km"
              )
            )
        }
        
        if (!is.null(route_data)) {
          selected_point <- nearest_points[route_data$charge_point_index,]
          selected_coords <- st_coordinates(st_geometry(selected_point))
          
          map <- map %>%
            addPolylines(
              lng = c(start_coords[1], selected_coords[1]),
              lat = c(start_coords[2], selected_coords[2]),
              color = "blue",
              weight = 3,
              opacity = 0.7,
              dashArray = "5, 10"
            ) %>%
            addPolylines(
              lng = c(selected_coords[1], end_coords[1]),
              lat = c(selected_coords[2], end_coords[2]),
              color = "blue",
              weight = 3,
              opacity = 0.7,
              dashArray = "5, 10"
            )
        }
        
        all_lngs <- c(start_coords[1], end_coords[1], st_coordinates(st_geometry(nearest_points))[,1])
        all_lats <- c(start_coords[2], end_coords[2], st_coordinates(st_geometry(nearest_points))[,2])
        
        map <- map %>%
          fitBounds(
            lng1 = min(all_lngs),
            lat1 = min(all_lats),
            lng2 = max(all_lngs),
            lat2 = max(all_lats)
          )
        
        return(map)
        
      }, error = function(e) {
        return(
          leaflet() %>%
            addTiles() %>%
            setView(lng = 0.1218, lat = 52.2053, zoom = 10) %>%
            addControl(
              html = paste("<div style='background: #f8d7da; padding: 10px; border-radius: 5px;'>
                           <h4>Error Rendering Map</h4>
                           <p>", e$message, "</p>
                           </div>"),
              position = "topright"
            )
        )
      })
    })
  })
}
