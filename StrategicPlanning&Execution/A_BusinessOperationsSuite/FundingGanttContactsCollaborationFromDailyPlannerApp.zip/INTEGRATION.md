# Funding, Gantt, Contacts and Collaboration: integration guide

These four tab groups were moved out of DaysPlanningFundingTravel on 25 November 2026, so they can be merged into another app:

- **Funding Programmes** (6 tabs): Find Programmes, Bulk Import, Add Entry, Browse Data, Visualizations (with Save to Google Drive), About.
- **Gantt to Tickets** (8 tabs): Upload Gantt, Review & Edit, Submit to Boards, Manage Contacts, Email Notifications, Bulk Email, Trello & Jira, Email (SMTP).
- **Contact Manager** (5 tabs, plus 1 disabled): Process Contact, Explore Contacts, OpenAI Config, Customise Message, Send Email. `contacts_smtp_config` is disabled, as before.
- **Online Collaboration** (2 tabs): Slack Connection, Channels.

The code of every tab is unchanged from the previous DaysPlanningFundingTravel zip.

## This zip runs on its own

It is a complete app: API Configuration (BigQuery, Claude, Google Drive, Titan, Debug Console) plus the four groups. Start it as usual with `shiny::runApp()`. It was started here and returned HTTP 200, with all 27 modules found.

Contact Manager > Process Contact reads PDF and Word files with `pdftools` and `readtext`. Install them if they are missing: `install.packages(c("pdftools", "readtext"))`.

## Merging into another app with the same layout

The other app must use the same module format: `modules/<Tab group>/<id>.R`, with a header, `<id>_ui` and `<id>_server`.

1. Copy the four folders from `modules/` into the other app's `modules/`.
2. Merge `modules/_registry_fragment_for_merge.yml.txt` into the other app's `modules/_module_registry.yml`. It holds the four `groups:` items with their sections and tab labels, and the 22 `modules:` entries.
3. Bring across the shared code the tabs call, listed per tab below. If the other app already has a file with the same name, compare the two files and merge them rather than overwriting.
4. APIManager (`R/utils_api.R`): the tabs use the members listed below. They include the BigQuery tables `funding_programmes`, `gantt_tasks`, `gantt_contacts`, `business_contacts` and `contact_communications`, the Trello, Jira, SMTP and OpenAI settings, and the Slack session. Copy those fields and methods into the other app's API class, or keep this `utils_api.R`.
5. `R/utils_tables.R`: add the funding, gantt and contacts lines of `TABLE_MODULE_KEYS`, so the sidebar checks those tables when the tabs are opened.
6. Packages: everything in `global.R`, plus `pdftools`, `readtext`, `readxl`, `writexl` and `base64enc`. These are named in the tab headers, and the loader installs and warns on its own.

## Links to the Day Planner app

- **Send Email** is in both apps. Events Scheduling's Zoom invites open it, so a copy stays in DaysPlanningFundingTravel under Events Scheduling > Calendar & Invites. It has the same id, `contacts_send_email`.
- The Funding Visualizations "load to Titan calendar" buttons need Events Scheduling > Events to Calendar, which stayed in the Day Planner app. In an app without that tab, the buttons are replaced by a note, and the .ics download still works. If the other app has Events to Calendar, the buttons come back by themselves.
- Saved diagrams in Google Drive keep the same paths: `<root>/Funding Programmes/Visualizations/<country>/...`

## What each tab uses

### Funding Programmes

| Tab file | Shared R files it calls into | APIManager members used |
|---|---|---|
| `funding_about.R` | - | 0:  |
| `funding_add_single.R` | `utils_common.R`, `utils_timezone.R` | 3: `bq_authenticated`, `bq_insert_funding`, `trigger_state_update_funding` |
| `funding_browse.R` | `utils_suite_tabs.R` | 0:  |
| `funding_bulk_import.R` | `utils_suite_tabs.R` | 0:  |
| `funding_visualizations.R` | `utils_common.R`, `utils_diagram.R`, `utils_drive_export.R`, `utils_export.R`, `utils_ics.R`, `utils_titan.R` | 6: `bq_authenticated`, `bq_full_table_funding`, `bq_get_funding_taxonomy`, `bq_query`, `state_trigger_funding`, `tab_gate` |
| `generate_programme.R` | `utils_common.R`, `utils_nav.R`, `utils_timezone.R` | 6: `bq_authenticated`, `bq_insert_funding`, `call_claude`, `claude_authenticated`, `set_pending_bulk_text_funding`, `trigger_state_update_funding` |

### Gantt to Tickets

| Tab file | Shared R files it calls into | APIManager members used |
|---|---|---|
| `gantt_api_config.R` | - | 4: `set_jira_credentials`, `set_trello_credentials`, `test_jira_connection`, `test_trello_connection` |
| `gantt_email_config.R` | - | 4: `gantt_email_body_template`, `gantt_email_subject_template`, `set_gantt_smtp_config`, `test_gantt_smtp_connection` |
| `gantt_email_contacts.R` | - | 10: `bq_authenticated`, `bq_get_gantt_contacts`, `gantt_smtp_authenticated`, `gantt_smtp_host`, `gantt_smtp_password`, `gantt_smtp_port`, `gantt_smtp_user`, `send_email_via_curl`, `state_trigger_gantt`, `tab_gate` |
| `gantt_email_send.R` | - | 11: `bq_authenticated`, `bq_get_gantt_contacts`, `gantt_email_body_template`, `gantt_email_subject_template`, `gantt_smtp_authenticated`, `gantt_smtp_host`, `gantt_smtp_password`, `gantt_smtp_port`, `gantt_smtp_user`, `gantt_tasks_data`, `send_email_via_curl` |
| `gantt_manage_contacts.R` | - | 6: `bq_authenticated`, `bq_get_gantt_contacts`, `bq_insert_gantt_contact`, `state_trigger_gantt`, `tab_open`, `trigger_state_update_gantt` |
| `gantt_review_edit.R` | `utils_calendar_export.R`, `utils_timezone.R` | 6: `bq_authenticated`, `bq_insert_gantt_tasks`, `gantt_tasks_data`, `gantt_time_zone`, `state_trigger_gantt`, `trigger_state_update_gantt` |
| `gantt_submit_boards.R` | `utils_common.R`, `utils_export.R` | 14: `bq_authenticated`, `bq_get_gantt_tasks`, `bq_insert_gantt_tasks`, `create_jira_issue`, `create_trello_card`, `gantt_tasks_data`, `get_trello_lists`, `jira_email`, `jira_project_key`, `jira_token`, `jira_url`, `trello_board_id` ... |
| `gantt_upload.R` | - | 2: `gantt_tasks_data`, `trigger_state_update_gantt` |

### Contact Manager

| Tab file | Shared R files it calls into | APIManager members used |
|---|---|---|
| `contacts_api_config.R` | - | 2: `set_contacts_openai_credentials`, `test_contacts_openai_connection` |
| `contacts_customise_communication.R` | `utils_nav.R` | 9: `bq_authenticated`, `bq_get_recent_communications`, `bq_insert_communication`, `call_openai`, `contacts_api_authenticated`, `contacts_generated_message`, `contacts_selected_contact`, `state_trigger_contacts`, `trigger_state_update_contacts` |
| `contacts_explore.R` | `utils_common.R`, `utils_export.R`, `utils_nav.R` | 7: `bq_authenticated`, `bq_delete_contact`, `bq_get_contacts`, `bq_update_contact`, `set_contacts_selected_contact`, `state_trigger_contacts`, `tab_open` |
| `contacts_process.R` | - | 4: `bq_authenticated`, `bq_insert_contact`, `call_openai`, `contacts_api_authenticated` |
| `contacts_send_email.R` | `utils_timezone.R`, `utils_titan.R`, `utils_zoom.R` | 10: `contacts_generated_message`, `contacts_selected_contact`, `contacts_selected_contact_email`, `mail_drafts`, `state_trigger_contacts`, `titan_log_add`, `titan_pass`, `titan_smtp`, `titan_smtp_ok`, `titan_state` |
| `contacts_smtp_config.R` | - | 2: `set_contacts_smtp_config`, `test_contacts_smtp_connection` |

### Online Collaboration

| Tab file | Shared R files it calls into | APIManager members used |
|---|---|---|
| `slack_channels.R` | `utils_slack.R`, `utils_timezone.R` | 4: `slack_log_add`, `slack_state`, `slack_token`, `slack_users` |
| `slack_connection.R` | `utils_slack.R` | 5: `slack_log`, `slack_log_add`, `slack_set_session`, `slack_sign_out`, `slack_state` |

### Shared R files needed by the four groups (number of tab files using each)

- `R/utils_common.R`: 5
- `R/utils_timezone.R`: 5
- `R/utils_export.R`: 3
- `R/utils_nav.R`: 3
- `R/utils_suite_tabs.R`: 2
- `R/utils_titan.R`: 2
- `R/utils_slack.R`: 2
- `R/utils_diagram.R`: 1
- `R/utils_drive_export.R`: 1
- `R/utils_ics.R`: 1
- `R/utils_calendar_export.R`: 1
- `R/utils_zoom.R`: 1
