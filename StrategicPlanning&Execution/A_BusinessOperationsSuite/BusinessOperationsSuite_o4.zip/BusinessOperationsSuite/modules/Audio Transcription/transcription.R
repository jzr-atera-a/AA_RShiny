# modules/Audio Transcription/transcription.R
# Subtab: Audio Transcription (Whisper, batch of up to 10 files)
# FIXED: Robust error handling with retry logic and exponential backoff
# Uses openai_base.R for API calls and timeout management

transcription_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "Audio Upload", status = "primary", solidHeader = TRUE, width = 6,
          fileInput(ns("audioFiles"), "Choose Audio Files (up to 10)",
                    multiple = TRUE,
                    accept = c(".mp3", ".m4a", ".flac", ".ogg", ".wav")),
          verbatimTextOutput(ns("fileInfo")),
          h5("Processing Settings:"),
          checkboxInput(ns("useTimeout"), "Use custom timeout", value = FALSE),
          conditionalPanel(condition = sprintf("input['%s']", ns("useTimeout")),
                            numericInput(ns("timeout"), "Timeout (seconds):",
                                        value = 180, min = 30, max = 900)),
          p(em("Leave unchecked for auto-calculated timeout (30 sec per MB)"),
            style = "color: #666; font-size: 11px;"),
          br(),
          actionButton(ns("transcribeBtn"), "Transcribe", class = "btn-primary btn-lg", style = "width: 100%;")),
      box(title = "Processing Status", status = "info", solidHeader = TRUE, width = 6,
          verbatimTextOutput(ns("status")))
    ),
    fluidRow(
      box(title = "Transcription Results", status = "success", solidHeader = TRUE, width = 12,
          textAreaInput(ns("results"), NULL, height = "400px", placeholder = "Results will appear here..."),
          fluidRow(
            column(8, textInput(ns("savePath"), "Save directory:", placeholder = "Select directory...")),
            column(2, br(), shinyDirButton(ns("browseDir"), "Browse...", "Select Directory")),
            column(2, br(), actionButton(ns("saveBtn"), "Save", class = "btn-success", style = "width: 100%;"))
          ))
    )
  )
}

transcription_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    volumes <- get_volume_roots()
    shinyDirChoose(input, "browseDir", roots = volumes, session = session)

    values <- reactiveValues(
      save_dir = getwd(),
      transcription = "",
      status_log = ""
    )

    observeEvent(input$browseDir, {
      if (!is.integer(input$browseDir)) {
        selected <- parseDirPath(volumes, input$browseDir)
        if (length(selected) > 0) {
          values$save_dir <- selected
          updateTextInput(session, "savePath", value = selected)
        }
      }
    })

    output$fileInfo <- renderText({
      req(input$audioFiles)
      num <- nrow(input$audioFiles)
      total_size <- round(sum(input$audioFiles$size) / 1024 / 1024, 2)
      if (num > 10) {
        "⚠️ Maximum 10 files allowed"
      } else {
        paste("Files:", num, "\nTotal size:", total_size, "MB")
      }
    })

    # Add status message with timestamp
    add_status <- function(msg) {
      timestamp <- format(Sys.time(), "%H:%M:%S")
      values$status_log <- paste(values$status_log,
                                  sprintf("[%s] %s", timestamp, msg),
                                  sep = "\n")
      output$status <- renderText(values$status_log)
    }

    observeEvent(input$transcribeBtn, {
      req(input$audioFiles)

      # Reset status log
      values$status_log <- ""

      # Validate API key
      if (is.null(api_manager) || nchar(api_manager$whisper_api_key) == 0) {
        add_status("❌ Whisper API key not configured")
        add_status("")
        add_status("Setup:")
        add_status("1. Go to 'API Settings' tab group")
        add_status("2. Click 'OpenAI API (Whisper + ChatGPT)'")
        add_status("3. Enter your OpenAI API key")
        add_status("4. Click 'Save API Key' and 'Test Connection'")
        add_status("5. Return here and try again")
        showNotification("Please configure Whisper API key first", type = "error", duration = 10)
        return()
      }

      num_files <- nrow(input$audioFiles)

      # Validate file count
      if (num_files > 10) {
        add_status("❌ Too many files (max 10)")
        showNotification("Please select up to 10 files only", type = "error")
        return()
      }

      # Get timeout settings
      use_timeout <- isTRUE(input$useTimeout)
      timeout_val <- if (use_timeout &&
                         !is.null(input$timeout) &&
                         is.numeric(input$timeout) &&
                         input$timeout > 0) {
        input$timeout
      } else {
        NULL
      }

      add_status("🔄 INITIALIZING BATCH TRANSCRIPTION")
      add_status("")
      add_status(sprintf("Files to process: %d", num_files))
      add_status(sprintf("Timeout: %s",
                         if (!is.null(timeout_val)) sprintf("%d seconds (custom)", timeout_val)
                         else "Auto-calculated (30 sec per MB)"))
      add_status("Max retries: 3 with exponential backoff")
      add_status("")
      add_status("Starting transcription...")
      add_status("")

      all_transcriptions <- character()
      total_words <- 0
      files_completed <- 0
      overall_start <- Sys.time()

      tryCatch({
        for (i in 1:num_files) {
          file_name <- input$audioFiles$name[i]
          file_path <- input$audioFiles$datapath[i]
          file_size_mb <- round(input$audioFiles$size[i] / 1024 / 1024, 2)

          add_status("")
          add_status(sprintf("═══ FILE %d of %d ═══", i, num_files))
          add_status(sprintf("Name: %s", file_name))
          add_status(sprintf("Size: %.2f MB", file_size_mb))
          add_status("Status: Starting transcription...")

          file_start <- Sys.time()

          # Call transcribe_audio with retry logic built in
          transcription <- api_manager$transcribe_audio(
            file_path = file_path,
            use_timeout = use_timeout,
            timeout_seconds = timeout_val
          )

          file_time <- as.numeric(difftime(Sys.time(), file_start, units = "secs"))

          # Format result
          file_header <- sprintf("\n\n═══ FILE %d: %s ═══\n", i, file_name)
          all_transcriptions <- c(all_transcriptions, paste0(file_header, transcription))
          combined <- paste(all_transcriptions, collapse = "\n")
          updateTextAreaInput(session, "results", value = combined)
          values$transcription <- combined

          # Count words
          file_words <- length(strsplit(trimws(transcription), "\\s+")[[1]])
          total_words <- total_words + file_words
          files_completed <- i

          add_status(sprintf("✓ Transcription complete"))
          add_status(sprintf("  Words: %s", format(file_words, big.mark = ",")))
          add_status(sprintf("  Time: %.1f seconds", file_time))
          add_status(sprintf("  Speed: %.0f words/sec", file_words / file_time))

          if (i < num_files) {
            add_status("")
            add_status("⏳ Pausing 1 second before next file...")
            Sys.sleep(1)
          }
        }

        # Final summary
        total_time <- as.numeric(difftime(Sys.time(), overall_start, units = "secs"))

        add_status("")
        add_status("═══════════════════════════════════════════")
        add_status("✅ ALL TRANSCRIPTIONS COMPLETE! ✅")
        add_status("═══════════════════════════════════════════")
        add_status("")
        add_status("Summary:")
        add_status(sprintf("  Files processed: %d", num_files))
        add_status(sprintf("  Total words: %s", format(total_words, big.mark = ",")))
        add_status(sprintf("  Total time: %.1f seconds (%.1f minutes)", total_time, total_time / 60))
        add_status(sprintf("  Average speed: %.0f words/sec", total_words / total_time))
        add_status("")
        add_status("✓ Transcriptions ready in text area")
        add_status("✓ Ready to save to file or analyze further")

        showNotification(
          sprintf("✅ %d file(s) transcribed! Total: %s words", num_files, format(total_words, big.mark = ",")),
          type = "message",
          duration = 5
        )

      }, error = function(e) {
        error_msg <- e$message

        add_status("")
        add_status("═══════════════════════════════════════════")
        add_status("❌ ERROR OCCURRED")
        add_status("═══════════════════════════════════════════")
        add_status("")
        add_status(sprintf("Error: %s", error_msg))
        add_status("")
        add_status(sprintf("Files completed before error: %d of %d", files_completed, num_files))

        if (files_completed > 0) {
          add_status(sprintf("Words transcribed: %s", format(total_words, big.mark = ",")))
        }

        add_status("")
        add_status("Troubleshooting:")
        add_status("1. Verify Whisper API key in 'API Settings > OpenAI API (Whisper + ChatGPT)'")
        add_status("2. Test connection in that tab")
        add_status("3. Check file size (max 25 MB per file)")
        add_status("4. Try with smaller files or different format")
        add_status("5. Try enabling custom timeout (300+ seconds for large files)")
        add_status("6. Check OpenAI status page for service issues")

        showNotification(
          paste("❌ Transcription failed:", substr(error_msg, 1, 80)),
          type = "error",
          duration = 10
        )

        # Save partial results if any
        if (length(all_transcriptions) > 0) {
          combined <- paste(all_transcriptions, collapse = "\n")
          updateTextAreaInput(session, "results", value = combined)
          values$transcription <- combined
          add_status("")
          add_status("📝 Partial results saved above")
        }
      })
    })

    # Save results to file
    observeEvent(input$saveBtn, {
      req(values$transcription, input$audioFiles)

      num <- nrow(input$audioFiles)
      filename <- if (num == 1) {
        paste0(tools::file_path_sans_ext(input$audioFiles$name[1]), ".txt")
      } else {
        paste0("transcription_batch_", num, "files_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt")
      }
      save_path <- file.path(values$save_dir, filename)

      tryCatch({
        writeLines(values$transcription, save_path)
        showNotification(sprintf("✓ Saved to: %s", filename), type = "message", duration = 5)
      }, error = function(e) {
        showNotification(paste("Error saving file:", e$message), type = "error")
      })
    })

    output$status <- renderText("")
  })
}
