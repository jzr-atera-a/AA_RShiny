# modules/Audio Transcription/converter.R
# Subtab: Audio Converter & Splitter
# Audio format conversion and splitting (M4A, MP3, WAV to MP3)
# Uses av library for reliable audio processing

converter_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "Audio File Upload", status = "primary", solidHeader = TRUE, width = 6,
          fileInput(ns("audioFile"), "Choose Audio File (M4A, MP3, WAV)",
                    accept = c(".m4a", ".mp3", ".wav")),
          verbatimTextOutput(ns("fileInfo")),
          h5("Output Settings:"),
          fluidRow(
            column(8, textInput(ns("outputPath"), "Save to directory:", placeholder = "Select directory...")),
            column(4, br(), shinyDirButton(ns("browseDir"), "Browse...", "Select Directory"))
          ),
          textInput(ns("outputPrefix"), "Output file prefix:", placeholder = "Leave empty for original name")),
      box(title = "Split Settings", status = "info", solidHeader = TRUE, width = 6,
          radioButtons(ns("splitMethod"), "Split Method:",
                       choices = list("By Number of Files" = "num_files", "By File Size" = "file_size"),
                       selected = "file_size"),
          conditionalPanel(condition = sprintf("input['%s'] == 'num_files'", ns("splitMethod")),
                            numericInput(ns("numSplits"), "Number of files:", value = 2, min = 1, max = 50)),
          conditionalPanel(condition = sprintf("input['%s'] == 'file_size'", ns("splitMethod")),
                            numericInput(ns("maxSizeMB"), "Maximum file size (MB):", value = 10, min = 1, max = 500)),
          br(),
          actionButton(ns("processBtn"), "Convert & Split Audio", class = "btn-success btn-lg", style = "width: 100%;"))
    ),
    fluidRow(
      box(title = "Processing Status", status = "warning", solidHeader = TRUE, width = 12,
          verbatimTextOutput(ns("status")))
    ),
    fluidRow(
      box(title = "Results", status = "success", solidHeader = TRUE, width = 12,
          DTOutput(ns("resultsTable")))
    )
  )
}

converter_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    volumes <- get_volume_roots()
    shinyDirChoose(input, "browseDir", roots = volumes, session = session)

    values <- reactiveValues(output_dir = getwd(), results = NULL, status_log = "")

    observeEvent(input$browseDir, {
      if (!is.integer(input$browseDir)) {
        selected <- parseDirPath(volumes, input$browseDir)
        if (length(selected) > 0) {
          values$output_dir <- selected
          updateTextInput(session, "outputPath", value = selected)
        }
      }
    })

    output$fileInfo <- renderText({
      req(input$audioFile)
      file_size_mb <- round(input$audioFile$size / 1024 / 1024, 2)
      paste("File:", input$audioFile$name, "\nSize:", file_size_mb, "MB")
    })

    # Log status updates
    add_status <- function(msg) {
      timestamp <- format(Sys.time(), "%H:%M:%S")
      values$status_log <- paste(values$status_log,
                                  sprintf("[%s] %s", timestamp, msg),
                                  sep = "\n")
      output$status <- renderText(values$status_log)
    }

    observeEvent(input$processBtn, {
      req(input$audioFile)

      values$status_log <- ""
      add_status("🔄 Starting audio processing...")

      tryCatch({
        input_path <- input$audioFile$datapath
        file_name <- input$audioFile$name
        file_ext <- tolower(tools::file_ext(file_name))
        file_size_mb <- input$audioFile$size / 1024 / 1024

        add_status(sprintf("📁 File: %s (%.2f MB)", file_name, file_size_mb))
        add_status(sprintf("📍 Input: %s", input_path))
        add_status(sprintf("📂 Output: %s", values$output_dir))

        # Get duration using ffprobe (non-blocking with timeout)
        add_status("⏱️ Reading audio duration...")

        # Get duration using av library (reliable method)
        audio_info <- tryCatch({
          av::av_media_info(input_path)
        }, error = function(e) {
          NULL
        })

        if (is.null(audio_info)) {
          add_status("❌ Could not determine audio duration")
          add_status("   Check: 1. File is valid audio 2. File is readable 3. File permissions")
          output$status <- renderText(values$status_log)
          return()
        }

        duration <- audio_info$duration
        if (is.na(duration) || duration <= 0) {
          add_status("❌ Invalid audio duration detected")
          return()
        }

        add_status(sprintf("✓ Duration: %.2f seconds (%.2f minutes)", duration, duration / 60))

        # Calculate number of segments
        num_segments <- if (input$splitMethod == "num_files") {
          input$numSplits
        } else {
          # Calculate based on file size
          max_size_mb <- input$maxSizeMB
          bytes_per_second <- input$audioFile$size / duration
          max_duration <- (max_size_mb * 0.95 * 1024 * 1024) / bytes_per_second
          ceiling(duration / max_duration)
        }

        add_status(sprintf("✓ Will create %d segments", num_segments))

        segment_duration <- duration / num_segments
        output_files <- character()
        prefix <- if (nchar(trimws(input$outputPrefix)) > 0) input$outputPrefix else tools::file_path_sans_ext(file_name)

        # Process each segment
        for (i in 1:num_segments) {
          add_status(sprintf(""))
          add_status(sprintf("📝 Processing segment %d of %d", i, num_segments))

          start_time <- (i - 1) * segment_duration
          end_time <- min(i * segment_duration, duration)
          segment_length <- end_time - start_time

          # Output filename (use MP3 for consistency)
          filename <- if (num_segments == 1) {
            paste0(prefix, ".mp3")
          } else {
            paste0(prefix, "_part", sprintf("%02d", i), ".mp3")
          }
          filepath <- file.path(values$output_dir, filename)

          add_status(sprintf("   Start: %02d:%02d:%02d",
                             floor(start_time/3600), floor((start_time%%3600)/60), floor(start_time%%60)))
          add_status(sprintf("   Duration: %.2f seconds", segment_length))

          # Use av library to extract and convert segment
          add_status("   🔄 Encoding audio segment...")

          convert_result <- tryCatch({
            av::av_audio_convert(input_path, filepath,
                                format = "mp3",
                                start_time = start_time,
                                total_time = segment_length)
            TRUE
          }, error = function(e) {
            FALSE
          })

          if (!convert_result) {
            add_status(sprintf("   ❌ Failed to encode segment %d", i))
            return()
          }

          if (!file.exists(filepath)) {
            add_status(sprintf("   ❌ Output file not created for segment %d", i))
            return()
          }

          output_size_mb <- file.size(filepath) / 1024 / 1024
          add_status(sprintf("   ✓ Created: %s (%.2f MB)", filename, output_size_mb))

          output_files <- c(output_files, filename)
        }

        # Create results table
        values$results <- data.frame(
          Segment = 1:num_segments,
          Filename = output_files,
          Status = rep("✓ Complete", num_segments),
          stringsAsFactors = FALSE
        )

        add_status("")
        add_status(sprintf("✅ SUCCESS! Created %d file(s)", num_segments))
        add_status("📊 Summary:")
        for (i in seq_along(output_files)) {
          file_path <- file.path(values$output_dir, output_files[i])
          if (file.exists(file_path)) {
            size_mb <- file.size(file_path) / 1024 / 1024
            add_status(sprintf("   %d. %s (%.2f MB)", i, output_files[i], size_mb))
          }
        }

        showNotification(sprintf("✅ Created %d audio files successfully!", num_segments),
                        type = "message", duration = 5)

      }, error = function(e) {
        add_status("")
        add_status(sprintf("❌ ERROR: %s", e$message))
        add_status("")
        add_status("TROUBLESHOOTING:")
        add_status("• Verify audio file is valid and readable")
        add_status("• Try with a smaller or different format audio file")
        add_status("• Check file permissions on output directory")
        add_status("• Try reducing number of segments")

        showNotification(paste("❌ Error:", substr(e$message, 1, 100)), type = "error", duration = 10)
      })
    })

    output$resultsTable <- renderDT({
      req(values$results)
      datatable(values$results, options = list(dom = 't', pageLength = 10), rownames = FALSE)
    })

    output$status <- renderText("")
  })
}
