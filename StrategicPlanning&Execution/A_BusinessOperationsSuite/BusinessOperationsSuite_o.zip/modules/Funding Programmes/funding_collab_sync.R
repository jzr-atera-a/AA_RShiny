# modules/Funding Programmes/funding_collab_sync.R
# Subtab: Collaboration Sync - exchange funding programmes with the CollaborationPlanning app through its Drive folder.
#   Import: its programmes list (latest Backups/<date>/programmes.csv) and the programmes in its Claude analyses
#           -> preview (New / Repeated / Already imported) -> funding_programmes in BigQuery, repeated rows flagged.
#   Share:  our programmes -> analyses in its format, picked up by its Analysis library > "Read from Drive".
# The folder and how to reach it: API Settings > Google Drive > CollaborationPlanning folder. Code: R/utils_collab_sync.R

funding_collab_sync_ui <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      box(title = "CollaborationPlanning Folder", status = "primary", solidHeader = TRUE, width = 12,
          p("Both apps exchange programmes through CollaborationPlanning's Google Drive folder: its Claude analyses ",
            "(", tags$code("<Country>/<Category>/<Topic>/<programme>__<id>.json"), ") and its daily backup ",
            "(", tags$code("Backups/<date>/programmes.csv"), "). Set the folder in ", tags$b("API Settings > Google Drive"), "."),
          actionButton(ns("check"), "Check Folder", icon = icon("folder-open"), class = "btn-info"),
          uiOutput(ns("folder_status")))
    ),
    fluidRow(
      box(title = "Import from CollaborationPlanning into BigQuery", status = "success", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4, checkboxInput(ns("use_backup"), "Its programmes list (latest daily backup)", value = TRUE)),
            column(4, checkboxInput(ns("use_analyses"), "Programmes found in its Claude analyses", value = TRUE)),
            column(4, actionButton(ns("read"), "Read from Drive", icon = icon("cloud-download-alt"), class = "btn-primary", style = "width:100%"))),
          uiOutput(ns("read_status")),
          DT::dataTableOutput(ns("preview")),
          br(),
          fluidRow(
            column(6, checkboxInput(ns("include_already"), "Also load rows that were imported before (marked as repeated)", value = FALSE)),
            column(6, actionButton(ns("load"), "Load into BigQuery", icon = icon("database"), class = "btn-success", style = "width:100%"))),
          tags$p(class = "help-block",
                 tags$b("New"), ": not in our table yet. ",
                 tags$b("Repeated"), ": a programme with the same name and funder/sponsor is already in our table (or earlier in this list); ",
                 "it is loaded too, with ", tags$code("repeated = TRUE"), " so it is easy to spot in Browse Data. ",
                 tags$b("Already imported"), ": this very record of CollaborationPlanning was loaded before; left out unless ticked above."),
          uiOutput(ns("load_status")))
    ),
    fluidRow(
      box(title = "Share Our Programmes with CollaborationPlanning", status = "warning", solidHeader = TRUE, width = 12,
          p("Each programme is written as an analysis in CollaborationPlanning's own format and place. There, the owner opens ",
            tags$b("Analysis library > Read from Drive"), " to bring them in (it takes new ones and newer copies)."),
          fluidRow(
            column(4, radioButtons(ns("which"), "Programmes to share",
                                   choices = c("Added in this app (not the ones imported from CollaborationPlanning)" = "ours",
                                               "All programmes in our table" = "all"), selected = "ours")),
            column(4, selectizeInput(ns("countries"), "Only these countries (empty = all)", choices = NULL, multiple = TRUE),
                      selectizeInput(ns("categories"), "Only these categories (empty = all)", choices = NULL, multiple = TRUE)),
            column(4, br(), actionButton(ns("preview_share"), "Preview", icon = icon("eye"), class = "btn-info", style = "width:100%"),
                      br(), br(), actionButton(ns("share"), "Write to Drive", icon = icon("cloud-upload-alt"), class = "btn-warning", style = "width:100%"))),
          uiOutput(ns("share_status")))
    )
  )
}

funding_collab_sync_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    marked <- reactiveVal(NULL)
    note <- function(cls, ...) tags$div(class = cls, ...)
    sa_path <- function() tryCatch(cred_local()$json_path, error = function(e) NA)
    folder <- function() {
      s <- collab_load_settings()
      if (!collab_ready(s, sa_path())) stop("The CollaborationPlanning folder is not set up: open API Settings > Google Drive > CollaborationPlanning folder.", call. = FALSE)
      list(s = s, f = collab_folder(s, sa_path()))
    }

    observeEvent(input$check, {
      r <- tryCatch({
        x <- folder(); b <- x$f$latest_backup("programmes"); a <- x$f$analyses()
        list(mode = x$f$mode, where = x$f$where, backup = if (is.null(b)) "none yet" else b$day, analyses = length(a))
      }, error = function(e) e)
      output$folder_status <- renderUI(if (inherits(r, "error")) note("status-error", conditionMessage(r)) else
        note("status-success", sprintf("✓ Folder reachable (%s: %s). Latest programmes backup: %s. Analysis files: %d.",
                                       if (r$mode == "api") "Google Drive API" else "folder on this computer", r$where, r$backup, r$analyses)))
    })

    # ---- import
    observeEvent(input$read, {
      if (!isTRUE(input$use_backup) && !isTRUE(input$use_analyses)) return(output$read_status <- renderUI(note("status-warning", "Tick at least one source.")))
      if (!api_manager$bq_authenticated) return(output$read_status <- renderUI(note("status-error", "Connect to BigQuery first (API Settings > BigQuery Config): the repeat check needs our table.")))
      res <- withProgress(message = "Reading CollaborationPlanning's folder...", tryCatch({
        x <- folder(); parts <- list(); info <- character(0)
        if (isTRUE(input$use_backup)) {
          b <- x$f$latest_backup("programmes")
          if (is.null(b)) info <- c(info, "no programmes backup yet") else {
            p <- collab_programmes_to_bos(collab_read_csv_text(b$text)); parts$backup <- p
            info <- c(info, sprintf("%d programme(s) from the backup of %s", nrow(p), b$day)) }
        }
        if (isTRUE(input$use_analyses)) {
          incProgress(0.4)
          ra <- collab_read_analyses(x$f$analyses()); parts$analyses <- ra$rows
          info <- c(info, sprintf("%d programme(s) from %d analysis file(s)%s", nrow(ra$rows), ra$analyses,
                                  if (ra$skipped_own) sprintf(" (%d shared by this app skipped)", ra$skipped_own) else ""))
        }
        parts <- Filter(function(d) is.data.frame(d) && nrow(d) > 0, parts)
        incoming <- if (length(parts)) do.call(rbind, lapply(parts, collab_conform)) else collab_conform(NULL)
        incProgress(0.3)
        list(m = if (nrow(incoming)) collab_mark_repeats(incoming, api_manager$bq_funding_keys()) else incoming, info = info)
      }, error = function(e) e))
      if (inherits(res, "error")) { marked(NULL); return(output$read_status <- renderUI(note("status-error", conditionMessage(res)))) }
      marked(res$m)
      n <- function(st) if (nrow(res$m)) sum(res$m$status == st) else 0
      output$read_status <- renderUI(note("status-info", paste0(paste(res$info, collapse = "; "), ". "),
        tags$b(sprintf("New: %d, Repeated: %d, Already imported: %d.", n("New"), n("Repeated"), n("Already imported")))))
    })

    output$preview <- DT::renderDataTable({
      m <- marked(); req(m, nrow(m))
      show <- m[, c("status", "programme_name", "key_sponsors", "country", "category", "amount_of_money", "deadline", "source", "same_as_id")]
      names(show) <- c("Status", "Programme", "Funder / sponsors", "Country", "Category", "Amount", "Deadline", "From", "Same as our id")
      DT::formatStyle(DT::datatable(show, rownames = FALSE, options = list(pageLength = 15, scrollX = TRUE)), "Status",
                      backgroundColor = DT::styleEqual(c("New", "Repeated", "Already imported"), c("#d4edda", "#fff3cd", "#e2e3e5")),
                      fontWeight = "bold")
    })

    observeEvent(input$load, {
      m <- marked()
      if (is.null(m) || !nrow(m)) return(output$load_status <- renderUI(note("status-warning", "Read from Drive first.")))
      rows <- collab_rows_for_bq(m, isTRUE(input$include_already))
      if (!nrow(rows)) return(output$load_status <- renderUI(note("status-warning", "Nothing to load: every row was imported before.")))
      r <- withProgress(message = sprintf("Loading %d row(s) into BigQuery...", nrow(rows)), tryCatch(api_manager$bq_insert_funding(rows), error = function(e) e))
      if (inherits(r, "error")) return(output$load_status <- renderUI(note("status-error", "Not loaded: ", conditionMessage(r))))
      rep_n <- sum(rows$repeated == "TRUE")
      cat(sprintf("[Collaboration Sync] loaded %d row(s) from CollaborationPlanning (%d repeated)\n", r, rep_n))
      api_manager$bq_bump("state_trigger_funding")
      marked(collab_mark_repeats(m[, setdiff(names(m), c("status", "same_as_id"))], api_manager$bq_funding_keys()))
      output$load_status <- renderUI(note("status-success", sprintf("✓ Loaded %d programme(s) into BigQuery: %d new, %d marked as repeated. ", r, r - rep_n, rep_n),
                                          "See them in Browse Data (column ", tags$code("repeated"), ")."))
    })

    # ---- share
    share_rows <- function() {
      if (!api_manager$bq_authenticated) stop("Connect to BigQuery first (API Settings > BigQuery Config).", call. = FALSE)
      api_manager$bq_need("funding")
      if (!isTRUE(api_manager$bq_time_zone_ready[["funding"]])) api_manager$bq_ensure_time_zone_column("funding")
      d <- api_manager$bq_query(sprintf("SELECT * FROM `%s`", api_manager$bq_full_table_funding))
      if (is.null(d) || !nrow(d)) return(data.frame())
      if (input$which == "ours" && "source" %in% names(d)) d <- d[is.na(d$source) | !startsWith(as.character(d$source), "CollaborationPlanning"), , drop = FALSE]
      if (length(input$countries)) d <- d[d$country %in% input$countries, , drop = FALSE]
      if (length(input$categories)) d <- d[d$category %in% input$categories, , drop = FALSE]
      d
    }
    observe({   # filter choices from the table (once connected)
      api_manager$state_trigger_funding()
      req(api_manager$bq_authenticated)
      tx <- tryCatch(api_manager$bq_get_funding_taxonomy(), error = function(e) NULL)
      if (!is.null(tx)) {
        updateSelectizeInput(session, "countries", choices = sort(unique(tx$country %|g|% character(0))), server = TRUE)
        updateSelectizeInput(session, "categories", choices = sort(unique(tx$category %|g|% character(0))), server = TRUE)
      }
    })
    observeEvent(input$preview_share, {
      d <- tryCatch(share_rows(), error = function(e) e)
      output$share_status <- renderUI(if (inherits(d, "error")) note("status-error", conditionMessage(d)) else
        note("status-info", sprintf("%d programme(s) would be written as analyses: %s%s", nrow(d),
                                    paste(utils::head(d$programme_name, 8), collapse = "; "), if (nrow(d) > 8) "; ..." else "")))
    })
    observeEvent(input$share, {
      res <- withProgress(message = "Writing to CollaborationPlanning's folder...", tryCatch({
        x <- folder(); d <- share_rows()
        if (!nrow(d)) stop("No programmes match.", call. = FALSE)
        paths <- character(0)
        for (i in seq_len(nrow(d))) {
          e <- collab_export_record(d[i, , drop = FALSE], x$s, tryCatch(session$userData$user_email %|g|% "", error = function(e) ""))
          paths <- c(paths, x$f$write_analysis(e$levels, e$stem, e$json, e$html, e$analysis_id))
          incProgress(1 / nrow(d))
        }
        paths
      }, error = function(e) e))
      if (inherits(res, "error")) return(output$share_status <- renderUI(note("status-error", "Not shared: ", conditionMessage(res))))
      cat(sprintf("[Collaboration Sync] shared %d programme(s) with CollaborationPlanning\n", length(res)))
      output$share_status <- renderUI(note("status-success",
        sprintf("✓ %d programme(s) written. In CollaborationPlanning: Analysis library > Read from Drive. ", length(res)),
        tags$details(tags$summary("Files"), tags$pre(paste(res, collapse = "\n")))))
    })
  })
}
