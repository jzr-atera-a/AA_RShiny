# R/utils_td_hubs.R
# ============================================================
# Technical Designs: related tabs are shown as ONE sidebar tab with horizontal sub-tabs ("hubs").
# The existing modules keep their ids, UI and server code: a hub only places their UI inside a tabsetPanel.
#   * create_ui (global.R) skips the children as separate sidebar tabs and the hub draws them;
#   * create_server builds a hub's children together with the hub (see global.R);
#   * td_nav() jumps to a child: it selects the hub in the sidebar and the sub-tab inside it.
# ============================================================

TD_HUBS <- list(
  td_hub_arch = list(title = "Architectures and Design Patterns", icon = "sitemap",
    blurb = "ML / GenAI and data processing architectures and software design patterns: learn them in the guide, get a recommendation for your problem, then generate and draw the one you need.",
    children = list(
      list(id = "techdesign_guide", label = "Design Guide", icon = "book"),
      list(id = "techdesign_recommender", label = "Design Recommender", icon = "lightbulb"),
      list(id = "techdesign_ml", label = "ML / GenAI", icon = "brain"),
      list(id = "techdesign_data", label = "Data Processing", icon = "database"),
      list(id = "techdesign_patterns", label = "Software Patterns", icon = "puzzle-piece"))),
  td_hub_algo = list(title = "Algorithms (LeetCode / Meta interview)", icon = "project-diagram",
    blurb = "Start with the handbook of the 23 LeetCode pattern groups, then paste your question in the selector: the Editing Tool recommends the pattern and draws it as an interactive network you can save and download.",
    children = list(
      list(id = "techdesign_algo_handbook", label = "Intro and Handbook", icon = "book-open"),
      list(id = "techdesign_algorithm", label = "Select, Generate and Visualise", icon = "magic"))),
  td_hub_social = list(title = "Social Dynamics Algorithms", icon = "users",
    blurb = "The top 36 social dynamics algorithms for influencing people, romantic partners, business partners, investors and collaborators: overview, handbook with scenarios and Harvard references, and one diagram tab per audience.",
    children = list(
      list(id = "techdesign_soc_guide", label = "Top 36 Overview", icon = "list-ol"),
      list(id = "techdesign_soc_handbook", label = "Handbook", icon = "book-open"),
      list(id = "techdesign_soc_influence", label = "Influencing", icon = "bullhorn"),
      list(id = "techdesign_soc_romantic", label = "Romantic", icon = "heart"),
      list(id = "techdesign_soc_business", label = "Business", icon = "handshake"),
      list(id = "techdesign_soc_investors", label = "Investors", icon = "chart-line"),
      list(id = "techdesign_soc_collab", label = "Collaborators", icon = "users"))),
  td_hub_manage = list(title = "Library and Editing", icon = "layer-group",
    blurb = "Everything saved in the Technical Designs table: browse the library, edit a design, compare two designs side by side, or paste designs in bulk.",
    children = list(
      list(id = "techdesign_library", label = "Design Library", icon = "layer-group"),
      list(id = "techdesign_editor", label = "Design Editor", icon = "edit"),
      list(id = "techdesign_compare", label = "Compare Designs", icon = "columns"),
      list(id = "techdesign_bulk_import", label = "Bulk Import", icon = "file-import"))),
  td_hub_studio = list(title = "Studios", icon = "palette",
    blurb = "Presentation tools: the Market Matrix and the Infographic Studio turn designs and evidence into visual one-pagers and slides.",
    children = list(
      list(id = "techdesign_matrix", label = "Market Matrix", icon = "table"),
      list(id = "techdesign_infographic", label = "Infographic Studio", icon = "palette")))
)
TD_HUB_OF <- unlist(lapply(names(TD_HUBS), function(h) setNames(rep(h, length(TD_HUBS[[h]]$children)), vapply(TD_HUBS[[h]]$children, function(x) x$id, ""))))
TD_HUB_CHILD_IDS <- names(TD_HUB_OF)

td_hub_ui <- function(hub) {
  h <- TD_HUBS[[hub]]
  tagList(
    div(class = "td-hub-banner", h3(icon(h$icon), " ", h$title), p(h$blurb)),
    div(class = "td-hub",
        do.call(tabsetPanel, c(list(id = paste0(hub, "_tabs"), type = "tabs"),
          lapply(h$children, function(ch) {
            f <- get(paste0(ch$id, "_ui"), envir = .GlobalEnv)
            tabPanel(title = tagList(icon(ch$icon), " ", ch$label), value = ch$id, f(ch$id))
          }))))
  )
}

# Jump to a Technical Designs tab by its old tab id: selects the hub in the sidebar and the sub-tab inside it.
td_nav <- function(session, tab) {
  root <- session$rootScope()
  hub <- unname(TD_HUB_OF[tab])
  if (length(hub) == 0 || is.na(hub)) { updateTabItems(root, "sidebar_menu", selected = tab); return(invisible()) }
  updateTabItems(root, "sidebar_menu", selected = hub)
  updateTabsetPanel(root, paste0(hub, "_tabs"), selected = tab)
  invisible()
}
