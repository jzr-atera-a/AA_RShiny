# modules/Six Sigma Analysis/sixsigma_tool_guide/ui.R

# Small local helper - not exported, just keeps the 33 cards below
# consistent without repeating the same box/layout markup every time.
.sixsigma_tool_card <- function(name, when_to_use, best_for, sample_request) {
  box(
    title = name, status = "primary", solidHeader = TRUE, width = 6,
    p(tags$strong("Use it when: "), when_to_use),
    p(tags$strong("Best for: "), best_for),
    div(class = "example-box",
        h4("Try asking for it like this:"),
        p(tags$em(sample_request))
    )
  )
}

.sixsigma_phase_header <- function(phase_label, phase_description) {
  fluidRow(
    box(width = 12, status = "warning", solidHeader = FALSE,
        style = "background-color: #FFFACD; border-left: 5px solid #FF8C00;",
        h4(phase_label, style = "margin-top: 0;"),
        p(phase_description, style = "margin-bottom: 0;")
    )
  )
}

sixsigma_tool_guide_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "Which Six Sigma diagram should I ask for?", status = "primary", solidHeader = TRUE, width = 12,
          p("Each entry below is one value of the ", tags$strong("Diagram Type"), " dropdown on the Generate ",
            "Diagram tab, organized by which of the 7 Groups (", tags$strong("Diagram Group"), ") it belongs ",
            "to - covering every tool named in the Lean Six Sigma Green Belt Body of Knowledge. Pick the Group ",
            "first (which phase or lens of the project you're in), then the specific Type. As with Strategic ",
            "Analysis, Claude fills in the content - but for several of these tools (Pareto, Control Chart, ",
            "FMEA, Pugh Matrix, Gage R&R, Scatter Plot, Normal Distribution, Process Capability, Spaghetti ",
            "Diagram) the app itself calculates every derived number, never Claude, so the maths is always correct.")
      )
    ),

    .sixsigma_phase_header("FRAMEWORK OVERVIEW", "The overarching Six Sigma methodology and organizational structure, before diving into a specific project phase."),
    fluidRow(
      .sixsigma_tool_card(
        "DMAIC Process Flow",
        "you need to show the 5-phase methodology used to improve an existing process.",
        "framing a project plan or explaining the Six Sigma approach to stakeholders.",
        "\"Show the DMAIC process for improving our order fulfillment cycle time\""
      ),
      .sixsigma_tool_card(
        "DMADV Process Flow",
        "you're designing a new product or process from scratch, rather than improving an existing one.",
        "Design for Six Sigma (DFSS) projects.",
        "\"Show the DMADV process for designing our new customer onboarding flow\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Six Sigma Roles Hierarchy",
        "you need to explain the belt-based organizational structure of a Six Sigma program.",
        "onboarding new team members or clarifying who does what.",
        "\"Show our Six Sigma roles hierarchy from Champions to Yellow Belts\""
      ),
      box(title = "Moving into Define", status = "info", solidHeader = TRUE, width = 6,
          p("Once the methodology is clear, the Define-phase tools below help scope the actual project.")
      )
    ),

    .sixsigma_phase_header("DEFINE", "Scoping the project and translating customer needs into measurable requirements."),
    fluidRow(
      .sixsigma_tool_card(
        "SIPOC",
        "you need a high-level view of a process's boundaries before mapping it in detail.",
        "scoping a project and identifying key stakeholders at the very start.",
        "\"Build a SIPOC for our invoice processing workflow\""
      ),
      .sixsigma_tool_card(
        "CTQ Tree",
        "you need to translate a vague customer need into specific, measurable requirements.",
        "turning Voice of the Customer feedback into concrete project success metrics.",
        "\"Build a CTQ tree for 'reliable delivery' for our logistics customers\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Stakeholder Analysis",
        "you need to prioritize how to engage different stakeholders based on their power and interest.",
        "planning communication and change management for a project.",
        "\"Build a stakeholder power/interest grid for our ERP rollout\""
      ),
      .sixsigma_tool_card(
        "Voice of the Customer Tree",
        "you need to show how raw customer statements translate into specific requirements.",
        "grounding a project in what customers actually said, not assumptions.",
        "\"Build a Voice of Customer tree for our restaurant's service complaints\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Cost of Quality",
        "you want to categorize quality-related spending into prevention, appraisal, and failure costs.",
        "building the financial case for a quality improvement project.",
        "\"Break down the cost of quality for our current defect rate\""
      ),
      box(title = "Moving into Measure", status = "info", solidHeader = TRUE, width = 6,
          p("Once the project is scoped, the Measure-phase tools below help document and quantify the current state.")
      )
    ),

    .sixsigma_phase_header("MEASURE", "Documenting how the process actually works today, and collecting reliable data about it."),
    fluidRow(
      .sixsigma_tool_card(
        "Process Map",
        "you need to document the actual step-by-step flow of a process, including decision points.",
        "building a shared, accurate baseline understanding before root-cause analysis.",
        "\"Map our current mortgage approval process including decision points\""
      ),
      .sixsigma_tool_card(
        "Gage R&R",
        "you need to confirm your measurement system itself isn't the source of process variation.",
        "validating data reliability before trusting any other analysis built on it.",
        "\"Show a Gage R&R breakdown for our caliper measurements on machined parts\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "House of Quality",
        "you need to translate customer requirements into technical specifications (QFD).",
        "product development teams balancing customer needs against engineering trade-offs.",
        "\"Build a House of Quality matrix for our new laptop's cooling requirements\""
      ),
      .sixsigma_tool_card(
        "Check Sheet",
        "you need a simple structured way to show tallied data collection results.",
        "presenting raw defect/event counts by category and time period.",
        "\"Build a check sheet for defect types recorded over 5 shifts\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Histogram",
        "you need to show the shape of a data distribution.",
        "understanding spread, central tendency, and skew in measurement data.",
        "\"Build a histogram of our call center response times\""
      ),
      .sixsigma_tool_card(
        "Scatter Plot",
        "you suspect two variables are correlated and want to see (and quantify) the relationship.",
        "correlation analysis - the app computes the trend line and correlation coefficient for you.",
        "\"Build a scatter plot of machine temperature vs. defect rate\""
      )
    ),

    .sixsigma_phase_header("ANALYSE", "Finding and prioritizing the root cause(s) of the problem."),
    fluidRow(
      .sixsigma_tool_card(
        "Fishbone / Ishikawa Diagram",
        "you need to brainstorm and categorize potential root causes across standard categories.",
        "structured cause exploration across Methods, Machines, Materials, Manpower, Measurement, and Environment.",
        "\"Build a fishbone diagram investigating why our deliveries keep arriving late\""
      ),
      .sixsigma_tool_card(
        "Five Whys",
        "you need a fast, simple drill-down from a symptom to a single dominant root cause.",
        "quick investigations that don't need a full team brainstorm.",
        "\"Do a Five Whys on why our website checkout keeps failing\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Pareto Chart",
        "you need to prioritize which causes or categories to fix first, based on frequency, cost, or impact.",
        "focusing limited improvement resources using the 80/20 rule.",
        "\"Build a Pareto chart of our top customer complaint categories\""
      ),
      .sixsigma_tool_card(
        "FMEA (Failure Mode & Effects Analysis)",
        "you need to proactively assess and prioritize the risk of potential failure modes before they occur.",
        "risk-based prioritization using Severity \u00d7 Occurrence \u00d7 Detection (RPN) - the app computes RPN for you.",
        "\"Build an FMEA for our new online payment system\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Current Reality Tree",
        "you need to trace a chain of intermediate causes back to a single deep root cause (Theory of Constraints).",
        "complex problems with multiple layered symptoms, not a single obvious cause.",
        "\"Build a Current Reality Tree for chronic late shipments\""
      ),
      .sixsigma_tool_card(
        "Spaghetti Diagram",
        "you want to visualize wasted movement of people, materials, or information through a workspace.",
        "identifying layout inefficiencies - the app computes the total distance travelled for you.",
        "\"Build a spaghetti diagram of a nurse's movement pattern through a hospital ward\""
      )
    ),

    .sixsigma_phase_header("IMPROVE", "Designing, comparing, and piloting solutions."),
    fluidRow(
      .sixsigma_tool_card(
        "Pugh Decision Matrix",
        "you need to objectively compare several candidate solutions against a baseline across multiple criteria.",
        "solution-selection decisions where you want to remove personal bias - the app computes each column's total.",
        "\"Compare 3 candidate CRM systems using a Pugh matrix against our current system\""
      ),
      .sixsigma_tool_card(
        "DOE Factorial Design Table",
        "you need to plan an experiment that tests multiple process factors at once, efficiently.",
        "finding optimal process operating settings without testing every combination one at a time.",
        "\"Design a 2x2 factorial experiment testing temperature and pressure on yield\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "5S Workplace Organisation",
        "you're planning a foundational workplace organization initiative.",
        "creating a disciplined foundation (Sort, Set in Order, Shine, Standardise, Sustain) that other improvements build on.",
        "\"Plan a 5S implementation for our warehouse picking area\""
      ),
      .sixsigma_tool_card(
        "Seven Deadly Wastes",
        "you need to categorize sources of waste in a process using the classic Lean taxonomy.",
        "waste identification workshops (Transport, Inventory, Motion, Waiting, Overproduction, Over-processing, Defects).",
        "\"Identify the seven wastes present in our current order-picking process\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Five Lean Principles",
        "you need to frame an improvement effort around the core Lean philosophy.",
        "explaining the Value-Value Stream-Flow-Pull-Perfection sequence to a team.",
        "\"Apply the five Lean principles to our software deployment pipeline\""
      ),
      .sixsigma_tool_card(
        "Poka-Yoke Devices",
        "you want to inventory specific error-proofing mechanisms for a process.",
        "cataloguing prevention vs. detection devices side by side.",
        "\"List Poka-Yoke devices to prevent wrong-part assembly on our production line\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "SMED Analysis",
        "you need to plan reducing changeover/setup time on equipment.",
        "classifying activities as internal (machine stopped) vs. external (done while running).",
        "\"Build a SMED analysis for our injection moulding changeover\""
      ),
      .sixsigma_tool_card(
        "Chaku-Chaku Flow",
        "you're designing a one-operator, multi-station continuous flow production line.",
        "visualizing the sequence of stations an operator moves through.",
        "\"Design a Chaku-Chaku flow for our small parts assembly cell\""
      )
    ),

    .sixsigma_phase_header("CONTROL", "Monitoring that the improvement sticks, long after the project ends."),
    fluidRow(
      .sixsigma_tool_card(
        "Control Chart",
        "you need to monitor whether a process is statistically stable over time.",
        "ongoing process monitoring and detecting special-cause variation - the app computes the center line and \u00b13\u03c3 limits from your data, never trusting Claude with that maths.",
        "\"Build a control chart for our call center average handle time over the last 15 days\""
      ),
      .sixsigma_tool_card(
        "Balanced Scorecard",
        "you need to track strategic performance across multiple perspectives at once, not just one metric.",
        "holistic, ongoing monitoring across Financial, Customer, Internal Process, and Learning & Growth.",
        "\"Build a balanced scorecard for our customer service department\""
      )
    ),
    fluidRow(
      .sixsigma_tool_card(
        "Andon Board",
        "you want a visual status signal board showing the current state of multiple stations/lines at a glance.",
        "real-time visual management on a shop floor or service line.",
        "\"Build an Andon board for our 5 assembly line stations\""
      ),
      box(title = "Moving to Data Analysis", status = "info", solidHeader = TRUE, width = 6,
          p("The Data Analysis tools below sit underneath everything else - they're the statistical foundation ",
            "for judging whether a process is actually capable and stable.")
      )
    ),

    .sixsigma_phase_header("DATA ANALYSIS", "The statistical foundation - understanding variation and process capability."),
    fluidRow(
      .sixsigma_tool_card(
        "Normal Distribution",
        "you want to illustrate the Central Limit Theorem or a bell-curve-shaped distribution.",
        "teaching/explaining variation - the app computes the actual bell curve from just a mean and standard deviation.",
        "\"Show the normal distribution of our part weights with mean 250g and sd 3g\""
      ),
      .sixsigma_tool_card(
        "Process Capability (Cp/Cpk)",
        "you need to formally assess whether a process can reliably meet specification limits.",
        "capability studies - the app computes Cp, Cpk, and an approximate sigma level from your raw mean/sigma/spec limits, never trusting Claude with that maths.",
        "\"Assess process capability for our shaft diameter with spec 100\u00b15mm\""
      )
    ),
    fluidRow(
      box(title = "Still not sure?", status = "info", solidHeader = TRUE, width = 12,
          p("If you know the tool's name, just say it in your request - e.g. \"Build a Fishbone for...\" - and ",
            "pick the matching Group + Type from the dropdowns above. Claude fills in the content; the Type you ",
            "pick fixes the exact structure and, where the tool involves real statistics, guarantees the app - ",
            "not Claude - does the maths.")
      )
    )
  )
}
