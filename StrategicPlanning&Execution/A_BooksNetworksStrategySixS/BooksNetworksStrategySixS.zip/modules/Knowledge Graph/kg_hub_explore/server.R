# modules/Knowledge Graph/kg_hub_explore/server.R
# no logic: the hub only shows its children (their servers are built together with the hub, see create_server)
kg_hub_explore_server <- function(id, api_manager) invisible(NULL)
