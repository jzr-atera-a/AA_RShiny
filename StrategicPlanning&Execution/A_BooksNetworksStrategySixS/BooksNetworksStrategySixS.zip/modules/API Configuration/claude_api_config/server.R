# modules/claude_api_config/server.R
# Claude API Configuration Server Logic

claude_api_config_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    cred_tick <- reactiveVal(0)
    output$auto_key <- renderUI(app_cred_banner("claude", cred_tick))
    observeEvent(input$cred_load, {
      d <- trimws(input$cred_dir %||% ""); if (!nzchar(d)) { showNotification("Type the folder first.", type = "warning"); return() }
      app_cred_autoload(api_manager, dir = d, which = "claude", force = TRUE); cred_tick(cred_tick() + 1)
    })

    observeEvent(input$test_connection, {
      typed <- nzchar(trimws(input$api_key %||% ""))
      if (!typed && !(isTRUE(api_manager$claude_authenticated) && !is.null(api_manager$claude_api_key))) {
        showNotification("Paste a key first, or load one from the key folder.", type = "warning"); return()
      }

      output$status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"),
                 " Testing connection...")
      })

      tryCatch({
        # empty box = test the key already loaded (for example from the key folder)
        api_manager$set_claude_credentials(
          api_key = if (typed) input$api_key else api_manager$claude_api_key,
          model = input$model,
          max_tokens = input$max_tokens,
          timeout = input$timeout
        )

        api_manager$test_claude_connection()

        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   " ✓ Connection Successful!",
                   tags$br(),
                   tags$small("Model: ", input$model),
                   tags$br(),
                   tags$small("Timeout: ", input$timeout, " seconds"),
                   tags$br(),
                   tags$small("Status: Ready to generate tables"))
        })

        showNotification("✓ Editing Tool API connection successful!", type = "message")

      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Connection Failed: ",
                   tags$br(),
                   tags$small(e$message))
        })
        showNotification(paste("Error:", e$message), type = "error", duration = 10)
      })
    })

    observeEvent(input$save_credentials, {
      req(input$api_key)

      api_manager$set_claude_credentials(
        api_key = input$api_key,
        model = input$model,
        max_tokens = input$max_tokens,
        timeout = input$timeout
      )

      showNotification("✓ Credentials saved successfully!", type = "message")

      output$status <- renderUI({
        tags$div(class = "status-success",
                 tags$i(class = "fa fa-check-circle"),
                 " Credentials Saved",
                 tags$br(),
                 tags$small("Model: ", input$model),
                 tags$br(),
                 tags$small("Max Tokens: ", input$max_tokens),
                 tags$br(),
                 tags$small("Timeout: ", input$timeout, " seconds"))
      })
    })

    observeEvent(input$diagnose, {
      output$diagnostics_output <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"),
                 " Running diagnostics... check the R console for live detail.")
      })

      lines <- tryCatch({
        api_manager$diagnose_network()
      }, error = function(e) {
        c(paste("Diagnostics failed to run:", e$message))
      })

      output$diagnostics_output <- renderUI({
        tags$div(class = "status-info",
                 tags$pre(style = "white-space: pre-wrap; font-size: 12px;",
                          paste(lines, collapse = "\n")))
      })
    })

    output$status <- renderUI({ tags$div() })
    output$diagnostics_output <- renderUI({ tags$div() })

    session$onSessionEnded(function() {})
  })
}
