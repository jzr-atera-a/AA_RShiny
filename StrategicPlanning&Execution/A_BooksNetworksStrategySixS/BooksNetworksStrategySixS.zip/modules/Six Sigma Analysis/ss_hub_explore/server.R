# modules/Six Sigma Analysis/ss_hub_explore/server.R
# no logic: the hub only shows its children (their servers are built together with the hub, see create_server)
ss_hub_explore_server <- function(id, api_manager) invisible(NULL)
