# modules/Six Sigma Analysis/sixsigma_visualizations.R
# ---- module --------------------------------------------------------------------------------------
# id:           sixsigma_visualizations
# name:         Six Sigma Visualizations
# label:        Visualizations
# icon:         project-diagram
# description:  Render a selected Six Sigma diagram using the type-appropriate professional renderer
# packages:     shiny, shinydashboard, plotly
# api_optional: bigquery
# --------------------------------------------------------------------------------------------------

# ==== UI ===========================================================================================

sixsigma_visualizations_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "Select a Six Sigma Diagram to View", status = "primary", solidHeader = TRUE, width = 12,
          fluidRow(
            column(3, selectInput(ns("viz_category"), "Category: *", choices = NULL)),
            column(3, selectInput(ns("viz_domain"), "Domain: *", choices = NULL)),
            column(3, selectInput(ns("viz_topic"), "Topic: *", choices = NULL)),
            column(3, selectInput(ns("viz_diagram_id"), "Diagram: *", choices = NULL))
          ),
          actionButton(ns("view"), "Render Diagram", icon = icon("eye"),
                      class = "btn-primary btn-lg", style = "width: 100%;")
      )
    ),
    fluidRow(
      box(title = "Rendered Diagram", status = "success", solidHeader = TRUE, width = 12,
          htmlOutput(ns("status")),
          export_controls_ui(ns, ns("export_target"), "sixsigma_diagram"),
          uiOutput(ns("diagram_output"))
      )
    )
  )
}

# ==== Server =======================================================================================

sixsigma_visualizations_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    # ------------------------------------------------------------
    # Category -> Domain -> Topic -> Diagram cascade, same pattern as
    # Strategic Analysis's diagram_visualizations and Knowledge Graph's
    # visualize_kg_d3 - four short, chained dropdowns instead of one
    # mega-dropdown. The Diagram label includes the specific tool name
    # (e.g. "Fishbone / Ishikawa Diagram") so picking among several
    # diagrams under the same topic is unambiguous even without a
    # separate Group/Type filter at this stage.
    #
    # IMPORTANT: every level below uses observe() and reads viz_taxonomy()
    # directly, rather than observeEvent(input$viz_category, ...) reacting
    # only to the PARENT INPUT'S VALUE changing. That distinction matters:
    # if a fresh diagram is uploaded under a Category/Domain string that
    # was already selected (e.g. re-using a Domain string under a
    # different Category than before), the dropdown's SELECTED VALUE never
    # actually changes even though the underlying data behind it did - so
    # observeEvent(input$viz_domain, ...) would never re-fire, leaving
    # Topic/Diagram silently stuck showing OLD data that happened to share
    # that Domain string. observe() has no such gap: it re-runs whenever
    # ANY reactive value read inside it changes, including viz_taxonomy()
    # itself, so a fresh BigQuery pull always recascades all the way down
    # regardless of whether any dropdown's selected string happens to
    # coincide with its previous value.
    # ------------------------------------------------------------
    viz_taxonomy <- reactive({
      api_manager$state_trigger_sixsigma()
      if (!api_manager$bq_authenticated) return(api_manager$empty_sixsigma_taxonomy())
      tryCatch(api_manager$bq_get_sixsigma_taxonomy(), error = function(e) api_manager$empty_sixsigma_taxonomy())
    })

    observe({
      tax <- viz_taxonomy()
      categories <- sort(unique(tax$category[nchar(trimws(tax$category)) > 0]))
      if (length(categories) == 0) {
        updateSelectInput(session, "viz_category", choices = c("(no categories yet)" = ""))
      } else {
        current <- isolate(input$viz_category)
        selected <- if (!is.null(current) && current %in% categories) current else categories[1]
        updateSelectInput(session, "viz_category", choices = setNames(categories, categories), selected = selected)
      }
    })

    observe({
      tax <- viz_taxonomy()
      cat_val <- input$viz_category
      if (is.null(cat_val) || cat_val == "") {
        updateSelectInput(session, "viz_domain", choices = c("(select a category first)" = ""))
        return()
      }
      domains <- sort(unique(tax$domain[tax$category == cat_val & nchar(trimws(tax$domain)) > 0]))
      if (length(domains) == 0) {
        updateSelectInput(session, "viz_domain", choices = c("(no domains found)" = ""))
      } else {
        current <- isolate(input$viz_domain)
        selected <- if (!is.null(current) && current %in% domains) current else domains[1]
        updateSelectInput(session, "viz_domain", choices = setNames(domains, domains), selected = selected)
      }
    })

    observe({
      tax <- viz_taxonomy()
      cat_val <- input$viz_category
      dom_val <- input$viz_domain
      if (is.null(cat_val) || is.null(dom_val) || cat_val == "" || dom_val == "") {
        updateSelectInput(session, "viz_topic", choices = c("(select a domain first)" = ""))
        return()
      }
      topics <- sort(unique(tax$topic[tax$category == cat_val & tax$domain == dom_val & nchar(trimws(tax$topic)) > 0]))
      if (length(topics) == 0) {
        updateSelectInput(session, "viz_topic", choices = c("(no topics found)" = ""))
      } else {
        current <- isolate(input$viz_topic)
        selected <- if (!is.null(current) && current %in% topics) current else topics[1]
        updateSelectInput(session, "viz_topic", choices = setNames(topics, topics), selected = selected)
      }
    })

    observe({
      tax <- viz_taxonomy()
      cat_val <- input$viz_category
      dom_val <- input$viz_domain
      top_val <- input$viz_topic
      if (is.null(cat_val) || is.null(dom_val) || is.null(top_val) ||
          cat_val == "" || dom_val == "" || top_val == "") {
        updateSelectInput(session, "viz_diagram_id", choices = c("(select a topic first)" = ""))
        return()
      }

      diagrams <- tax[tax$category == cat_val & tax$domain == dom_val & tax$topic == top_val, , drop = FALSE]
      if (nrow(diagrams) == 0) {
        updateSelectInput(session, "viz_diagram_id", choices = c("(no diagrams found)" = ""))
      } else {
        labels <- sprintf("%s - %s (%s)", diagrams$diagram_name, diagrams$title,
                          ifelse(diagrams$is_template, "template", "generated"))
        current <- isolate(input$viz_diagram_id)
        choices <- setNames(diagrams$diagram_id, labels)
        selected <- if (!is.null(current) && current %in% diagrams$diagram_id) current else diagrams$diagram_id[1]
        updateSelectInput(session, "viz_diagram_id", choices = choices, selected = selected)
      }
    })

    # ------------------------------------------------------------
    # Pull + render the selected diagram
    # ------------------------------------------------------------
    observeEvent(input$view, {
      diag_id <- input$viz_diagram_id
      if (is.null(diag_id) || nchar(trimws(diag_id)) == 0) {
        showNotification("No diagram selected.", type = "warning")
        return()
      }

      output$status <- renderUI({ tags$div(class = "status-info", tags$i(class = "fa fa-spinner fa-spin"), " Loading diagram...") })

      cat("========================================================\n")
      cat("📥 [Six Sigma Analysis][DEBUG] Visualizations tab: pulling diagram from BigQuery\n")
      cat(sprintf("    diagram_id : %s\n", diag_id))
      t0 <- Sys.time()

      tryCatch({
        components <- api_manager$bq_get_sixsigma_components(diag_id)
        query_elapsed <- round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 2)

        if (nrow(components) == 0) {
          cat(sprintf("    result     : 0 rows returned in %ss - nothing to render\n", query_elapsed))
          cat("========================================================\n")
          output$status <- renderUI({
            tags$div(class = "status-warning", tags$i(class = "fa fa-exclamation-triangle"), " No components found for this diagram_id.")
          })
          output$diagram_output <- renderUI({ tags$div() })
          return()
        }

        diagram_type <- components$diagram_type[1]
        component_type_counts <- table(components$component_type)

        cat(sprintf("    result     : %d row(s) returned in %ss\n", nrow(components), query_elapsed))
        cat(sprintf("    diagram_type  : %s (group: %s)\n", diagram_type, components$diagram_group[1]))
        cat(sprintf("    diagram_name  : %s | title: %s\n", components$diagram_name[1], components$title[1]))
        cat(sprintf("    category/domain/topic : %s / %s / %s\n", components$category[1], components$domain[1], components$topic[1]))
        cat("    component_type breakdown:\n")
        for (ct_name in names(component_type_counts)) {
          cat(sprintf("      - %-20s : %d\n", ct_name, component_type_counts[[ct_name]]))
        }
        if (diagram_type == "fmea_table") {
          n_fmea <- sum(!is.na(components$severity))
          cat(sprintf("    FMEA rows with S/O/D set : %d (RPN will be computed at render time)\n", n_fmea))
        }
        if (diagram_type %in% c("sipoc", "doe_table", "pugh_matrix") && all(is.na(components$grid_col))) {
          cat("    ⚠️  WARNING: diagram_type expects grid_col but all values are NA - layout may be degenerate\n")
        }
        cat("========================================================\n")

        render_t0 <- Sys.time()
        rendered <- render_sixsigma(components, diagram_type)
        render_elapsed <- round(as.numeric(difftime(Sys.time(), render_t0, units = "secs")), 3)
        cat(sprintf("🎨 [Six Sigma Analysis][DEBUG] render_sixsigma() completed in %ss\n", render_elapsed))

        export_title <- if (has_real_value(components$title[1])) components$title[1] else diagram_type
        output$diagram_output <- renderUI({ export_capture_wrapper(session$ns, rendered, export_title, meta = components) })
        output$status <- renderUI({
          tags$div(class = "status-success", tags$i(class = "fa fa-check-circle"),
                   sprintf(" Rendered %d component(s) as '%s'", nrow(components), diagram_type))
        })

      }, error = function(e) {
        cat(sprintf("❌ [Six Sigma Analysis][DEBUG] Visualization failed: %s\n", app_err_text(e)))
        cat("========================================================\n")
        output$status <- renderUI({
          tags$div(class = "status-error", tags$i(class = "fa fa-times-circle"), " Error: ", app_err_text(e))
        })
        output$diagram_output <- renderUI({ tags$div() })
      })
    })

    output$status <- renderUI({ tags$div() })
    output$diagram_output <- renderUI({ tags$div() })
  })
}
