# modules/Book Summary/books_bulk_import.R
# ---- module --------------------------------------------------------------------------------------
# id:           books_bulk_import
# name:         Bulk Import
# icon:         file-import
# description:  Parse and upload summaries in bulk
# packages:     shiny, shinydashboard, DT
# --------------------------------------------------------------------------------------------------

# ==== UI ===========================================================================================

books_bulk_import_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(
        title = "Bulk Import Book Summary to BigQuery",
        status = "primary",
        solidHeader = TRUE,
        width = 12,

        h4("Paste or Generate Book Summary"),
        p("Paste a complete book summary to parse and upload to BigQuery."),

        div(class = "alert alert-info",
            tags$strong("Format with NEW Fields:"),
            tags$ul(
              tags$li("Book metadata: [Title], [Author], [Genre], [Topic]"),
              tags$li("[chapter], [section], [main_details]"),
              tags$li("NEW: [formula], [formula_explanation]"),
              tags$li("NEW: [reference_url], [reference_description]"),
              tags$li("[numeric_data], [numeric_data_description]")
            )
        ),

        textAreaInput(ns("summary_text"), "Paste Book Summary Here:", height = "500px",
                      placeholder = "[Book Title]\n[Author]\n[Genre]\n[Topic]\n\n[chapter]: Chapter 01: Title\n..."),

        fluidRow(
          column(4, actionButton(ns("parse"), "Parse Summary", class = "btn-info btn-lg",
                                 icon = icon("cogs"), width = "100%")),
          column(4, actionButton(ns("upload"), "Upload to BigQuery", class = "btn-success btn-lg",
                                 icon = icon("cloud-upload-alt"), width = "100%")),
          column(4, actionButton(ns("clear"), "Clear All", class = "btn-danger",
                                 icon = icon("trash"), width = "100%"))
        ),

        br(),
        htmlOutput(ns("status"))
      )
    ),

    fluidRow(
      box(
        title = "Parsed Data Preview",
        status = "info",
        solidHeader = TRUE,
        width = 12,
        htmlOutput(ns("parse_info")),
        br(),
        div(class = "preview-section", DT::dataTableOutput(ns("preview_table")))
      )
    )
  )
}

# ==== Server =======================================================================================

books_bulk_import_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    parsed_data <- reactiveVal(NULL)

    # Receive text pushed from the Generate Summary tab's "Copy to Bulk
    # Import" button (see APIManager$pending_bulk_text in R/utils_api.R)
    observeEvent(api_manager$pending_bulk_text_books(), {
      incoming_text <- api_manager$pending_bulk_text_books()
      if (nchar(incoming_text) > 0) {
        cat("📥 [bulk_import] Received text from generate_summary (", nchar(incoming_text), "chars )\n")
        updateTextAreaInput(session, "summary_text", value = incoming_text)
      }
    }, ignoreInit = FALSE)   # FALSE: a tab built lazily (after the hand-off) still picks the text up

    # Parse summary
    observeEvent(input$parse, {

      if (trimws(input$summary_text) == "") {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-exclamation-triangle"),
                   " Please paste a summary to parse")
        })
        return()
      }

      output$status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"),
                 " Parsing...")
      })

      tryCatch({
        parsed_df <- parse_summary_text(input$summary_text)
        parsed_data(parsed_df)

        output$parse_info <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Successfully parsed %d entries from '%s' by %s",
                           nrow(parsed_df), parsed_df$book_name[1], parsed_df$author[1]))
        })

        output$preview_table <- DT::renderDataTable({
          DT::datatable(parsed_df, options = list(pageLength = 10, scrollX = TRUE), rownames = FALSE)
        })

        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Parsed %d entries!", nrow(parsed_df)))
        })

        showNotification(sprintf("✓ Parsed %d entries!", nrow(parsed_df)), type = "message")

      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Error: ", app_err_text(e))
        })
        showNotification(paste("Error:", app_err_text(e)), type = "error")
      })
    })

    # Upload to BigQuery
    observeEvent(input$upload, {

      if (!api_manager$bq_authenticated) {
        showNotification("Please authenticate with BigQuery first!", type = "error")
        return()
      }

      if (is.null(parsed_data())) {
        showNotification("Please parse the summary first!", type = "error")
        return()
      }

      output$status <- renderUI({
        tags$div(class = "status-info",
                 tags$i(class = "fa fa-spinner fa-spin"),
                 " Uploading...")
      })

      tryCatch({
        rows_uploaded <- api_manager$bq_insert_books(parsed_data())

        # ⭐ TRIGGER DATA REFRESH - notify other modules
        api_manager$trigger_state_update_books()

        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Successfully uploaded %d rows! Visualizations updated.", rows_uploaded))
        })

        showNotification(sprintf("✓ Uploaded %d rows!", rows_uploaded), type = "message")

      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"),
                   " Error: ", app_err_text(e))
        })
        showNotification(paste("Error:", app_err_text(e)), type = "error")
      })
    })

    # Clear
    observeEvent(input$clear, {
      updateTextAreaInput(session, "summary_text", value = "")
      parsed_data(NULL)
      output$parse_info <- renderUI({})
      output$preview_table <- DT::renderDataTable({})
      output$status <- renderUI({
        tags$div(class = "status-info", "Cleared.")
      })
    })

    # Default outputs
    output$status <- renderUI({ tags$div() })
    output$parse_info <- renderUI({ tags$div() })
    output$preview_table <- DT::renderDataTable({})

  })
}
