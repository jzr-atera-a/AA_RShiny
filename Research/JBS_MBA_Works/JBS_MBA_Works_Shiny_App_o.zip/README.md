# MBA 2024–2025 · Works & Essays (R Shiny)

Interactive companion to the collection *Jose_Zubizarreta_MBA_Works_and_Essays*.

## Run
```r
install.packages(c("shiny", "shinydashboard", "plotly", "DT"))
shiny::runApp("JBS_MBA_Works_App")   # or open app.R in RStudio and press Run App
```
Tested with R 4.x, shiny 1.8.0, shinydashboard 0.7.2, plotly 4.10.4, DT 0.31.

## Structure
- `app.R` — user interface, server, tab builders and the term-grouped sidebar.
- `R/data_works.R` — one entry per work: term, code, hand-in date, printed pages,
  word count (where the cover sheet states it), summary, key arguments,
  conclusions and frameworks. Edit this file to change any text.
- `www/styles.css` — stylesheet.
- `www/pdf/` — one PDF per work (cut from the collection, with the printed page range).
- `www/img/` — crest and JBS logo.

## Notes
- Sidebar: four term groups (Michaelmas, Lent, Easter, Summer). Each expands to a term
  overview and one tab per work, in hand-in order.
- Printed page numbers follow the collection: the cover, dedication and both introductions are
  unnumbered, and the index is page 4.
- Summaries and key points were drafted from the submitted texts to help navigation. Check them
  before sharing the app.
- The Cambridge Venture Project has no hand-in date in the index, so it is listed as undated.
