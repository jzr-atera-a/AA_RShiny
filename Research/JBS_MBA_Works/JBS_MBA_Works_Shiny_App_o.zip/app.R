# =============================================================================
# MBA 2024\u20132025 \u00b7 Works & Essays \u2014 interactive collection
# Jose Francisco Zubizarreta Rodriguez \u00b7 Cambridge Judge Business School
#
# Run:      shiny::runApp("JBS_MBA_Works_App")   (or open app.R in RStudio)
# Packages: shiny, shinydashboard, plotly, DT
# =============================================================================

library(shiny)
library(shinydashboard)
library(plotly)
library(DT)

source(file.path("R", "data_works.R"), local = TRUE, encoding = "UTF-8")

# ---- UI helpers --------------------------------------------------------------
fmt_date <- function(d) if (is.na(d)) "Undated" else format(d, "%d %B %Y")
fmt_words <- function(n) if (is.na(n)) "\u2014" else format(n, big.mark = ",")

kpi <- function(value, label, icon_name, colour = "#1D4E89") {
  div(class = "kpi-card", style = paste0("--accent:", colour),
      span(class = "kpi-ico", icon(icon_name)),
      div(class = "kpi-val", value),
      div(class = "kpi-lab", label))
}

hero <- function(kicker, title, subtitle, colour = "#1D4E89") {
  div(class = "hero", style = paste0("--accent:", colour),
      div(class = "hero-kicker", kicker),
      h2(class = "hero-title", title),
      p(class = "hero-sub", subtitle))
}

pager <- function(i) {
  n <- length(WORKS)
  prev_w <- if (i > 1) WORKS[[i - 1]] else NULL
  next_w <- if (i < n) WORKS[[i + 1]] else NULL
  div(class = "pager",
      if (!is.null(prev_w)) actionButton(paste0("prev_", WORKS[[i]]$id),
                                         paste0(" Previous: ", prev_w$code), icon = icon("chevron-left"),
                                         class = "btn-pager"),
      if (!is.null(next_w)) actionButton(paste0("next_", WORKS[[i]]$id),
                                         paste0("Next: ", next_w$code, " "), icon = icon("chevron-right"),
                                         class = "btn-pager btn-pager-next"))
}

works_table <- function(works) {
  df <- data.frame(
    Term = sapply(works, function(w) sub(" Term.*", "", w$term_label)),
    Code = sapply(works, `[[`, "code"),
    Work = sapply(works, `[[`, "title"),
    Type = sapply(works, `[[`, "type"),
    `Hand-in` = sapply(works, function(w) fmt_date(w$hand_in)),
    Pages = sapply(works, `[[`, "pages_label"),
    Words = sapply(works, function(w) fmt_words(w$words)),
    check.names = FALSE, stringsAsFactors = FALSE)
  datatable(df, rownames = FALSE, escape = TRUE, class = "cell-border stripe hover compact",
            options = list(pageLength = 25, dom = "ft", ordering = FALSE, scrollX = TRUE,
                           language = list(search = "Filter:", zeroRecords = "No matching works")))
}

# ---- Tab builders ------------------------------------------------------------
work_tab <- function(i) {
  w <- WORKS[[i]]
  term <- TERMS[[which(sapply(TERMS, `[[`, "key") == w$term)]]
  tabItem(
    tabName = w$tab,
    hero(paste(term$label, "\u00b7", w$type), w$title, w$subtitle, term$colour),
    fluidRow(
      column(3, kpi(w$code, "Assignment", "file-alt", term$colour)),
      column(3, kpi(w$pages_label, "Printed pages", "book-open", term$colour)),
      column(3, kpi(fmt_words(w$words), "Word count (cover sheet)", "pen-nib", term$colour)),
      column(3, kpi(fmt_date(w$hand_in), "Hand-in date", "calendar-alt", term$colour))
    ),
    fluidRow(
      box(width = 7, title = "Summary", status = "primary", solidHeader = TRUE,
          p(class = "lead", w$summary),
          h4(class = "sub-h", "Key arguments"),
          tags$ul(class = "bullets", lapply(w$key, tags$li))),
      box(width = 5, title = "Conclusions and recommendations", status = "primary", solidHeader = TRUE,
          tags$ul(class = "bullets", lapply(w$conclusions, tags$li)),
          h4(class = "sub-h", "Frameworks and concepts"),
          div(class = "tags", lapply(w$frameworks, function(f) span(class = "tag", f))),
          hr(),
          tags$dl(class = "meta",
                  tags$dt("Lecturer"), tags$dd(if (is.null(w$lecturer)) "\u2014" else w$lecturer),
                  tags$dt("Term"), tags$dd(term$label),
                  tags$dt("Printed pages"), tags$dd(w$pages_label)))
    ),
    fluidRow(
      box(width = 12, title = "Document", status = "info", solidHeader = TRUE,
          div(class = "viewer-bar",
              span(class = "viewer-note", icon("file-pdf"), " Pages ", w$pages_label, " of the collection"),
              div(class = "viewer-actions",
                  tags$a(href = w$file, target = "_blank", class = "btn btn-default btn-sm",
                         icon("external-link-alt"), " Open in new tab"),
                  tags$a(href = w$file, download = paste0("Zubizarreta_", w$id, ".pdf"),
                         class = "btn btn-primary btn-sm", icon("download"), " Download PDF"))),
          tags$iframe(src = paste0(w$file, "#navpanes=0&view=FitH"), class = "pdf-frame",
                      title = w$title, loading = "lazy"))
    ),
    pager(i)
  )
}

term_tab <- function(t) {
  works <- works_in(t$key)
  pages <- sum(sapply(works, function(w) w$pages[2] - w$pages[1] + 1))
  words <- sum(sapply(works, function(w) if (is.na(w$words)) 0 else w$words))
  dates <- do.call(c, lapply(works, function(w) w$hand_in))
  range_txt <- if (all(is.na(dates))) "Undated" else
    paste(format(min(dates, na.rm = TRUE), "%d %b"), "\u2013", format(max(dates, na.rm = TRUE), "%d %b %Y"))
  tabItem(
    tabName = t$tab,
    hero(paste("Term \u00b7", length(works), "works"), t$label, t$intro, t$colour),
    fluidRow(
      column(3, kpi(length(works), "Works in this term", "layer-group", t$colour)),
      column(3, kpi(pages, "Printed pages", "book-open", t$colour)),
      column(3, kpi(format(words, big.mark = ","), "Words (where stated)", "pen-nib", t$colour)),
      column(3, kpi(range_txt, "Hand-in range", "calendar-alt", t$colour))
    ),
    fluidRow(
      box(width = 12, title = "Works in this term", status = "primary", solidHeader = TRUE,
          DTOutput(paste0("tbl_", t$key)))
    )
  )
}

overview_tab <- function() {
  total_words <- sum(sapply(WORKS, function(w) if (is.na(w$words)) 0 else w$words))
  tabItem(
    tabName = "overview",
    hero("MBA 2024\u20132025 \u00b7 Cambridge Judge Business School",
         "Works & Essays",
         "Main submitted work completed by Jose Francisco Zubizarreta Rodriguez across the Michaelmas, Lent, Easter and Summer terms."),
    fluidRow(
      column(3, kpi(length(WORKS), "Works and deliveries", "folder-open")),
      column(3, kpi(4, "Terms", "calendar")),
      column(3, kpi("200", "Numbered pages", "book-open")),
      column(3, kpi(format(total_words, big.mark = ","), "Words (where stated)", "pen-nib"))
    ),
    fluidRow(
      box(width = 7, title = "About this collection", status = "primary", solidHeader = TRUE,
          p(class = "lead", "This document brings together the main submitted essays, presentations and projects completed during the MBA 2024\u20132025 at the University of Cambridge Judge Business School."),
          p("Some subjects did not require an essay, presentation or project: for these, the main grading criterion was a final examination, so no written work from those subjects appears here."),
          p("The programme changes slightly from year to year. For the full curriculum, see ",
            tags$a(href = "https://www.jbs.cam.ac.uk/masters-degrees/mba/curriculum/", target = "_blank",
                   "jbs.cam.ac.uk \u2014 MBA curriculum"), ".")),
      box(width = 5, title = "How to use this app", status = "primary", solidHeader = TRUE,
          tags$ol(class = "steps",
                  tags$li("Open a term in the sidebar to expand its works."),
                  tags$li("Each work has its summary, key arguments, conclusions and the document itself."),
                  tags$li("Use Previous and Next to move through the collection in order."),
                  tags$li("Use Timeline & index for hand-in dates, word counts and a searchable index.")))
    ),
    fluidRow(
      box(width = 12, title = "Contents", status = "info", solidHeader = TRUE, DTOutput("tbl_all"))
    )
  )
}

timeline_tab <- function() {
  tabItem(
    tabName = "timeline",
    hero("Collection tools", "Timeline & index",
         "Hand-in dates across the four terms, word counts where the cover sheets state them, and a searchable index of every work."),
    fluidRow(
      box(width = 12, title = "Hand-in timeline", status = "primary", solidHeader = TRUE,
          plotlyOutput("plot_timeline", height = "420px"),
          p(class = "note", "The Cambridge Venture Project presentation is undated and is not shown on the timeline."))),
    fluidRow(
      box(width = 12, title = "Word count by work (where stated on the cover sheet)", status = "primary", solidHeader = TRUE,
          plotlyOutput("plot_words", height = "460px"))),
    fluidRow(
      box(width = 12, title = "Index of works and page numbers", status = "info", solidHeader = TRUE,
          DTOutput("tbl_index")))
  )
}

about_tab <- function() {
  tabItem(
    tabName = "about",
    hero("Notes", "About and method",
         "How this app was built and how to read the summaries."),
    fluidRow(
      box(width = 6, title = "Source and page numbers", status = "primary", solidHeader = TRUE,
          p("All documents come from the printed collection, Jose_Zubizarreta_MBA_Works_and_Essays. Page numbers are the printed numbers in the collection: the cover is unnumbered, the dedication and both introductions are unnumbered, and the index is page 4."),
          p("Hand-in dates are taken from the index. Word counts are shown only where the cover sheet states them.")),
      box(width = 6, title = "Summaries", status = "primary", solidHeader = TRUE,
          p("The summaries, key arguments and conclusions were drafted from the submitted texts to help navigation. They are not a substitute for the documents themselves, which are shown in full in each tab."),
          p("Where a work contains a group presentation, its slides are shown three per page."))
    ),
    fluidRow(
      box(width = 12, title = "Credits", status = "info", solidHeader = TRUE,
          div(class = "credits",
              tags$img(src = "img/crest.png", alt = "Crest", class = "credit-crest"),
              div(p(tags$strong("Jose Francisco Zubizarreta Rodriguez"), " \u00b7 MBA 2024\u20132025 \u00b7 Cambridge Judge Business School"),
                  p("Master of Business Administration \u00b7 Finance Concentration \u00b7 Graduate of the Spark 1.0 Programme at King's College Entrepreneurship Lab."),
                  tags$img(src = "img/jbs_logo.jpg", alt = "Cambridge Judge Business School", class = "credit-logo")))))
  )
}

# ---- Sidebar -----------------------------------------------------------------
term_menu <- function(t) {
  works <- works_in(t$key)
  subs <- c(
    list(menuSubItem(paste0("Term overview"), tabName = t$tab, icon = icon("info-circle"))),
    lapply(works, function(w) menuSubItem(paste0(w$code, " \u00b7 ", w$short), tabName = w$tab))
  )
  do.call(menuItem, c(list(text = t$label, icon = icon(t$icon), startExpanded = FALSE), subs))
}

ui <- dashboardPage(
  title = "Works & Essays \u00b7 MBA 2024\u20132025",
  skin = "blue",
  dashboardHeader(
    title = span(icon("graduation-cap"), " Works & Essays"),
    titleWidth = 280
  ),
  dashboardSidebar(
    width = 280,
    div(class = "sidebar-brand",
        tags$img(src = "img/crest.png", alt = "Crest"),
        div(class = "sidebar-name", "Jose F. Zubizarreta Rodriguez",
            span(class = "sidebar-sub", "MBA 2024\u20132025"))),
    sidebarMenu(
      id = "menu",
      menuItem("Collection overview", tabName = "overview", icon = icon("home")),
      tags$li(class = "header", "TERMS"),
      lapply(TERMS, term_menu),
      tags$li(class = "header", "TOOLS"),
      menuItem("Timeline & index", tabName = "timeline", icon = icon("calendar-alt")),
      menuItem("About and method", tabName = "about", icon = icon("info-circle"))
    )
  ),
  dashboardBody(
    tags$head(
      tags$link(rel = "preconnect", href = "https://fonts.googleapis.com"),
      tags$link(rel = "stylesheet",
                href = "https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;600;700&display=swap"),
      tags$link(rel = "stylesheet", type = "text/css", href = "styles.css"),
      tags$meta(name = "viewport", content = "width=device-width, initial-scale=1")
    ),
    do.call(tabItems, c(list(overview_tab()),
                        lapply(TERMS, term_tab),
                        lapply(seq_along(WORKS), work_tab),
                        list(timeline_tab(), about_tab())))
  )
)

# ---- Server ------------------------------------------------------------------
TERM_ORDER <- sapply(TERMS, `[[`, "key")

server <- function(input, output, session) {

  # Term tables
  for (t in TERMS) local({
    key <- t$key
    output[[paste0("tbl_", key)]] <- renderDT(works_table(works_in(key)))
  })

  output$tbl_all <- renderDT(works_table(WORKS))
  output$tbl_index <- renderDT(works_table(WORKS))

  # Timeline: dated works only, chronological from top
  dated <- Filter(function(w) !is.na(w$hand_in), WORKS)
  tl <- data.frame(
    label = sapply(dated, function(w) paste0(w$code, " \u00b7 ", w$short)),
    term = sapply(dated, `[[`, "term"),
    hand_in = as.Date(sapply(dated, function(w) format(w$hand_in))),
    pages = sapply(dated, `[[`, "pages_label"),
    title = sapply(dated, `[[`, "title"),
    stringsAsFactors = FALSE)
  tl$label <- factor(tl$label, levels = rev(tl$label))

  output$plot_timeline <- renderPlotly({
    p <- plot_ly()
    for (k in TERM_ORDER) {
      d <- tl[tl$term == k, , drop = FALSE]
      if (nrow(d) == 0) next
      p <- add_trace(p, data = d, x = ~hand_in, y = ~label, type = "scatter", mode = "markers",
                     name = k, marker = list(size = 13, color = TERM_COL[[k]]),
                     text = ~paste0(title, "<br>Hand-in: ", format(hand_in, "%d %b %Y"), "<br>Pages ", pages),
                     hoverinfo = "text")
    }
    p %>% layout(
      xaxis = list(title = "Hand-in date", gridcolor = "#E3E9F1"),
      yaxis = list(title = "", automargin = TRUE, gridcolor = "#E3E9F1"),
      paper_bgcolor = "rgba(0,0,0,0)", plot_bgcolor = "#F7F9FC",
      legend = list(orientation = "h", y = -0.2),
      font = list(family = "Source Sans 3, sans-serif", color = "#1F2D3D")
    ) %>% config(displaylogo = FALSE)
  })

  output$plot_words <- renderPlotly({
    wd <- Filter(function(w) !is.na(w$words), WORKS)
    d <- data.frame(label = sapply(wd, function(w) paste0(w$code, " \u00b7 ", w$short)),
                    term = sapply(wd, `[[`, "term"), words = sapply(wd, `[[`, "words"),
                    stringsAsFactors = FALSE)
    d$label <- factor(d$label, levels = rev(d$label))
    p <- plot_ly()
    for (k in TERM_ORDER) {
      dd <- d[d$term == k, , drop = FALSE]
      if (nrow(dd) == 0) next
      p <- add_trace(p, data = dd, x = ~words, y = ~label, type = "bar", orientation = "h",
                     name = k, marker = list(color = TERM_COL[[k]]),
                     hovertemplate = "%{y}<br>%{x:,} words<extra></extra>")
    }
    p %>% layout(
      barmode = "overlay",
      xaxis = list(title = "Words (cover sheet)", gridcolor = "#E3E9F1"),
      yaxis = list(title = "", automargin = TRUE),
      paper_bgcolor = "rgba(0,0,0,0)", plot_bgcolor = "#F7F9FC",
      legend = list(orientation = "h", y = -0.15),
      font = list(family = "Source Sans 3, sans-serif", color = "#1F2D3D")
    ) %>% config(displaylogo = FALSE)
  })

  # Previous / Next buttons move through the collection in order
  invisible(lapply(seq_along(WORKS), function(i) {
    id <- WORKS[[i]]$id
    if (i > 1) observeEvent(input[[paste0("prev_", id)]],
                            updateTabItems(session, "menu", WORKS[[i - 1]]$tab))
    if (i < length(WORKS)) observeEvent(input[[paste0("next_", id)]],
                                        updateTabItems(session, "menu", WORKS[[i + 1]]$tab))
  }))
}

shinyApp(ui = ui, server = server)
