# ============================================================================
# SETUP — run once before launching the app
# Rscript setup.R
# ============================================================================

cat("Installing required R packages...\n\n")

pkgs <- c(
  "shiny",
  "shinydashboard",
  "shinyjs",
  "R6",
  "yaml",
  "purrr",
  "httr",
  "jsonlite",
  "processx",
  "fs",
  "DT"
)

for (pkg in pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    cat("  Installing:", pkg, "\n")
    install.packages(pkg, repos = "https://cloud.r-project.org", quiet = TRUE)
  } else {
    cat("  ✓ Already installed:", pkg, "\n")
  }
}

cat("\n\nInstalling required Python packages...\n")
cat("(Uses whichever Python is on PATH — configure env in the app's Settings tab)\n\n")

py_pkgs <- c("anthropic", "jupyter_client", "ipykernel")
for (pkg in py_pkgs) {
  cat("  pip install", pkg, "\n")
}

system(paste("python3 -m pip install", paste(py_pkgs, collapse = " "), "-q"))

cat("\n✅ Setup complete — run: shiny::runApp()\n")
