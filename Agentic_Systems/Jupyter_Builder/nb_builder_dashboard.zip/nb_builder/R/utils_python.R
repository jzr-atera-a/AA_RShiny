# ============================================================================
# PYTHON BRIDGE - R6 CLASS
# Manages Python process lifecycle via processx
# ============================================================================

PythonBridge <- R6::R6Class(
  "PythonBridge",

  public = list(
    process     = NULL,    # processx::process object
    run_dir     = NULL,
    log_path    = NULL,
    python_path = NULL,
    script_path = NULL,

    initialize = function(python_path = NULL) {
      self$python_path <- if (is.null(python_path) || nchar(trimws(python_path)) == 0) {
        self$detect_python()
      } else {
        python_path
      }
      self$script_path <- file.path(getwd(), "python", "notebook_builder.py")
      cat("✓ PythonBridge ready:", self$python_path, "\n")
    },

    detect_python = function() {
      candidates <- c("python3", "python")
      for (p in candidates) {
        path <- Sys.which(p)
        if (nchar(path) > 0) return(unname(path))
      }
      "python3"   # fallback — user must configure Tab 1
    },

    # ── Validate python path before launching ──────────────────────────────

    validate = function(py_path = NULL) {
      path <- if (!is.null(py_path)) py_path else self$python_path
      result <- tryCatch({
        out <- processx::run(path, args = c("-c", "import sys; print(sys.version)"),
                             timeout = 10, error_on_status = FALSE)
        if (out$status == 0) {
          list(ok = TRUE,  msg = paste("Python:", trimws(out$stdout)))
        } else {
          list(ok = FALSE, msg = paste("Error:", out$stderr))
        }
      }, error = function(e) list(ok = FALSE, msg = e$message))
      result
    },

    # ── Launch the notebook builder as subprocess ─────────────────────────

    launch = function(spec, run_dir, api_key, model, context_dir,
                      max_cost, max_tokens, max_retries, max_consec_fails,
                      review_every) {

      self$run_dir  <- run_dir
      self$log_path <- file.path(run_dir, "run.log")

      dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)

      # Build args — pass everything via JSON config file so we avoid shell escaping
      cfg <- list(
        spec            = spec,
        run_dir         = run_dir,
        api_key         = api_key,
        model           = model,
        context_dir     = context_dir,
        max_cost_usd    = max_cost,
        max_tokens      = max_tokens,
        max_retries     = max_retries,
        max_consec_fails= max_consec_fails,
        review_every    = review_every
      )
      launch_cfg_path <- file.path(run_dir, "launch_config.json")
      jsonlite::write_json(cfg, launch_cfg_path, pretty = TRUE, auto_unbox = TRUE)

      self$process <- processx::process$new(
        command    = self$python_path,
        args       = c(self$script_path, "--launch-config", launch_cfg_path),
        stdout     = self$log_path,
        stderr     = self$log_path,
        cleanup    = FALSE   # keep running if R session refreshes
      )
      cat("✓ Python process launched PID:", self$process$get_pid(), "\n")
      invisible(self)
    },

    # ── Resume existing run ────────────────────────────────────────────────

    resume = function(run_dir, api_key) {
      self$run_dir  <- run_dir
      self$log_path <- file.path(run_dir, "run.log")

      # Update API key in the launch config (may have changed)
      cfg_path <- file.path(run_dir, "launch_config.json")
      if (file.exists(cfg_path)) {
        cfg <- jsonlite::fromJSON(cfg_path)
        cfg$api_key <- api_key
        jsonlite::write_json(cfg, cfg_path, pretty = TRUE, auto_unbox = TRUE)
      }

      # Clear any stale control file
      ctrl <- file.path(run_dir, "control.json")
      jsonlite::write_json(list(command = "run"), ctrl, auto_unbox = TRUE)

      self$process <- processx::process$new(
        command = self$python_path,
        args    = c(self$script_path, "--launch-config", cfg_path, "--resume"),
        stdout  = self$log_path,
        stderr  = self$log_path,
        cleanup = FALSE
      )
      cat("✓ Python process resumed PID:", self$process$get_pid(), "\n")
      invisible(self)
    },

    is_running = function() {
      !is.null(self$process) && self$process$is_alive()
    },

    stop_process = function() {
      if (self$is_running()) {
        self$process$kill()
        cat("✓ Python process killed\n")
      }
    },

    get_pid = function() {
      if (!is.null(self$process)) self$process$get_pid() else NA
    }
  )
)
