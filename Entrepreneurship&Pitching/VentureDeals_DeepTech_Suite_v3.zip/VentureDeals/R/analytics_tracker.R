# R/analytics_tracker.R — User Interaction Tracker
#
# Tracks:
#   - Tab navigation (which tab, how long spent)
#   - Slider / input changes (element name, new value)
#   - Button clicks (which button)
#   - Box interactions (via JS click detection on .box elements)
#   - Session start / end
#
# All events are queued in a reactive list and flushed to Google Sheets
# in batches every 30 seconds to minimise API calls.

library(shiny)

# ── JS injection: captures box clicks and sends to Shiny ───
analytics_js <- function() {
  tags$script(HTML("
    // ── Box click tracking ─────────────────────────────
    $(document).on('click', '.box', function(e) {
      var title = $(this).find('.box-title').first().text().trim();
      if (!title) title = $(this).find('h3,h4,h5').first().text().trim();
      if (!title) title = 'unnamed_box';
      Shiny.setInputValue('__tracker_box_click',
        { title: title, tab: $('.tab-pane.active').attr('id') || '',
          t: Date.now() },
        { priority: 'event' }
      );
    });

    // ── Tab navigation tracking ────────────────────────
    $(document).on('shown.bs.tab', 'a[data-toggle=tab]', function(e) {
      var tabName = $(e.target).attr('data-value') ||
                    $(e.target).attr('href') || '';
      Shiny.setInputValue('__tracker_tab_change',
        { tab: tabName.replace('#',''), t: Date.now() },
        { priority: 'event' }
      );
    });

    // Also watch sidebar menu clicks (shinydashboard)
    $(document).on('click', '.sidebar-menu a[data-toggle=tab]', function() {
      var tab = $(this).attr('data-value') || $(this).text().trim();
      Shiny.setInputValue('__tracker_tab_change',
        { tab: tab, t: Date.now() },
        { priority: 'event' }
      );
    });

    // ── Button click tracking ──────────────────────────
    $(document).on('click', '.action-button:not(#login_submit)', function() {
      var lbl = $(this).text().trim().substring(0, 60);
      var id  = $(this).attr('id') || 'unknown_btn';
      Shiny.setInputValue('__tracker_btn_click',
        { id: id, label: lbl, t: Date.now() },
        { priority: 'event' }
      );
    });

    // ── Plotly interaction tracking ────────────────────
    $(document).on('plotly_relayout plotly_selected', function(e, data) {
      var plotId = $(e.target).attr('id') || 'unknown_plot';
      Shiny.setInputValue('__tracker_plot_interact',
        { plot: plotId, t: Date.now() },
        { priority: 'event' }
      );
    });

    // ── Visibility / session timing ────────────────────
    var _sessionStart = Date.now();
    var _tabStart     = Date.now();
    var _currentTab   = 'unknown';

    Shiny.addCustomMessageHandler('__tracker_set_tab', function(tab) {
      _currentTab = tab;
      _tabStart   = Date.now();
    });

    // Flush remaining time on page unload
    window.addEventListener('beforeunload', function() {
      var secs = Math.round((Date.now() - _sessionStart) / 1000);
      Shiny.setInputValue('__tracker_session_end', { secs: secs, t: Date.now() },
        { priority: 'event' });
    });
  "))
}

# ── Server-side tracker module ───────────────────────────────
#
# Call tracker_server() inside your main server() after auth is confirmed.
# Pass: email (string), session_id (string), flush_interval_secs (int)

tracker_server <- function(email_reactive, session_id, flush_secs = 30) {
  function(input, output, session) {

    # Queue: collect events here, flush in batches
    queue <- reactiveVal(list())

    # Time-on-tab tracking
    tab_state <- reactiveValues(
      current  = "unknown",
      entered  = Sys.time()
    )

    # Convenience: push an event onto the queue
    push_event <- function(event_type, tab = "", element = "", detail = "", duration = NA) {
      ev <- list(
        email         = isolate(email_reactive()),
        session_id    = session_id,
        event_type    = event_type,
        tab           = tab,
        element       = element,
        detail        = substr(as.character(detail), 1, 200),
        duration_secs = duration
      )
      queue(c(queue(), list(ev)))
    }

    # ── Log session start ─────────────────────────────
    push_event("session_start", detail = paste0("agent: ", session$clientData$url_hostname))

    # ── Tab changes ───────────────────────────────────
    observeEvent(input$`__tracker_tab_change`, {
      tc <- input$`__tracker_tab_change`
      new_tab  <- tc$tab

      # Log duration on previous tab
      duration <- as.numeric(Sys.time() - tab_state$entered, units = "secs")
      if (tab_state$current != "unknown") {
        push_event("tab_exit", tab = tab_state$current, duration = round(duration, 1))
      }

      # Log entry to new tab
      push_event("tab_view", tab = new_tab)
      tab_state$current <- new_tab
      tab_state$entered <- Sys.time()

      # Tell JS the current tab name
      session$sendCustomMessage("__tracker_set_tab", new_tab)
    })

    # Also track shinydashboard sidebar tab switch via input$tabs
    observeEvent(input$tabs, {
      new_tab  <- input$tabs
      duration <- as.numeric(Sys.time() - tab_state$entered, units = "secs")
      if (tab_state$current != new_tab) {
        if (tab_state$current != "unknown")
          push_event("tab_exit", tab = tab_state$current, duration = round(duration, 1))
        push_event("tab_view", tab = new_tab)
        tab_state$current <- new_tab
        tab_state$entered <- Sys.time()
      }
    }, ignoreNULL = TRUE)

    # ── Box clicks ────────────────────────────────────
    observeEvent(input$`__tracker_box_click`, {
      bc <- input$`__tracker_box_click`
      push_event("box_click",
                 tab     = tab_state$current,
                 element = "box",
                 detail  = bc$title)
    })

    # ── Button clicks ─────────────────────────────────
    observeEvent(input$`__tracker_btn_click`, {
      bc <- input$`__tracker_btn_click`
      push_event("button_click",
                 tab     = tab_state$current,
                 element = bc$id,
                 detail  = bc$label)
    })

    # ── Plot interactions ─────────────────────────────
    observeEvent(input$`__tracker_plot_interact`, {
      pi <- input$`__tracker_plot_interact`
      push_event("plot_interact",
                 tab     = tab_state$current,
                 element = pi$plot)
    })

    # ── Slider / input changes (sampled, not every keypress) ─
    # Track key module inputs by name
    tracked_inputs <- c(
      "montecarlo_valuation-exit_val",
      "montecarlo_valuation-rev_base",
      "montecarlo_valuation-mult_mean",
      "montecarlo_valuation-run_mc",
      "montecarlo_runway-cash_start",
      "montecarlo_runway-burn_start",
      "montecarlo_runway-run_runway",
      "cap_table-serA_raised",
      "cap_table-serA_premoney",
      "cap_table-option_pool",
      "economic_terms-exit_val",
      "convertible-note_size",
      "convertible-cap",
      "convertible-discount"
    )

    # Debounced observer factory for each tracked input
    lapply(tracked_inputs, function(inp_id) {
      # Use observe + debounce pattern
      deb <- debounce(reactive({ input[[inp_id]] }), 1500)
      observe({
        val <- deb()
        if (!is.null(val)) {
          push_event("input_change",
                     tab     = tab_state$current,
                     element = inp_id,
                     detail  = paste0(val, collapse = ","))
        }
      })
    })

    # ── Session end ───────────────────────────────────
    observeEvent(input$`__tracker_session_end`, {
      se <- input$`__tracker_session_end`
      push_event("session_end", duration = se$secs)
      flush_queue(queue())  # final flush
      queue(list())
    })

    # ── Periodic flush to Google Sheets ──────────────
    flush_queue <- function(events) {
      if (length(events) == 0) return(invisible())
      for (ev in events) {
        tryCatch(
          sheets_log_event(
            email         = ev$email,
            session_id    = ev$session_id,
            event_type    = ev$event_type,
            tab           = ev$tab,
            element       = ev$element,
            detail        = ev$detail,
            duration_secs = ev$duration_secs
          ),
          error = function(e) invisible()
        )
      }
      cat(sprintf("✓ Tracker: flushed %d events for %s\n",
                  length(events), isolate(email_reactive())))
    }

    # Flush every N seconds
    observe({
      invalidateLater(flush_secs * 1000, session)
      isolate({
        evs <- queue()
        if (length(evs) > 0) {
          flush_queue(evs)
          queue(list())
        }
      })
    })

    # Flush on session end
    session$onSessionEnded(function() {
      isolate({
        evs <- queue()
        if (length(evs) > 0) flush_queue(evs)
      })
    })
  }
}
