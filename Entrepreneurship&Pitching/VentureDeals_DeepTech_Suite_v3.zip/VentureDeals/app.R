# app.R — Venture Deals: DeepTech Fundraising Suite
# v4.0 — Google Sheets REST API auth + analytics tracking + admin reporting

library(shiny)
library(shinydashboard)
library(plotly)
library(DT)
library(yaml)
library(R6)
library(dplyr)
library(httr)
library(jsonlite)
library(openssl)
library(base64enc)

source("global.R",               local = TRUE)
source("R/module_loader.R",      local = TRUE)
source("R/sheets_backend.R",     local = TRUE)
source("R/auth.R",               local = TRUE)
source("R/analytics_tracker.R", local = TRUE)

for (f in list.files("modules", pattern = "\\.R$", full.names = TRUE)) {
  source(f, local = TRUE)
}

# Attempt Sheets connection at startup
sheets_connect()

# ── Main dashboard UI ────────────────────────────────────────
make_app_ui <- function(show_admin = FALSE) {
  dashboardPage(
    skin = "black",
    dashboardHeader(title = "Venture Deals · DeepTech"),
    dashboardSidebar(
      tags$div(class = "sidebar-book-badge",
        tags$div(class = "book-chip",    "VENTURE DEALS · DEEPTECH"),
        tags$div(class = "book-authors", "Brad Feld & Jason Mendelson"),
        tags$div(class = "book-pub",     "Applied to DeepTech Founders")),
      sidebarMenu(id = "tabs",
        menuItem("\U0001f9ed App Guide",        tabName = "guide",                icon = icon("compass")),
        menuItem("\U0001f30d Overview",          tabName = "overview",             icon = icon("home")),
        menuItem("1 \u00b7 The Players",        tabName = "players",              icon = icon("users")),
        menuItem("2 \u00b7 Term Sheet",         tabName = "term_sheet",           icon = icon("file-alt")),
        menuItem("3 \u00b7 Economic Terms",     tabName = "economic_terms",       icon = icon("chart-pie")),
        menuItem("4 \u00b7 Control Terms",      tabName = "control_terms",        icon = icon("chess-king")),
        menuItem("5 \u00b7 Cap Table",          tabName = "cap_table",            icon = icon("table")),
        menuItem("6 \u00b7 Convertible Debt",   tabName = "convertible",          icon = icon("sync-alt")),
        menuItem("7 \u00b7 MC Valuation",       tabName = "montecarlo_valuation", icon = icon("dice")),
        menuItem("8 \u00b7 MC Runway",          tabName = "montecarlo_runway",    icon = icon("road")),
        menuItem("9 \u00b7 Negotiation",        tabName = "negotiation",          icon = icon("handshake")),
        menuItem("10 \u00b7 DeepTech Deals",    tabName = "deeptech_deals",       icon = icon("microchip")),
        if (show_admin)
          menuItem("\u2605 Admin Analytics",    tabName = "admin_reporting",      icon = icon("chart-bar"))
      )
    ),
    dashboardBody(
      tags$head(
        tags$link(rel = "stylesheet", type = "text/css", href = "css/global.css"),
        tags$link(rel = "stylesheet", type = "text/css", href = "css/auth.css"),
        tags$meta(charset = "UTF-8"),
        analytics_js()
      ),
      uiOutput("session_bar"),
      tabItems(
        tabItem(tabName = "guide",                guide_ui("guide")),
        tabItem(tabName = "overview",             overview_ui("overview")),
        tabItem(tabName = "players",              players_ui("players")),
        tabItem(tabName = "term_sheet",           term_sheet_ui("term_sheet")),
        tabItem(tabName = "economic_terms",       economic_terms_ui("economic_terms")),
        tabItem(tabName = "control_terms",        control_terms_ui("control_terms")),
        tabItem(tabName = "cap_table",            cap_table_ui("cap_table")),
        tabItem(tabName = "convertible",          convertible_ui("convertible")),
        tabItem(tabName = "montecarlo_valuation", montecarlo_valuation_ui("montecarlo_valuation")),
        tabItem(tabName = "montecarlo_runway",    montecarlo_runway_ui("montecarlo_runway")),
        tabItem(tabName = "negotiation",          negotiation_ui("negotiation")),
        tabItem(tabName = "deeptech_deals",       deeptech_deals_ui("deeptech_deals")),
        if (show_admin)
          tabItem(tabName = "admin_reporting",    admin_reporting_ui("admin_reporting"))
      )
    )
  )
}

# ── Root UI ──────────────────────────────────────────────────
ui <- fluidPage(
  tags$head(
    tags$link(rel = "stylesheet",
              href = "https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@400;700&display=swap"),
    tags$link(rel = "stylesheet", type = "text/css", href = "css/auth.css"),
    tags$style(HTML("body{margin:0;padding:0;} .container-fluid{padding:0;}"))
  ),
  uiOutput("root_ui")
)

# ── Server ───────────────────────────────────────────────────
server <- function(input, output, session) {

  auth <- auth_server("auth")

  output$root_ui <- renderUI({
    if (auth$authenticated()) {
      make_app_ui(show_admin = is_admin(auth$email()))
    } else {
      err <- if (auth$locked()) NULL
             else if (auth$attempts() > 0) "That email is not on the access list."
             else NULL
      login_screen_ui(err, auth$attempts_left(), auth$locked())
    }
  })

  output$session_bar <- renderUI({
    req(auth$authenticated())
    session_bar_ui(auth$email())
  })

  observeEvent(auth$authenticated(), {
    req(auth$authenticated())

    guide_server("guide")
    overview_server("overview")
    players_server("players")
    term_sheet_server("term_sheet")
    economic_terms_server("economic_terms")
    control_terms_server("control_terms")
    cap_table_server("cap_table")
    convertible_server("convertible")
    montecarlo_valuation_server("montecarlo_valuation")
    montecarlo_runway_server("montecarlo_runway")
    negotiation_server("negotiation")
    deeptech_deals_server("deeptech_deals")

    if (is_admin(auth$email()))
      admin_reporting_server("admin_reporting", email_reactive = auth$email)

    tryCatch({
      callModule(
        tracker_server(
          email_reactive = auth$email,
          session_id     = auth$session_id(),
          flush_secs     = 30
        ),
        id      = "tracker",
        session = session
      )
    }, error = function(e) cat("⚠ Tracker:", e$message, "\n"))

    cat("✓ App loaded for:", auth$email(), "\n")
  }, once = TRUE)
}

shinyApp(ui, server)
