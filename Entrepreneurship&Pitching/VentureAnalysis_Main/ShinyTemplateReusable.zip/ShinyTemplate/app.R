# app.R — Shiny App Template
# ─────────────────────────────────────────────────────────────
# Portable skeleton with:
#   ✓ Google Sheets login gate (email allowlist)
#   ✓ Google Sheets analytics tracking
#   ✓ Admin reporting tab (user management + analytics charts)
#   ✓ 3 dummy content tabs (replace with your own)
#   ✓ Dark DeepTech theme (CSS in www/css/)
#
# QUICK START:
#   1. Add your Sheet ID + admin email to .Renviron
#   2. Add google_service_account.json to auth/
#   3. Replace tab_one/two/three modules with your content
#   4. Run: shiny::runApp()
#
# TO ADD A NEW TAB:
#   a. Create modules/my_tab.R with my_tab_ui() + my_tab_server()
#   b. Add menuItem() to dashboardSidebar
#   c. Add tabItem() to dashboardBody tabItems()
#   d. Call my_tab_server("my_tab") in server()
# ─────────────────────────────────────────────────────────────

library(shiny)
library(shinydashboard)
library(plotly)
library(DT)
library(dplyr)
library(httr)
library(jsonlite)
library(openssl)
library(base64enc)

# Load all R files
source("global.R",                local = TRUE)
source("R/sheets_backend.R",      local = TRUE)
source("R/analytics_tracker.R",   local = TRUE)
source("R/auth.R",                local = TRUE)

# Load all modules
for (f in list.files("modules", pattern = "\\.R$", full.names = TRUE)) {
  source(f, local = TRUE)
}

# Connect to Google Sheets at startup
sheets_connect()

# ── APP NAME ─────────────────────────────────────────────────
APP_NAME     <- "My App"                        # shown on login screen + header
APP_SUBTITLE <- "Enter your registered email address to continue."

# ── UI ───────────────────────────────────────────────────────
ui <- dashboardPage(
  skin = "black",
  dashboardHeader(title = APP_NAME),

  dashboardSidebar(
    # ── Sidebar branding ─────────────────────────────────────
    tags$div(style = "padding:14px 14px 10px;border-bottom:1px solid rgba(0,191,255,0.20);margin-bottom:6px;",
      tags$div(style = "background:rgba(0,191,255,0.12);border:1px solid rgba(0,191,255,0.40);
                        color:#00e5ff;border-radius:8px;padding:6px 10px;font-size:9px;
                        font-weight:800;text-align:center;letter-spacing:1.5px;
                        font-family:'Courier New',monospace;",
               toupper(APP_NAME)),
      tags$div(style = "font-size:10px;color:rgba(173,200,255,0.60);text-align:center;margin-top:5px;",
               "Powered by Atera Analytics")
    ),

    sidebarMenu(id = "tabs",
      menuItem("\U0001f3e0 Tab One",   tabName = "tab_one",   icon = icon("home")),
      menuItem("\U0001f4ca Tab Two",   tabName = "tab_two",   icon = icon("chart-bar")),
      menuItem("\U0001f527 Tab Three", tabName = "tab_three", icon = icon("tools")),
      # Admin tab — hidden by CSS, revealed via JS for admin emails only
      tags$div(id = "admin_menu_item",
        menuItem("\u2605 Admin", tabName = "admin_reporting", icon = icon("shield-alt"))
      )
    )
  ),

  dashboardBody(
    tags$head(
      tags$link(rel = "stylesheet",
        href = "https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@400;700&display=swap"),
      tags$link(rel = "stylesheet", type = "text/css", href = "css/global.css"),
      tags$link(rel = "stylesheet", type = "text/css", href = "css/auth.css"),
      tags$style(HTML("#admin_menu_item { display: none !important; }")),
      analytics_js()    # inject JS event tracking
    ),

    # Login overlay (always in DOM, hidden after auth via JS)
    login_overlay_ui(APP_NAME, APP_SUBTITLE),

    # Session bar (shows logged-in email after auth)
    uiOutput("session_bar"),

    tabItems(
      tabItem(tabName = "tab_one",         tab_one_ui("tab_one")),
      tabItem(tabName = "tab_two",         tab_two_ui("tab_two")),
      tabItem(tabName = "tab_three",       tab_three_ui("tab_three")),
      tabItem(tabName = "admin_reporting", admin_reporting_ui("admin_reporting"))
    )
  )
)

# ── Server ───────────────────────────────────────────────────
server <- function(input, output, session) {

  # Auth state
  state <- reactiveValues(
    authenticated = FALSE,
    email         = NULL,
    attempts      = 0,
    locked_until  = NULL,
    session_id    = paste0("s_", format(Sys.time(), "%Y%m%d%H%M%S"),
                           "_", sample(1000:9999, 1))
  )

  # ── Initialise all module servers at startup ───────────────
  # (must be at top level of server, not inside observeEvent)
  tab_one_server("tab_one")
  tab_two_server("tab_two")
  tab_three_server("tab_three")
  admin_reporting_server("admin_reporting", email_reactive = reactive(state$email))

  # Analytics tracker — JS inputs passed from parent to bypass namespacing
  tracker_server(
    id                     = "tracker",
    email_reactive         = reactive({ state$email %||% "" }),
    session_id             = isolate(state$session_id),
    tab_reactive           = reactive(input$tabs),
    box_click_reactive     = reactive(input$`__tracker_box_click`),
    btn_click_reactive     = reactive(input$`__tracker_btn_click`),
    tab_change_reactive    = reactive(input$`__tracker_tab_change`),
    plot_interact_reactive = reactive(input$`__tracker_plot_interact`),
    session_end_reactive   = reactive(input$`__tracker_session_end`),
    flush_secs             = 10
  )

  # ── Login logic ────────────────────────────────────────────
  observeEvent(input$login_submit, {
    email <- tolower(trimws(input$login_email %||% ""))
    if (!nzchar(email)) return()

    # Lockout check
    if (!is.null(state$locked_until) && Sys.time() < state$locked_until) return()
    if (!is.null(state$locked_until) && Sys.time() >= state$locked_until) {
      state$locked_until <- NULL; state$attempts <- 0
    }

    allowed <- tryCatch(sheets_get_allowed_emails(),
                        error = function(e) character(0))

    if (email %in% allowed) {
      state$authenticated <- TRUE
      state$email         <- email
      session$sendCustomMessage("authenticate_user", list())
      if (is_admin(email)) session$sendCustomMessage("show_admin_tab", list())
      tryCatch(sheets_log_login(email, TRUE,  state$session_id), error = function(e) invisible())
      cat("✓ Auth: granted for", email, "\n")
    } else {
      state$attempts <- state$attempts + 1
      tryCatch(sheets_log_login(email, FALSE, state$session_id), error = function(e) invisible())
      cat("✗ Auth: denied for", email, "\n")
      if (state$attempts >= 5) state$locked_until <- Sys.time() + 300
    }
  }, ignoreNULL = TRUE, ignoreInit = TRUE)

  # Login error message
  output$login_error <- renderUI({
    if (state$attempts > 0 && !state$authenticated)
      div(class = "login-error",
          "\u26a0 That email is not on the access list.",
          if (state$attempts > 1)
            span(style = "background:rgba(231,76,60,0.18);border:1px solid rgba(231,76,60,0.35);
                          color:#f5b7b1;border-radius:6px;padding:2px 9px;font-size:10px;
                          font-weight:700;margin-left:6px;",
                 paste0(pmax(0, 5 - state$attempts), " attempt(s) left")))
  })

  # Session bar
  output$session_bar <- renderUI({
    req(state$authenticated)
    session_bar_ui(state$email)
  })
}

shinyApp(ui, server)
