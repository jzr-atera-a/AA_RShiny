# modules/tab_two.R — Dummy Tab 2
# ─────────────────────────────────────────────────────────────
# TEMPLATE: Replace with your own content.
# Demonstrates: bar chart, select input, info boxes.
# ─────────────────────────────────────────────────────────────

tab_two_ui <- function(id) {
  ns <- NS(id)
  tagList(
    page_hero(
      title    = "Tab Two — Bar Chart & Filters",
      subtitle = "Dummy tab showing a filtered bar chart. Replace with your own content.",
      badges   = c("DEMO", "BAR CHART", "FILTER")
    ),

    fluidRow(
      box(title = "Filtered Bar Chart", status = "warning", solidHeader = TRUE, width = 8,
        selectInput(ns("category"), "Select Category",
                    choices = c("Revenue", "Costs", "Profit", "Users"),
                    selected = "Revenue"),
        plotlyOutput(ns("bar_chart"), height = "340px")
      ),
      box(title = "Summary", status = "success", solidHeader = TRUE, width = 4,
        sh("Key Figures"),
        uiOutput(ns("summary_stats")),
        hr_blue(),
        success_box(tags$strong("✓ Template: "),
          "Wire this box to reactive data from your own source.")
      )
    ),

    fluidRow(
      box(title = "Description", status = "primary", solidHeader = TRUE, width = 12,
        sh("About This Tab"),
        tags$p(style = "color:#8fb0d8;font-size:13px;",
          "This is a placeholder tab. Replace the bar chart with your own Plotly visualisation,",
          " connect the select input to a real data filter, and wire the summary stats to your metrics."),
        warn_box(tags$strong("⚠ Template reminder: "),
          "Add any slider or select inputs you want tracked to the ",
          tags$code("tracked_inputs"), " vector in ", tags$code("R/analytics_tracker.R"), ".")
      )
    )
  )
}

tab_two_server <- function(id, ...) {
  moduleServer(id, function(input, output, session) {

    dummy_data <- reactive({
      set.seed(42)
      months <- month.abb
      data.frame(
        month = months,
        value = round(runif(12, 50, 500) *
          switch(input$category,
            Revenue = 1.0, Costs = 0.7, Profit = 0.3, Users = 2.0, 1.0))
      )
    })

    output$bar_chart <- renderPlotly({
      df <- dummy_data()
      plot_ly(df, x = ~month, y = ~value, type = "bar",
              marker = list(color = "#0066cc",
                            line = list(color = "#00e5ff", width = 0.5))) %>%
        layout(title = list(text = paste(input$category, "by Month"),
                            font = list(color = "#cdd9f5")),
               xaxis = list(title = "Month"),
               yaxis = list(title = input$category)) %>%
        dt_theme()
    })

    output$summary_stats <- renderUI({
      df <- dummy_data()
      tagList(
        mc_stat(round(sum(df$value), 0),      paste("Total", input$category)),
        mc_stat(round(mean(df$value), 1),     "Monthly Average"),
        mc_stat(round(max(df$value), 0),      "Peak Month")
      )
    })
  })
}
