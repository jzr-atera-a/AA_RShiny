# modules/admin_reporting.R — Admin Analytics Tab
# ─────────────────────────────────────────────────────────────
# Visible only to emails listed in SHEETS_CONFIG$admin_emails.
# Shows: user management, login log, analytics charts,
#        user filter dropdown affecting all analytics outputs.
# ─────────────────────────────────────────────────────────────

admin_reporting_ui <- function(id) {
  ns <- NS(id)
  tagList(
    page_hero(
      title    = "Admin Analytics",
      subtitle = "Live user activity from Google Sheets. Manage users, view login history, and analyse interaction patterns.",
      badges   = c("ADMIN ONLY", "LIVE DATA", "USER MANAGEMENT")
    ),

    # ── User Management ──────────────────────────────────────
    fluidRow(
      box(title = "\U0001f465 User Management", status = "primary", solidHeader = TRUE, width = 12,
        fluidRow(
          column(5,
            sh("Add User"),
            div(style = "display:flex;gap:8px;align-items:flex-end;",
              div(style = "flex:1;",
                tags$input(id = ns("new_email"), type = "email", placeholder = "new@user.com",
                  style = "width:100%;background:rgba(4,13,33,0.90);border:1px solid rgba(0,191,255,0.25);
                           border-radius:8px;color:#cdd9f5;font-size:13px;padding:8px 12px;")
              ),
              selectInput(ns("new_role"), NULL, choices = c("user","admin","viewer"), width = "100px"),
              actionButton(ns("add_user"), "Add",
                style = "background:linear-gradient(135deg,#006633,#00aa55);color:#fff;
                         border:none;border-radius:8px;padding:8px 18px;font-weight:700;")
            ),
            uiOutput(ns("add_result"))
          ),
          column(7,
            sh("Current Users"),
            actionButton(ns("refresh_users"), "\u21ba Refresh",
              style = "background:rgba(0,191,255,0.15);color:#00e5ff;border:1px solid rgba(0,191,255,0.30);
                       border-radius:6px;padding:4px 14px;font-size:12px;margin-bottom:8px;"),
            DT::dataTableOutput(ns("users_table"))
          )
        )
      )
    ),

    # ── Login Stats ───────────────────────────────────────────
    fluidRow(
      box(title = "\U0001f512 Login Activity", status = "info", solidHeader = TRUE, width = 5,
        actionButton(ns("refresh_logins"), "\u21ba Refresh",
          style = "background:rgba(0,191,255,0.15);color:#00e5ff;border:1px solid rgba(0,191,255,0.30);
                   border-radius:6px;padding:4px 14px;font-size:12px;margin-bottom:8px;"),
        fluidRow(
          column(6, uiOutput(ns("stat_total_logins"))),
          column(6, uiOutput(ns("stat_unique_users")))
        ),
        fluidRow(
          column(6, uiOutput(ns("stat_today_logins"))),
          column(6, uiOutput(ns("stat_denied")))
        ),
        br(),
        DT::dataTableOutput(ns("login_table"))
      ),
      box(title = "\U0001f4c5 Logins Over Time", status = "warning", solidHeader = TRUE, width = 7,
        plotlyOutput(ns("login_timeline"), height = "300px")
      )
    ),

    # ── Analytics Filter ──────────────────────────────────────
    fluidRow(
      box(title = "\U0001f50d Analytics Filter", status = "primary", solidHeader = TRUE, width = 12,
        fluidRow(
          column(5,
            sh("Filter by User"),
            div(style = "display:flex;gap:10px;align-items:center;",
              div(style = "flex:1;", uiOutput(ns("email_filter_ui"))),
              actionButton(ns("refresh_analytics"), "\u21ba Refresh Analytics",
                style = "background:rgba(0,191,255,0.15);color:#00e5ff;
                         border:1px solid rgba(0,191,255,0.30);border-radius:6px;
                         padding:8px 14px;font-size:12px;white-space:nowrap;")
            )
          ),
          column(7, sh("Filter Summary"), uiOutput(ns("filter_summary")))
        )
      )
    ),

    # ── Analytics Charts ──────────────────────────────────────
    fluidRow(
      box(title = "\U0001f5f9 Tab Engagement", status = "success", solidHeader = TRUE, width = 6,
        plotlyOutput(ns("tab_engagement"), height = "320px")
      ),
      box(title = "\U0001f3af Top Interacted Elements", status = "danger", solidHeader = TRUE, width = 6,
        plotlyOutput(ns("top_elements"), height = "320px")
      )
    ),
    fluidRow(
      box(title = "\U0001f5b1\ufe0f Interaction Heatmap", status = "warning", solidHeader = TRUE, width = 6,
        plotlyOutput(ns("interaction_heatmap"), height = "320px")
      ),
      box(title = "\U0001f4cb Raw Analytics Log", status = "info", solidHeader = TRUE, width = 6,
        DT::dataTableOutput(ns("analytics_table"))
      )
    )
  )
}

admin_reporting_server <- function(id, email_reactive, ...) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    users_data     <- reactiveVal(NULL)
    logins_data    <- reactiveVal(NULL)
    analytics_data <- reactiveVal(NULL)

    observe({ 
      users_data(sheets_get_users_df())
      logins_data(sheets_get_login_log())
      analytics_data(sheets_get_analytics())
    })
    observeEvent(input$refresh_users,    { users_data(sheets_get_users_df()) })
    observeEvent(input$refresh_logins,   { logins_data(sheets_get_login_log()) })
    observeEvent(input$refresh_analytics, { analytics_data(sheets_get_analytics()) })

    # Email dropdown — stable native select (avoids selectize flickering)
    available_emails <- reactive({
      df <- analytics_data()
      if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(character(0))
      sort(unique(df$email[!is.na(df$email) & nchar(df$email) > 0]))
    })

    last_emails <- reactiveVal(character(0))
    observeEvent(available_emails(), {
      emails <- available_emails()
      if (identical(emails, last_emails())) return()
      last_emails(emails)
      opts <- c(tags$option(value = "__all__", "All Users"),
                lapply(emails, function(e) tags$option(value = e, e)))
      output$email_filter_ui <- renderUI({
        tagList(
          tags$select(id = session$ns("email_filter"), class = "admin-email-select",
                      style = "width:100%;background:rgba(4,13,33,0.90);
                               border:1px solid rgba(0,191,255,0.30);border-radius:8px;
                               color:#cdd9f5;font-family:Inter,sans-serif;font-size:13px;
                               padding:8px 12px;outline:none;cursor:pointer;",
                      tagList(opts)),
          tags$script(HTML(sprintf("
            (function(){
              var s=document.getElementById('%s');
              if(!s)return;
              s.addEventListener('change',function(){
                Shiny.setInputValue('%s',this.value,{priority:'event'});
              });
              Shiny.setInputValue('%s',s.value,{priority:'event'});
            })();
          ", session$ns("email_filter"), session$ns("email_filter"), session$ns("email_filter"))))
        )
      })
    }, ignoreNULL = TRUE)

    current_filter <- reactive({ input$email_filter %||% "__all__" })

    filtered_analytics <- reactive({
      df  <- analytics_data()
      sel <- current_filter()
      if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(df)
      if (is.null(sel) || sel == "__all__") return(df)
      df[!is.na(df$email) & df$email == sel, ]
    })

    # Filter summary
    output$filter_summary <- renderUI({
      df  <- analytics_data(); fdf <- filtered_analytics(); sel <- current_filter()
      if (is.null(df) || !is.data.frame(df) || nrow(df) == 0)
        return(tip_box("No analytics data yet — use the app and click Refresh Analytics."))
      fluidRow(
        column(4, mc_stat(if (sel == "__all__") "All Users" else sel, "Showing")),
        column(4, mc_stat(if (is.null(fdf)) 0 else nrow(fdf), "Events in View")),
        column(4, mc_stat(length(unique(df$email[!is.na(df$email)])), "Total Users"))
      )
    })

    # Add user
    observeEvent(input$add_user, {
      email <- trimws(input$new_email %||% "")
      if (!nzchar(email)) { output$add_result <- renderUI(warn_box("Enter an email.")); return() }
      result <- sheets_add_user(email, role = input$new_role, added_by = email_reactive())
      output$add_result <- renderUI(
        if (result$ok) success_box(tags$strong("\u2713 "), result$msg)
        else warn_box(tags$strong("\u274c "), result$msg))
      users_data(sheets_get_users_df())
    })

    # Users table
    output$users_table <- DT::renderDataTable({
      df <- users_data(); req(!is.null(df))
      df <- df[!grepl("^REMOVED_", df$email, ignore.case = TRUE), ]
      DT::datatable(df, rownames = FALSE, options = list(pageLength = 8, dom = "ftp")) %>%
        DT::formatStyle(names(df), backgroundColor = "rgba(7,26,62,0.60)", color = "#8fb0d8")
    })

    # Login stats
    safe_login <- function(df) is.data.frame(df) && nrow(df) > 0
    output$stat_total_logins <- renderUI({
      df <- logins_data()
      mc_stat(if (safe_login(df)) nrow(df[df$success=="TRUE",]) else 0, "Total Logins") })
    output$stat_unique_users <- renderUI({
      df <- logins_data()
      mc_stat(if (safe_login(df)) length(unique(df$email[df$success=="TRUE"])) else 0, "Unique Users") })
    output$stat_today_logins <- renderUI({
      df <- logins_data(); today <- format(Sys.Date(), "%Y-%m-%d")
      mc_stat(if (safe_login(df) && "timestamp" %in% names(df))
        sum(startsWith(as.character(df$timestamp), today) & df$success=="TRUE") else 0, "Today") })
    output$stat_denied <- renderUI({
      df <- logins_data()
      mc_stat(if (safe_login(df)) nrow(df[df$success=="FALSE",]) else 0, "Denied") })

    output$login_table <- DT::renderDataTable({
      df <- logins_data()
      if (!safe_login(df)) return(DT::datatable(data.frame(Message = "No data yet"), rownames = FALSE))
      df <- tail(df[order(as.character(df$timestamp), decreasing = TRUE), ], 50)
      DT::datatable(df, rownames = FALSE, options = list(pageLength = 6, dom = "ftp")) %>%
        DT::formatStyle(names(df), backgroundColor = "rgba(7,26,62,0.60)", color = "#8fb0d8")
    })

    output$login_timeline <- renderPlotly({
      df <- logins_data()
      if (!safe_login(df)) return(plot_ly() %>% layout(title=list(text="No data yet",font=list(color="#cdd9f5"))) %>% dt_theme())
      df <- df[!is.na(df$success) & df$success=="TRUE", ]
      if (nrow(df)==0) return(plot_ly() %>% dt_theme())
      df$date <- substr(df$timestamp, 1, 10)
      agg <- df %>% dplyr::group_by(date, email) %>% dplyr::summarise(n=n(), .groups="drop")
      plot_ly(agg, x=~date, y=~n, color=~email, type="bar") %>%
        layout(barmode="stack", title=list(text="Daily Logins by User",font=list(color="#cdd9f5"))) %>% dt_theme()
    })

    # Analytics charts — all use filtered_analytics()
    safe_analytics <- function() {
      df <- filtered_analytics()
      is.data.frame(df) && nrow(df) > 0
    }
    empty_plot <- function(msg = "No data yet — navigate the app then Refresh Analytics") {
      plot_ly() %>% layout(title=list(text=msg,font=list(color="#cdd9f5"))) %>% dt_theme()
    }
    suffix <- reactive({ sel <- current_filter(); if (sel=="__all__") "All Users" else sel })

    output$tab_engagement <- renderPlotly({
      if (!safe_analytics()) return(empty_plot())
      df    <- filtered_analytics()
      views <- df[!is.na(df$event_type) & df$event_type=="tab_view", ]
      if (nrow(views)==0) return(empty_plot("No tab view data yet"))
      exits <- df[!is.na(df$event_type) & df$event_type=="tab_exit" &
                  !is.na(df$duration_secs) & nchar(as.character(df$duration_secs))>0, ]
      tc <- views %>% dplyr::group_by(tab) %>% dplyr::summarise(views=n(), .groups="drop")
      if (nrow(exits)>0) {
        exits$dur <- suppressWarnings(as.numeric(exits$duration_secs))
        avg <- exits %>% dplyr::group_by(tab) %>% dplyr::summarise(avg_secs=mean(dur,na.rm=TRUE), .groups="drop")
        tc  <- dplyr::left_join(tc, avg, by="tab")
      } else tc$avg_secs <- NA
      tc <- tc[order(tc$views, decreasing=TRUE), ]
      plot_ly(tc) %>%
        add_trace(x=~tab, y=~views, type="bar", name="Views", marker=list(color="#0066cc")) %>%
        add_trace(x=~tab, y=~round(tc$avg_secs,0), type="scatter", mode="markers",
                  yaxis="y2", name="Avg secs", marker=list(color="#00e5ff",size=10)) %>%
        layout(title=list(text=paste("Tab Engagement —",suffix()),font=list(color="#cdd9f5")),
               xaxis=list(tickangle=-20), yaxis=list(title="Views"),
               yaxis2=list(overlaying="y",side="right",color="#00e5ff")) %>% dt_theme()
    })

    output$top_elements <- renderPlotly({
      if (!safe_analytics()) return(empty_plot())
      df <- filtered_analytics()
      df <- df[!is.na(df$event_type) & df$event_type %in%
               c("box_click","button_click","input_change","plot_interact") &
               !is.na(df$element) & nchar(as.character(df$element))>0, ]
      if (nrow(df)==0) return(empty_plot("No element interactions yet"))
      top <- df %>% dplyr::group_by(element,event_type) %>%
        dplyr::summarise(n=n(),.groups="drop") %>% dplyr::arrange(dplyr::desc(n)) %>% head(15)
      plot_ly(top, x=~n, y=~reorder(element,n), type="bar", orientation="h", color=~event_type) %>%
        layout(title=list(text=paste("Top Elements —",suffix()),font=list(color="#cdd9f5")),
               xaxis=list(title="Count"), barmode="stack") %>% dt_theme()
    })

    output$interaction_heatmap <- renderPlotly({
      if (!safe_analytics()) return(empty_plot())
      df <- filtered_analytics()
      df <- df[!is.na(df$event_type) & df$event_type %in%
               c("tab_view","box_click","button_click","input_change","plot_interact"), ]
      if (nrow(df)==0) return(empty_plot())
      heat  <- df %>% dplyr::group_by(email,tab) %>% dplyr::summarise(events=n(),.groups="drop")
      users <- sort(unique(heat$email)); tabs <- sort(unique(heat$tab))
      grid  <- expand.grid(email=users, tab=tabs, stringsAsFactors=FALSE)
      grid  <- dplyr::left_join(grid, heat, by=c("email","tab"))
      grid$events[is.na(grid$events)] <- 0
      z_mat <- matrix(grid$events, nrow=length(users), ncol=length(tabs),
                      byrow=FALSE, dimnames=list(users,tabs))
      plot_ly(x=tabs, y=users, z=z_mat, type="heatmap",
              colorscale=list(c(0,"#020a1a"),c(0.5,"#0066cc"),c(1,"#00e5ff"))) %>%
        layout(title=list(text=paste("Heatmap —",suffix()),font=list(color="#cdd9f5")),
               xaxis=list(tickangle=-20)) %>% dt_theme()
    })

    output$analytics_table <- DT::renderDataTable({
      df <- filtered_analytics()
      if (!safe_analytics()) return(DT::datatable(data.frame(Message="No data yet"), rownames=FALSE))
      df <- tail(df[order(as.character(df$timestamp),decreasing=TRUE),], 100)
      DT::datatable(df, rownames=FALSE, options=list(pageLength=6,dom="ftp")) %>%
        DT::formatStyle(names(df), backgroundColor="rgba(7,26,62,0.60)", color="#8fb0d8")
    })
  })
}
