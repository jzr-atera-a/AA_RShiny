# modules/tab_one.R — Dummy Tab 1
# ─────────────────────────────────────────────────────────────
# TEMPLATE: Replace this content with your own tab.
# This tab demonstrates: boxes, a reactive plotly chart,
# a slider input, and a data table.
# ─────────────────────────────────────────────────────────────

tab_one_ui <- function(id) {
  ns <- NS(id)
  tagList(
    page_hero(
      title    = "Tab One — Charts & Metrics",
      subtitle = "Dummy tab showing a reactive Plotly chart and summary metrics. Replace with your own content.",
      badges   = c("DEMO", "PLOTLY", "REACTIVE")
    ),

    fluidRow(
      column(3,
        mc_stat("42", "Metric A"),
        mc_stat("£1.2M", "Metric B"),
        mc_stat("87%", "Metric C")
      ),
      column(9,
        box(title = "Sample Chart", status = "primary", solidHeader = TRUE, width = 12,
          sliderInput(ns("n_points"), "Number of points", 10, 200, 50, 10),
          plotlyOutput(ns("scatter"), height = "320px")
        )
      )
    ),

    fluidRow(
      box(title = "Sample Table", status = "info", solidHeader = TRUE, width = 12,
        tip_box(tags$strong("ℹ️ Template note: "),
          "Replace this dummy data table with your own data source."),
        DT::dataTableOutput(ns("table"))
      )
    )
  )
}

tab_one_server <- function(id, ...) {
  moduleServer(id, function(input, output, session) {

    output$scatter <- renderPlotly({
      n  <- input$n_points
      df <- data.frame(x = rnorm(n), y = rnorm(n),
                       group = sample(c("A","B","C"), n, replace = TRUE))
      plot_ly(df, x = ~x, y = ~y, color = ~group, type = "scatter",
              mode = "markers", marker = list(size = 8, opacity = 0.8)) %>%
        layout(title = list(text = paste(n, "Random Points"), font = list(color="#cdd9f5"))) %>%
        dt_theme()
    })

    output$table <- DT::renderDataTable({
      df <- data.frame(
        Name  = paste0("Item ", 1:10),
        Value = round(runif(10, 100, 1000), 0),
        Score = round(runif(10, 0, 100), 1),
        Status = sample(c("Active","Pending","Closed"), 10, replace = TRUE)
      )
      DT::datatable(df, rownames = FALSE,
                    options = list(pageLength = 5, dom = "ftp")) %>%
        DT::formatStyle(names(df),
                        backgroundColor = "rgba(7,26,62,0.60)", color = "#8fb0d8")
    })
  })
}
