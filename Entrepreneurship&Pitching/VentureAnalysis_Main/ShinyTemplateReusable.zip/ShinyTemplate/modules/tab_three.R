# modules/tab_three.R — Dummy Tab 3
# ─────────────────────────────────────────────────────────────
# TEMPLATE: Replace with your own content.
# Demonstrates: text content, framework cards, action button.
# ─────────────────────────────────────────────────────────────

tab_three_ui <- function(id) {
  ns <- NS(id)
  tagList(
    page_hero(
      title    = "Tab Three — Content & Actions",
      subtitle = "Dummy tab showing text content, info boxes, and a reactive action button.",
      badges   = c("DEMO", "CONTENT", "ACTIONS")
    ),

    fluidRow(
      box(title = "Content Cards", status = "primary", solidHeader = TRUE, width = 6,
        sh("Section A"),
        div(style = "background:rgba(7,26,62,0.85);border:1px solid rgba(0,191,255,0.18);
                     border-left:4px solid #00bfff;border-radius:10px;
                     padding:14px 16px;margin-bottom:12px;",
          tags$h5(style = "color:#cdd9f5;font-weight:700;margin-bottom:7px;", "Card Title"),
          tags$p(style = "color:#8fb0d8;font-size:12.5px;margin:0;",
            "Replace this with your own content. Cards like this work well for",
            " definitions, frameworks, key principles, or reference material.")
        ),
        div(style = "background:rgba(7,26,62,0.85);border:1px solid rgba(0,191,255,0.18);
                     border-left:4px solid #00aa55;border-radius:10px;
                     padding:14px 16px;margin-bottom:12px;",
          tags$h5(style = "color:#cdd9f5;font-weight:700;margin-bottom:7px;", "Another Card"),
          tags$p(style = "color:#8fb0d8;font-size:12.5px;margin:0;",
            "Use left-border colour to signal category or priority.",
            " Cyan = primary, green = positive, red = warning.")
        )
      ),
      box(title = "Actions", status = "success", solidHeader = TRUE, width = 6,
        sh("Interactive Element"),
        tags$p(style = "color:#8fb0d8;font-size:13px;",
          "Click the button below to trigger a reactive update."),
        actionButton(ns("my_button"), "\u25b6 Run Action",
          style = "background:linear-gradient(135deg,#0066cc,#00bfff);
                   color:#fff;border:none;border-radius:8px;
                   padding:10px 24px;font-weight:700;margin-bottom:16px;"),
        uiOutput(ns("action_result")),
        hr_blue(),
        tip_box(tags$strong("💡 Tracking: "),
          "This button click is automatically tracked in the analytics log",
          " via the JS button click listener in ", tags$code("analytics_js()"), ".")
      )
    ),

    fluidRow(
      box(title = "How to Add a New Tab", status = "info", solidHeader = TRUE, width = 12,
        sh("Steps"),
        tags$ol(style = "color:#8fb0d8;font-size:13px;line-height:2;",
          tags$li("Create ", tags$code("modules/my_tab.R"), " with ",
                  tags$code("my_tab_ui()"), " and ", tags$code("my_tab_server()")),
          tags$li("Add a ", tags$code("menuItem()"), " in ", tags$code("app.R"), " sidebar"),
          tags$li("Add a ", tags$code("tabItem()"), " in ", tags$code("app.R"), " dashboardBody"),
          tags$li("Call ", tags$code("my_tab_server('my_tab')"), " in the server function"),
          tags$li("Add any slider/input IDs to ", tags$code("tracked_inputs"),
                  " in ", tags$code("R/analytics_tracker.R"))
        )
      )
    )
  )
}

tab_three_server <- function(id, ...) {
  moduleServer(id, function(input, output, session) {

    click_count <- reactiveVal(0)

    observeEvent(input$my_button, {
      click_count(click_count() + 1)
    })

    output$action_result <- renderUI({
      n <- click_count()
      if (n == 0) return(
        tags$p(style = "color:#7aa8e0;font-size:13px;",
               "No action run yet. Click the button above.")
      )
      success_box(
        tags$strong("✓ Action completed! "),
        paste0("Button clicked ", n, " time", if (n > 1) "s" else "", ". ",
               "Replace this output with your own reactive result.")
      )
    })
  })
}
