# global.R — Shiny App Template
# ─────────────────────────────────────────────────────────────
# Reusable skeleton with:
#   - Google Sheets login gate + analytics tracking
#   - Admin reporting tab
#   - 3 dummy content tabs
#
# HOW TO USE IN A NEW APP:
#   1. Copy this folder, rename it
#   2. Edit modules/_module_registry.yml to add/remove tabs
#   3. Replace modules/tab_one.R, tab_two.R, tab_three.R with your content
#   4. Set GOOGLE_SHEETS_ID + ADMIN_EMAILS in .Renviron
#   5. Add your service account JSON to auth/google_service_account.json
#   6. Run: shiny::runApp()
# ─────────────────────────────────────────────────────────────

library(shiny)
library(shinydashboard)
library(plotly)
library(DT)
library(dplyr)
library(httr)
library(jsonlite)
library(openssl)
library(base64enc)

# ── Load env vars locally (.Renviron ignored on shinyapps.io) ─
if (file.exists(".Renviron")) readRenviron(".Renviron")

# ── UI Helpers ────────────────────────────────────────────────

# Page hero banner
page_hero <- function(title, subtitle, badges = character()) {
  badge_tags <- lapply(badges, function(b)
    span(style = "display:inline-block;background:rgba(0,191,255,0.15);
                  border:1px solid rgba(0,191,255,0.40);color:#00e5ff;
                  padding:3px 12px;border-radius:20px;font-size:10px;
                  font-weight:700;letter-spacing:0.5px;margin-right:5px;", b))
  div(style = "background:linear-gradient(135deg,#020a1a,#071a3e);
               border-left:5px solid #00bfff;border-radius:12px;
               padding:28px 28px 22px;margin-bottom:20px;
               box-shadow:0 8px 32px rgba(0,0,0,0.5);",
    div(style = "font-size:11px;font-weight:700;color:#00e5ff;
                 letter-spacing:2px;text-transform:uppercase;margin-bottom:8px;",
        "Shiny Template"),
    tags$h1(style = "font-size:1.8em;font-weight:800;color:#fff;
                     margin:0 0 8px;", title),
    tags$p(style = "color:#adc8ff;font-size:13px;margin:0 0 14px;", subtitle),
    div(tagList(badge_tags))
  )
}

# Section heading
sh <- function(text) tags$p(
  style = "font-size:11px;font-weight:800;color:#00e5ff;
           text-transform:uppercase;letter-spacing:1.2px;
           border-bottom:2px solid #00bfff;padding-bottom:5px;margin:16px 0 10px;",
  text
)

# Metric card
mc_stat <- function(val, lbl) div(
  style = "background:rgba(0,191,255,0.10);border:1px solid rgba(0,191,255,0.25);
           border-radius:8px;padding:12px;text-align:center;margin-bottom:10px;",
  div(style = "font-family:'Courier New',monospace;font-size:18px;
               color:#00e5ff;font-weight:700;", val),
  div(style = "font-size:10px;color:#7aa8e0;text-transform:uppercase;
               letter-spacing:1px;", lbl)
)

hr_blue <- function() tags$hr(
  style = "border:none;border-top:1px solid rgba(0,191,255,0.25);margin:16px 0;")

tip_box     <- function(...) div(style = "background:rgba(0,99,165,0.18);
  border:1px solid rgba(0,150,255,0.35);border-left:4px solid #0099ff;
  border-radius:8px;padding:12px 14px;margin-bottom:12px;
  font-size:12.5px;color:#adc8ff;", ...)

success_box <- function(...) div(style = "background:rgba(0,100,50,0.18);
  border:1px solid rgba(0,180,80,0.30);border-left:4px solid #00aa55;
  border-radius:8px;padding:12px 14px;margin-bottom:12px;
  font-size:12.5px;color:#a9dfbf;", ...)

warn_box    <- function(...) div(style = "background:rgba(180,40,40,0.15);
  border:1px solid rgba(220,80,80,0.30);border-left:4px solid #e74c3c;
  border-radius:8px;padding:12px 14px;margin-bottom:12px;
  font-size:12.5px;color:#f5b7b1;", ...)

# ── Plotly dark theme ─────────────────────────────────────────
dt_theme <- function(p) {
  p %>% layout(
    paper_bgcolor = "rgba(4,13,33,0)",
    plot_bgcolor  = "rgba(4,13,33,0)",
    font          = list(color = "#8fb0d8", family = "Inter, sans-serif"),
    xaxis = list(gridcolor = "rgba(0,191,255,0.10)",
                 zerolinecolor = "rgba(0,191,255,0.15)", color = "#7aa8e0"),
    yaxis = list(gridcolor = "rgba(0,191,255,0.10)",
                 zerolinecolor = "rgba(0,191,255,0.15)", color = "#7aa8e0"),
    legend = list(bgcolor = "rgba(7,26,62,0.80)",
                  bordercolor = "rgba(0,191,255,0.20)", borderwidth = 1,
                  font = list(color = "#adc8ff"))
  )
}

`%||%` <- function(x, y) if (is.null(x)) y else x
