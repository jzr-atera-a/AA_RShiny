# R/auth.R — Login Gate
# ─────────────────────────────────────────────────────────────
# Renders a full-screen login overlay.
# Validates email against Google Sheets allowlist.
# Locks out after 5 failed attempts for 5 minutes.
# ─────────────────────────────────────────────────────────────

library(shiny)

# Login overlay UI — rendered inside dashboardBody
# The overlay uses position:fixed + z-index:99999 to cover everything.
# It is always in the DOM (not inside conditionalPanel) so Shiny
# button bindings work immediately on page load.
login_overlay_ui <- function(app_name = "My App", app_subtitle = "Enter your registered email to continue.") {
  div(id = "login_overlay", class = "login-overlay", style = "display:flex;",
    div(class = "login-card",
      div(class = "login-badge", "\U0001f512 Restricted Access"),
      tags$h1(class = "login-title", app_name),
      tags$p(class = "login-subtitle", app_subtitle),
      tags$label(class = "login-label", `for` = "login_email", "Email Address"),
      textInput("login_email", label = NULL, placeholder = "you@example.com"),
      actionButton("login_submit", "\U0001f510 Request Access", class = "login-btn"),
      uiOutput("login_error"),
      div(class = "login-footer",
          "Access restricted to authorised users only.", tags$br(),
          "Contact your administrator to request access.")
    ),
    # JS: show/hide overlay, show admin tab
    tags$script(HTML("
      Shiny.addCustomMessageHandler('authenticate_user', function(msg) {
        document.getElementById('login_overlay').style.display = 'none';
        document.body.classList.add('authenticated');
      });
      Shiny.addCustomMessageHandler('show_admin_tab', function(msg) {
        document.getElementById('admin_menu_item')
          .style.setProperty('display', 'block', 'important');
      });
    "))
  )
}

# Session bar — shown at top after login
session_bar_ui <- function(email) {
  div(class = "session-bar",
      span(style = "color:#00aa55;", "\u25cf"),
      span("\U0001f4e7 Logged in as:"),
      span(style = "color:#00e5ff;font-weight:700;", email),
      span(style = "color:rgba(0,191,255,0.35);", "|"),
      span(format(Sys.time(), "%d %b %Y %H:%M")),
      if (is_admin(email))
        span(style = "background:rgba(0,191,255,0.15);color:#00e5ff;
                      border:1px solid rgba(0,191,255,0.30);border-radius:4px;
                      padding:1px 8px;font-size:10px;font-weight:700;
                      margin-left:6px;", "\u2605 ADMIN")
  )
}
