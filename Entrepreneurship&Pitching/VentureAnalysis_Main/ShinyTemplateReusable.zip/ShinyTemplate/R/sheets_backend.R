# R/sheets_backend.R — Google Sheets Backend
# ─────────────────────────────────────────────────────────────
# Pure REST API using httr + jsonlite + openssl + base64enc
# No googlesheets4 / googledrive dependency (avoids version conflicts)
#
# REQUIRED ENV VARS (set in .Renviron or shinyapps.io dashboard):
#   GOOGLE_SHEETS_ID  — ID from spreadsheet URL
#   ADMIN_EMAILS      — comma-separated admin email(s)
#
# REQUIRED FILE:
#   auth/google_service_account.json — service account key
#
# GOOGLE SHEET STRUCTURE (3 tabs):
#   allowed_emails : email | role | added_by | added_date | notes
#   login_log      : timestamp | email | role | success | ip | session_id
#   analytics_log  : timestamp | email | session_id | event_type | tab | element | detail | duration_secs
#
# NOTE: If your sheet was created from the provided template xlsx,
#       rows 1-2 are decorative headers, row 3 = column headers, data from row 4.
#       Adjust EMAIL_DATA_ROW below if your sheet has a different structure.
# ─────────────────────────────────────────────────────────────

library(httr)
library(jsonlite)

EMAIL_DATA_ROW <- 4   # row where email data starts (after template headers)
LOG_HEADER_ROW <- 3   # row where log column headers are

SHEETS_CONFIG <- list(
  sheet_id      = Sys.getenv("GOOGLE_SHEETS_ID",
                             "YOUR_SHEET_ID_HERE"),  # fallback for deployment
  sa_key_path   = "auth/google_service_account.json",
  tab_emails    = "allowed_emails",
  tab_login_log = "login_log",
  tab_analytics = "analytics_log",
  cache_secs    = 60,
  admin_emails  = trimws(strsplit(
    Sys.getenv("ADMIN_EMAILS", "admin@yourcompany.com"), ","
  )[[1]])
)

.sheets_env <- new.env(parent = emptyenv())
.sheets_env$token       <- NULL
.sheets_env$token_exp   <- NULL
.sheets_env$connected   <- FALSE
.sheets_env$email_cache <- NULL
.sheets_env$cache_time  <- NULL

# ── Base64url encode ──────────────────────────────────────────
b64url <- function(x) {
  if (is.character(x)) x <- charToRaw(x)
  b <- base64enc::base64encode(x)
  b <- gsub("\\+", "-", b); b <- gsub("/", "_", b); b <- gsub("=+$", "", b)
  b
}

# ── JWT token for service account ────────────────────────────
get_sa_token <- function() {
  if (!is.null(.sheets_env$token) && !is.null(.sheets_env$token_exp) &&
      Sys.time() < .sheets_env$token_exp - 60)
    return(.sheets_env$token)

  key_path <- SHEETS_CONFIG$sa_key_path
  if (!file.exists(key_path)) stop("Key file not found: ", key_path)
  sa  <- jsonlite::fromJSON(key_path)
  now <- as.integer(Sys.time())

  header_str <- '{"alg":"RS256","typ":"JWT"}'
  claim_str  <- paste0(
    '{"iss":"', sa$client_email, '"',
    ',"scope":"https://www.googleapis.com/auth/spreadsheets',
    ' https://www.googleapis.com/auth/drive"',
    ',"aud":"https://oauth2.googleapis.com/token"',
    ',"iat":', now, ',"exp":', now + 3600L, '}')

  signing_input <- paste0(b64url(header_str), ".", b64url(claim_str))
  pkey <- openssl::read_key(sa$private_key)
  sig  <- b64url(openssl::signature_create(charToRaw(signing_input),
                  hash = openssl::sha256, key = pkey))
  jwt  <- paste0(signing_input, ".", sig)

  resp <- httr::POST("https://oauth2.googleapis.com/token",
    body = list(grant_type = "urn:ietf:params:oauth:grant-type:jwt-bearer",
                assertion  = jwt), encode = "form")
  httr::stop_for_status(resp)
  tok <- httr::content(resp, as = "parsed")
  .sheets_env$token     <- tok$access_token
  .sheets_env$token_exp <- Sys.time() + tok$expires_in
  .sheets_env$token
}

# ── Core REST ─────────────────────────────────────────────────
sheets_get <- function(range) {
  tok  <- get_sa_token()
  url  <- sprintf("https://sheets.googleapis.com/v4/spreadsheets/%s/values/%s",
                  SHEETS_CONFIG$sheet_id, utils::URLencode(range, reserved = TRUE))
  resp <- httr::GET(url, httr::add_headers(Authorization = paste("Bearer", tok)))
  httr::stop_for_status(resp)
  httr::content(resp, as = "parsed")
}

sheets_append <- function(tab, values_list) {
  tok  <- get_sa_token()
  url  <- sprintf(
    "https://sheets.googleapis.com/v4/spreadsheets/%s/values/%s:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS",
    SHEETS_CONFIG$sheet_id, utils::URLencode(tab, reserved = TRUE))
  body <- jsonlite::toJSON(list(values = list(values_list)), auto_unbox = TRUE)
  resp <- httr::POST(url, httr::add_headers(Authorization = paste("Bearer", tok),
                     `Content-Type` = "application/json"), body = body)
  httr::stop_for_status(resp)
  invisible(TRUE)
}

parse_sheet <- function(result, skip_rows = 0) {
  rows <- result$values
  if (is.null(rows) || length(rows) == 0) return(NULL)
  if (skip_rows > 0 && length(rows) > skip_rows) rows <- rows[(skip_rows + 1):length(rows)]
  if (length(rows) < 1) return(NULL)
  headers <- unlist(rows[[1]])
  if (length(rows) < 2) {
    empty <- as.data.frame(matrix(nrow = 0, ncol = length(headers)), stringsAsFactors = FALSE)
    names(empty) <- headers; return(empty)
  }
  data <- lapply(rows[-1], function(r) { r <- unlist(r); length(r) <- length(headers); r })
  df   <- as.data.frame(do.call(rbind, data), stringsAsFactors = FALSE)
  names(df) <- headers; df
}

# ── Connection test ───────────────────────────────────────────
sheets_connect <- function() {
  if (.sheets_env$connected) return(TRUE)
  if (!file.exists(SHEETS_CONFIG$sa_key_path)) {
    cat("⚠ Sheets: key not found — file fallback\n"); return(FALSE)
  }
  if (nchar(SHEETS_CONFIG$sheet_id) < 10 ||
      SHEETS_CONFIG$sheet_id == "YOUR_SHEET_ID_HERE") {
    cat("⚠ Sheets: GOOGLE_SHEETS_ID not set — file fallback\n"); return(FALSE)
  }
  if (!requireNamespace("openssl", quietly = TRUE) ||
      !requireNamespace("base64enc", quietly = TRUE)) {
    cat("⚠ Sheets: install openssl + base64enc\n"); return(FALSE)
  }
  tryCatch({
    tok  <- get_sa_token()
    url  <- sprintf("https://sheets.googleapis.com/v4/spreadsheets/%s?fields=properties.title",
                    SHEETS_CONFIG$sheet_id)
    resp <- httr::GET(url, httr::add_headers(Authorization = paste("Bearer", tok)))
    httr::stop_for_status(resp)
    info <- httr::content(resp, as = "parsed")
    cat("✓ Sheets: Connected to:", info$properties$title, "\n")
    .sheets_env$connected <- TRUE; TRUE
  }, error = function(e) {
    cat("⚠ Sheets:", e$message, "— file fallback\n"); FALSE
  })
}

# ── User management ───────────────────────────────────────────
sheets_get_allowed_emails <- function(force = FALSE) {
  if (!force && !is.null(.sheets_env$email_cache) && !is.null(.sheets_env$cache_time) &&
      as.numeric(Sys.time() - .sheets_env$cache_time, units = "secs") < SHEETS_CONFIG$cache_secs)
    return(.sheets_env$email_cache)
  if (sheets_connect()) {
    tryCatch({
      result <- sheets_get(paste0(SHEETS_CONFIG$tab_emails, "!A", EMAIL_DATA_ROW, ":A200"))
      rows   <- result$values
      if (!is.null(rows) && length(rows) > 0) {
        emails <- tolower(trimws(sapply(rows, function(r) r[[1]])))
        emails <- emails[nchar(emails) > 0 & !startsWith(emails, "removed_")]
        .sheets_env$email_cache <- emails
        .sheets_env$cache_time  <- Sys.time()
        return(emails)
      }
    }, error = function(e) cat("⚠ Sheets: email read error:", e$message, "\n"))
  }
  sheets_emails_from_file()
}

sheets_get_users_df <- function() {
  if (sheets_connect()) tryCatch({
    result <- sheets_get(paste0(SHEETS_CONFIG$tab_emails, "!A", EMAIL_DATA_ROW - 1, ":E200"))
    return(parse_sheet(result))
  }, error = function(e) NULL)
  emails <- sheets_emails_from_file()
  data.frame(email = emails, role = "user", added_by = "file",
             added_date = NA, notes = NA, stringsAsFactors = FALSE)
}

sheets_add_user <- function(email, role = "user", added_by = "admin", notes = "") {
  email <- tolower(trimws(email))
  if (!sheets_connect()) return(list(ok = FALSE, msg = "Not connected"))
  tryCatch({
    sheets_append(SHEETS_CONFIG$tab_emails,
      list(email, role, added_by, format(Sys.time(), "%Y-%m-%d %H:%M:%S"), notes))
    .sheets_env$email_cache <- NULL
    list(ok = TRUE, msg = paste0("User ", email, " added"))
  }, error = function(e) list(ok = FALSE, msg = e$message))
}

sheets_remove_user <- function(email) {
  list(ok = FALSE,
       msg = paste0("Prefix '", email, "' with REMOVED_ in the Google Sheet to revoke access."))
}

# ── Login logging ─────────────────────────────────────────────
sheets_log_login <- function(email, success, session_id, ip = "unknown") {
  tryCatch({
    if (sheets_connect())
      sheets_append(SHEETS_CONFIG$tab_login_log, list(
        format(Sys.time(), "%Y-%m-%d %H:%M:%S"), email,
        if (tolower(email) %in% tolower(SHEETS_CONFIG$admin_emails)) "admin" else "user",
        if (success) "TRUE" else "FALSE", ip, session_id))
  }, error = function(e) invisible())
}

# ── Analytics logging ─────────────────────────────────────────
sheets_log_event <- function(email, session_id, event_type,
                             tab = "", element = "", detail = "",
                             duration_secs = NA) {
  tryCatch({
    if (sheets_connect())
      sheets_append(SHEETS_CONFIG$tab_analytics, list(
        format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
        email, session_id, event_type, tab, element,
        substr(as.character(detail), 1, 200),
        if (is.na(duration_secs)) "" else as.character(round(duration_secs, 1))))
  }, error = function(e) invisible())
}

# ── Analytics reading (for admin tab) ────────────────────────
sheets_get_login_log <- function() {
  if (!sheets_connect()) return(NULL)
  tryCatch({
    parse_sheet(sheets_get(paste0(SHEETS_CONFIG$tab_login_log,
                                  "!A", LOG_HEADER_ROW, ":F2000")))
  }, error = function(e) NULL)
}

sheets_get_analytics <- function() {
  if (!sheets_connect()) return(NULL)
  tryCatch({
    parse_sheet(sheets_get(paste0(SHEETS_CONFIG$tab_analytics,
                                  "!A", LOG_HEADER_ROW, ":H2000")))
  }, error = function(e) NULL)
}

# ── File fallback ─────────────────────────────────────────────
sheets_emails_from_file <- function() {
  path <- "auth/allowed_emails.txt"
  if (!file.exists(path)) return(character(0))
  lines <- trimws(readLines(path, warn = FALSE))
  tolower(lines[nchar(lines) > 0 & !startsWith(lines, "#")])
}

is_admin <- function(email) {
  tolower(trimws(email)) %in% tolower(trimws(SHEETS_CONFIG$admin_emails))
}
