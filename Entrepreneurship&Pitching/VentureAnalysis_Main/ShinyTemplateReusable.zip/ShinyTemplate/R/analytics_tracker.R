# R/analytics_tracker.R — User Interaction Tracker
# ─────────────────────────────────────────────────────────────
# Tracks: tab navigation, button clicks, box clicks,
#         slider changes (debounced), plotly interactions,
#         session start/end.
#
# All events queued in memory, flushed to Google Sheets
# every FLUSH_SECS seconds.
#
# KEY DESIGN: All JS-driven inputs are passed as reactives
# from the PARENT server to bypass moduleServer namespacing.
# (Inside moduleServer, input$__tracker_X becomes
#  tracker-__tracker_X and never matches JS setInputValue calls)
# ─────────────────────────────────────────────────────────────

library(shiny)

# ── JS injection — call analytics_js() inside dashboardBody tags$head ──
analytics_js <- function() {
  tags$script(HTML("
    // Box clicks
    $(document).on('click', '.box', function() {
      var title = $(this).find('.box-title').first().text().trim() ||
                  $(this).find('h3,h4,h5').first().text().trim() || 'unnamed_box';
      Shiny.setInputValue('__tracker_box_click',
        { title: title, t: Date.now() }, { priority: 'event' });
    });

    // Sidebar tab clicks (shinydashboard)
    $(document).on('click', '.sidebar-menu a[data-toggle=tab]', function() {
      Shiny.setInputValue('__tracker_tab_change',
        { tab: $(this).attr('data-value') || $(this).text().trim(), t: Date.now() },
        { priority: 'event' });
    });

    // Action button clicks (excludes login button)
    $(document).on('click', '.action-button:not(#login_submit)', function() {
      Shiny.setInputValue('__tracker_btn_click',
        { id: $(this).attr('id') || 'unknown', label: $(this).text().trim().substring(0,60), t: Date.now() },
        { priority: 'event' });
    });

    // Plotly interactions
    $(document).on('plotly_relayout plotly_selected', function(e) {
      Shiny.setInputValue('__tracker_plot_interact',
        { plot: $(e.target).attr('id') || 'unknown_plot', t: Date.now() },
        { priority: 'event' });
    });

    // Session duration on close
    var _t0 = Date.now();
    window.addEventListener('beforeunload', function() {
      Shiny.setInputValue('__tracker_session_end',
        { secs: Math.round((Date.now() - _t0) / 1000), t: Date.now() },
        { priority: 'event' });
    });
  "))
}

# ── Tracker module server ─────────────────────────────────────
#
# USAGE in app.R server():
#
#   tracker_server(
#     id                     = "tracker",
#     email_reactive         = reactive({ state$email %||% "" }),
#     session_id             = isolate(state$session_id),
#     tab_reactive           = reactive(input$tabs),          # parent input$tabs
#     box_click_reactive     = reactive(input$`__tracker_box_click`),
#     btn_click_reactive     = reactive(input$`__tracker_btn_click`),
#     tab_change_reactive    = reactive(input$`__tracker_tab_change`),
#     plot_interact_reactive = reactive(input$`__tracker_plot_interact`),
#     session_end_reactive   = reactive(input$`__tracker_session_end`),
#     flush_secs             = 10
#   )
#
# ADD CUSTOM TRACKED INPUTS:
#   Extend tracked_inputs vector below with "module_id-input_id" strings.

tracker_server <- function(id, email_reactive, session_id,
                           tab_reactive,
                           box_click_reactive,
                           btn_click_reactive,
                           tab_change_reactive,
                           plot_interact_reactive,
                           session_end_reactive,
                           flush_secs = 10) {

  moduleServer(id, function(input, output, session) {

    queue     <- reactiveVal(list())
    tab_state <- reactiveValues(current = "unknown", entered = Sys.time())

    # Push event to queue (only when email is set = user authenticated)
    push_event <- function(event_type, tab = "", element = "",
                           detail = "", duration = NA) {
      em <- isolate(email_reactive())
      if (is.null(em) || !nzchar(trimws(em))) return(invisible())
      queue(c(queue(), list(list(
        email = em, session_id = session_id, event_type = event_type,
        tab = tab, element = element,
        detail = substr(as.character(detail), 1, 200),
        duration_secs = duration
      ))))
    }

    # Flush queue to Google Sheets
    flush_queue <- function(events) {
      if (length(events) == 0) return(invisible())
      for (ev in events) tryCatch(
        sheets_log_event(ev$email, ev$session_id, ev$event_type,
                         ev$tab, ev$element, ev$detail, ev$duration_secs),
        error = function(e) invisible()
      )
    }

    # Session start when email becomes available
    observeEvent(email_reactive(), {
      em <- email_reactive()
      if (!is.null(em) && nzchar(trimws(em)))
        push_event("session_start",
                   detail = paste0("host:", session$clientData$url_hostname))
    }, ignoreNULL = FALSE, ignoreInit = FALSE)

    # Tab changes via shinydashboard input$tabs (parent reactive)
    observeEvent(tab_reactive(), {
      new_tab <- tab_reactive()
      if (!is.null(new_tab) && nzchar(new_tab) && tab_state$current != new_tab) {
        dur <- as.numeric(Sys.time() - tab_state$entered, units = "secs")
        if (tab_state$current != "unknown")
          push_event("tab_exit", tab = tab_state$current, duration = round(dur, 1))
        push_event("tab_view", tab = new_tab)
        tab_state$current <- new_tab; tab_state$entered <- Sys.time()
      }
    }, ignoreNULL = TRUE, ignoreInit = TRUE)

    # Tab changes via JS click (parent reactive)
    observeEvent(tab_change_reactive(), {
      tc <- tab_change_reactive(); if (is.null(tc)) return()
      new_tab <- tc$tab
      if (!is.null(new_tab) && nzchar(new_tab) && tab_state$current != new_tab) {
        dur <- as.numeric(Sys.time() - tab_state$entered, units = "secs")
        if (tab_state$current != "unknown")
          push_event("tab_exit", tab = tab_state$current, duration = round(dur, 1))
        push_event("tab_view", tab = new_tab)
        tab_state$current <- new_tab; tab_state$entered <- Sys.time()
      }
    }, ignoreNULL = TRUE)

    observeEvent(box_click_reactive(), {
      bc <- box_click_reactive(); if (is.null(bc)) return()
      push_event("box_click", tab = tab_state$current,
                 element = "box", detail = bc$title)
    }, ignoreNULL = TRUE)

    observeEvent(btn_click_reactive(), {
      bc <- btn_click_reactive(); if (is.null(bc)) return()
      push_event("button_click", tab = tab_state$current,
                 element = bc$id, detail = bc$label)
    }, ignoreNULL = TRUE)

    observeEvent(plot_interact_reactive(), {
      pi <- plot_interact_reactive(); if (is.null(pi)) return()
      push_event("plot_interact", tab = tab_state$current, element = pi$plot)
    }, ignoreNULL = TRUE)

    observeEvent(session_end_reactive(), {
      se <- session_end_reactive(); if (is.null(se)) return()
      push_event("session_end", duration = se$secs)
      flush_queue(queue()); queue(list())
    }, ignoreNULL = TRUE)

    # ── ADD YOUR TRACKED INPUTS HERE ──────────────────────────
    # Format: "module_id-input_id" — debounced 1.5s
    tracked_inputs <- c(
      # "tab_one-my_slider",
      # "tab_two-my_select",
    )

    lapply(tracked_inputs, function(inp_id) {
      deb <- debounce(reactive({ input[[inp_id]] }), 1500)
      observe({
        val <- deb()
        if (!is.null(val))
          push_event("input_change", tab = tab_state$current,
                     element = inp_id, detail = paste0(val, collapse = ","))
      })
    })

    # Periodic flush
    observe({
      invalidateLater(flush_secs * 1000, session)
      isolate({ evs <- queue(); if (length(evs) > 0) { flush_queue(evs); queue(list()) } })
    })

    session$onSessionEnded(function() {
      isolate({ evs <- queue(); if (length(evs) > 0) flush_queue(evs) })
    })
  })
}
