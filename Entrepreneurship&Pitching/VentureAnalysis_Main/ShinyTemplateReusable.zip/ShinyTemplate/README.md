# Shiny App Template
**Portable skeleton — login gate + analytics tracking + 3 dummy tabs**

Built by Atera Analytics. Drop into any Claude chat and say:
*"Use this template to build [your app description]"*

---

## What's included

| Feature | File |
|---|---|
| Google Sheets login gate | `R/sheets_backend.R` + `R/auth.R` |
| Analytics event tracking | `R/analytics_tracker.R` |
| Admin tab (users + charts) | `modules/admin_reporting.R` |
| 3 dummy content tabs | `modules/tab_one/two/three.R` |
| Dark DeepTech theme | `www/css/global.css` + `auth.css` |

---

## Quick start

### 1. Set up Google Sheets
Create a spreadsheet with 3 tabs:
- `allowed_emails` — headers: `email | role | added_by | added_date | notes`
- `login_log` — headers: `timestamp | email | role | success | ip | session_id`
- `analytics_log` — headers: `timestamp | email | session_id | event_type | tab | element | detail | duration_secs`

### 2. Service account
- Create a Google service account, enable Sheets + Drive APIs
- Share the spreadsheet with the service account email (Editor)
- Save the JSON key as `auth/google_service_account.json`

### 3. Environment variables
Edit `.Renviron`:
```
GOOGLE_SHEETS_ID=your_sheet_id_here
ADMIN_EMAILS=your@email.com
```

### 4. Run locally
```r
shiny::runApp()
```

---

## Adding a new tab

1. Create `modules/my_tab.R` with `my_tab_ui(id)` and `my_tab_server(id, ...)`
2. Add to `app.R` sidebar: `menuItem("My Tab", tabName = "my_tab", icon = icon("..."))`
3. Add to `app.R` body: `tabItem(tabName = "my_tab", my_tab_ui("my_tab"))`
4. Add to `app.R` server: `my_tab_server("my_tab")`
5. Optionally add slider/input IDs to `tracked_inputs` in `R/analytics_tracker.R`

---

## Customising

| What | Where |
|---|---|
| App name | `APP_NAME` in `app.R` |
| Sidebar branding | sidebar div in `app.R` |
| Colour theme | `www/css/global.css` |
| Login screen text | `login_overlay_ui()` in `R/auth.R` |
| Tracked sliders | `tracked_inputs` in `R/analytics_tracker.R` |
| Sheet ID hardcoded fallback | `SHEETS_CONFIG$sheet_id` in `R/sheets_backend.R` |
| Admin emails hardcoded fallback | `SHEETS_CONFIG$admin_emails` in `R/sheets_backend.R` |

---

## File structure
```
ShinyTemplate/
├── app.R                        ← Entry point — edit APP_NAME here
├── global.R                     ← UI helpers + plotly theme
├── .Renviron                    ← Local env vars (never commit)
├── .gitignore
├── R/
│   ├── sheets_backend.R         ← Google Sheets REST API layer
│   ├── analytics_tracker.R      ← Event tracking module
│   └── auth.R                   ← Login overlay UI
├── modules/
│   ├── tab_one.R                ← Dummy tab 1 (replace me)
│   ├── tab_two.R                ← Dummy tab 2 (replace me)
│   ├── tab_three.R              ← Dummy tab 3 (replace me)
│   └── admin_reporting.R        ← Admin analytics tab (keep as-is)
├── auth/
│   ├── allowed_emails.txt       ← Fallback email list
│   └── google_service_account.json  ← YOU add this (gitignored)
└── www/css/
    ├── global.css               ← App theme
    └── auth.css                 ← Login screen styles
```

---

## Required R packages
```r
install.packages(c(
  "shiny", "shinydashboard", "plotly", "DT", "dplyr",
  "httr", "jsonlite", "openssl", "base64enc"
))
```
