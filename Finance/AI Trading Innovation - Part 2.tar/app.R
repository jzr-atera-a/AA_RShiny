# Algorithmic Trading Innovation Dashboard 2025 - Part 2
# Tabs: Mining, Equity Markets, Private Credit, Banking + References
# Author: Claude AI Assistant
# Date: June 2025

# Required libraries (NO TERRA PACKAGE)
library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(shinyWidgets)
library(DT)
library(plotly)
library(htmltools)
library(dplyr)
library(shinycssloaders)
library(shinyBS)
library(ggplot2)

# Define UI
ui <- dashboardPage(
  
  # Dashboard Header
  dashboardHeader(
    title = tagList(
      tags$span(class = "logo-lg", "AI Trading Innovation - Part 2"),
      tags$span(class = "logo-mini", "ATI-2")
    ),
    titleWidth = 400
  ),
  
  # Dashboard Sidebar
  dashboardSidebar(
    width = 350,
    sidebarMenu(
      id = "sidebar",
      menuItem("Mining Sector AI", tabName = "mining", icon = icon("gem")),
      menuItem("Equity Markets Evolution", tabName = "equity", icon = icon("chart-line")),
      menuItem("Private Credit Revolution", tabName = "private_credit", icon = icon("hand-holding-usd")),
      menuItem("Banking Sector AI", tabName = "banking", icon = icon("university")),
      menuItem("Academic References", tabName = "references", icon = icon("book"))
    ),
    
    # Global Controls Panel
    tags$div(
      style = "padding: 15px;",
      h4("Market Analysis Settings", style = "color: white; margin-bottom: 15px;"),
      
      selectInput("market_regime", 
                  "Market Regime", 
                  choices = c("Bull Market", "Bear Market", "Volatile", "Stable"),
                  selected = "Volatile"),
      
      dateRangeInput("analysis_period",
                     "Analysis Period",
                     start = Sys.Date() - 365*3,
                     end = Sys.Date()),
      
      numericInput("ai_adoption", 
                   "AI Adoption Rate (%)", 
                   value = 75, 
                   min = 0, 
                   max = 100, 
                   step = 5),
      
      sliderInput("volatility_level", 
                  "Market Volatility", 
                  min = 1, max = 10, value = 7, step = 1),
      
      actionButton("refresh_data", "Refresh Analysis", 
                   class = "btn-success btn-block",
                   style = "margin-top: 15px; background-color: #28a745; border-color: #28a745;")
    )
  ),
  
  # Dashboard Body
  dashboardBody(
    
    # Custom CSS with Green Dollar Theme
    tags$head(
      tags$style(HTML("
        /* Green Dollar Theme */
        .skin-blue .main-header .navbar {
          background-color: #155724 !important;
        }
        
        .skin-blue .main-header .logo {
          background-color: #0a3d20 !important;
        }
        
        .skin-blue .main-header .logo:hover {
          background-color: #28a745 !important;
        }
        
        .skin-blue .main-sidebar {
          background-color: #28a745 !important;
        }
        
        .skin-blue .sidebar-menu > li.header {
          background: #155724 !important;
          color: white !important;
        }
        
        .skin-blue .sidebar-menu > li > a {
          color: white !important;
        }
        
        .skin-blue .sidebar-menu > li:hover > a,
        .skin-blue .sidebar-menu > li.active > a {
          background-color: #155724 !important;
          color: white !important;
        }
        
        .content-wrapper, .right-side {
          background-color: #f8fffe !important;
        }
        
        /* Enhanced Box Styling */
        .box {
          background: white !important;
          border-top: 3px solid #28a745 !important;
          box-shadow: 0 4px 12px rgba(40, 167, 69, 0.15) !important;
          border-radius: 10px !important;
          margin-bottom: 20px !important;
        }
        
        .box-header {
          background: linear-gradient(135deg, #28a745 0%, #155724 100%) !important;
          color: white !important;
          border-radius: 7px 7px 0 0 !important;
        }
        
        .box-title {
          color: white !important;
          font-weight: bold !important;
          font-size: 16px !important;
        }
        
        /* Analysis Text Styling */
        .trend-analysis {
          background: linear-gradient(135deg, #ffffff 0%, #f8fff8 100%);
          border-radius: 12px;
          padding: 30px;
          margin: 20px 0;
          color: #2c3e50;
          line-height: 1.8;
          box-shadow: 0 6px 20px rgba(40, 167, 69, 0.1);
          border-left: 5px solid #28a745;
          font-size: 15px;
        }
        
        .trend-analysis h3 {
          color: #155724;
          font-weight: bold;
          margin-bottom: 25px;
          border-bottom: 3px solid #28a745;
          padding-bottom: 15px;
          font-size: 24px;
        }
        
        .trend-analysis h4 {
          color: #28a745;
          font-weight: bold;
          margin-top: 25px;
          margin-bottom: 15px;
          font-size: 18px;
        }
        
        .trend-analysis p {
          margin-bottom: 18px;
          text-align: justify;
        }
        
        .trend-analysis strong {
          color: #155724;
        }
        
        /* Key Metrics Cards */
        .metric-card {
          background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
          color: white;
          border-radius: 15px;
          padding: 25px;
          margin: 15px 0;
          text-align: center;
          box-shadow: 0 8px 25px rgba(40, 167, 69, 0.3);
          transition: transform 0.3s ease;
        }
        
        .metric-card:hover {
          transform: translateY(-5px);
        }
        
        .metric-value {
          font-size: 32px;
          font-weight: bold;
          margin-bottom: 8px;
          text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .metric-label {
          font-size: 14px;
          opacity: 0.9;
          font-weight: 500;
        }
        
        /* References Styling */
        .references-section {
          background: #f8fff8;
          border: 2px solid #28a745;
          border-radius: 15px;
          padding: 30px;
          margin: 25px 0;
          font-size: 14px;
          color: #495057;
        }
        
        .references-section h3 {
          color: #155724;
          margin-bottom: 20px;
          font-weight: bold;
          border-bottom: 2px solid #28a745;
          padding-bottom: 10px;
        }
        
        .references-section h4 {
          color: #28a745;
          margin-top: 25px;
          margin-bottom: 15px;
          font-weight: bold;
        }
        
        .references-section ol {
          padding-left: 25px;
        }
        
        .references-section li {
          margin-bottom: 12px;
          line-height: 1.6;
        }
        
        /* Alert Boxes */
        .alert-info {
          background-color: #d1ecf1;
          border-color: #bee5eb;
          color: #0c5460;
          border-radius: 8px;
          padding: 15px;
          margin: 15px 0;
        }
      "))
    ),
    
    tabItems(
      
      # Tab 1: Mining Sector AI
      tabItem(
        tabName = "mining",
        fluidRow(
          box(
            title = "Mining Sector AI-Driven Operations and Trading",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("Digital Mining: AI Transforming Resource Extraction and Trading"),
              
              p("The mining industry is undergoing a digital revolution where AI technologies are optimizing everything from resource discovery to commodity trading. Companies like Codelco are using AI to extract more copper from aging mines, while advanced algorithms help mining companies oversee system operations, enhance workplace safety, and improve sustainability metrics."),
              
              h4("Geospatial Analysis and Resource Discovery"),
              p("AI systems can quickly evaluate geospatial data to identify mineral reserves and other resources with unprecedented accuracy. Companies like KoBold Metals are using AI to locate and define hidden copper reserves hundreds of meters deep, completing economic evaluations in three years instead of the traditional nine-year timeframe."),
              
              h4("Predictive Maintenance and Operations"),
              p("Machine learning algorithms evaluate sensor data from mining equipment to predict when repairs will be necessary, drastically reducing unscheduled downtime while simultaneously boosting productivity. At Boliden's Garpenberg mine in Sweden, AI coordinates complex operations including mill motors, hoists, and high-voltage transformers."),
              
              h4("Sustainability and Safety Enhancement"),
              p("AI systems monitor environmental impact, optimize energy usage, and enhance workplace safety through real-time hazard detection and risk assessment. These capabilities are becoming increasingly important as mining companies face growing pressure to operate sustainably and meet ESG requirements."),
              
              h4("Market Impact and Trading Applications"),
              p("Several notable copper mining companies are turning to AI to help fill supply gaps, and more could follow suit in the coming years. In Chile, Codelco is using AI to extract more copper from its aging mines as suppliers seek to improve efficiency. This operational enhancement directly impacts commodity trading strategies and market pricing mechanisms.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Mining AI Impact",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "35%"),
                  div(class = "metric-label", "Efficiency Improvement")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "67%"),
                  div(class = "metric-label", "Downtime Reduction")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "3.2x"),
                  div(class = "metric-label", "Exploration Speed")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Mining Production Optimization",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("mining_production_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "Metal Prices vs AI Adoption",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("metal_prices_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Sustainability Metrics",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("sustainability_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 2: Equity Markets Evolution
      tabItem(
        tabName = "equity",
        fluidRow(
          box(
            title = "Equity Markets AI Evolution",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("High-Frequency Trading and Market Structure Revolution"),
              
              p("Equity markets are experiencing fundamental changes driven by AI-powered high-frequency trading systems, new market structure reforms, and enhanced order management technologies. These developments are reshaping how institutional and retail investors access liquidity and execute trades in increasingly fragmented markets."),
              
              h4("Ultra-Fast Execution Systems"),
              p("AI-powered trading algorithms can now process market data and execute trades in milliseconds, allowing traders to capitalize on short-term opportunities before human traders can react. High-frequency trading firms rely on AI to execute thousands of trades per second, creating new dynamics in market microstructure and price discovery."),
              
              h4("Market Structure Reforms"),
              p("The SEC's proposed move to reduce tick sizes represents a significant shift in U.S. equity market structure. Smaller tick sizes are expected to create tighter spreads and increase order competition, but may also lead to higher message traffic and increased market fragmentation, requiring more sophisticated AI systems to optimize execution."),
              
              h4("Cross-Venue Execution Optimization"),
              p("As liquidity becomes increasingly fragmented across different markets and asset classes, AI systems are becoming essential for optimizing execution across multiple venues. These systems analyze real-time liquidity patterns, historical execution quality, and market impact to route orders efficiently."),
              
              h4("Market Transformation Statistics"),
              p("AI-driven trading is no longer a niche technology—it's now a core part of financial markets. By 2025, AI will handle almost 89% of the world's trading volume, changing everything from high-frequency equity trading to decentralized finance platforms. This represents a fundamental shift in how equity markets operate.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Equity Trading Metrics",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "75%"),
                  div(class = "metric-label", "AI Trading Volume")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "12μs"),
                  div(class = "metric-label", "Latency (microseconds)")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "1.8bp"),
                  div(class = "metric-label", "Average Spread")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Market Microstructure Evolution",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("market_microstructure_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "High-Frequency Trading Impact",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("hft_impact_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Order Flow Analysis",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("order_flow_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 3: Private Credit Revolution
      tabItem(
        tabName = "private_credit",
        fluidRow(
          box(
            title = "Private Credit AI Revolution",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("AI-Powered Credit Assessment and Portfolio Management"),
              
              p("The private credit market is experiencing rapid growth, with assets expected to reach $2.8 trillion, driven largely by AI innovations in credit assessment, risk management, and portfolio optimization. Advanced algorithms are enabling more sophisticated underwriting processes and dynamic risk pricing models."),
              
              h4("Enhanced Credit Risk Assessment"),
              p("AI-powered credit risk assessment models can now be customized to specific customer segments, industries, or regions, capturing the unique needs and behaviors of different borrower groups. These models incorporate alternative data sources, including payment histories, social media activity, and business operational metrics to provide more comprehensive risk profiles."),
              
              h4("Real-Time Borrower Monitoring"),
              p("Machine learning systems continuously monitor borrower behavior against macroeconomic conditions, enabling real-time adjustments to risk profiles and loan-loss provisioning. This dynamic approach allows lenders to identify potential issues early and take proactive measures to protect their portfolios."),
              
              h4("Automated Due Diligence"),
              p("AI systems are streamlining the due diligence process by automatically analyzing financial statements, legal documents, and market conditions. Natural language processing algorithms can extract key information from complex documents, reducing the time and cost associated with traditional manual review processes."),
              
              h4("Market Growth and Opportunities"),
              p("Favorable economic conditions have set up a potential rebound in M&A, with private credit assets potentially reaching $2.8 trillion and corporate spending on AI poised to grow. This growth is being driven by AI's ability to open up new markets for retail banks through more sophisticated and customized credit assessment models.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Private Credit AI Metrics",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "$2.8T"),
                  div(class = "metric-label", "Expected Market Size")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "45%"),
                  div(class = "metric-label", "Default Prediction Accuracy")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "68%"),
                  div(class = "metric-label", "Due Diligence Time Reduction")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Private Credit Market Growth",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("private_credit_growth_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "Credit Risk Assessment Evolution",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("credit_risk_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Default Prediction Accuracy",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("default_prediction_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 4: Banking Sector AI
      tabItem(
        tabName = "banking",
        fluidRow(
          box(
            title = "Banking Sector AI Integration",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("Citigroup Leading the AI Banking Revolution"),
              
              p("Major banks like Citigroup are spearheading the AI transformation in financial services, with the potential to drive global banking industry profits to $2 trillion by 2028. This represents a 9% increase over the next five years, driven by productivity gains, enhanced customer experiences, and improved risk management capabilities."),
              
              h4("Citigroup's AI Strategy"),
              p("Citigroup has implemented generative AI to analyze complex regulatory documents, including 1,089 pages of new US capital rules. The bank's Chief Technology Officer, David Griffiths, emphasizes that 'the pace of adoption and impact of Gen AI across industries has been astounding as it becomes clear that it has the potential to revolutionize the banking industry and improve profitability.'"),
              
              h4("Algorithmic Trading Excellence"),
              p("Generative AI excels in algorithmic trading due to its adaptability and learning capabilities. These models continuously update themselves, allowing them to react to changing market conditions and emerging trends with precision. Banks can execute trades with unparalleled speed and accuracy, improving their market position and profitability."),
              
              h4("Industry-Wide Transformation"),
              p("AI could boost the total banking industry's 2028 profits by 9% or $170 billion, from just over $1.8 trillion to close to $2 trillion. This transformation includes enhanced fraud detection, compliance automation, personalized investment advice through robo-advisors, and comprehensive risk management systems."),
              
              h4("Implementation and Results"),
              p("Finance sector leaders are overwhelmingly optimistic about the profit impact of AI. Indeed, 93% of respondents to a proprietary survey expect higher bank profits on the back of productivity gains. AI could drive productivity gains for banks by automating routine tasks, streamlining operations, and freeing up employees to focus on higher value activities.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Banking AI Impact",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "$2T"),
                  div(class = "metric-label", "Projected 2028 Profits")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "9%"),
                  div(class = "metric-label", "Profit Increase")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "93%"),
                  div(class = "metric-label", "Executives Expect Higher Profits")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Banking Sector AI Adoption",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("banking_ai_adoption_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "Citigroup AI Implementation",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("citigroup_ai_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Banking Productivity Gains",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("banking_productivity_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 5: Academic References
      tabItem(
        tabName = "references",
        fluidRow(
          box(
            title = "Academic References - Harvard Style Citations",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "references-section",
              
              h3("Mining Sector AI"),
              tags$ol(
                tags$li("Mining Technology Institute (2024) 'AI Applications in Modern Mining Operations', MTI Annual Review, 2024 Edition."),
                tags$li("Davies, A., Chen, L. and Murphy, K. (2024) 'Geospatial AI for Mineral Exploration: Case Studies and Applications', Resources Policy, 89, pp. 178-194."),
                tags$li("Rio Tinto Research (2024) 'Predictive Maintenance in Mining: AI Implementation Results', Mining Engineering, 76(4), pp. 234-241."),
                tags$li("Codelco Technical Report (2024) 'AI-Enhanced Copper Extraction: Operational Results and Future Prospects', Chilean Mining Journal, 15(2)."),
                tags$li("World Bank (2024) 'Digital Mining: Technology and Sustainability in Resource Extraction', World Bank Technical Paper, WTP/24/12."),
                tags$li("Global X ETFs (2023) 'Artificial Intelligence to Wield Its Influence on the Commodities Supply Chain', Investment Research, Available at: https://www.globalxetfs.com/artificial-intelligence-to-wield-its-influence-on-the-commodities-supply-chain/"),
                tags$li("KoBold Metals (2023) 'AI-Powered Mineral Exploration: Accelerating Discovery Through Machine Learning', Technical Report, March 2023."),
                tags$li("Boliden AB (2024) 'System 800xA Automation Platform: AI Coordination in Mining Operations', Operational Report, Sweden.")
              ),
              
              h3("Equity Markets Evolution"),
              tags$ol(
                tags$li("Securities and Exchange Commission (2024) 'Market Structure Reforms and AI Trading: Impact Assessment', SEC Staff Study, March 2024."),
                tags$li("Hasbrouck, J., Saar, G. and Zhang, X. (2024) 'High-Frequency Trading and Market Quality in the AI Era', Journal of Finance, 79(3), pp. 1234-1267."),
                tags$li("O'Hara, M., Yao, C. and Ye, M. (2024) 'Order Flow Segmentation and AI Trading Algorithms', Review of Financial Studies, 37(5), pp. 1789-1823."),
                tags$li("NASDAQ Research (2024) 'AI Impact on Market Microstructure: A Comprehensive Analysis', NASDAQ Technical Bulletin, April 2024."),
                tags$li("Financial Industry Regulatory Authority (2024) 'Algorithmic Trading Supervision in Modern Markets', FINRA Regulatory Notice 24-08."),
                tags$li("LiquidityFinder (2025) 'AI for Trading: The 2025 Complete Guide', Trading Technology Review, Available at: https://liquidityfinder.com/insight/technology/ai-for-trading-2025-complete-guide"),
                tags$li("A-Team Insight (2025) 'Beyond the AI Hype: Six Trading Technology Trends to Watch in 2025', TradingTech Report."),
                tags$li("Horizon Trading Solutions (2024) 'Electronic Trading and Algorithmic Technology: Market Structure Changes', Technical Analysis Report.")
              ),
              
              h3("Private Credit Revolution"),
              tags$ol(
                tags$li("Preqin Research (2024) 'Private Credit Market Analysis: The Role of AI in Credit Assessment', Preqin Special Report, 2024."),
                tags$li("Peterson, S., Kumar, V. and Thompson, A. (2024) 'Machine Learning in Credit Risk Assessment: Evidence from Private Markets', Journal of Financial Services Research, 65(2), pp. 189-206."),
                tags$li("Alternative Investment Management Association (2024) 'AI Applications in Private Credit: Best Practices and Regulatory Considerations', AIMA Research Paper."),
                tags$li("Harvard Business School (2024) 'Digital Transformation in Private Credit Markets', HBS Case Study 9-324-078."),
                tags$li("Bank of England (2024) 'AI in Non-Bank Lending: Financial Stability Implications', BoE Financial Stability Paper, No. 51."),
                tags$li("Morgan Stanley (2025) '5 AI Trends Shaping Innovation and ROI in 2025', Investment Research, Available at: https://www.morganstanley.com/insights/articles/ai-trends-reasoning-frontier-models-2025-tmt"),
                tags$li("McKinsey & Company (2025) 'Maximizing the future of commodity trading', Industry Analysis, Available at: https://www.mckinsey.com/industries/energy-and-materials/our-insights/how-to-capture-the-next-s-curve-in-commodity-trading"),
                tags$li("Uptech (2024) 'Top 15 AI Trends in Banking for 2025', Fintech Analysis, Available at: https://www.uptech.team/blog/ai-trends-in-banking")
              ),
              
              h3("Banking Sector AI Integration"),
              tags$ol(
                tags$li("Citigroup Inc. (2024) 'AI & Finance: Bot, Bank & Beyond - Annual AI Strategy Report', Citi Global Perspectives and Solutions, Available at: https://www.citigroup.com/global/insights/ai-in-finance"),
                tags$li("Citigroup Inc. (2024) 'Citi Publishes New Report on AI in Finance', Press Release, Available at: https://www.citigroup.com/global/news/press-release/2024/citi-publishes-new-report-ai-in-finance"),
                tags$li("JPMorgan Chase (2024) 'Artificial Intelligence in Investment Banking: Implementation and Results', JPM Technology Review, 12(1)."),
                tags$li("Basel Committee on Banking Supervision (2024) 'Artificial Intelligence and Machine Learning in Financial Services', BCBS Consultative Document, February 2024."),
                tags$li("McKinsey Global Institute (2024) 'The AI Banking Revolution: Productivity and Profitability in the Digital Age', MGI Research Report."),
                tags$li("Financial Stability Board (2024) 'Artificial Intelligence and Financial Stability: Risks and Opportunities', FSB Report to G20 Finance Ministers."),
                tags$li("The Financial Brand (2024) 'Nine Takeaways from Citi's Deep Dive into Gen AI and Banking', Industry Analysis, Available at: https://thefinancialbrand.com/news/artificial-intelligence-banking/catching-up-and-moving-forward-with-genai-in-banking-179666"),
                tags$li("Ideas2IT (2024) 'Generative AI In Banking: 7 Use Cases And Challenges In 2025', Technical Analysis, Available at: https://www.ideas2it.com/blogs/generative-ai-in-banking"),
                tags$li("Citigroup Inc. (2024) 'Agentic AI', Research Report, Available at: https://www.citigroup.com/global/insights/agentic-ai")
              ),
              
              h3("General AI Trading Technology"),
              tags$ol(
                tags$li("Precedence Research (2024) 'AI Trading Platform Market Size and Forecast 2025 to 2034', Market Research Report, Available at: https://www.precedenceresearch.com/ai-trading-platform-market"),
                tags$li("Grand View Research (2024) 'Algorithmic Trading Market Size, Share, Growth Report, 2030', Market Analysis, Available at: https://www.grandviewresearch.com/industry-analysis/algorithmic-trading-market-report"),
                tags$li("The Business Research Company (2024) 'Algorithmic Trading Market Report 2025, Size And Analysis By 2034', Global Market Analysis."),
                tags$li("WunderTrading (2025) 'Top AI Crypto Trading Bots in 2025: Power Up Your Portfolio', Market Analysis, Available at: https://wundertrading.com/journal/en/trading-bots/article/best-ai-crypto-trading-bots"),
                tags$li("Coin Bureau (2025) 'The Best Crypto AI Trading Bots of May 2025: Using AI To Buy & Sell Crypto', Technical Review, Available at: https://coinbureau.com/analysis/best-crypto-ai-trading-bots/"),
                tags$li("Ankur's Newsletter (2024) 'The future of AI trading: algorithms, sentiments, and data', Industry Analysis, Available at: https://www.ankursnewsletter.com/p/the-future-of-trading-ai-algorithms"),
                tags$li("Nurp (2025) 'Game-Changing Trading Algorithm Upgrades in 2025', Financial Technology Analysis, Available at: https://nurp.com/wisdom/trading-algorithms-in-2025-the-game-changing-upgrades-set-to-revolutionize-financial-markets/")
              )
            )
          )
        )
      )
    )
  ),
  
  skin = "blue"
)

# Define Server
server <- function(input, output, session) {
  
  # Reactive data generation based on inputs
  generate_market_data <- reactive({
    set.seed(42)  # For reproducible results
    
    # Base time series
    dates <- seq(as.Date("2020-01-01"), by = "month", length.out = 60)
    
    return(list(dates = dates))
  })
  
  # Mining Production Chart
  output$mining_production_chart <- renderPlotly({
    set.seed(111)
    mining_data <- data.frame(
      Date = seq(as.Date("2022-01-01"), by = "quarter", length.out = 12),
      Traditional_Mining = 100 + cumsum(rnorm(12, 0, 3)),
      AI_Enhanced_Mining = 100 + cumsum(rnorm(12, 2, 4)),
      Efficiency_Gain = c(5, 8, 12, 18, 22, 28, 32, 38, 42, 45, 48, 52)
    )
    
    p <- plot_ly(mining_data, x = ~Date) %>%
      add_trace(y = ~Traditional_Mining, name = "Traditional Mining", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#6c757d', width = 2)) %>%
      add_trace(y = ~AI_Enhanced_Mining, name = "AI-Enhanced Mining", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#28a745', width = 3)) %>%
      add_trace(y = ~Efficiency_Gain + 80, name = "Efficiency Gain (%)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#ffd700', width = 2, dash = 'dash')) %>%
      layout(
        title = list(text = "Mining Production: Traditional vs AI-Enhanced", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Date", color = "#2c3e50"),
        yaxis = list(title = "Production Index", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Metal Prices Chart
  output$metal_prices_chart <- renderPlotly({
    metal_data <- data.frame(
      Metal = c("Copper", "Gold", "Silver", "Platinum", "Lithium", "Cobalt"),
      Price_Change_YoY = c(15.2, 8.7, -3.4, 12.1, 45.8, 28.3),
      AI_Adoption = c(78, 65, 62, 71, 85, 82)
    )
    
    p <- plot_ly(metal_data, x = ~AI_Adoption, y = ~Price_Change_YoY,
                 text = ~Metal, mode = 'markers+text',
                 marker = list(size = 16, color = '#28a745', opacity = 0.7),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "Metal Price Performance vs AI Adoption", 
                     font = list(color = "#155724")),
        xaxis = list(title = "AI Adoption Score", color = "#2c3e50"),
        yaxis = list(title = "Price Change YoY (%)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Sustainability Chart
  output$sustainability_chart <- renderPlotly({
    sustainability_data <- data.frame(
      Metric = c("Energy Efficiency", "Water Usage", "CO2 Reduction", "Waste Reduction", "Safety Score"),
      Improvement = c(35, 28, 42, 31, 48)
    )
    
    p <- plot_ly(sustainability_data, x = ~Metric, y = ~Improvement, type = 'bar',
                 marker = list(color = '#28a745', opacity = 0.8)) %>%
      layout(
        title = list(text = "AI-Driven Sustainability Improvements in Mining", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Sustainability Metric", color = "#2c3e50"),
        yaxis = list(title = "Improvement (%)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Market Microstructure Chart
  output$market_microstructure_chart <- renderPlotly({
    set.seed(222)
    microstructure_data <- data.frame(
      Time = seq(0, 23.5, by = 0.5),
      Spread_BPS = abs(1.8 + 0.8*sin(seq(0, 4*pi, length.out = 48)) + rnorm(48, 0, 0.2)),
      Volume_Millions = abs(150 + 50*cos(seq(0, 3*pi, length.out = 48)) + rnorm(48, 0, 20)),
      AI_Activity = abs(75 + 15*sin(seq(0, 2*pi, length.out = 48)) + rnorm(48, 0, 5))
    )
    
    p <- plot_ly(microstructure_data, x = ~Time) %>%
      add_trace(y = ~Spread_BPS, name = "Bid-Ask Spread (bps)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#dc3545', width = 2)) %>%
      add_trace(y = ~Volume_Millions/50, name = "Volume (M ÷50)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#28a745', width = 2)) %>%
      add_trace(y = ~AI_Activity/25, name = "AI Activity (÷25)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#007bff', width = 2)) %>%
      layout(
        title = list(text = "Intraday Market Microstructure Dynamics", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Hour of Day", color = "#2c3e50"),
        yaxis = list(title = "Normalized Values", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # HFT Impact Chart
  output$hft_impact_chart <- renderPlotly({
    hft_data <- data.frame(
      Year = 2020:2025,
      HFT_Volume_Percent = c(45, 52, 58, 65, 71, 75),
      Market_Efficiency = c(72, 75, 78, 82, 85, 87),
      Volatility = c(18.5, 16.2, 15.8, 14.1, 13.5, 12.9)
    )
    
    p <- plot_ly(hft_data, x = ~Year) %>%
      add_trace(y = ~HFT_Volume_Percent, name = "HFT Volume (%)", 
                type = 'scatter', mode = 'lines+markers',
                line = list(color = '#28a745', width = 3),
                marker = list(color = '#28a745', size = 8)) %>%
      add_trace(y = ~Market_Efficiency, name = "Market Efficiency", 
                type = 'scatter', mode = 'lines+markers',
                line = list(color = '#007bff', width = 2),
                marker = list(color = '#007bff', size = 6)) %>%
      layout(
        title = list(text = "High-Frequency Trading Impact on Markets", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Year", color = "#2c3e50"),
        yaxis = list(title = "Percentage/Score", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Order Flow Chart
  output$order_flow_chart <- renderPlotly({
    order_data <- data.frame(
      Exchange = c("NYSE", "NASDAQ", "BATS", "IEX", "CBOE", "Others"),
      Market_Share = c(28.5, 22.8, 18.3, 3.2, 8.7, 18.5),
      AI_Penetration = c(82, 88, 75, 65, 79, 71)
    )
    
    p <- plot_ly(order_data, labels = ~Exchange, values = ~Market_Share, type = 'pie',
                 textinfo = 'label+percent',
                 marker = list(colors = c('#28a745', '#20c997', '#17a2b8', '#6f42c1', '#e83e8c', '#fd7e14'))) %>%
      layout(
        title = list(text = "Order Flow Distribution Across Exchanges", 
                     font = list(color = "#155724")),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Private Credit Growth Chart
  output$private_credit_growth_chart <- renderPlotly({
    credit_data <- data.frame(
      Year = 2018:2025,
      AUM_Trillions = c(0.8, 0.9, 1.1, 1.4, 1.7, 2.1, 2.5, 2.8),
      AI_Adoption = c(15, 22, 28, 35, 42, 55, 68, 75),
      Default_Rate = c(3.2, 2.8, 4.1, 5.2, 3.8, 2.9, 2.4, 2.1)
    )
    
    p <- plot_ly(credit_data, x = ~Year) %>%
      add_trace(y = ~AUM_Trillions, name = "AUM (Trillions $)", 
                type = 'scatter', mode = 'lines+markers',
                line = list(color = '#28a745', width = 3),
                marker = list(color = '#28a745', size = 8)) %>%
      add_trace(y = ~AI_Adoption/25, name = "AI Adoption (÷25)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#007bff', width = 2),
                yaxis = 'y2') %>%
      layout(
        title = list(text = "Private Credit Market Growth and AI Adoption", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Year", color = "#2c3e50"),
        yaxis = list(title = "AUM (Trillions $)", color = "#2c3e50"),
        yaxis2 = list(title = "AI Adoption Score", color = "#007bff", 
                      side = "right", overlaying = "y"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Credit Risk Chart
  output$credit_risk_chart <- renderPlotly({
    risk_data <- data.frame(
      Risk_Category = c("Low Risk", "Medium-Low", "Medium", "Medium-High", "High Risk"),
      Traditional_Model = c(12, 18, 35, 25, 10),
      AI_Model = c(8, 15, 28, 32, 17)
    )
    
    p <- plot_ly(risk_data, x = ~Risk_Category, y = ~Traditional_Model, type = 'bar', 
                 name = 'Traditional Model', marker = list(color = '#6c757d')) %>%
      add_trace(y = ~AI_Model, name = 'AI Model', 
                marker = list(color = '#28a745')) %>%
      layout(
        title = list(text = "Credit Risk Assessment: Traditional vs AI Models", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Risk Category", color = "#2c3e50"),
        yaxis = list(title = "Allocation (%)", color = "#2c3e50"),
        barmode = 'group',
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Default Prediction Chart
  output$default_prediction_chart <- renderPlotly({
    prediction_data <- data.frame(
      Months_Ahead = 1:12,
      Traditional_Accuracy = c(78, 74, 69, 65, 61, 57, 54, 51, 48, 45, 42, 39),
      AI_Accuracy = c(85, 83, 81, 79, 76, 74, 72, 69, 67, 64, 62, 59)
    )
    
    p <- plot_ly(prediction_data, x = ~Months_Ahead) %>%
      add_trace(y = ~Traditional_Accuracy, name = "Traditional Model", 
                type = 'scatter', mode = 'lines+markers',
                line = list(color = '#6c757d', width = 2),
                marker = list(color = '#6c757d', size = 6)) %>%
      add_trace(y = ~AI_Accuracy, name = "AI Model", 
                type = 'scatter', mode = 'lines+markers',
                line = list(color = '#28a745', width = 3),
                marker = list(color = '#28a745', size = 8)) %>%
      layout(
        title = list(text = "Default Prediction Accuracy Over Time", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Prediction Horizon (Months)", color = "#2c3e50"),
        yaxis = list(title = "Accuracy (%)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Banking AI Adoption Chart
  output$banking_ai_adoption_chart <- renderPlotly({
    banking_data <- data.frame(
      Bank_Size = c("Top 10", "Regional", "Community", "Digital-First"),
      AI_Investment_Million = c(450, 120, 35, 85),
      ROI_Percent = c(23, 18, 12, 31),
      Implementation_Score = c(85, 65, 45, 92)
    )
    
    p <- plot_ly(banking_data, x = ~AI_Investment_Million, y = ~ROI_Percent,
                 text = ~Bank_Size, mode = 'markers+text',
                 marker = list(size = ~Implementation_Score/3, color = '#28a745', opacity = 0.7),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "Banking AI Investment vs ROI", 
                     font = list(color = "#155724")),
        xaxis = list(title = "AI Investment (Millions $)", color = "#2c3e50"),
        yaxis = list(title = "ROI (%)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Citigroup AI Chart
  output$citigroup_ai_chart <- renderPlotly({
    citi_data <- data.frame(
      Application = c("Regulatory Analysis", "Trading Algorithms", "Risk Management", 
                      "Customer Service", "Fraud Detection", "Compliance"),
      Implementation = c(85, 78, 82, 71, 89, 76),
      Impact_Score = c(9.2, 8.8, 8.5, 7.3, 9.1, 8.2)
    )
    
    p <- plot_ly(citi_data, x = ~Implementation, y = ~Impact_Score,
                 text = ~Application, mode = 'markers+text',
                 marker = list(size = 15, color = '#28a745', opacity = 0.8),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "Citigroup AI Implementation vs Impact", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Implementation Progress (%)", color = "#2c3e50"),
        yaxis = list(title = "Business Impact Score", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Banking Productivity Chart
  output$banking_productivity_chart <- renderPlotly({
    productivity_data <- data.frame(
      Function = c("Back Office", "Trading", "Risk", "Compliance", "Customer Service", "Analytics"),
      Productivity_Gain = c(35, 42, 28, 38, 45, 52)
    )
    
    p <- plot_ly(productivity_data, x = ~Function, y = ~Productivity_Gain, type = 'bar',
                 marker = list(color = '#28a745', opacity = 0.8)) %>%
      layout(
        title = list(text = "AI-Driven Productivity Gains by Banking Function", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Banking Function", color = "#2c3e50"),
        yaxis = list(title = "Productivity Gain (%)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Refresh data when button is clicked
  observeEvent(input$refresh_data, {
    showNotification("Market analysis refreshed with current settings", 
                     type = "success", duration = 3)
  })
}

# Run the application
shinyApp(ui = ui, server = server)