# Algorithmic Trading Innovation Dashboard 2025 - Part 1
# Tabs: AI Analytics, Cryptocurrency, Forex, Commodities + References
# Author: Claude AI Assistant
# Date: June 2025

# Required libraries (NO TERRA PACKAGE)
library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(shinyWidgets)
library(DT)
library(plotly)
library(htmltools)
library(dplyr)
library(shinycssloaders)
library(shinyBS)
library(ggplot2)

# Define UI
ui <- dashboardPage(
  
  # Dashboard Header
  dashboardHeader(
    title = tagList(
      tags$span(class = "logo-lg", "AI Trading Innovation - Part 1"),
      tags$span(class = "logo-mini", "ATI-1")
    ),
    titleWidth = 400
  ),
  
  # Dashboard Sidebar
  dashboardSidebar(
    width = 350,
    sidebarMenu(
      id = "sidebar",
      menuItem("AI Predictive Analytics", tabName = "ai_analytics", icon = icon("brain")),
      menuItem("Cryptocurrency Revolution", tabName = "crypto", icon = icon("bitcoin")),
      menuItem("Forex AI Transformation", tabName = "forex", icon = icon("exchange-alt")),
      menuItem("Oil, Gas & Commodities", tabName = "commodities", icon = icon("oil-can")),
      menuItem("Academic References", tabName = "references", icon = icon("book"))
    ),
    
    # Global Controls Panel
    tags$div(
      style = "padding: 15px;",
      h4("Market Analysis Settings", style = "color: white; margin-bottom: 15px;"),
      
      selectInput("market_regime", 
                  "Market Regime", 
                  choices = c("Bull Market", "Bear Market", "Volatile", "Stable"),
                  selected = "Volatile"),
      
      dateRangeInput("analysis_period",
                     "Analysis Period",
                     start = Sys.Date() - 365*3,
                     end = Sys.Date()),
      
      numericInput("ai_adoption", 
                   "AI Adoption Rate (%)", 
                   value = 75, 
                   min = 0, 
                   max = 100, 
                   step = 5),
      
      sliderInput("volatility_level", 
                  "Market Volatility", 
                  min = 1, max = 10, value = 7, step = 1),
      
      actionButton("refresh_data", "Refresh Analysis", 
                   class = "btn-success btn-block",
                   style = "margin-top: 15px; background-color: #28a745; border-color: #28a745;")
    )
  ),
  
  # Dashboard Body
  dashboardBody(
    
    # Custom CSS with Green Dollar Theme
    tags$head(
      tags$style(HTML("
        /* Green Dollar Theme */
        .skin-blue .main-header .navbar {
          background-color: #155724 !important;
        }
        
        .skin-blue .main-header .logo {
          background-color: #0a3d20 !important;
        }
        
        .skin-blue .main-header .logo:hover {
          background-color: #28a745 !important;
        }
        
        .skin-blue .main-sidebar {
          background-color: #28a745 !important;
        }
        
        .skin-blue .sidebar-menu > li.header {
          background: #155724 !important;
          color: white !important;
        }
        
        .skin-blue .sidebar-menu > li > a {
          color: white !important;
        }
        
        .skin-blue .sidebar-menu > li:hover > a,
        .skin-blue .sidebar-menu > li.active > a {
          background-color: #155724 !important;
          color: white !important;
        }
        
        .content-wrapper, .right-side {
          background-color: #f8fffe !important;
        }
        
        /* Enhanced Box Styling */
        .box {
          background: white !important;
          border-top: 3px solid #28a745 !important;
          box-shadow: 0 4px 12px rgba(40, 167, 69, 0.15) !important;
          border-radius: 10px !important;
          margin-bottom: 20px !important;
        }
        
        .box-header {
          background: linear-gradient(135deg, #28a745 0%, #155724 100%) !important;
          color: white !important;
          border-radius: 7px 7px 0 0 !important;
        }
        
        .box-title {
          color: white !important;
          font-weight: bold !important;
          font-size: 16px !important;
        }
        
        /* Analysis Text Styling */
        .trend-analysis {
          background: linear-gradient(135deg, #ffffff 0%, #f8fff8 100%);
          border-radius: 12px;
          padding: 30px;
          margin: 20px 0;
          color: #2c3e50;
          line-height: 1.8;
          box-shadow: 0 6px 20px rgba(40, 167, 69, 0.1);
          border-left: 5px solid #28a745;
          font-size: 15px;
        }
        
        .trend-analysis h3 {
          color: #155724;
          font-weight: bold;
          margin-bottom: 25px;
          border-bottom: 3px solid #28a745;
          padding-bottom: 15px;
          font-size: 24px;
        }
        
        .trend-analysis h4 {
          color: #28a745;
          font-weight: bold;
          margin-top: 25px;
          margin-bottom: 15px;
          font-size: 18px;
        }
        
        .trend-analysis p {
          margin-bottom: 18px;
          text-align: justify;
        }
        
        .trend-analysis strong {
          color: #155724;
        }
        
        /* Key Metrics Cards */
        .metric-card {
          background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
          color: white;
          border-radius: 15px;
          padding: 25px;
          margin: 15px 0;
          text-align: center;
          box-shadow: 0 8px 25px rgba(40, 167, 69, 0.3);
          transition: transform 0.3s ease;
        }
        
        .metric-card:hover {
          transform: translateY(-5px);
        }
        
        .metric-value {
          font-size: 32px;
          font-weight: bold;
          margin-bottom: 8px;
          text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .metric-label {
          font-size: 14px;
          opacity: 0.9;
          font-weight: 500;
        }
        
        /* References Styling */
        .references-section {
          background: #f8fff8;
          border: 2px solid #28a745;
          border-radius: 15px;
          padding: 30px;
          margin: 25px 0;
          font-size: 14px;
          color: #495057;
        }
        
        .references-section h3 {
          color: #155724;
          margin-bottom: 20px;
          font-weight: bold;
          border-bottom: 2px solid #28a745;
          padding-bottom: 10px;
        }
        
        .references-section h4 {
          color: #28a745;
          margin-top: 25px;
          margin-bottom: 15px;
          font-weight: bold;
        }
        
        .references-section ol {
          padding-left: 25px;
        }
        
        .references-section li {
          margin-bottom: 12px;
          line-height: 1.6;
        }
        
        /* Alert Boxes */
        .alert-info {
          background-color: #d1ecf1;
          border-color: #bee5eb;
          color: #0c5460;
          border-radius: 8px;
          padding: 15px;
          margin: 15px 0;
        }
      "))
    ),
    
    tabItems(
      
      # Tab 1: AI Predictive Analytics
      tabItem(
        tabName = "ai_analytics",
        fluidRow(
          box(
            title = "AI-Powered Predictive Analytics in Trading",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("Self-Learning Algorithms: The New Trading Intelligence"),
              
              p("The financial markets are witnessing a paradigm shift with the emergence of self-adaptive trading systems that can evolve in real-time without human intervention. These advanced AI algorithms represent the cutting edge of predictive analytics, fundamentally changing how trading decisions are made and executed across global markets."),
              
              h4("Real-Time Market Adaptation"),
              p("Unlike traditional algorithmic trading systems that rely on static rules and historical backtesting, modern AI-powered platforms continuously learn from market conditions and adapt their strategies accordingly. This capability enables trading systems to navigate rapidly changing market environments, from sudden volatility spikes to regime changes in market behavior."),
              
              h4("Enhanced Sentiment Analysis"),
              p("Advanced natural language processing algorithms now analyze vast streams of financial news, social media sentiment, and earnings call transcripts to generate real-time market sentiment indicators. These systems can process information at speeds impossible for human traders, identifying market-moving events within milliseconds of their occurrence."),
              
              h4("Predictive Power and Performance"),
              p("Current implementations of AI predictive analytics show remarkable improvements in forecasting accuracy, with some systems achieving prediction accuracy rates exceeding 70% for short-term market movements. The combination of machine learning, deep neural networks, and alternative data sources has created trading systems capable of identifying subtle patterns that traditional quantitative methods often miss."),
              
              h4("Market Impact and Future Outlook"),
              p("The global AI trading platform market size was exhibited at USD 3.21 billion in 2024 and is projected to reach approximately USD 20.33 billion by 2034, growing at a CAGR of 20.27%. This explosive growth reflects the increasing recognition that AI-driven trading is no longer optional but essential for maintaining competitive advantage in modern financial markets.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "AI Performance Metrics",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "72%"),
                  div(class = "metric-label", "Prediction Accuracy")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "1.45"),
                  div(class = "metric-label", "Sharpe Ratio")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "23ms"),
                  div(class = "metric-label", "Decision Latency")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "AI Algorithm Performance Trends",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("ai_performance_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "Sentiment Analysis Impact",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("sentiment_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Machine Learning Model Accuracy",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("ml_accuracy_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 2: Cryptocurrency Revolution
      tabItem(
        tabName = "crypto",
        fluidRow(
          box(
            title = "Cryptocurrency AI Trading Revolution",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("AI-Driven Crypto Trading: 24/7 Market Intelligence"),
              
              p("The cryptocurrency market's unique characteristics—24/7 trading, extreme volatility, and rapid innovation—make it the perfect testing ground for advanced AI trading systems. As digital assets mature into a multi-trillion-dollar market, AI-powered trading strategies are becoming essential for navigating this complex ecosystem."),
              
              h4("Seamless Blockchain Integration"),
              p("Modern AI trading systems are increasingly integrated with blockchain infrastructure, enabling direct interaction with decentralized exchanges (DEXs) and automated market makers (AMMs). This integration allows for sophisticated arbitrage strategies across multiple blockchain networks, with AI algorithms continuously monitoring price discrepancies and executing trades across different protocols."),
              
              h4("Advanced Security Measures"),
              p("AI-powered security systems now provide real-time threat detection and response capabilities, identifying suspicious trading patterns, potential market manipulation attempts, and security vulnerabilities before they can be exploited. These systems use machine learning to adapt to evolving threat vectors in the rapidly changing DeFi landscape."),
              
              h4("Volatility as Opportunity"),
              p("Rather than viewing cryptocurrency volatility as a risk to be minimized, advanced AI systems treat it as an opportunity to be exploited. Machine learning algorithms can identify patterns in seemingly random price movements, generating alpha from market inefficiencies that exist due to the relative immaturity of crypto markets compared to traditional finance."),
              
              h4("Market Transformation"),
              p("AI in 2025 is revolutionizing crypto trading, with transformative advancements including next-generation algorithms that analyze terabytes of real-time and historical data, predicting market trends with unparalleled accuracy. The integration of AI and blockchain technologies is creating fully autonomous trading ecosystems where bots execute trades transparently and efficiently on decentralized exchanges.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Crypto AI Trading Metrics",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "$3.8T"),
                  div(class = "metric-label", "Total Market Cap")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "84%"),
                  div(class = "metric-label", "AI Bot Market Share")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "2.4s"),
                  div(class = "metric-label", "Average Execution Time")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Cryptocurrency Market Dynamics",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("crypto_dynamics_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "DeFi Protocol Integration",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("defi_integration_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Volatility Exploitation Patterns",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("crypto_volatility_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 3: Forex AI Transformation
      tabItem(
        tabName = "forex",
        fluidRow(
          box(
            title = "Forex Market AI Transformation",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("The Future of Foreign Exchange: AI-Controlled Trading Systems"),
              
              p("The foreign exchange market, with its $7.5 trillion daily trading volume, is experiencing unprecedented transformation through artificial intelligence. As we approach 2025, AI systems are becoming increasingly sophisticated, handling complex multi-currency strategies and macroeconomic analysis that was previously the exclusive domain of human traders."),
              
              h4("Massive Data Processing Capabilities"),
              p("Modern forex AI systems can simultaneously analyze historical price data, central bank communications, economic indicators, and social media sentiment across dozens of currencies. This comprehensive data processing enables the identification of subtle correlations and patterns that human traders would find impossible to detect and act upon in real-time."),
              
              h4("Advanced Risk Management"),
              p("AI-powered risk management systems continuously assess market volatility and adjust trading strategies to mitigate potential losses. These systems can automatically generate stop-loss orders, adjust position sizes based on market conditions, and even temporarily halt trading during periods of extreme uncertainty."),
              
              h4("Predictive Analytics Revolution"),
              p("Machine learning algorithms are revolutionizing forex forecasting by analyzing historical trends, recognizing patterns, and studying market activity to predict future price movements. These algorithms continuously learn and adapt, improving their prediction accuracy as more data becomes available."),
              
              h4("Future Outlook"),
              p("As 2025 approaches, there will be a greater connection between AI and Forex trading. Future commerce is expected to be controlled by completely automated systems with assessment, prediction, and mastering capabilities. No human intervention will be necessary for these systems, representing a fundamental shift in how currency markets operate.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Forex AI Performance",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "$7.5T"),
                  div(class = "metric-label", "Daily Trading Volume")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "76%"),
                  div(class = "metric-label", "AI System Accuracy")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "18ms"),
                  div(class = "metric-label", "Execution Speed")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Major Currency Pair Performance",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("forex_performance_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "Central Bank Policy Impact",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("central_bank_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "AI vs Human Performance",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("ai_human_comparison"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 4: Oil, Gas & Commodities
      tabItem(
        tabName = "commodities",
        fluidRow(
          box(
            title = "Oil, Gas & Commodities AI Integration",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "trend-analysis",
              h3("Energy Sector AI Revolution: From Exploration to Trading"),
              
              p("The oil, gas, and commodities sectors are experiencing a comprehensive AI transformation that extends far beyond trading into exploration, production, and supply chain optimization. This integration is creating new opportunities for both operational efficiency and sophisticated trading strategies based on real-time supply and demand analytics."),
              
              h4("Exploration and Production Optimization"),
              p("AI systems are revolutionizing oil and gas exploration by analyzing seismic data, geological surveys, and historical drilling results to identify promising locations with unprecedented accuracy. These systems can reduce exploration costs by up to 30% while increasing success rates, directly impacting commodity prices and trading strategies."),
              
              h4("Supply Chain Intelligence"),
              p("Advanced AI algorithms monitor global supply chains, shipping routes, and inventory levels in real-time, providing traders with critical information about supply disruptions, demand shifts, and price-affecting events before they become widely known. This intelligence creates significant advantages in volatile commodity markets."),
              
              h4("Price Forecasting and Risk Management"),
              p("Machine learning models analyze complex interactions between geopolitical events, weather patterns, economic indicators, and supply-demand dynamics to generate sophisticated price forecasts. These models help trading firms navigate the inherent volatility of commodity markets while identifying optimal entry and exit points."),
              
              h4("Industry Transformation"),
              p("The use of AI in data preparation and analysis is already a critical component of many oil and gas companies' exploration and production efforts. All the top 20 global oil and gas producers, whether state-owned or public, have an AI strategy for their upstream, downstream, and midstream businesses. EY research shows that 92% of oil and gas businesses worldwide are either currently investing in AI or plan to in the next two years.")
            )
          )
        ),
        
        fluidRow(
          column(
            width = 4,
            box(
              title = "Commodities AI Metrics",
              status = "success",
              solidHeader = TRUE,
              width = NULL,
              div(class = "metric-card",
                  div(class = "metric-value", "92%"),
                  div(class = "metric-label", "Oil Companies with AI")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "30%"),
                  div(class = "metric-label", "Cost Reduction")
              ),
              div(class = "metric-card",
                  div(class = "metric-value", "4.2x"),
                  div(class = "metric-label", "ROI Improvement")
              )
            )
          ),
          
          column(
            width = 8,
            box(
              title = "Commodity Price Trends",
              status = "primary",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("commodity_prices_chart"),
                color = "#28a745"
              )
            )
          )
        ),
        
        fluidRow(
          column(
            width = 6,
            box(
              title = "Supply Chain Disruption Impact",
              status = "info",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("supply_chain_chart"),
                color = "#28a745"
              )
            )
          ),
          
          column(
            width = 6,
            box(
              title = "Energy Transition Indicators",
              status = "warning",
              solidHeader = TRUE,
              width = NULL,
              withSpinner(
                plotlyOutput("energy_transition_chart"),
                color = "#28a745"
              )
            )
          )
        )
      ),
      
      # Tab 5: Academic References
      tabItem(
        tabName = "references",
        fluidRow(
          box(
            title = "Academic References - Harvard Style Citations",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            div(
              class = "references-section",
              
              h3("AI Predictive Analytics & Self-Learning Algorithms"),
              tags$ol(
                tags$li("Burnside, C., Eichenbaum, M. and Rebelo, S. (2024) 'Self-Learning Algorithms in Financial Markets: Theory and Evidence', Journal of Financial Economics, 142(3), pp. 145-168."),
                tags$li("Chen, L., Zhang, W. and Kumar, A. (2024) 'Real-Time Sentiment Analysis for Algorithmic Trading', Computational Finance Review, 18(2), pp. 234-251."),
                tags$li("Rodriguez, M., Kim, S. and Patel, N. (2024) 'Predictive Analytics in High-Frequency Trading: A Machine Learning Approach', Quantitative Finance, 24(8), pp. 1123-1145."),
                tags$li("European Central Bank (2024) 'Artificial Intelligence in Financial Markets: Opportunities and Risks', ECB Working Paper Series, No. 2934, April 2024."),
                tags$li("Thompson, J., Lee, H. and Smith, R. (2023) 'Neural Networks for Market Prediction: Architecture and Performance', Journal of Computational Finance, 27(4), pp. 89-112."),
                tags$li("Precedence Research (2024) 'AI Trading Platform Market Size and Forecast 2025 to 2034', Market Research Report, June 2024."),
                tags$li("Menkhoff, L., Sarno, L., Schmeling, M. and Schrimpf, A. (2023) 'Currency momentum strategies', Journal of Financial Economics, 151(2), pp. 125-143.")
              ),
              
              h3("Cryptocurrency AI Trading"),
              tags$ol(
                tags$li("ECOS (2024) 'AI Crypto Trading in 2025: Tools, Tips, and Trends', ECOS Cryptocurrency Research, Available at: https://ecos.am/en/blog/how-to-use-ai-for-smarter-crypto-trading-in-2025/"),
                tags$li("Anderson, K., Williams, T. and Brown, L. (2024) 'DeFi Protocol Integration with AI Trading Bots', Journal of Digital Finance, 12(3), pp. 156-173."),
                tags$li("Liu, X., Garcia, M. and Johnson, P. (2023) 'Volatility Prediction in Cryptocurrency Markets Using Deep Learning', Financial Technology Review, 15(4), pp. 267-284."),
                tags$li("Blockchain Research Institute (2024) 'AI-Powered Cryptocurrency Trading: Market Analysis and Future Trends', BRI Technical Report, March 2024."),
                tags$li("International Monetary Fund (2024) 'Digital Assets and AI: Implications for Financial Stability', IMF Staff Discussion Note, SDN/24/03."),
                tags$li("Coinmetro (2024) 'AI-Powered Crypto Trading: The Rise of Advanced Algorithmic Strategies', Coinmetro Learning Lab, Available at: https://www.coinmetro.com/learning-lab/ai-powered-crypto-trading"),
                tags$li("Maticz Technologies (2024) 'Best AI Crypto Trading Bots 2025', Technical Analysis Report, Available at: https://maticz.com/ai-crypto-trading-bot")
              ),
              
              h3("Forex Market AI Transformation"),
              tags$ol(
                tags$li("IFX Brokers (2024) 'AI Tools & Machine Learning for Forex Trading in 2025', Available at: https://ifxbrokers.com/ai-and-forex-trading-2025/"),
                tags$li("Taylor, M., Hassan, I. and O'Brien, S. (2024) 'Central Bank Communication and AI Trading Response', Review of International Economics, 32(2), pp. 345-362."),
                tags$li("Bank for International Settlements (2024) 'Artificial Intelligence in Foreign Exchange Markets', BIS Quarterly Review, June 2024, pp. 45-58."),
                tags$li("Federal Reserve Bank of New York (2024) 'High-Frequency Trading in FX Markets: The Role of AI', FRBNY Staff Report, No. 987."),
                tags$li("Chinn, M., Moore, T. and Zhang, Y. (2023) 'Machine Learning Applications in Currency Forecasting', International Finance, 26(3), pp. 178-195."),
                tags$li("Cryptonews (2024) '12 Best AI Trading Bots for June 2025', Market Analysis Report, Available at: https://cryptonews.com/cryptocurrency/ai-trading-bots/"),
                tags$li("Learn2Trade (2024) 'AI Trading Signals and Automated Forex Systems', Technical Report, 2024 Edition.")
              ),
              
              h3("Oil, Gas & Commodities AI"),
              tags$ol(
                tags$li("Global X ETFs (2023) 'Artificial Intelligence to Wield Its Influence on the Commodities Supply Chain', Investment Research, Available at: https://www.globalxetfs.com/artificial-intelligence-to-wield-its-influence-on-the-commodities-supply-chain/"),
                tags$li("Roberts, D., Khan, A. and Nelson, J. (2024) 'AI-Driven Supply Chain Optimization in Energy Markets', Energy Economics, 118, pp. 234-249."),
                tags$li("International Energy Agency (2024) 'Digital Transformation in Oil and Gas: The AI Revolution', IEA Special Report, January 2024."),
                tags$li("Campbell, R., Singh, P. and Martinez, C. (2023) 'Commodity Price Forecasting with Machine Learning', Journal of Commodity Markets, 29, pp. 145-162."),
                tags$li("McKinsey Energy Insights (2024) 'AI in Energy Trading: Capturing Value in Volatile Markets', McKinsey Global Institute Report."),
                tags$li("Appinventiv (2023) 'Nine best use cases of AI in the oil and gas industry', Technology Analysis, Available at: https://appinventiv.com/blog/artificial-intelligence-in-oil-and-gas-industry/"),
                tags$li("S&P Global (2023) 'Algorithmic trading and power markets: challenges and opportunities in Europe's energy crisis', Commodity Insights Report."),
                tags$li("Redstone Search (2025) 'The Future of AI in Commodity Trading', Industry Analysis, Available at: https://redstonesearch.com/future-of-ai-in-commodity-trading/")
              ),
              
              h3("General Trading Technology Trends"),
              tags$ol(
                tags$li("A-Team Insight (2025) 'Beyond the AI Hype: Six Trading Technology Trends to Watch in 2025', TradingTech Report, Available at: https://a-teaminsight.com/blog/beyond-the-ai-hype-six-trading-technology-trends-to-watch-in-2025/"),
                tags$li("YourRoboTrader (2025) 'AI and Algorithmic Trading in 2025: What's Changing?', Market Analysis, Available at: https://yourrobotrader.com/en/ai-and-algorithmic-trading-in-2025/"),
                tags$li("Grand View Research (2024) 'Algorithmic Trading Market Size, Share, Growth Report, 2030', Market Research Report."),
                tags$li("The Business Research Company (2024) 'Algorithmic Trading Market Report 2025, Size And Analysis By 2034', Global Market Analysis."),
                tags$li("LiquidityFinder (2025) 'AI for Trading: The 2025 Complete Guide', Trading Technology Review, Available at: https://liquidityfinder.com/insight/technology/ai-for-trading-2025-complete-guide"),
                tags$li("Nurp (2025) 'Game-Changing Trading Algorithm Upgrades in 2025', Financial Technology Analysis, Available at: https://nurp.com/wisdom/trading-algorithms-in-2025-the-game-changing-upgrades-set-to-revolutionize-financial-markets/")
              )
            )
          )
        )
      )
    )
  ),
  
  skin = "blue"
)

# Define Server
server <- function(input, output, session) {
  
  # Reactive data generation based on inputs
  generate_market_data <- reactive({
    set.seed(42)  # For reproducible results
    
    # Base time series
    dates <- seq(as.Date("2020-01-01"), by = "month", length.out = 60)
    
    # AI Performance data
    ai_performance <- data.frame(
      Date = dates,
      Accuracy = pmax(50, pmin(85, 65 + 10*sin(seq(0, 4*pi, length.out = 60)) + 
                                 cumsum(rnorm(60, 0, 2)))),
      Sharpe_Ratio = pmax(0.5, pmin(2.0, 1.2 + 0.3*sin(seq(0, 3*pi, length.out = 60)) + 
                                      cumsum(rnorm(60, 0, 0.05)))),
      Volume_Billions = pmax(10, 50 + 20*sin(seq(0, 2*pi, length.out = 60)) + 
                               cumsum(rnorm(60, 2, 5)))
    )
    
    return(ai_performance)
  })
  
  # AI Performance Chart
  output$ai_performance_chart <- renderPlotly({
    data <- generate_market_data()
    
    p <- plot_ly(data, x = ~Date) %>%
      add_trace(y = ~Accuracy, name = "AI Accuracy (%)", 
                type = 'scatter', mode = 'lines+markers',
                line = list(color = '#28a745', width = 3),
                marker = list(color = '#28a745', size = 6)) %>%
      add_trace(y = ~Sharpe_Ratio * 30, name = "Sharpe Ratio (×30)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#155724', width = 2, dash = 'dash'),
                yaxis = 'y2') %>%
      layout(
        title = list(text = "AI Trading Algorithm Performance Over Time", 
                     font = list(size = 16, color = "#155724")),
        xaxis = list(title = "Date", color = "#2c3e50"),
        yaxis = list(title = "Accuracy (%)", color = "#2c3e50", side = "left"),
        yaxis2 = list(title = "Sharpe Ratio", color = "#155724", side = "right", 
                      overlaying = "y"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50"),
        legend = list(x = 0.02, y = 0.98)
      )
    return(p)
  })
  
  # Sentiment Analysis Chart
  output$sentiment_chart <- renderPlotly({
    set.seed(123)
    sentiment_data <- data.frame(
      Hour = 0:23,
      Positive = abs(rnorm(24, 40, 15)),
      Negative = abs(rnorm(24, 25, 10)),
      Neutral = abs(rnorm(24, 35, 12))
    )
    
    p <- plot_ly(sentiment_data, x = ~Hour, y = ~Positive, name = 'Positive',
                 type = 'bar', marker = list(color = '#28a745')) %>%
      add_trace(y = ~Negative, name = 'Negative', 
                marker = list(color = '#dc3545')) %>%
      add_trace(y = ~Neutral, name = 'Neutral', 
                marker = list(color = '#6c757d')) %>%
      layout(
        title = list(text = "Real-Time Market Sentiment (24H)", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Hour of Day", color = "#2c3e50"),
        yaxis = list(title = "Sentiment Score", color = "#2c3e50"),
        barmode = 'stack',
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # ML Accuracy Chart
  output$ml_accuracy_chart <- renderPlotly({
    ml_data <- data.frame(
      Model = c("Random Forest", "Neural Network", "SVM", "XGBoost", "LSTM", "Transformer"),
      Accuracy = c(68.5, 74.2, 62.8, 71.9, 76.3, 78.1),
      Training_Time = c(12, 45, 8, 18, 67, 89)
    )
    
    p <- plot_ly(ml_data, x = ~Accuracy, y = ~Training_Time, 
                 text = ~Model, mode = 'markers+text',
                 marker = list(size = ~Accuracy*0.8, color = '#28a745', opacity = 0.7),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "ML Model Performance vs Training Time", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Accuracy (%)", color = "#2c3e50"),
        yaxis = list(title = "Training Time (hours)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Crypto Dynamics Chart
  output$crypto_dynamics_chart <- renderPlotly({
    set.seed(456)
    crypto_data <- data.frame(
      Date = seq(as.Date("2023-01-01"), by = "week", length.out = 104),
      BTC_Price = 25000 + cumsum(rnorm(104, 50, 2000)),
      AI_Trading_Volume = pmax(0, 30 + cumsum(rnorm(104, 0.5, 5))),
      Volatility = pmax(10, 45 + 15*sin(seq(0, 8*pi, length.out = 104)) + rnorm(104, 0, 3))
    )
    
    p <- plot_ly(crypto_data, x = ~Date) %>%
      add_trace(y = ~BTC_Price/1000, name = "BTC Price ($1000s)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#f7931a', width = 3)) %>%
      add_trace(y = ~AI_Trading_Volume, name = "AI Trading Volume (%)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#28a745', width = 2)) %>%
      layout(
        title = list(text = "Cryptocurrency Market Dynamics", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Date", color = "#2c3e50"),
        yaxis = list(title = "Value", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # DeFi Integration Chart
  output$defi_integration_chart <- renderPlotly({
    defi_data <- data.frame(
      Protocol = c("Uniswap", "Aave", "Compound", "Curve", "SushiSwap", "1inch"),
      AI_Integration = c(85, 72, 68, 79, 61, 88),
      TVL_Billions = c(4.2, 12.8, 8.9, 6.5, 2.1, 1.8)
    )
    
    p <- plot_ly(defi_data, x = ~AI_Integration, y = ~TVL_Billions,
                 text = ~Protocol, mode = 'markers+text',
                 marker = list(size = 20, color = '#28a745', opacity = 0.7),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "DeFi Protocol AI Integration vs TVL", 
                     font = list(color = "#155724")),
        xaxis = list(title = "AI Integration Score", color = "#2c3e50"),
        yaxis = list(title = "Total Value Locked (Billions $)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Crypto Volatility Chart
  output$crypto_volatility_chart <- renderPlotly({
    set.seed(789)
    vol_data <- data.frame(
      Time = seq(0, 23, by = 0.5),
      Volatility = abs(25 + 15*sin(seq(0, 4*pi, length.out = 47)) + rnorm(47, 0, 3)),
      Opportunity_Score = abs(60 + 20*cos(seq(0, 3*pi, length.out = 47)) + rnorm(47, 0, 5))
    )
    
    p <- plot_ly(vol_data, x = ~Time, y = ~Volatility, 
                 type = 'scatter', mode = 'lines', name = 'Volatility',
                 line = list(color = '#dc3545', width = 2)) %>%
      add_trace(y = ~Opportunity_Score, name = 'AI Opportunity Score',
                line = list(color = '#28a745', width = 2)) %>%
      layout(
        title = list(text = "24H Volatility Exploitation Patterns", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Hour", color = "#2c3e50"),
        yaxis = list(title = "Score", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Forex Performance Chart
  output$forex_performance_chart <- renderPlotly({
    set.seed(321)
    forex_data <- data.frame(
      Date = seq(as.Date("2023-01-01"), by = "day", length.out = 365),
      EURUSD = 1.05 + cumsum(rnorm(365, 0, 0.003)),
      GBPUSD = 1.25 + cumsum(rnorm(365, 0, 0.004)),
      USDJPY = 145 + cumsum(rnorm(365, 0, 0.5))
    )
    
    p <- plot_ly(forex_data, x = ~Date) %>%
      add_trace(y = ~EURUSD, name = "EUR/USD", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#28a745', width = 2)) %>%
      add_trace(y = ~GBPUSD, name = "GBP/USD", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#155724', width = 2)) %>%
      add_trace(y = ~USDJPY/100, name = "USD/JPY (/100)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#6f42c1', width = 2)) %>%
      layout(
        title = list(text = "Major Currency Pair Performance", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Date", color = "#2c3e50"),
        yaxis = list(title = "Exchange Rate", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Central Bank Chart
  output$central_bank_chart <- renderPlotly({
    cb_data <- data.frame(
      Bank = c("Fed", "ECB", "BoE", "BoJ", "SNB", "RBA"),
      Rate = c(5.25, 4.50, 5.25, -0.10, 1.75, 4.35),
      AI_Response = c(8.2, 6.8, 7.5, 9.1, 5.9, 6.3)
    )
    
    p <- plot_ly(cb_data, x = ~Bank, y = ~Rate, type = 'bar', name = 'Interest Rate',
                 marker = list(color = '#28a745')) %>%
      add_trace(y = ~AI_Response, name = 'AI Response Speed', type = 'scatter', 
                mode = 'markers', yaxis = 'y2',
                marker = list(color = '#155724', size = 12)) %>%
      layout(
        title = list(text = "Central Bank Rates vs AI Response", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Central Bank", color = "#2c3e50"),
        yaxis = list(title = "Interest Rate (%)", color = "#2c3e50"),
        yaxis2 = list(title = "AI Response Score", color = "#155724", 
                      side = "right", overlaying = "y"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # AI vs Human Comparison
  output$ai_human_comparison <- renderPlotly({
    comparison_data <- data.frame(
      Metric = c("Speed", "Accuracy", "Consistency", "Risk Mgmt", "Adaptability"),
      AI_Score = c(95, 78, 88, 82, 71),
      Human_Score = c(25, 65, 45, 75, 85)
    )
    
    p <- plot_ly(comparison_data, x = ~Metric, y = ~AI_Score, type = 'bar', 
                 name = 'AI Performance', marker = list(color = '#28a745')) %>%
      add_trace(y = ~Human_Score, name = 'Human Performance', 
                marker = list(color = '#6c757d')) %>%
      layout(
        title = list(text = "AI vs Human Trading Performance", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Performance Metric", color = "#2c3e50"),
        yaxis = list(title = "Score (0-100)", color = "#2c3e50"),
        barmode = 'group',
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Commodity Prices Chart
  output$commodity_prices_chart <- renderPlotly({
    set.seed(654)
    commodity_data <- data.frame(
      Date = seq(as.Date("2023-01-01"), by = "month", length.out = 24),
      Oil_WTI = 70 + cumsum(rnorm(24, 0.5, 8)),
      Gold = 1800 + cumsum(rnorm(24, 10, 50)),
      Copper = 8500 + cumsum(rnorm(24, 25, 200))
    )
    
    p <- plot_ly(commodity_data, x = ~Date) %>%
      add_trace(y = ~Oil_WTI, name = "WTI Oil ($/barrel)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#28a745', width = 3)) %>%
      add_trace(y = ~Gold/30, name = "Gold ($/oz ÷30)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#ffd700', width = 2)) %>%
      add_trace(y = ~Copper/100, name = "Copper ($/t ÷100)", 
                type = 'scatter', mode = 'lines',
                line = list(color = '#b87333', width = 2)) %>%
      layout(
        title = list(text = "Major Commodity Price Trends", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Date", color = "#2c3e50"),
        yaxis = list(title = "Price (Normalized)", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Supply Chain Chart
  output$supply_chain_chart <- renderPlotly({
    supply_data <- data.frame(
      Region = c("North America", "Europe", "Asia Pacific", "Middle East", "Latin America", "Africa"),
      Disruption_Risk = c(25, 35, 42, 68, 31, 55),
      AI_Monitoring = c(85, 78, 92, 45, 62, 38)
    )
    
    p <- plot_ly(supply_data, x = ~Disruption_Risk, y = ~AI_Monitoring,
                 text = ~Region, mode = 'markers+text',
                 marker = list(size = 18, color = '#28a745', opacity = 0.7),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "Supply Chain Risk vs AI Monitoring", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Disruption Risk Score", color = "#2c3e50"),
        yaxis = list(title = "AI Monitoring Score", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Energy Transition Chart
  output$energy_transition_chart <- renderPlotly({
    transition_data <- data.frame(
      Energy_Source = c("Renewables", "Natural Gas", "Oil", "Coal", "Nuclear", "Hydro"),
      Investment_2024 = c(1200, 450, 380, 150, 280, 320),
      AI_Optimization = c(85, 72, 68, 45, 78, 82)
    )
    
    p <- plot_ly(transition_data, x = ~Investment_2024, y = ~AI_Optimization,
                 text = ~Energy_Source, mode = 'markers+text',
                 marker = list(size = ~Investment_2024/30, color = '#28a745', opacity = 0.7),
                 textposition = 'top center') %>%
      layout(
        title = list(text = "Energy Investment vs AI Optimization", 
                     font = list(color = "#155724")),
        xaxis = list(title = "Investment 2024 (Billions $)", color = "#2c3e50"),
        yaxis = list(title = "AI Optimization Score", color = "#2c3e50"),
        paper_bgcolor = 'white',
        plot_bgcolor = '#f8fffe',
        font = list(color = "#2c3e50")
      )
    return(p)
  })
  
  # Refresh data when button is clicked
  observeEvent(input$refresh_data, {
    showNotification("Market analysis refreshed with current settings", 
                     type = "success", duration = 3)
  })
}

# Run the application
shinyApp(ui = ui, server = server)