# app.R - Entry Point with Automatic Cleanup

# Clear everything
rm(list = ls(all.names = TRUE))
if (exists("ModuleLoader")) rm(ModuleLoader)
if (exists("module_loader")) rm(module_loader)

# Clear old module functions
loaded_objects <- ls(envir = .GlobalEnv)
module_functions <- grep("_(ui|server)$", loaded_objects, value = TRUE)
if (length(module_functions) > 0) {
  rm(list = module_functions, envir = .GlobalEnv)
}

# Load global configuration
source("global.R", local = FALSE)

cat("\n⚙️  Initializing Module Loader...\n")
module_loader <- ModuleLoader$new()
module_loader$print()
module_loader$load_packages()
module_loader$source_modules()

cat("\n🚀 Launching application...\n\n")

# Launch app
shinyApp(
  ui = create_ui(module_loader),
  server = function(input, output, session) {
    # Cleanup on session end
    session$onSessionEnded(function() {
      cat("\n🧹 Cleaning up session...\n")
      gc(verbose = FALSE)
      cat("✓ Cleanup complete\n")
    })
    
    # Initialize server
    create_server(module_loader, session)
  }
)
