admin_settings_server <- function(id, photo_manager, session) {
  moduleServer(id, function(input, output, session) {
    pm <- photo_manager
    ns <- session$ns
    unlocked <- reactiveVal(FALSE)
    print_parent <- reactiveVal(pm$config$print_parent %||% "")
    pending_root <- reactiveVal(NULL)

    volumes <- get_volume_roots()
    shinyFiles::shinyDirChoose(input, "rootDir", roots = volumes, session = session)
    shinyFiles::shinyDirChoose(input, "printDir", roots = volumes, session = session)

    # ------------------------------------------------------------ lock UI
    locked_ui <- function() {
      fluidRow(column(
        width = 12,
        box(
          title = "Acceso del administrador", status = "primary", solidHeader = TRUE, width = NULL,
          div(class = "lock-box",
              h3("🔒 Esta sección es solo para el administrador"),
              passwordInput(ns("code"), "Escriba el código de administrador:", width = "100%"),
              actionButton(ns("unlock"), "Entrar", class = "btn-primary btn-big", style = "width: 100%;"))
        )
      ))
    }

    # ----------------------------------------------- print / watermark box
    print_box <- function(cfg) {
      fonts <- pm$wm_fonts
      wm_controls <- if (length(fonts) == 0) {
        p(class = "status-bad", "Para usar el sello de agua instale los paquetes ragg y systemfonts (vea install_packages.R).")
      } else {
        css_map <- jsonlite::toJSON(lapply(fonts, function(f) f$css), auto_unbox = TRUE)
        render_js <- I(sprintf(paste0(
          "{option: function(item, escape) { var m = %s; return '<div style=\"font-family: \\'' + m[item.value] + '\\', sans-serif; font-size: 19px; padding: 9px 12px;\">' + escape(item.label) + '</div>'; },",
          " item: function(item, escape) { var m = %s; return '<div style=\"font-family: \\'' + m[item.value] + '\\', sans-serif;\">' + escape(item.label) + '</div>'; }}"),
          css_map, css_map))
        font_choices <- setNames(names(fonts), vapply(fonts, function(f) f$label, character(1)))
        sel_font <- if (cfg$wm_font %in% names(fonts)) cfg$wm_font else names(fonts)[1]
        tagList(
          checkboxInput(ns("wmEnabled"),
                        HTML("<b>Guardar con sello de agua</b> – escribe <i>País – Ciudad/Región/Evento</i> en la esquina inferior derecha de cada foto"),
                        value = isTRUE(cfg$wm_enabled)),
          conditionalPanel(
            "input.wmEnabled", ns = ns,
            div(class = "wm-panel",
                fluidRow(
                  column(6,
                         selectizeInput(ns("wmFont"), "Tipo de letra:", choices = font_choices, selected = sel_font,
                                        width = "100%", options = list(render = render_js)),
                         sliderInput(ns("wmSize"), "Tamaño de la letra:", min = 2, max = 10, step = 0.5,
                                     value = as.numeric(cfg$wm_size %||% 5), post = " %", width = "100%"),
                         uiOutput(ns("wmSizeHint"))),
                  column(6,
                         checkboxInput(ns("wmBold"), "Letra en negritas (más fácil de leer)", isTRUE(cfg$wm_bold)),
                         radioButtons(ns("wmStyle"), "Estilo del sello:", choices = WM_STYLES,
                                      selected = cfg$wm_style %||% "dark_box"))
                ),
                tags$b("Vista previa (con una de las fotos elegidas):"),
                div(class = "wm-preview", imageOutput(ns("wmPreview"), height = "auto"))
            )
          )
        )
      }

      box(
        title = "3. Copiar fotos para imprimir", status = "primary", solidHeader = TRUE, width = NULL,
        p(HTML("Las fotos elegidas se copian a una carpeta llamada <b>Imprimir</b>, con una carpeta por país adentro
               (por ejemplo <i>Imprimir/México</i>). Las fotos originales <b>no se modifican</b>.")),
        shinyFiles::shinyDirButton(ns("printDir"), "Elegir dónde crear la carpeta Imprimir…",
                                   "Seleccione dónde crear la carpeta Imprimir", class = "btn-info btn-big",
                                   style = "width: 100%;", icon = icon("folder-open")),
        uiOutput(ns("printPath")),
        radioButtons(ns("printMode"), "Si la carpeta Imprimir ya tiene fotos:",
                     choices = c("Reemplazar todo (queda solo lo elegido ahora)" = "replace",
                                 "Solo agregar o actualizar (no borra nada)" = "update"),
                     selected = cfg$print_mode %||% "replace"),
        hr(),
        wm_controls,
        hr(),
        actionButton(ns("export"), "Copiar fotos elegidas a Imprimir", class = "btn-success btn-big",
                     style = "width: 100%;", icon = icon("print"))
      )
    }

    admin_ui <- function() {
      cfg <- pm$config
      fluidRow(
        column(
          width = 7,
          box(
            title = "1. Carpeta principal y escaneo", status = "primary", solidHeader = TRUE, width = NULL,
            p("Elija la carpeta principal. Adentro debe haber una carpeta por país, y dentro de cada país una carpeta por ciudad, región o evento."),
            uiOutput(ns("rootStatus")),
            br(),
            fluidRow(
              column(6, shinyFiles::shinyDirButton(
                ns("rootDir"), "Buscar carpeta principal…", "Seleccione la carpeta PRINCIPAL de fotos",
                class = "btn-info btn-big", style = "width: 100%;", icon = icon("folder-open"))),
              column(6, actionButton(ns("scan"), "Escanear carpetas y fotos", class = "btn-success btn-big",
                                     style = "width: 100%;", icon = icon("sync")))
            ),
            br(),
            checkboxInput(ns("makePreviews"),
                          "Preparar también todas las vistas previas ahora (escaneo más lento, pero las fotos cargan más rápido después)", FALSE),
            tags$details(
              tags$summary(style = "cursor: pointer; font-size: 16px; color: #667eea;", "…o escriba / pegue la ruta de la carpeta"),
              br(),
              textInput(ns("rootPath"), NULL, value = cfg$root_folder, width = "100%",
                        placeholder = "p. ej. C:/Users/Ana/Pictures/Viajes"),
              actionButton(ns("useTyped"), "Usar esta ruta", class = "btn-primary admin-btn")
            ),
            uiOutput(ns("scanResult"))
          ),
          print_box(cfg),
          box(
            title = "Resumen de carpetas (fotos, sugeridas, elegidas)", status = "info", solidHeader = TRUE,
            width = NULL, collapsible = TRUE,
            div(class = "table-scroll", tableOutput(ns("overview")))
          )
        ),
        column(
          width = 5,
          box(
            title = "2. Reglas para el usuario", status = "primary", solidHeader = TRUE, width = NULL,
            numericInput(ns("limit"), "Máximo de fotos por país:", value = cfg$limit_per_country,
                         min = 1, step = 1, width = "100%"),
            fluidRow(
              column(8, numericInput(ns("cost"), "Costo por foto impresa:", value = cfg$cost_per_photo,
                                     min = 0, step = 0.5, width = "100%")),
              column(4, textInput(ns("currency"), "Moneda:", value = cfg$currency, width = "100%"))
            ),
            actionButton(ns("saveRules"), "Guardar reglas", class = "btn-primary btn-big", style = "width: 100%;")
          ),
          box(
            title = "4. Lista de fotos elegidas", status = "primary", solidHeader = TRUE, width = NULL,
            uiOutput(ns("selStatus")),
            downloadButton(ns("downloadSel"), "Descargar lista de fotos elegidas (CSV)", class = "btn-success admin-btn",
                           style = "width: 100%; margin-bottom: 10px;"),
            hr(),
            selectInput(ns("clearWhich"), "Borrar fotos elegidas de:", choices = NULL, width = "100%"),
            actionButton(ns("clear"), "Borrar fotos elegidas…", class = "btn-danger admin-btn", style = "width: 100%;")
          ),
          box(
            title = "Información", status = "info", solidHeader = TRUE, width = NULL, collapsible = TRUE,
            collapsed = TRUE,
            div(class = "reference-box", style = "margin-top: 0;",
                h4(style = "margin-top: 0; color: #4f46e5;", "🗂 Dónde se guarda todo"),
                tags$ul(
                  tags$li(tags$code("data/config.json"), " – carpeta, límite, costo"),
                  tags$li(tags$code("data/selections.json"), " – cada foto elegida"),
                  tags$li(tags$code("data/inventory.rds"), " – resultado del último escaneo"),
                  tags$li(tags$code("data/thumb_cache/"), " – vistas previas (se pueden borrar sin problema)")
                ),
                p("Las fotos elegidas se guardan por carpeta principal. Si cambia la carpeta se ocultan; si vuelve a la misma, regresan.")),
            br(),
            actionButton(ns("lock"), "Cerrar sección de administrador", class = "btn-default", icon = icon("lock"),
                         style = "width: 100%;")
          )
        )
      )
    }

    output$panel <- renderUI(if (unlocked()) admin_ui() else locked_ui())

    observeEvent(input$unlock, {
      if (identical(trimws(input$code %||% ""), pm$admin_code)) {
        unlocked(TRUE)
        showNotification("Sección de administrador abierta", type = "message")
      } else {
        updateTextInput(session, "code", value = "")
        showNotification("Código incorrecto", type = "error")
      }
    })
    observeEvent(input$lock, unlocked(FALSE))

    # ------------------------------------------------------- main folder
    output$rootStatus <- renderUI({
      pm$cfg_trigger()
      root <- pm$root()
      scanned <- if (!is.null(pm$scanned_at)) fmt_fecha(pm$scanned_at) else "nunca"
      tagList(
        tags$b("Carpeta principal actual:"),
        div(class = "folder-path", if (nzchar(root)) root else "(todavía no se elige)"),
        div(style = "margin-top: 8px;",
            if (pm$root_ok()) span(class = "status-ok", "✔ Carpeta encontrada") else span(class = "status-bad", "✖ Carpeta no disponible"),
            sprintf("   ·   Último escaneo: %s   ·   Fotos: %s", scanned,
                    fmt_int(if (pm$has_inventory()) nrow(pm$photos) else 0)))
      )
    })

    apply_root <- function(path) {
      path <- trimws(path)
      if (!nzchar(path) || !dir.exists(path)) {
        showNotification("Esa carpeta no existe.", type = "error"); return()
      }
      if (identical(normalizePath(path, winslash = "/"), pm$root())) {
        showNotification("Esa ya es la carpeta principal.", type = "message"); return()
      }
      n_sel <- nrow(pm$current_selections())
      if (n_sel > 0) {
        pending_root(path)
        showModal(modalDialog(
          title = "¿Cambiar la carpeta principal?",
          p(sprintf("El usuario tiene %s fotos elegidas en la carpeta actual.", n_sel)),
          p("Se quedan guardadas en el archivo, pero no se verán mientras use otra carpeta. Regresan si vuelve a elegir la carpeta actual."),
          footer = tagList(modalButton("Cancelar"),
                           actionButton(ns("confirmRoot"), "Sí, cambiar carpeta", class = "btn-primary"))
        ))
      } else {
        do_set_root(path)
      }
    }

    do_set_root <- function(path) {
      res <- pm$set_root(path)
      if (identical(res, "set")) {
        updateTextInput(session, "rootPath", value = pm$root())
        msg <- if (pm$has_inventory()) "Carpeta principal guardada (se recuperó el escaneo anterior de esta carpeta)."
               else "Carpeta principal guardada. Ahora presione “Escanear carpetas y fotos”."
        showNotification(msg, type = "message", duration = 8)
      } else if (!identical(res, "same")) {
        showNotification(res, type = "error")
      }
    }

    observeEvent(input$confirmRoot, { removeModal(); do_set_root(pending_root()) })

    observeEvent(input$rootDir, {
      if (is.integer(input$rootDir)) return()
      path <- shinyFiles::parseDirPath(volumes, input$rootDir)
      if (length(path) == 0) return()
      apply_root(as.character(path))
    })
    observeEvent(input$useTyped, apply_root(input$rootPath))

    # ---------------------------------------------------------------- scan
    observeEvent(input$scan, {
      if (!pm$root_ok()) {
        showNotification("Primero elija la carpeta principal.", type = "error"); return()
      }
      res <- tryCatch(
        withProgress(message = "Escaneando fotos…", value = 0, {
          pm$scan(progress = function(f, d) setProgress(f * 0.98, detail = d))
        }),
        error = function(e) { showNotification(conditionMessage(e), type = "error"); NULL })
      if (is.null(res)) return()

      if (isTRUE(input$makePreviews) && res$photos > 0) {
        withProgress(message = "Preparando vistas previas…", value = 0, {
          pm$pregenerate_previews(progress = function(f, d) setProgress(f, detail = d))
        })
      }

      output$scanResult <- renderUI(div(
        class = "dimension-display", style = "margin-top: 14px;",
        HTML(sprintf(
          "<b>Escaneo terminado.</b> %s países · %s lugares · %s fotos.%s%s",
          res$countries, res$places, fmt_int(res$photos),
          if (res$loose_root > 0) sprintf("<br>⚠ %s foto(s) están sueltas en la carpeta principal (no dentro de un país) y no se tomaron en cuenta.", res$loose_root) else "",
          if (res$removed_selections > 0) sprintf("<br>⚠ %s foto(s) elegidas ya no existen en la computadora y se quitaron de la lista.", res$removed_selections) else ""
        ))))
      showNotification(sprintf("Escaneo terminado: se encontraron %s fotos", fmt_int(res$photos)), type = "message")
    })

    output$overview <- renderTable({
      pm$cfg_trigger(); pm$sel_trigger()
      pm$overview()
    }, striped = TRUE, hover = TRUE, spacing = "s", width = "100%", digits = 1)

    # --------------------------------------------------------------- rules
    observeEvent(input$saveRules, {
      lim <- suppressWarnings(as.integer(input$limit))
      cost <- suppressWarnings(as.numeric(input$cost))
      if (is.na(lim) || lim < 1) { showNotification("El límite debe ser un número entero de 1 o más.", type = "error"); return() }
      if (is.na(cost) || cost < 0) { showNotification("El costo debe ser 0 o más.", type = "error"); return() }
      cur <- trimws(input$currency %||% "MXN"); if (!nzchar(cur)) cur <- "MXN"
      pm$update_rules(lim, cost, cur)
      over <- pm$country_summary()
      over <- over$country[over$chosen > lim]
      showNotification(
        if (length(over)) sprintf("Reglas guardadas. Ojo: %s ya tiene(n) más de %s fotos elegidas.", paste(over, collapse = ", "), lim)
        else "Reglas guardadas.", type = if (length(over)) "warning" else "message", duration = 8)
    })

    # ---------------------------------------------------------- selections
    output$selStatus <- renderUI({
      pm$cfg_trigger(); pm$sel_trigger()
      cs <- pm$country_summary()
      p(HTML(sprintf("<b>%s</b> fotos elegidas en total · costo aproximado <b>%s</b>",
                     sum(cs$chosen), fmt_money(sum(cs$cost), pm$currency()))))
    })

    observe({
      pm$cfg_trigger()
      cs <- pm$country_summary()
      updateSelectInput(session, "clearWhich",
                        choices = c("Todos los países" = "", setNames(cs$country, cs$country)))
    })

    observeEvent(input$clear, {
      what <- if (nzchar(input$clearWhich %||% "")) input$clearWhich else "TODOS los países"
      showModal(modalDialog(
        title = "¿Borrar fotos elegidas?",
        p(sprintf("Esto quita las marcas de %s. No se puede deshacer.", what)),
        footer = tagList(modalButton("Cancelar"),
                         actionButton(ns("confirmClear"), "Sí, borrar", class = "btn-danger"))
      ))
    })
    observeEvent(input$confirmClear, {
      removeModal()
      n <- pm$clear_selections(if (nzchar(input$clearWhich %||% "")) input$clearWhich else NULL)
      showNotification(sprintf("Se borraron %s foto(s) elegidas.", n), type = "message")
    })

    output$downloadSel <- downloadHandler(
      filename = function() paste0("fotos_elegidas_", format(Sys.time(), "%Y%m%d_%H%M"), ".csv"),
      content = function(file) write_csv_utf8(pm$selection_table_es(), file)
    )

    # ------------------------------------------------- print folder
    observeEvent(input$printDir, {
      if (is.integer(input$printDir)) return()
      path <- shinyFiles::parseDirPath(volumes, input$printDir)
      if (length(path) == 0) return()
      path <- normalizePath(as.character(path), winslash = "/")
      if (pm$root_ok() && startsWith(paste0(path, "/"), paste0(pm$root(), "/"))) {
        showNotification("Elija una ubicación FUERA de la carpeta principal de fotos.", type = "error", duration = 8)
        return()
      }
      pm$set_preference("print_parent", path)
      print_parent(path)
    })

    output$printPath <- renderUI({
      pm$cfg_trigger(); pm$sel_trigger()
      par <- print_parent()
      if (!nzchar(par)) {
        return(div(class = "folder-path", style = "margin: 8px 0;", "(todavía no se elige la ubicación)"))
      }
      cs <- pm$country_summary(); cs <- cs$country[cs$chosen > 0]
      sub <- if (length(cs)) paste0(" → ", paste(cs, collapse = ", ")) else ""
      tagList(
        div(style = "margin-top: 8px;", tags$b("Las fotos se guardarán en:")),
        div(class = "folder-path", style = "margin-bottom: 8px;", paste0(pm$print_folder(par), sub)),
        if (!dir.exists(par)) div(class = "status-bad", "✖ Esa ubicación ya no existe, elija otra.")
      )
    })

    # Save print / watermark preferences whenever they change
    observeEvent(input$printMode, pm$set_preference("print_mode", input$printMode), ignoreInit = TRUE)
    observeEvent(input$wmEnabled, pm$set_preference("wm_enabled", isTRUE(input$wmEnabled)), ignoreInit = TRUE)
    observeEvent(input$wmFont, pm$set_preference("wm_font", input$wmFont), ignoreInit = TRUE)
    observeEvent(input$wmSize, pm$set_preference("wm_size", input$wmSize), ignoreInit = TRUE)
    observeEvent(input$wmBold, pm$set_preference("wm_bold", isTRUE(input$wmBold)), ignoreInit = TRUE)
    observeEvent(input$wmStyle, pm$set_preference("wm_style", input$wmStyle), ignoreInit = TRUE)

    output$wmSizeHint <- renderUI({
      req(input$wmSize)
      div(class = "wm-hint",
          sprintf("En una foto de 10 × 15 cm, las letras medirán aprox. %s mm de alto.", wm_letter_mm(input$wmSize)))
    })

    wm_settings <- debounce(reactive({
      req(length(pm$wm_fonts) > 0, input$wmFont, input$wmSize, input$wmStyle)
      f <- pm$wm_fonts[[input$wmFont]]
      req(f)
      list(family = f$family, size = input$wmSize, bold = isTRUE(input$wmBold), style = input$wmStyle,
           label = f$label)
    }), 400)

    output$wmPreview <- renderImage({
      wm <- wm_settings()
      pm$cfg_trigger()
      sample <- NULL
      cur <- pm$current_selections()
      if (nrow(cur) > 0 && pm$root_ok()) sample <- cur[1, ]
      else if (pm$has_inventory()) sample <- pm$photos[1, ]
      img <- NULL; text <- "México \u2013 Cancún"
      if (!is.null(sample)) {
        img <- tryCatch(magick::image_read(file.path(pm$root(), sample$rel_path))[1], error = function(e) NULL)
        text <- watermark_text(sample$country, sample$subfolder)
      }
      if (is.null(img)) img <- magick::image_blank(1500, 1000, "#7f8fa6")
      img <- magick::image_scale(magick::image_orient(img), "1000x1000")
      img <- add_watermark(img, text, wm$family, wm$size, wm$bold, wm$style)
      tmp <- tempfile(fileext = ".jpg")
      magick::image_write(img, tmp, format = "jpeg", quality = 85)
      list(src = tmp, contentType = "image/jpeg", width = "100%", alt = "Vista previa del sello de agua")
    }, deleteFile = TRUE)

    # ------------------------------------------------------- export
    observeEvent(input$export, {
      par <- print_parent()
      if (!nzchar(par) || !dir.exists(par)) {
        showNotification("Primero elija dónde crear la carpeta Imprimir.", type = "error"); return()
      }
      n <- nrow(pm$current_selections())
      if (n == 0) { showNotification("Todavía no hay fotos elegidas.", type = "warning"); return() }
      out <- pm$print_folder(par)
      has_content <- dir.exists(out) && length(list.files(out)) > 0
      use_wm <- isTRUE(input$wmEnabled) && length(pm$wm_fonts) > 0
      cs <- pm$country_summary(); cs <- cs[cs$chosen > 0, ]
      showModal(modalDialog(
        title = "¿Copiar las fotos para imprimir?",
        div(class = "big-message",
            p(HTML(sprintf("Se copiarán <b>%s fotos</b> de %s país(es) a:", n, nrow(cs)))),
            div(class = "folder-path", out),
            tags$ul(style = "margin-top: 10px;",
                    tags$li(HTML(paste0("Carpetas: <b>", paste(htmltools::htmlEscape(cs$country), collapse = "</b>, <b>"), "</b>"))),
                    tags$li(if (use_wm) sprintf("Con sello de agua: %s, %s %%%s", sub(" –.*", "", isolate(wm_settings())$label),
                                                input$wmSize, if (isTRUE(input$wmBold)) ", negritas" else "")
                            else "Sin sello de agua (copia exacta de las fotos)")),
            if (has_content && identical(input$printMode, "replace"))
              p(class = "status-bad", "⚠ La carpeta Imprimir ya tiene archivos: se borrarán y quedarán solo las fotos elegidas ahora.")),
        footer = tagList(modalButton("Cancelar"),
                         actionButton(ns("confirmExport"), "Sí, copiar fotos", class = "btn-success"))
      ))
    })

    observeEvent(input$confirmExport, {
      removeModal()
      use_wm <- isTRUE(input$wmEnabled) && length(pm$wm_fonts) > 0
      wm <- if (use_wm) isolate(wm_settings()) else NULL
      res <- tryCatch(
        withProgress(message = if (use_wm) "Copiando fotos con sello de agua…" else "Copiando fotos…", value = 0,
                     pm$export_for_print(print_parent(), mode = input$printMode %||% "replace", watermark = wm,
                                         progress = function(f, d) setProgress(f, detail = d))),
        error = function(e) { showNotification(conditionMessage(e), type = "error", duration = 10); NULL })
      if (!is.null(res)) {
        showModal(modalDialog(
          title = "✅ Fotos listas para imprimir",
          div(class = "big-message",
              p(sprintf("Se copiaron %s de %s fotos a:", res$copied, res$total)),
              div(class = "folder-path", res$folder),
              p(style = "margin-top: 10px;", "Adentro hay una carpeta por país, y también los archivos lista_para_imprimir.csv y resumen_del_pedido.csv."),
              if (length(res$failed))
                p(class = "status-bad", sprintf("⚠ %s foto(s) no se pudieron copiar: %s", length(res$failed),
                                                paste(head(res$failed, 5), collapse = ", ")))),
          footer = modalButton("Aceptar"), easyClose = TRUE))
      }
    })
  })
}
