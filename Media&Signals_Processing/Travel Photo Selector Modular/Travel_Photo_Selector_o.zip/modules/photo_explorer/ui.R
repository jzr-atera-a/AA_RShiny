photo_explorer_ui <- function(id) {
  ns <- NS(id)

  tagList(
    # Row 1: totals, how many chosen out of the limit, estimated cost
    uiOutput(ns("stats")),

    # Row 2: choosing country / place / layout (left) + suggested photos per place (right)
    fluidRow(
      column(
        width = 8,
        box(
          title = "1. Elija el viaje",
          status = "primary",
          solidHeader = TRUE,
          width = NULL,

          fluidRow(
            column(6, selectInput(ns("country"), "País:", choices = NULL, width = "100%")),
            column(6, selectInput(ns("subfolder"), "Ciudad, región o evento:", choices = NULL, width = "100%"))
          ),
          fluidRow(
            column(
              6,
              radioButtons(
                ns("layout"),
                "¿Cuántas fotos quiere ver en la pantalla?",
                choices = c("4 fotos grandes (2 × 2)" = "2x2", "9 fotos más chicas (3 × 3)" = "3x3"),
                selected = "2x2"
              )
            ),
            column(
              6,
              radioButtons(
                ns("filter"),
                "Mostrar:",
                choices = c("Todas las fotos" = "all", "Solo las que ya elegí" = "chosen", "Las que todavía no elijo" = "not"),
                selected = "all"
              )
            )
          ),

          div(
            class = "info-box-tpl how-to-strip",
            HTML(paste0(
              "<b style='color:#667eea;'>📝 ¿Cómo funciona?</b> ",
              "Haga clic en una foto (o en el botón <b>Elegir</b>) para marcarla; otra vez para quitarla. ",
              "Use <b>Ver grande</b> para verla en tamaño grande. Todo se guarda solito."
            ))
          )
        )
      ),
      column(
        width = 4,
        box(
          title = "Fotos sugeridas por lugar",
          status = "info",
          solidHeader = TRUE,
          width = NULL,
          uiOutput(ns("placeGuide"))
        )
      )
    ),

    # Row 3: the photo matrix uses the full width of the page
    fluidRow(
      column(
        width = 12,
        box(
          title = "2. Marque las fotos que quiere imprimir",
          status = "primary",
          solidHeader = TRUE,
          width = NULL,

          uiOutput(ns("suggestBanner")),
          uiOutput(ns("grid")),
          uiOutput(ns("pager"))
        )
      )
    )
  )
}
