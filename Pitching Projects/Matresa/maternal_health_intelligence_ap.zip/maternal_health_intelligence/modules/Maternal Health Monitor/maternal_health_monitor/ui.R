# modules/Maternal Health Monitor/maternal_health_monitor/ui.R
# Seven subtabs, in order of increasing complexity:
#   1. Continuity Gap Timeline            (ref: "Maternal health isn't a wellness gap")
#   2. Intelligence Layer & Interventions (ref: "The Intelligence Layer...")
#   3. Risk Trajectory & Early Detection  (ref: "Detect the trajectory early")
#   4. Statistical Concepts               (foundations: correlation, causality, significance, A/B testing)
#   5. Concepts Applied to Our Monitoring (the same four ideas, using this app's own data)
#   6. Cohort A/B Simulation              (treatment-pathway analog of driver_ab_test)
#   7. Intervention Timeline              (pregnancy -> 24 months postpartum, clickable care pathway)

maternal_health_monitor_ui <- function(id) {
  ns <- NS(id)

  tagList(

    fluidRow(
      column(12,
        div(class = "book-header",
          tags$h2(icon("heartbeat"), " Maternal Health Monitor"),
          tags$p(class = "author",
            "Continuity-gap timeline, the intelligence layer feeding the model, early-detection ",
            "risk trajectory, and a cohort simulation comparing pathways of support. ",
            "All figures are simulated except where a reference is cited.")
        )
      )
    ),

    fluidRow(
      box(title = NULL, status = "primary", solidHeader = FALSE, width = 12,

        tabsetPanel(id = ns("mh_tabs"),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 1 — CONTINUITY GAP TIMELINE
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("stream"), " Continuity Gap"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "THE PROBLEM"),
              tags$h3("Maternal health isn't a wellness gap - it's a continuity gap"),

              fluidRow(
                column(4, div(style="text-align:center;",
                  div(class = "stat-number", "\u00A38.1bn"),
                  div(class = "stat-label", "Annual cost of perinatal mental health problems, UK"))),
                column(4, div(style="text-align:center;",
                  div(class = "stat-number", "~20%"),
                  div(class = "stat-label", "Of mothers affected by a perinatal mental health problem"))),
                column(4, div(style="text-align:center;",
                  div(class = "stat-number", "1"),
                  div(class = "stat-label", "Structured postnatal mental health check in standard care (6-8 weeks)")))
              ),
              p(style="font-size:11px; color:rgba(255,255,255,0.6); text-align:center; margin-top:10px;",
                "Figures cited above are drawn from the reference list at the foot of this tab, not from ",
                "the simulated data used elsewhere in the app."),

              br(),
              fluidRow(
                column(4,
                  div(style="background:rgba(255,255,255,0.06); border:1px solid rgba(74,144,226,0.4); border-radius:8px; padding:8px; text-align:center;",
                    tags$img(src = "img/slide_continuity_gap.png", style = "width:100%; border-radius:4px;"),
                    tags$p(style="font-size:10px; color:#a8b6d8; margin:6px 0 0 0;",
                      "Original pitch-deck slide, provided for context.")
                  )
                ),
                column(8,
                  tags$h4("Touchpoint density across the maternal journey"),
                  p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                    "Baby touchpoints continue on a dense, well-defined schedule. Mother touchpoints ",
                    "drop to almost nothing after birth, subject to GP availability, then stay silent ",
                    "through the return-to-work transition.")
                )
              ),

              uiOutput(ns("journey_track")),

              p(style="font-size:11px; color:rgba(255,255,255,0.55); margin-top:6px;",
                icon("info-circle"), " Filled dots = an active, structured touchpoint for that stage. ",
                "Faded dots = no structured contact scheduled - this is where the continuity gap lives."),

              plotly::plotlyOutput(ns("touchpoint_density_plot"), height = "280px"),
              concept_note(
                tags$strong("What this shows: "),
                "The grouped bars count structured, scheduled touchpoints per journey stage for the ",
                "baby (health visitor checks, immunisations) versus the mother (antenatal appointments, ",
                "delivery care, the single 6-8 week postnatal check). The gap between the two bars in the ",
                "Postnatal and Return to Work columns is the continuity gap this app exists to close - it is ",
                "not that mothers are unwell less often, it is that almost nobody is structurally checking."
              )
            ),

            reference_panel_ui(c("bauer2014", "cox1987"))
          ),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 2 — INTELLIGENCE LAYER & INTERVENTIONS
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("brain"), " Intelligence Layer"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "THE TECHNOLOGY"),
              tags$h3("The intelligence layer for preventative maternal health"),
              p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                "Building the longitudinal data foundation for a maternal digital twin: continuous ",
                "inputs feed a single intelligence layer, which drives four downstream capabilities."),

              fluidRow(
                column(3,
                  div(style="background:rgba(255,255,255,0.06); border:1px solid rgba(74,144,226,0.4); border-radius:8px; padding:8px; text-align:center;",
                    tags$img(src = "img/slide_intelligence_layer.png", style = "width:100%; border-radius:4px;"),
                    tags$p(style="font-size:10px; color:#a8b6d8; margin:6px 0 0 0;",
                      "Original pitch-deck slide, provided for context.")
                  )
                ),
                column(9,
                  tags$h4("Explore an input signal", style="margin-top:0;"),
                  p(style="font-size:11.5px; color:rgba(255,255,255,0.6);",
                    "Pick a signal to see what it captures and exactly which downstream capability it feeds. ",
                    "No single signal feeds everything - that separation is what keeps the model explainable."),
                  selectInput(ns("signal_select"), NULL,
                    choices = c("Mood" = "mood", "Blood pressure" = "bp", "Sleep" = "sleep",
                                "Symptoms" = "symptoms", "Care history" = "care_history",
                                "Work & support context" = "work_context")),
                  uiOutput(ns("signal_detail"))
                )
              ),

              br(),
              tags$h4("The maternal digital twin"),
              p(style="font-size:11.5px; color:rgba(255,255,255,0.6);",
                "Six continuous input streams (left) are combined into one longitudinal record per mother ",
                "- the digital twin - which in turn drives four distinct outputs (right). Inputs never feed ",
                "an output directly; everything passes through the twin, which is what lets the model compare ",
                "a mother to her own history rather than to a population average."),
              uiOutput(ns("digital_twin_diagram")),

              br(),
              tags$h4("Roadmap"),
              p(style="font-size:11.5px; color:rgba(255,255,255,0.6);",
                "The intelligence layer is built in three stages, each unlocking a heavier level of ",
                "regulatory classification as the model moves from personalisation to prediction."),
              fluidRow(
                column(4, div(class = "mint-card",
                  span(class="risk-badge", style="background:#1a6b35;", "In beta testing"),
                  tags$h5("V1 - Capture & personalise"),
                  p(style="font-size:12px;", "Continuous check-ins and connected-device signals generate personalised education and the first longitudinal maternal dataset."),
                  p(style="font-size:10.5px; color:#a8b6d8;", tags$em("Regulatory: Class I device")))),
                column(4, div(class = "mint-card",
                  span(class="risk-badge", style="background:#d4ac0d;", "In development"),
                  tags$h5("V2 - Support clinician decisions"),
                  p(style="font-size:12px;", "Longitudinal insights and scored screening at the periodic check help clinicians prioritise concerns and reduce missed issues."),
                  p(style="font-size:10.5px; color:#a8b6d8;", tags$em("Regulatory: Class I device")))),
                column(4, div(class = "mint-card",
                  span(class="risk-badge", style="background:#c0392b;", "2027+"),
                  tags$h5("V3 - Predict & prevent"),
                  p(style="font-size:12px;", "Condition-specific models flag divergence from a mother's own baseline weeks before a clinical threshold is crossed."),
                  p(style="font-size:10.5px; color:#a8b6d8;", tags$em("Regulatory: Class IIa / FDA track"))))
              )
            ),

            reference_panel_ui(c("hurwitz2024", "abdalrazaq2023"))
          ),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 3 — RISK TRAJECTORY & EARLY DETECTION
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("chart-line"), " Risk Trajectory"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "THE BACK END"),
              tags$h3("Detect the trajectory early - months before crisis"),
              p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                "Condition-specific models read the longitudinal record continuously and flag ",
                "divergence from a mother's own baseline before a clinical threshold is crossed.")
            ),

            fluidRow(
              column(3,
                div(style="background:rgba(255,255,255,0.06); border:1px solid rgba(74,144,226,0.4); border-radius:8px; padding:8px; text-align:center; margin-bottom:14px;",
                  tags$img(src = "img/slide_risk_trajectory.png", style = "width:100%; border-radius:4px;"),
                  tags$p(style="font-size:10px; color:#a8b6d8; margin:6px 0 0 0;",
                    "Original pitch-deck slide, provided for context.")
                )
              ),
              column(9,
                fluidRow(
                  column(4, selectInput(ns("rt_cohort_filter"), "Cohort:",
                           choices = c("All cohorts" = "all", COHORT_LABELS), selected = "all")),
                  column(4, uiOutput(ns("rt_mother_selector"))),
                  column(4, br(), actionButton(ns("rt_resample"), "Resample Cohort",
                           class = "btn-primary", icon = icon("sync"), style = "width:100%;"))
                )
              )
            ),

            fluidRow(
              box(title = "Risk Trajectory vs Own Baseline", status = "primary", solidHeader = TRUE, width = 8,
                concept_note(
                  tags$strong("What this shows: "),
                  "The composite risk score (0-100) for the selected mother, plotted week by week since ",
                  "birth. It is scored against her own baseline, not a population average, so a steady ",
                  "climb is meaningful even if her absolute score never looks extreme. The dashed line is ",
                  "the clinical threshold zone; the annotated point is where the model first flags sustained ",
                  "divergence - typically weeks before that dashed line is reached."
                ),
                plotly::plotlyOutput(ns("trajectory_plot"), height = "360px")
              ),
              box(title = "What Raised The Flag", status = "warning", solidHeader = TRUE, width = 4,
                concept_note(
                  tags$strong("Flagged: "), "the week the behavioural score first crossed the early-warning ",
                  "level. ", tags$strong("Lead time: "), "how many days earlier that is than the clinical ",
                  "threshold would have been crossed - the window in which support can still change the outcome."
                ),
                uiOutput(ns("flag_kpis")),
                br(),
                p(style="font-size:11px; color:#a8b6d8; margin-bottom:2px;",
                  "Each bar below is one signal's weighted contribution to the score at the flagged week - ",
                  "the longer the bar, the more that signal drove the flag."),
                plotly::plotlyOutput(ns("breakdown_plot"), height = "200px"),
                br(),
                uiOutput(ns("action_panel"))
              )
            ),

            fluidRow(
              box(title = "Risk Criteria & Calibration Check", status = "primary", solidHeader = TRUE, width = 12,
                fluidRow(
                  column(6,
                    p(style="font-size:12px; color:#e0e7ff;",
                      "Five behavioural signals feed the composite score. Each is a 0-1 measure of how far ",
                      "that week's reading has drifted from the mother's own recent baseline; the weight sets ",
                      "how much a full-scale drift in that signal alone can move the composite score."),
                    tags$table(class = "table table-condensed",
                      tags$thead(tags$tr(tags$th("Signal"), tags$th("Weight"), tags$th("What it captures"))),
                      tags$tbody(
                        tags$tr(tags$td("Sleep fragmentation"), tags$td("0.89"), tags$td("Broken, non-restorative sleep vs the mother's own recent pattern")),
                        tags$tr(tags$td("Mood variance (14-day)"), tags$td("0.74"), tags$td("How much day-to-day mood is swinging over a rolling 2-week window")),
                        tags$tr(tags$td("Check-in engagement drop"), tags$td("0.61"), tags$td("Falling participation in app check-ins - often an early withdrawal signal")),
                        tags$tr(tags$td("Support content change"), tags$td("0.49"), tags$td("Shift in which support/education content she is engaging with")),
                        tags$tr(tags$td("Resting HRV vs own baseline"), tags$td("0.39"), tags$td("Autonomic/physiological strain relative to her own resting baseline"))
                      )
                    ),
                    p(style="font-size:11.5px; color:#a8b6d8;",
                      "The EPDS self-harm item (item 10) is a separate, deterministic trigger and is ",
                      "never blended into this weighted composite - see the app README for the safety rationale.")
                  ),
                  column(6,
                    p(style="font-size:12px; color:#e0e7ff;",
                      "A risk score is only useful as a visual if it spans the whole colour scale under ",
                      "realistic inputs, rather than clustering everyone into one band. This chart is that ",
                      "check: each mother's latest-week score, banded Low/Moderate/High/Critical, by cohort."),
                    plotly::plotlyOutput(ns("distribution_plot"), height = "240px")
                  )
                )
              )
            ),

            reference_panel_ui(c("abdalrazaq2023", "hurwitz2024"))
          ),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 4 — STATISTICAL CONCEPTS (foundations, general examples)
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("graduation-cap"), " Statistical Concepts"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "FOUNDATIONS"),
              tags$h3("Four ideas behind every chart in this app"),
              p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                "Correlation, causality, statistical significance and A/B testing are easy to blur together. ",
                "Each box below explains one concept in plain language with a general mental-health example, ",
                "before the next tab applies all four directly to postpartum depression monitoring.")
            ),

            fluidRow(
              column(6,
                div(class = "mint-card", style = "margin-bottom:18px;",
                  tags$h4(icon("link"), " Correlation"),
                  p("Two things move together across a population. Correlation tells you ",
                    tags$em("how strongly"), " they move together (from -1 to +1), but says nothing about ",
                    "why - it does not tell you which one is driving the other, or whether a third factor ",
                    "is driving both."),
                  div(class = "concept-note",
                    tags$strong("Mental health example: "),
                    "People who sleep poorly tend to report more depressive symptoms - a well-replicated ",
                    "correlation. But that alone does not tell us poor sleep causes depression: depression ",
                    "could disrupt sleep, or a third factor (chronic stress, illness) could drive both."
                  ),
                  box_reference_note(c("baglioni2011", "altman2015"))
                )
              ),
              column(6,
                div(class = "mint-card", style = "margin-bottom:18px;",
                  tags$h4(icon("arrow-right"), " Causality"),
                  p("Causality means changing X actually produces a change in Y. Establishing it usually ",
                    "needs more than an observed association - classic criteria include the strength and ",
                    "consistency of the association, whether cause precedes effect, and whether a plausible ",
                    "biological or psychological mechanism exists."),
                  div(class = "concept-note",
                    tags$strong("Mental health example: "),
                    "\"Mothers who received peer support did better\" could simply mean more resourced or ",
                    "motivated mothers both sought support and did better anyway. Randomly assigning mothers ",
                    "to support vs no support - a controlled trial - is what lets researchers say the ",
                    "support itself caused the improvement."
                  ),
                  box_reference_note(c("hill1965", "dennis2013"))
                )
              )
            ),

            fluidRow(
              column(6,
                div(class = "mint-card",
                  tags$h4(icon("percentage"), " Statistical Significance"),
                  p("A p-value answers one narrow question: if there were truly no effect, how surprising ",
                    "would this result be? A small p-value means \"unlikely to be chance\" - it does not mean ",
                    "\"large\", \"important\", or \"clinically meaningful\". Those need an effect size alongside it."),
                  div(class = "concept-note",
                    tags$strong("Mental health example: "),
                    "A trial with thousands of participants could find a statistically significant (p = 0.001) ",
                    "1-point average reduction on a 30-point depression scale. Significant, yes - but a ",
                    "1-point shift may barely register in a mother's daily life. Significance and importance ",
                    "are two different questions."
                  ),
                  box_reference_note(c("wasserstein2016", "sullivan2012"))
                )
              ),
              column(6,
                div(class = "mint-card",
                  tags$h4(icon("balance-scale"), " A/B Testing"),
                  p("An A/B test (a randomised controlled trial by another name) randomly assigns people to ",
                    "two or more versions of something and compares the outcome. Random assignment is the ",
                    "part that lets you attribute any difference to the intervention itself, rather than to ",
                    "who happened to end up in which group."),
                  div(class = "concept-note",
                    tags$strong("Mental health example: "),
                    "Comparing mothers who chose to download a support app against those who did not is ",
                    "not an A/B test - the two groups likely differ in motivation and access before the app ",
                    "ever enters the picture. A genuine test randomly assigns who gets the app."
                  ),
                  box_reference_note(c("kohavi2009", "dennis2013"))
                )
              )
            )
          ),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 5 — CONCEPTS APPLIED TO PPD MONITORING
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("microscope"), " Applied to Our Monitoring"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "IN PRACTICE"),
              tags$h3("The same four ideas, applied to this app"),
              p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                "Every chart elsewhere in this module leans on one of the four concepts from the previous ",
                "tab. Here is exactly where and how, using this app's own simulated data and outputs.")
            ),

            fluidRow(
              column(6,
                div(class = "mint-card", style = "margin-bottom:18px;",
                  tags$h4(icon("link"), " Correlation, in our data"),
                  p("The five behavioural signals behind the composite score - sleep fragmentation, mood ",
                    "variance, engagement drop, support-content change, HRV delta - were chosen because ",
                    "they correlate with EPDS scores in the simulated cohort. The scatter below plots one ",
                    "signal against EPDS score, with the correlation coefficient computed live."),
                  fluidRow(
                    column(6, selectInput(ns("corr_signal_select"), "Signal to correlate with EPDS:",
                             choices = c("Sleep fragmentation" = "sleep_fragmentation",
                                         "Mood variance (14-day)" = "mood_variance_14d",
                                         "Check-in engagement drop" = "checkin_engagement_drop",
                                         "Resting HRV vs baseline" = "resting_hrv_delta")))
                  ),
                  plotly::plotlyOutput(ns("corr_scatter_plot"), height = "260px"),
                  div(class = "concept-note",
                    tags$strong("Reading this: "),
                    "A high correlation here is exactly why the signal was included in the score - but the ",
                    "app never claims that, say, poor sleep tracking ", tags$em("causes"), " higher EPDS ",
                    "scores. It is an early-warning marker, not a diagnosis or a causal claim."
                  ),
                  box_reference_note(c("baglioni2011", "altman2015"))
                )
              ),
              column(6,
                div(class = "mint-card", style = "margin-bottom:18px;",
                  tags$h4(icon("arrow-right"), " Causality, in our data"),
                  p("Nothing on the Risk Trajectory tab is a causal claim - it is a correlational early-warning ",
                    "flag. The one place this app comes close to a causal claim is the Cohort A/B Simulation, ",
                    "where mothers are (in simulation) assigned to a support pathway and outcomes compared."),
                  uiOutput(ns("causal_diagram")),
                  div(class = "concept-note",
                    tags$strong("The limitation, stated plainly: "),
                    "In this simulation, cohort assignment is random by construction. In a real deployment, ",
                    "mothers who opt in to an app are self-selected, not randomised - so a real causal claim ",
                    "about the app's effect would need a genuine randomised trial, not just a before/after or ",
                    "opt-in/opt-out comparison."
                  ),
                  box_reference_note(c("hill1965", "dennis2013"))
                )
              )
            ),

            fluidRow(
              column(6,
                div(class = "mint-card",
                  tags$h4(icon("percentage"), " Significance, in our data"),
                  p("The Cohort A/B Simulation tab reports a two-sample t-test comparing App-Supported ",
                    "against No-Support mothers. Below is that same comparison, recomputed live, alongside ",
                    "the effect size - because, per the previous tab, the two answer different questions."),
                  uiOutput(ns("significance_recap"))
                )
              ),
              column(6,
                div(class = "mint-card",
                  tags$h4(icon("balance-scale"), " A/B testing, in our data"),
                  p("The Cohort A/B Simulation tab's three arms are this app's A/B (technically A/B/C) test. ",
                    "The table below states plainly what would need to be true for it to license a causal ",
                    "claim in a real deployment, versus what the simulation actually provides."),
                  tags$table(class = "table table-condensed",
                    tags$thead(tags$tr(tags$th("Requirement"), tags$th("In this simulation"), tags$th("In a real trial"))),
                    tags$tbody(
                      tags$tr(tags$td("Random assignment to arm"), tags$td("Yes, by construction"), tags$td("Requires a randomisation protocol")),
                      tags$tr(tags$td("Pre-registered primary outcome"), tags$td("Composite risk score (illustrative)"), tags$td("Should be fixed before data collection - e.g. EPDS at a set week")),
                      tags$tr(tags$td("Sample size justified in advance"), tags$td("See the previous tab's power table"), tags$td("Same calculation, using real pilot-study variance")),
                      tags$tr(tags$td("Blinding"), tags$td("Not applicable (participant knows their support level)"), tags$td("Usually not possible either, for the same reason"))
                    )
                  ),
                  box_reference_note(c("kohavi2009", "julious2004"))
                )
              )
            )
          ),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 6 — COHORT A/B SIMULATION
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("balance-scale"), " Cohort A/B Simulation"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "VALIDATION"),
              tags$h3("Comparing pathways of support"),
              p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                "App-supported vs standard NHS care vs no structured support - the same ",
                "cohort-comparison pattern used to compare CPAP-treated, untreated and control ",
                "drivers, applied here to maternal wellbeing outcomes."),
              actionButton(ns("ab_resimulate"), "Re-simulate Cohorts",
                           class = "btn-primary", icon = icon("sync"))
            ),

            p(style="font-size:11.5px; color:#a8b6d8; margin:2px 4px 10px 4px;",
              icon("info-circle"), " The four KPIs below all compare the App-Supported cohort against the ",
              "No-Support control at the same simulated point in time (week 24, or the mother's own ",
              "onset week for the timing metric). Positive numbers favour the App-Supported cohort."),

            fluidRow(
              column(3, valueBoxOutput(ns("kpi_epds_delta"), width = 12)),
              column(3, valueBoxOutput(ns("kpi_risk_delta"), width = 12)),
              column(3, valueBoxOutput(ns("kpi_flag_lead"), width = 12)),
              column(3, valueBoxOutput(ns("kpi_selfharm_rate"), width = 12))
            ),

            fluidRow(
              box(title = "Composite Risk Score by Cohort (latest week) \u2014 Distribution & Significance",
                  status = "primary", solidHeader = TRUE, width = 6,
                concept_note(
                  tags$strong("What this shows: "),
                  "Each cohort's full distribution at week 24: the violin outline is the density shape, ",
                  "the box marks the middle 50% of mothers, the white line is the median, and points are ",
                  "individual mothers. The bracket reports a two-sample t-test comparing App-Supported ",
                  "against No-Support - this is the same significance-testing step used to validate the ",
                  "CPAP-treated vs untreated contrast in the reference driver-safety app."
                ),
                plotly::plotlyOutput(ns("ab_box_plot"), height = "380px")
              ),
              box(title = "Distribution Shape by Cohort (density curves)", status = "primary",
                  solidHeader = TRUE, width = 6,
                concept_note(
                  tags$strong("What this shows: "),
                  "A smoothed density (kernel density estimate) of composite risk scores for each cohort - ",
                  "the \"bell curve\" shape of each group. Dashed vertical lines mark each cohort's mean. ",
                  "The further apart the peaks and the less the curves overlap, the more clearly the ",
                  "intervention is separating outcomes between cohorts."
                ),
                plotly::plotlyOutput(ns("ab_density_plot"), height = "380px")
              )
            ),

            fluidRow(
              box(title = "Risk Evolution Over Weeks Postpartum (cohort mean \u00B1 SE)", status = "primary",
                  solidHeader = TRUE, width = 6,
                concept_note(
                  tags$strong("What this shows: "),
                  "The average composite risk score across each cohort, tracked from birth to week 24. ",
                  "The shaded band (toggle below) is \u00B1 one standard error of the mean - a narrow band means ",
                  "the cohort average is estimated precisely; a wide band means individual mothers vary a lot."
                ),
                checkboxInput(ns("ab_show_ci"), "Show confidence band", value = TRUE),
                plotly::plotlyOutput(ns("ab_evolution_plot"), height = "290px")
              ),
              box(title = "Normalised Metric Heatmap by Cohort", status = "primary", solidHeader = TRUE, width = 6,
                concept_note(
                  tags$strong("What this shows: "),
                  "The five underlying behavioural signals (not the combined score), averaged per cohort ",
                  "at week 24. Darker blue means that signal is, on average, further from baseline for that ",
                  "cohort - reading down a column shows which signals are driving that cohort's outcomes."
                ),
                plotly::plotlyOutput(ns("ab_heatmap_plot"), height = "280px")
              )
            ),

            fluidRow(
              box(title = "Per-Mother Risk Delta vs No-Support Baseline", status = "primary", solidHeader = TRUE, width = 12,
                concept_note(
                  tags$strong("What this shows: "),
                  "Every App-Supported and Standard-Care mother's week-24 risk score, minus the average ",
                  "No-Support score. Bars below zero mean that mother is doing better than the average ",
                  "unsupported mother; bars above zero mean she is doing worse."
                ),
                plotly::plotlyOutput(ns("ab_delta_plot"), height = "260px")
              )
            ),

            fluidRow(
              box(title = "Recommended Sample Size per Cohort", status = "warning", solidHeader = TRUE, width = 12,
                concept_note(
                  tags$strong("What this shows: "),
                  "How many mothers per cohort a real-world trial would need to reliably detect each ",
                  "outcome, using a standard closed-form power calculation (Julious, 2004) rather than a ",
                  "rule of thumb. \"Smaller but still significant\" means picking the smallest effect size ",
                  "that is still clinically meaningful, on the outcome that measures it most efficiently - ",
                  "not simply lowering the statistical bar."
                ),
                fluidRow(
                  column(3, selectInput(ns("ss_effect_preset"), "Assumed effect size (Cohen's d):",
                           choices = c("Small (d = 0.2) - conservative, needs a large sample" = "Small",
                                       "Medium (d = 0.5) - recommended, clinically meaningful" = "Medium",
                                       "Large (d = 0.8) - only for a strong intervention effect" = "Large"),
                           selected = "Medium")),
                  column(3, sliderInput(ns("ss_power"), "Statistical power (1 - \u03B2):",
                           min = 0.7, max = 0.95, value = 0.8, step = 0.05)),
                  column(3, sliderInput(ns("ss_alpha"), "Significance level (\u03B1, two-sided):",
                           min = 0.01, max = 0.10, value = 0.05, step = 0.01)),
                  column(3, br(), uiOutput(ns("ss_recommendation_badge")))
                ),
                tags$table(class = "table table-condensed",
                  tags$thead(tags$tr(
                    tags$th("Outcome measure"), tags$th("Type"), tags$th("Test"),
                    tags$th("Effect assumed"), tags$th("n per group"), tags$th("Total N (3 arms)"),
                    tags$th("Medical / statistical justification")
                  )),
                  tags$tbody(uiOutput(ns("ss_table_rows")))
                ),
                p(style="font-size:11px; color:#a8b6d8; margin-top:8px;",
                  "Formulas: continuous outcomes use the two-independent-means Normal approximation ",
                  "n = 2(z\u03B1 + z\u03B2)\u00B2 / d\u00B2; the binary safety outcome uses the two-proportions approximation ",
                  "(Julious, 2004). Effect-size benchmarks follow Cohen (1988). These are simulated-cohort ",
                  "planning numbers, not a real trial's registered sample size calculation.")
              )
            ),

            reference_panel_ui(c("dennis2013", "bauer2014", "cohen1988", "julious2004"))
          ),

          # ══════════════════════════════════════════════════════════════════
          # SUBTAB 7 — INTERVENTION TIMELINE (pregnancy -> 24 months postpartum)
          # ══════════════════════════════════════════════════════════════════
          tabPanel(
            title = tagList(icon("route"), " Intervention Timeline"),
            br(),

            div(class = "slide-panel",
              span(class = "slide-pill", "THE CARE PATHWAY"),
              tags$h3("Support from several weeks before birth to two years after"),
              fluidRow(
                column(3,
                  div(style="background:rgba(255,255,255,0.06); border:1px solid rgba(74,144,226,0.4); border-radius:8px; padding:8px; text-align:center;",
                    tags$img(src = "img/slide_matrescence_definition.png", style = "width:100%; border-radius:4px;"),
                    tags$p(style="font-size:10px; color:#a8b6d8; margin:6px 0 0 0;",
                      "Original pitch-deck slide, provided for context.")
                  )
                ),
                column(9,
                  p(style="font-size:12.5px; color:rgba(255,255,255,0.75);",
                    "\"Matrescence\" - the physical, psychological and identity transition into motherhood - ",
                    "does not fit inside a single postnatal check. This timeline lays out where each concept ",
                    "from the previous two tabs, and each capability from the Intelligence Layer tab, actually ",
                    "lands across that transition: several weeks before birth through to two years after it."),
                  p(style="font-size:11px; color:rgba(255,255,255,0.55);",
                    icon("info-circle"), " The curve below is an ", tags$strong("illustrative conceptual index"),
                    " built to show the logic of layered intervention - it is not measured outcome data. ",
                    "(The simulated cohort dataset used elsewhere in this app only runs to 24 weeks postpartum.)")
                )
              )
            ),

            fluidRow(
              box(title = "Illustrative Maternal Mental Health Risk Index, With vs Without Structured Support",
                  status = "primary", solidHeader = TRUE, width = 12,
                concept_note(
                  tags$strong("What this shows: "),
                  "A conceptual risk index (0-100, higher = greater elevated mental-health risk in the ",
                  "population) from 8 weeks before birth to 24 months after. The grey line is standard, ",
                  "unstructured care; the teal line is continuous, layered support of the kind described in ",
                  "this app. Markers on the teal line are the intervention points below - ",
                  tags$strong("click a marker to see its evidence and rationale."),
                  " Both curves still show a rise around the return-to-work transition (~week 52), because ",
                  "that transition carries real risk regardless of support - the difference support makes is ",
                  "in the height of that rise and how quickly it comes back down."
                ),
                plotly::plotlyOutput(ns("intervention_plot"), height = "420px")
              )
            ),

            fluidRow(
              box(title = "Intervention Detail", status = "warning", solidHeader = TRUE, width = 12,
                uiOutput(ns("intervention_detail"))
              )
            ),

            reference_panel_ui(c("dennis2013", "cox1987"))
          )
        )
      )
    )
  )
}
