/*
 * ============================================================================
 * ARDUINO MEGA 2560 - SERVO CONTROLLER
 * ============================================================================
 * Receives serial commands from Jetson Nano via USB
 * Controls single servo on Pin 9
 * Baud rate: 115200
 * ============================================================================
 */

#include <Servo.h>

// ============================================================================
// CONFIGURATION
// ============================================================================
#define SERVO_PIN 9           // Servo connected to Pin 9
#define BAUD_RATE 115200      // Serial communication speed
#define LED_PIN 13            // Built-in LED for status indication

// ============================================================================
// GLOBAL OBJECTS
// ============================================================================
Servo steeringServo;          // Servo object
int currentAngle = 90;        // Current servo position (starts at center)
String inputString = "";      // String to hold incoming serial data
boolean stringComplete = false;

// ============================================================================
// SETUP - Runs once on startup
// ============================================================================
void setup() {
  // Initialize serial communication
  Serial.begin(BAUD_RATE);
  
  // Initialize LED pin
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  
  // Attach servo to pin
  steeringServo.attach(SERVO_PIN);
  
  // Set servo to center position (90 degrees)
  steeringServo.write(90);
  currentAngle = 90;
  
  // Reserve 200 bytes for the input string
  inputString.reserve(200);
  
  // Startup indication - blink LED 3 times
  for(int i = 0; i < 3; i++) {
    digitalWrite(LED_PIN, HIGH);
    delay(200);
    digitalWrite(LED_PIN, LOW);
    delay(200);
  }
  
  // Send ready message
  Serial.println("ARDUINO:READY");
  Serial.println("SERVO:INITIALIZED");
  Serial.print("ANGLE:");
  Serial.println(currentAngle);
}

// ============================================================================
// MAIN LOOP - Runs continuously
// ============================================================================
void loop() {
  // Check if a complete command has been received
  if (stringComplete) {
    processCommand(inputString);
    
    // Clear the string for next command
    inputString = "";
    stringComplete = false;
  }
}

// ============================================================================
// SERIAL EVENT - Called when data arrives
// ============================================================================
void serialEvent() {
  while (Serial.available()) {
    // Read incoming byte
    char inChar = (char)Serial.read();
    
    // Add character to input string
    inputString += inChar;
    
    // Check if we received a newline (end of command)
    if (inChar == '\n') {
      stringComplete = true;
    }
  }
}

// ============================================================================
// PROCESS COMMAND - Parse and execute received commands
// ============================================================================
void processCommand(String command) {
  // Remove whitespace and newline characters
  command.trim();
  
  // Blink LED to indicate command received
  digitalWrite(LED_PIN, HIGH);
  
  // ========================================
  // PING command - Connection test
  // ========================================
  if (command.equals("PING")) {
    Serial.println("PONG");
    digitalWrite(LED_PIN, LOW);
    return;
  }
  
  // ========================================
  // STATUS command - Report current state
  // ========================================
  if (command.equals("STATUS")) {
    Serial.print("STATUS:");
    Serial.print(currentAngle);
    Serial.print(",");
    Serial.println(steeringServo.attached() ? "ATTACHED" : "DETACHED");
    digitalWrite(LED_PIN, LOW);
    return;
  }
  
  // ========================================
  // SERVO command - Format: SERVO:angle
  // ========================================
  if (command.startsWith("SERVO:")) {
    // Extract angle value
    int colonIndex = command.indexOf(':');
    if (colonIndex > 0) {
      String angleStr = command.substring(colonIndex + 1);
      int targetAngle = angleStr.toInt();
      
      // Validate angle range (0-180)
      if (targetAngle >= 0 && targetAngle <= 180) {
        // Move servo to target angle
        steeringServo.write(targetAngle);
        currentAngle = targetAngle;
        
        // Send confirmation
        Serial.print("OK:SERVO:");
        Serial.println(targetAngle);
        
        // Visual feedback based on position
        if (targetAngle < 45) {
          // Full left - fast blink
          for(int i = 0; i < 3; i++) {
            digitalWrite(LED_PIN, HIGH);
            delay(50);
            digitalWrite(LED_PIN, LOW);
            delay(50);
          }
        } else if (targetAngle > 135) {
          // Full right - fast blink
          for(int i = 0; i < 3; i++) {
            digitalWrite(LED_PIN, HIGH);
            delay(50);
            digitalWrite(LED_PIN, LOW);
            delay(50);
          }
        } else if (targetAngle >= 85 && targetAngle <= 95) {
          // Center - solid on briefly
          digitalWrite(LED_PIN, HIGH);
          delay(300);
          digitalWrite(LED_PIN, LOW);
        } else {
          // Slight turn - single blink
          digitalWrite(LED_PIN, HIGH);
          delay(150);
          digitalWrite(LED_PIN, LOW);
        }
      } else {
        // Invalid angle
        Serial.print("ERROR:ANGLE_OUT_OF_RANGE:");
        Serial.println(targetAngle);
        digitalWrite(LED_PIN, LOW);
      }
    } else {
      Serial.println("ERROR:INVALID_COMMAND_FORMAT");
      digitalWrite(LED_PIN, LOW);
    }
    return;
  }
  
  // ========================================
  // CENTER command - Move to 90 degrees
  // ========================================
  if (command.equals("CENTER")) {
    steeringServo.write(90);
    currentAngle = 90;
    Serial.println("OK:CENTER:90");
    digitalWrite(LED_PIN, HIGH);
    delay(300);
    digitalWrite(LED_PIN, LOW);
    return;
  }
  
  // ========================================
  // DETACH command - Release servo
  // ========================================
  if (command.equals("DETACH")) {
    steeringServo.detach();
    Serial.println("OK:DETACHED");
    digitalWrite(LED_PIN, LOW);
    return;
  }
  
  // ========================================
  // ATTACH command - Re-attach servo
  // ========================================
  if (command.equals("ATTACH")) {
    steeringServo.attach(SERVO_PIN);
    steeringServo.write(currentAngle);
    Serial.println("OK:ATTACHED");
    digitalWrite(LED_PIN, HIGH);
    delay(200);
    digitalWrite(LED_PIN, LOW);
    return;
  }
  
  // ========================================
  // Unknown command
  // ========================================
  Serial.print("ERROR:UNKNOWN_COMMAND:");
  Serial.println(command);
  digitalWrite(LED_PIN, LOW);
}

/*
 * ============================================================================
 * COMMAND REFERENCE
 * ============================================================================
 * 
 * PING               → Returns "PONG" (connection test)
 * STATUS             → Returns "STATUS:angle,ATTACHED" (current state)
 * SERVO:angle        → Move servo to specified angle (0-180)
 *                      Returns "OK:SERVO:angle"
 * CENTER             → Move servo to 90 degrees
 *                      Returns "OK:CENTER:90"
 * ATTACH             → Attach servo to pin (if detached)
 * DETACH             → Detach servo from pin (stop PWM signal)
 * 
 * ============================================================================
 * LED FEEDBACK
 * ============================================================================
 * 
 * Startup:           3 blinks (200ms each)
 * Command received:  LED on during processing
 * Full left/right:   3 fast blinks (50ms)
 * Center:            Solid on 300ms
 * Slight turn:       Single blink 150ms
 * 
 * ============================================================================
 */
