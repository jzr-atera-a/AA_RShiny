# ==============================================================================
# PHASE 2: ARDUINO INTEGRATION - Complete Setup Instructions
# ==============================================================================
# Adding Arduino Mega servo control to the WiFi robot system
# ==============================================================================

## OVERVIEW
Now we're adding the final piece: Arduino Mega controlling the actual servo!

Architecture:
R Shiny (PC) → WiFi → Jetson Nano → USB Serial → Arduino Mega → PWM → Servo

## PART 1: INSTALL PYSERIAL ON JETSON NANO
## ==============================================================================

### On Jetson Nano terminal:

```bash
# Install PySerial
pip3 install pyserial

# Verify installation
python3 -c "import serial; print('PySerial version:', serial.__version__)"

# Add user to dialout group (required for serial port access)
sudo usermod -a -G dialout $USER

# You may need to log out and log back in for group changes to take effect
# Or reboot the Jetson Nano
```

### Check if Arduino is detected:

```bash
# Before connecting Arduino
ls /dev/tty*

# Connect Arduino Mega via USB to Jetson Nano

# After connecting Arduino - look for new device
ls /dev/tty*

# Usually appears as:
# /dev/ttyACM0  (most common for Arduino Mega)
# OR
# /dev/ttyUSB0  (some USB adapters)
```

### Give permissions to the port (if needed):

```bash
sudo chmod 666 /dev/ttyACM0

# Or permanently:
sudo usermod -a -G dialout $USER
```

## PART 2: UPLOAD ARDUINO CODE
## ==============================================================================

### Option A: Using Arduino IDE on Jetson Nano

If Arduino IDE is already installed:

1. Open Arduino IDE on Jetson Nano
2. Copy the code from `arduino_servo_controller.ino`
3. Connect Arduino Mega via USB
4. Tools → Board → Arduino Mega 2560
5. Tools → Port → /dev/ttyACM0 (or the port you found)
6. Click Upload button (→)
7. Wait for "Done uploading"

### Option B: Using Arduino IDE on Windows PC

1. Connect Arduino Mega to Windows PC (temporarily)
2. Open Arduino IDE on Windows
3. Open `arduino_servo_controller.ino`
4. Tools → Board → Arduino Mega 2560
5. Tools → Port → COM# (whatever shows up)
6. Upload
7. After upload, disconnect from PC
8. Connect Arduino to Jetson Nano via USB

### Verify Arduino Code is Running:

After upload, open Serial Monitor (Tools → Serial Monitor)
- Set baud rate to 115200
- You should see:
  ```
  ARDUINO:READY
  SERVO:INITIALIZED
  ANGLE:90
  ```

## PART 3: HARDWARE CONNECTIONS
## ==============================================================================

### Power Setup (Your Option 2):

```
9V Barrel Jack → Arduino Mega VIN
                    ↓
             Onboard 5V regulator
                    ↓
Arduino 5V pin → Servo RED wire (Power)
Arduino GND    → Servo BLACK/BROWN wire (Ground)
Arduino Pin 9  → Servo YELLOW/WHITE wire (Signal)

USB Cable: Arduino Mega ←→ Jetson Nano (Data only)
```

### Wiring Checklist:

□ Servo RED (power) → Arduino 5V pin
□ Servo BLACK/BROWN (ground) → Arduino GND
□ Servo YELLOW/WHITE (signal) → Arduino Pin 9
□ Arduino 9V barrel jack connected
□ Arduino USB cable to Jetson Nano
□ Jetson Nano powered on and connected to WiFi

## PART 4: RUN THE FULL SYSTEM
## ==============================================================================

### Step 1: Stop the old Jetson server (if running)

If the WiFi test server is still running:
- Go to Jetson terminal
- Press Ctrl+C to stop it

### Step 2: Run the new full server on Jetson Nano

```bash
cd ~
python3 jetson_api_server_full.py
```

### Expected Output:

```
======================================================================
║  JETSON NANO FLASK API SERVER - Full Version
======================================================================
║  Host: 0.0.0.0
║  Port: 5000
║  Arduino Port: /dev/ttyACM0
║  Baud Rate: 115200
======================================================================
║  Initializing Arduino connection...
║
[2025-01-02 12:30:45] [INFO] Attempting to connect to Arduino on /dev/ttyACM0...
[2025-01-02 12:30:45] [INFO] Waiting for Arduino to initialize...
[2025-01-02 12:30:47] [SUCCESS] ✓ Arduino connected successfully!
[2025-01-02 12:30:47] [SUCCESS] ✓ Response: PONG
======================================================================
║  STATUS: Arduino connected ✓
======================================================================
║  Waiting for commands from R Shiny app...
```

If you see "✓ Arduino connected", you're ready!

### Step 3: Update and run R Shiny app on Windows

1. Close the old R Shiny app if running
2. Use the updated `servo_control_dashboard_FINAL.R`
3. Run it in RStudio
4. Should automatically connect to your Jetson IP

### Step 4: Test the complete system!

IN R SHINY APP:

1. Click "Connection Test" tab
2. Click "TEST CONNECTION" → Should show ✓ Connected
3. Go to "Control Panel" tab
4. Move slider to 45° (slight left)
5. Click "SEND TO SERVO"

EXPECTED RESULTS:

**On R Shiny:**
- Green notification: "Command sent successfully!"
- Status box shows: "● CONNECTED"
- Last Command: "SERVO 45°"
- Response shows: "Arduino: OK:SERVO:45"

**On Jetson Nano terminal:**
```
============================================================
║ COMMAND RECEIVED FROM R SHINY APP
============================================================
║ Command: SERVO
║ Angle: 45°
║ Direction: ◄ SLIGHT LEFT
║ Timestamp: 12:35:22.456
║------------------------------------------------------------
║ Arduino Response: OK:SERVO:45
============================================================

[2025-01-02 12:35:22] [INFO] → Sent to Arduino: SERVO:45
[2025-01-02 12:35:22] [INFO] ← Arduino response: OK:SERVO:45
```

**On Arduino:**
- Onboard LED (Pin 13) blinks when command received
- **SERVO PHYSICALLY MOVES TO 45°!** 🎉

## PART 5: TESTING DIFFERENT POSITIONS
## ==============================================================================

Try these test sequences:

### Test 1: Center Position
- Slider to 90°
- Click "CENTER (90°)" button OR "SEND TO SERVO"
- Servo should move to center
- Arduino LED: Solid on for 300ms

### Test 2: Full Left
- Slider to 0°
- Click "FULL LEFT (0°)" button OR "SEND TO SERVO"
- Servo should move fully left
- Arduino LED: 3 fast blinks

### Test 3: Full Right
- Slider to 180°
- Click "FULL RIGHT (180°)" button OR "SEND TO SERVO"
- Servo should move fully right
- Arduino LED: 3 fast blinks

### Test 4: Smooth Sweep
- Manually move slider: 0° → 45° → 90° → 135° → 180°
- Click "SEND TO SERVO" after each position
- Watch servo smoothly move through positions

## PART 6: TROUBLESHOOTING
## ==============================================================================

### Problem: "Arduino not connected" error

**Check 1: Verify Arduino is detected**
```bash
ls /dev/ttyACM*
# Should show /dev/ttyACM0
```

**Check 2: Test Arduino directly**
```bash
# Install screen utility
sudo apt-get install screen

# Connect to Arduino
screen /dev/ttyACM0 115200

# Type: PING
# Press Enter
# Should see: PONG

# Exit: Ctrl+A then K then Y
```

**Check 3: Permissions**
```bash
sudo chmod 666 /dev/ttyACM0
groups
# Should include "dialout"
```

**Check 4: Check if port is in use**
```bash
sudo lsof /dev/ttyACM0
# Should show python3 process or nothing
```

### Problem: Servo doesn't move

**Check 1: Power**
- Is 9V barrel jack connected to Arduino?
- Is Arduino power LED on?

**Check 2: Wiring**
- Servo RED to Arduino 5V? (NOT 3.3V!)
- Servo BLACK to Arduino GND?
- Servo SIGNAL to Pin 9?

**Check 3: Test servo with Arduino Serial Monitor**
- Open Arduino IDE Serial Monitor
- Set baud to 115200
- Type: SERVO:90
- Press Send
- Servo should move to center

**Check 4: Servo type**
- Is it a standard hobby servo (0-180°)?
- Or continuous rotation servo (90=stop)?
- For continuous rotation: 0=full reverse, 90=stop, 180=full forward

### Problem: Connection drops / timeouts

**Solution 1: Keep both terminals open**
- Jetson terminal with server running
- Don't minimize or close it

**Solution 2: Check WiFi**
- Both PC and Jetson on same network
- Stable WiFi signal

**Solution 3: Increase timeout**
- Edit Flask server: change `SERIAL_TIMEOUT = 2` to `= 5`

### Problem: Serial port changes to /dev/ttyUSB0

**Solution:**
Edit `jetson_api_server_full.py`:
```python
ARDUINO_PORT = '/dev/ttyUSB0'  # Change from /dev/ttyACM0
```

Or create a udev rule for persistent naming (advanced).

## PART 7: QUICK REFERENCE
## ==============================================================================

### Start the system:

```bash
# On Jetson Nano:
cd ~
python3 jetson_api_server_full.py

# On Windows PC (in R):
shiny::runApp("servo_control_dashboard_FINAL.R")
```

### Stop the system:

```bash
# On Jetson Nano:
Press Ctrl+C in terminal

# On Windows PC:
Close R Shiny app window or stop in RStudio
```

### Check Arduino connection:

```bash
# Quick test
ls /dev/ttyACM*

# Detailed test
python3 -c "import serial; s=serial.Serial('/dev/ttyACM0',115200,timeout=1); s.write(b'PING\n'); import time; time.sleep(0.1); print(s.readline())"
```

### Arduino LED patterns:

- 3 blinks at startup = Arduino ready
- Single blink = Command received
- 3 fast blinks = Full left/right turn
- Solid 300ms = Center position

## PART 8: WHAT'S NEXT?
## ==============================================================================

Now that basic servo control works, you can:

✓ Add the other 3 servos (right motor, head, arm)
✓ Integrate the CSI cameras
✓ Add LiDAR sensor
✓ Implement autonomous navigation
✓ Add VR headset control
✓ Create complex movement patterns

But first - enjoy controlling your servo via WiFi! 🎉

## ==============================================================================
## END OF ARDUINO INTEGRATION INSTRUCTIONS
## ==============================================================================
