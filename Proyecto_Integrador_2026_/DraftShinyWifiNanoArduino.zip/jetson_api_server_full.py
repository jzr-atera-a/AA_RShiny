#!/usr/bin/env python3
"""
==============================================================================
JETSON NANO - FLASK API SERVER (Full Version with Arduino)
==============================================================================
Receives HTTP commands from R Shiny app via WiFi
Sends serial commands to Arduino Mega via USB
Controls servo via Arduino
==============================================================================
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import serial
import time
import sys
from datetime import datetime
import threading

# ==============================================================================
# CONFIGURATION
# ==============================================================================
FLASK_HOST = '0.0.0.0'  # Listen on all network interfaces
FLASK_PORT = 5000
ARDUINO_PORT = '/dev/ttyACM0'  # USB connection to Arduino
ARDUINO_BAUD = 115200
SERIAL_TIMEOUT = 2  # Seconds to wait for Arduino response

# ==============================================================================
# FLASK APP INITIALIZATION
# ==============================================================================
app = Flask(__name__)
CORS(app)  # Enable cross-origin requests

# ==============================================================================
# GLOBAL STATE
# ==============================================================================
system_state = {
    'connected': True,
    'last_command': 'None',
    'last_angle': 90,
    'arduino_connected': False,
    'arduino_response': 'No response',
    'command_count': 0,
    'start_time': time.time(),
    'serial_error': None
}

# Global serial connection (will be initialized in main)
arduino_serial = None
serial_lock = threading.Lock()  # Thread safety for serial communication

# ==============================================================================
# HELPER FUNCTIONS
# ==============================================================================
def log_message(message, level='INFO'):
    """Print timestamped log messages to console"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] [{level}] {message}")
    sys.stdout.flush()

def print_command_box(command, angle=None, arduino_response=None):
    """Display command in a nice box format on terminal"""
    print("\n" + "="*70)
    print("║ COMMAND RECEIVED FROM R SHINY APP")
    print("="*70)
    print(f"║ Command: {command}")
    if angle is not None:
        print(f"║ Angle: {angle}°")
        
        # Visual representation
        if angle < 45:
            direction = "◄◄◄ FULL LEFT"
        elif angle < 85:
            direction = "◄ SLIGHT LEFT"
        elif angle <= 95:
            direction = "■ CENTER"
        elif angle <= 135:
            direction = "SLIGHT RIGHT ►"
        else:
            direction = "FULL RIGHT ►►►"
        
        print(f"║ Direction: {direction}")
    
    print(f"║ Timestamp: {datetime.now().strftime('%H:%M:%S.%f')[:-3]}")
    
    if arduino_response:
        print("║" + "-"*68)
        print(f"║ Arduino Response: {arduino_response}")
    
    print("="*70 + "\n")
    sys.stdout.flush()

def initialize_arduino():
    """Initialize serial connection to Arduino"""
    global arduino_serial, system_state
    
    try:
        log_message(f"Attempting to connect to Arduino on {ARDUINO_PORT}...")
        
        # Open serial connection
        arduino_serial = serial.Serial(
            port=ARDUINO_PORT,
            baudrate=ARDUINO_BAUD,
            timeout=SERIAL_TIMEOUT,
            write_timeout=SERIAL_TIMEOUT
        )
        
        # Wait for Arduino to reset after serial connection
        log_message("Waiting for Arduino to initialize...")
        time.sleep(2)
        
        # Clear any startup messages
        arduino_serial.reset_input_buffer()
        
        # Send PING to verify connection
        arduino_serial.write(b"PING\n")
        time.sleep(0.1)
        
        response = ""
        if arduino_serial.in_waiting > 0:
            response = arduino_serial.readline().decode('utf-8').strip()
        
        if "PONG" in response or arduino_serial.is_open:
            system_state['arduino_connected'] = True
            system_state['serial_error'] = None
            log_message("✓ Arduino connected successfully!", "SUCCESS")
            log_message(f"✓ Response: {response if response else 'Connection established'}")
            return True
        else:
            log_message("⚠ Arduino not responding to PING", "WARNING")
            system_state['arduino_connected'] = True  # Still mark as connected
            return True
            
    except serial.SerialException as e:
        error_msg = f"Serial connection error: {str(e)}"
        log_message(error_msg, "ERROR")
        system_state['arduino_connected'] = False
        system_state['serial_error'] = str(e)
        return False
    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        log_message(error_msg, "ERROR")
        system_state['arduino_connected'] = False
        system_state['serial_error'] = str(e)
        return False

def send_to_arduino(command):
    """Send command to Arduino and wait for response"""
    global arduino_serial, system_state
    
    if not system_state['arduino_connected'] or arduino_serial is None:
        return "ERROR:ARDUINO_NOT_CONNECTED"
    
    try:
        with serial_lock:  # Ensure thread-safe serial communication
            # Clear input buffer
            arduino_serial.reset_input_buffer()
            
            # Send command
            command_bytes = (command + "\n").encode('utf-8')
            arduino_serial.write(command_bytes)
            log_message(f"→ Sent to Arduino: {command}")
            
            # Wait for response with timeout
            time.sleep(0.1)  # Brief delay for Arduino to process
            
            response = ""
            start_time = time.time()
            timeout = 2.0  # 2 second timeout
            
            while time.time() - start_time < timeout:
                if arduino_serial.in_waiting > 0:
                    response = arduino_serial.readline().decode('utf-8').strip()
                    break
                time.sleep(0.05)
            
            if response:
                log_message(f"← Arduino response: {response}")
                system_state['arduino_response'] = response
                return response
            else:
                log_message("⚠ No response from Arduino", "WARNING")
                return "NO_RESPONSE"
                
    except serial.SerialException as e:
        error_msg = f"Serial error: {str(e)}"
        log_message(error_msg, "ERROR")
        system_state['arduino_connected'] = False
        return f"ERROR:{str(e)}"
    except Exception as e:
        error_msg = f"Error communicating with Arduino: {str(e)}"
        log_message(error_msg, "ERROR")
        return f"ERROR:{str(e)}"

# ==============================================================================
# API ENDPOINTS
# ==============================================================================

@app.route('/')
def index():
    """Root endpoint - API info"""
    return jsonify({
        'status': 'online',
        'message': 'Jetson Nano Flask API Server - Full Version',
        'version': '2.0 (Arduino Integrated)',
        'arduino_connected': system_state['arduino_connected'],
        'endpoints': [
            '/ping',
            '/status',
            '/test',
            '/servo'
        ],
        'uptime_seconds': round(time.time() - system_state['start_time'], 2)
    })

@app.route('/ping', methods=['GET'])
def ping():
    """Ping endpoint for connection testing"""
    log_message("PING received from R Shiny app")
    
    return jsonify({
        'status': 'success',
        'message': 'pong',
        'server': 'Jetson Nano',
        'timestamp': time.time(),
        'arduino_ready': system_state['arduino_connected']
    })

@app.route('/status', methods=['GET'])
def get_status():
    """Get current system status"""
    log_message("STATUS request received")
    
    uptime = time.time() - system_state['start_time']
    
    return jsonify({
        'status': 'success',
        'connected': system_state['connected'],
        'arduino_connected': system_state['arduino_connected'],
        'last_command': system_state['last_command'],
        'last_angle': system_state['last_angle'],
        'arduino_response': system_state['arduino_response'],
        'command_count': system_state['command_count'],
        'uptime_seconds': round(uptime, 2),
        'serial_error': system_state['serial_error'],
        'timestamp': time.time()
    })

@app.route('/test', methods=['POST'])
def test_command():
    """
    Test endpoint - receives servo commands but doesn't send to Arduino
    For backward compatibility with WiFi testing
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'status': 'error', 'message': 'No data received'}), 400
        
        command = data.get('command', 'UNKNOWN')
        angle = data.get('angle', None)
        
        system_state['last_command'] = command
        if angle is not None:
            system_state['last_angle'] = angle
        system_state['command_count'] += 1
        
        print_command_box(command, angle)
        
        response_data = {
            'status': 'success',
            'message': f'Test command received: {command} at {angle}°',
            'command': command,
            'angle': angle,
            'arduino_sent': False,
            'display_only': True,
            'command_count': system_state['command_count'],
            'timestamp': time.time()
        }
        
        return jsonify(response_data), 200
        
    except Exception as e:
        error_msg = f"Error processing test command: {str(e)}"
        log_message(error_msg, "ERROR")
        return jsonify({'status': 'error', 'message': error_msg}), 500

@app.route('/servo', methods=['POST'])
def control_servo():
    """
    Main servo control endpoint
    Receives angle from R Shiny and sends to Arduino
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'status': 'error', 'message': 'No data received'}), 400
        
        # Extract angle from request
        angle = data.get('angle', None)
        
        if angle is None:
            return jsonify({'status': 'error', 'message': 'Angle not specified'}), 400
        
        # Validate angle range
        if not (0 <= angle <= 180):
            return jsonify({
                'status': 'error',
                'message': f'Angle out of range: {angle} (must be 0-180)'
            }), 400
        
        # Check Arduino connection
        if not system_state['arduino_connected']:
            return jsonify({
                'status': 'error',
                'message': 'Arduino not connected',
                'serial_error': system_state['serial_error']
            }), 503
        
        # Update state
        system_state['last_command'] = 'SERVO'
        system_state['last_angle'] = angle
        system_state['command_count'] += 1
        
        # Send command to Arduino
        arduino_command = f"SERVO:{angle}"
        arduino_response = send_to_arduino(arduino_command)
        
        # Display on terminal
        print_command_box('SERVO', angle, arduino_response)
        
        # Check if command was successful
        success = "OK:SERVO" in arduino_response
        
        response_data = {
            'status': 'success' if success else 'warning',
            'message': f'Servo command sent: {angle}°',
            'command': 'SERVO',
            'angle': angle,
            'arduino_sent': True,
            'arduino_response': arduino_response,
            'command_count': system_state['command_count'],
            'timestamp': time.time()
        }
        
        return jsonify(response_data), 200
        
    except Exception as e:
        error_msg = f"Error controlling servo: {str(e)}"
        log_message(error_msg, "ERROR")
        return jsonify({'status': 'error', 'message': error_msg}), 500

@app.route('/arduino/ping', methods=['GET'])
def ping_arduino():
    """Test Arduino connection"""
    if not system_state['arduino_connected']:
        return jsonify({
            'status': 'error',
            'message': 'Arduino not connected'
        }), 503
    
    response = send_to_arduino("PING")
    
    return jsonify({
        'status': 'success',
        'arduino_response': response,
        'timestamp': time.time()
    })

# ==============================================================================
# STARTUP BANNER
# ==============================================================================
def print_startup_banner():
    """Display startup information"""
    print("\n" + "="*70)
    print("║")
    print("║  JETSON NANO FLASK API SERVER - Full Version")
    print("║")
    print("="*70)
    print(f"║  Host: {FLASK_HOST}")
    print(f"║  Port: {FLASK_PORT}")
    print(f"║  Arduino Port: {ARDUINO_PORT}")
    print(f"║  Baud Rate: {ARDUINO_BAUD}")
    print("="*70)
    print("║")
    print("║  Initializing Arduino connection...")
    print("║")
    sys.stdout.flush()

# ==============================================================================
# MAIN ENTRY POINT
# ==============================================================================
if __name__ == '__main__':
    print_startup_banner()
    
    # Initialize Arduino connection
    arduino_connected = initialize_arduino()
    
    if arduino_connected:
        print("="*70)
        print("║")
        print("║  STATUS: Arduino connected ✓")
        print("║")
    else:
        print("="*70)
        print("║")
        print("║  WARNING: Arduino not connected ⚠")
        print("║  Server will still run, but servo control unavailable")
        print("║")
        if system_state['serial_error']:
            print(f"║  Error: {system_state['serial_error']}")
            print("║")
    
    print("="*70)
    print("║")
    print("║  Available endpoints:")
    print("║    - GET  /            → API info")
    print("║    - GET  /ping        → Connection test")
    print("║    - GET  /status      → System status")
    print("║    - POST /test        → Test commands (WiFi only)")
    print("║    - POST /servo       → Control servo via Arduino")
    print("║    - GET  /arduino/ping → Test Arduino connection")
    print("║")
    print("="*70)
    print("║")
    print("║  Waiting for commands from R Shiny app...")
    print("║")
    print("="*70 + "\n")
    sys.stdout.flush()
    
    log_message("Flask server starting...")
    
    try:
        # Start Flask server
        app.run(
            host=FLASK_HOST,
            port=FLASK_PORT,
            debug=False,
            threaded=True
        )
    except KeyboardInterrupt:
        log_message("\n\nServer stopped by user (Ctrl+C)")
        
        # Close Arduino connection gracefully
        if arduino_serial and arduino_serial.is_open:
            log_message("Closing Arduino connection...")
            arduino_serial.close()
        
        print("\n" + "="*70)
        print("║  Server shutdown complete")
        print("="*70 + "\n")
    except Exception as e:
        log_message(f"Server error: {str(e)}", "ERROR")
        
        # Close Arduino connection on error
        if arduino_serial and arduino_serial.is_open:
            arduino_serial.close()
        
        sys.exit(1)
