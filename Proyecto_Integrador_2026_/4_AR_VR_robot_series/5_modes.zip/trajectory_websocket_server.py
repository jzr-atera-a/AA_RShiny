#!/usr/bin/env python3
"""
Jetson Nano WebSocket Server - AR Robot Control (5 Modes)
Handles commands from Quest 3 trajectory_5modes.html

  Mode 1 – Manual Control        : MODE_SELECTED only
  Mode 2 – User Trajectory       : GENERATE_COMMANDS  → streams motor/servo commands
  Mode 3 – M25 Highway           : EXECUTE_M25        → auto-runs M25 loop, streams M25_COMMAND
  Mode 4 – Track Robot (Ctrl)    : ROBOT_POSITION     → logs Kalman-filtered controller pose
  Mode 5 – Spatial Anchor Track  : ANCHOR_POSITION    → logs placed anchor position

WebSocket: wss://0.0.0.0:8443  (WSS, self-signed cert)
"""

import asyncio
import websockets
import ssl
import json
import os
import sys
import math
import csv
from datetime import datetime

# ── CONFIG ─────────────────────────────────────────────────────────────────────
HOST = '0.0.0.0'
PORT = 8443
CERT_FILE = 'cert.pem'
KEY_FILE  = 'key.pem'

# Robot hardware limits
SERVO2_CENTER = 90    # degrees (straight ahead)
SERVO2_MIN    = 50
SERVO2_MAX    = 130
MOTOR_MIN     = 50    # MD22 power  (0–128)
MOTOR_MAX     = 90
MOTOR_STOP    = 0
COMMAND_RATE  = 5     # Hz
WHEELBASE     = 0.34  # metres (34 cm)

# ── STATE ──────────────────────────────────────────────────────────────────────
connected_clients: set = set()
start_time = datetime.now()

# ══════════════════════════════════════════════════════════════════════════════
# COMMAND GENERATION  (Modes 2 & 3)
# ══════════════════════════════════════════════════════════════════════════════

def calculate_curvature(p1, p2, p3):
    """Circumradius of the triangle p1-p2-p3 (metres)."""
    a = math.hypot(p2['x'] - p1['x'], p2['z'] - p1['z'])
    b = math.hypot(p3['x'] - p2['x'], p3['z'] - p2['z'])
    c = math.hypot(p3['x'] - p1['x'], p3['z'] - p1['z'])
    if a < 0.001 or b < 0.001 or c < 0.001:
        return float('inf')
    s = (a + b + c) / 2
    area_sq = s * (s - a) * (s - b) * (s - c)
    if area_sq <= 0:
        return float('inf')
    area = math.sqrt(area_sq)
    curvature = (4 * area) / (a * b * c)
    return float('inf') if curvature == 0 else 1.0 / curvature


def curvature_to_servo(radius):
    """Ackermann steering: curvature radius → servo angle (degrees)."""
    if radius > 100:
        return SERVO2_CENTER
    angle_deg = math.degrees(math.atan2(WHEELBASE, radius))
    servo = SERVO2_CENTER + int(angle_deg * 2)
    return max(SERVO2_MIN, min(SERVO2_MAX, servo))


def motor_speed(distance_remaining):
    """Ramp motor power down near end of trajectory."""
    if distance_remaining < 0.5:
        return MOTOR_MIN
    elif distance_remaining < 1.0:
        return int(MOTOR_MIN + (MOTOR_MAX - MOTOR_MIN) * 0.5)
    return MOTOR_MAX


def generate_commands(points):
    """Generate 5 Hz robot command list from a list of {x, y, z} dicts."""
    if len(points) < 2:
        return []

    # Total arc length
    total_dist = sum(
        math.hypot(points[i]['x'] - points[i-1]['x'],
                   points[i]['z'] - points[i-1]['z'])
        for i in range(1, len(points))
    )

    avg_speed  = 0.15                           # m/s assumed
    total_time = total_dist / avg_speed
    n_cmds     = max(1, int(total_time * COMMAND_RATE))

    print(f"\n{'='*80}")
    print(f"  GENERATING COMMANDS  |  dist={total_dist:.2f}m  "
          f"est={total_time:.1f}s  cmds={n_cmds}")
    print(f"{'='*80}\n")

    commands = []
    for idx in range(n_cmds):
        target_d = (idx / n_cmds) * total_dist

        # Walk trajectory to find current segment
        seg_d = 0.0
        seg_i = 1
        for i in range(1, len(points)):
            seg_len = math.hypot(points[i]['x'] - points[i-1]['x'],
                                 points[i]['z'] - points[i-1]['z'])
            if seg_d + seg_len >= target_d:
                seg_i = i
                break
            seg_d += seg_len

        # Curvature from three neighbouring points
        ci = min(seg_i, len(points) - 2)
        if ci >= 1:
            r = calculate_curvature(points[ci-1], points[ci],
                                    points[min(ci+1, len(points)-1)])
            servo = curvature_to_servo(r)
        else:
            servo = SERVO2_CENTER

        dist_remaining = total_dist - target_d
        motor = motor_speed(dist_remaining)
        speed_cms = avg_speed * 100

        commands.append({
            'timestamp':           round(idx / COMMAND_RATE, 3),
            'distance_from_origin': round(target_d, 3),
            'distance_to_end':     round(dist_remaining, 3),
            'speed_cms':           round(speed_cms, 1),
            'servo2':              servo,
            'motor1':              motor,
            'motor2':              motor,
        })

    # Stop command
    commands.append({
        'timestamp':           round(total_time, 3),
        'distance_from_origin': round(total_dist, 3),
        'distance_to_end':     0.0,
        'speed_cms':           0.0,
        'servo2':              SERVO2_CENTER,
        'motor1':              MOTOR_STOP,
        'motor2':              MOTOR_STOP,
    })
    return commands


def save_csv(commands, prefix='robot_commands'):
    """Save command list to a timestamped CSV file."""
    ts  = datetime.now().strftime('%Y%m%d_%H%M%S')
    fn  = f'{prefix}_{ts}.csv'
    fields = ['timestamp', 'distance_from_origin', 'distance_to_end',
              'speed_cms', 'SERVO2', 'MOTOR1', 'MOTOR2']
    with open(fn, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for c in commands:
            w.writerow({
                'timestamp':           c['timestamp'],
                'distance_from_origin': c['distance_from_origin'],
                'distance_to_end':     c['distance_to_end'],
                'speed_cms':           c['speed_cms'],
                'SERVO2':              c['servo2'],
                'MOTOR1':              c['motor1'],
                'MOTOR2':              c['motor2'],
            })
    print(f"  ✓ Saved: {fn}")
    return fn


# ══════════════════════════════════════════════════════════════════════════════
# WEBSOCKET HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def handle_client(websocket, path=None):
    client_ip = getattr(websocket, 'remote_address', ('?',))[0]
    connected_clients.add(websocket)
    print(f"\n✓ Quest 3 connected: {client_ip}  (total={len(connected_clients)})")

    try:
        async for raw in websocket:
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            cmd = data.get('command', '')

            # ── MODE_SELECTED ────────────────────────────────────────────────
            if cmd == 'MODE_SELECTED':
                mode      = data.get('mode', '?')
                mode_name = data.get('mode_name', 'Unknown')
                ts        = data.get('timestamp', 0)
                print(f"\n{'='*60}")
                print(f"  🎮  MODE {mode}: {mode_name}")
                print(f"  t={ts:.0f}ms")
                print(f"{'='*60}\n")
                with open('mode_selections.log', 'a') as f:
                    f.write(f"{datetime.now().isoformat()} – Mode {mode}: {mode_name}\n")

            # ── MODE 2: GENERATE_COMMANDS ────────────────────────────────────
            elif cmd == 'GENERATE_COMMANDS':
                traj = data.get('trajectory', {})
                pts  = traj.get('points', [])
                print(f"\n{'='*60}")
                print(f"  MODE 2 – Trajectory received: {len(pts)} pts  "
                      f"dist={traj.get('distance', 0):.2f}m")
                print(f"{'='*60}\n")

                if len(pts) < 2:
                    continue

                commands = generate_commands(pts)
                csv_file = save_csv(commands)

                await websocket.send(json.dumps({
                    'type':          'commands_ready',
                    'command_count': len(commands),
                    'csv_file':      csv_file,
                }))

                # Stream at 5 Hz
                print(f"  Streaming {len(commands)} commands …\n")
                hdr = f"{'t(s)':>8} {'dOrg':>8} {'dEnd':>8} {'spd':>6} {'SRV':>5} {'M1':>4} {'M2':>4}"
                print(hdr)
                print('-' * len(hdr))
                for c in commands:
                    print(f"{c['timestamp']:8.3f} {c['distance_from_origin']:8.3f} "
                          f"{c['distance_to_end']:8.3f} {c['speed_cms']:6.1f} "
                          f"{c['servo2']:5d} {c['motor1']:4d} {c['motor2']:4d}")
                    await websocket.send(json.dumps({
                        'type':               'command_execute',
                        'timestamp':          c['timestamp'],
                        'speed_cms':          c['speed_cms'],
                        'servo2':             c['servo2'],
                        'motor1':             c['motor1'],
                        'motor2':             c['motor2'],
                        'distance_remaining': c['distance_to_end'],
                    }))
                    # TODO: send to Arduino:
                    # serial_port.write(
                    #     f"S{c['servo2']},M1:{c['motor1']},M2:{c['motor2']}\n".encode()
                    # )
                    await asyncio.sleep(1.0 / COMMAND_RATE)

                await websocket.send(json.dumps({
                    'type':         'execution_complete',
                    'total_commands': len(commands),
                }))
                print(f"\n  ✓ Mode 2 execution complete.\n")

            # ── MODE 3: EXECUTE_M25 ──────────────────────────────────────────
            elif cmd == 'EXECUTE_M25':
                start_loc = data.get('start_location', 'Sevenoaks')
                direction = data.get('direction', 'clockwise')
                print(f"\n{'='*60}")
                print(f"  MODE 3 – M25 from {start_loc} ({direction})")
                print(f"{'='*60}\n")

                try:
                    with open('sample_campus_map.geojson') as f:
                        geojson = json.load(f)

                    m25 = next((ft for ft in geojson['features']
                                if ft['properties'].get('heatmap')), None)
                    if not m25:
                        print("  ⚠ M25 feature not found in GeoJSON")
                        continue

                    coords = m25['geometry']['coordinates']

                    # Find Sevenoaks start index
                    sev = [0.00009, -0.00125]
                    start_idx = min(
                        range(len(coords)),
                        key=lambda i: math.hypot(coords[i][0] - sev[0],
                                                 coords[i][1] - sev[1])
                    )
                    ordered = coords[start_idx:] + coords[:start_idx]

                    # Scale GeoJSON ±0.0015° → AR ±1.5 m
                    scale = 1.5 / 0.0015
                    pts = [{'x': c[0] * scale, 'y': 0.0, 'z': c[1] * scale}
                           for c in ordered]

                    print(f"  Loaded {len(pts)} M25 points (start idx={start_idx})\n")

                    commands = generate_commands(pts)
                    csv_file = save_csv(commands, prefix='m25')

                    await websocket.send(json.dumps({
                        'type':          'm25_ready',
                        'command_count': len(commands),
                        'csv_file':      csv_file,
                    }))

                    # Stream M25_COMMAND messages (Quest 3 feeds 3D chart)
                    print(f"  Streaming {len(commands)} M25 commands …\n")
                    for c in commands:
                        print(f"  t={c['timestamp']:6.1f}s  "
                              f"dEnd={c['distance_to_end']:.2f}m  "
                              f"SRV={c['servo2']}  spd={c['speed_cms']:.1f}cm/s")
                        await websocket.send(json.dumps({
                            'type': 'M25_COMMAND',
                            'data': {
                                'timestamp':       c['timestamp'],
                                'speed_cms':       c['speed_cms'],
                                'distance_to_end': c['distance_to_end'],
                                'servo2':          c['servo2'],
                                'motor1':          c['motor1'],
                                'motor2':          c['motor2'],
                            }
                        }))
                        await asyncio.sleep(1.0 / COMMAND_RATE)

                    print(f"\n  ✓ M25 execution complete.\n")

                except FileNotFoundError:
                    print("  ⚠ sample_campus_map.geojson not found")
                except Exception as e:
                    import traceback
                    print(f"  ⚠ M25 error: {e}")
                    traceback.print_exc()

            # ── MODE 4: ROBOT_POSITION (Kalman-filtered controller) ──────────
            elif cmd == 'ROBOT_POSITION':
                d = data.get('data', {})
                print(f"  [MODE 4]  x={d.get('x_cm'):>7.1f}cm  "
                      f"z={d.get('z_cm'):>7.1f}cm  "
                      f"hdg={d.get('heading_deg'):>6.1f}°  "
                      f"dist={d.get('distance_from_center_cm'):>6.1f}cm  "
                      f"t={d.get('timestamp',0):.2f}s")
                # Append to live log
                with open('robot_tracking.log', 'a') as f:
                    f.write(json.dumps({**d, 'wall_time': datetime.now().isoformat()}) + '\n')
                # TODO: relay position to Arduino for closed-loop correction
                # TODO: echo adjusted target back to Quest 3 if needed

            # ── MODE 4: TRACKING_STOPPED ─────────────────────────────────────
            elif cmd == 'TRACKING_STOPPED':
                print(f"\n  [MODE 4]  ✗ Robot tracking stopped by user.\n")
                with open('mode_selections.log', 'a') as f:
                    f.write(f"{datetime.now().isoformat()} – Mode 4 tracking stopped\n")

            # ── MODE 5: ANCHOR_POSITION ──────────────────────────────────────
            elif cmd == 'ANCHOR_POSITION':
                d = data.get('data', {})
                print(f"  [MODE 5]  anchor  x={d.get('x_cm'):>7.1f}cm  "
                      f"z={d.get('z_cm'):>7.1f}cm  "
                      f"dist={d.get('distance_from_center_cm'):>6.1f}cm  "
                      f"t={d.get('timestamp',0):.2f}s")
                # Append to anchor log
                with open('anchor_tracking.log', 'a') as f:
                    f.write(json.dumps({**d, 'wall_time': datetime.now().isoformat()}) + '\n')
                # TODO: send anchor offset to robot for navigation correction

            else:
                print(f"  [UNKNOWN cmd]  {cmd}")

    except websockets.exceptions.ConnectionClosed:
        pass
    except Exception as e:
        import traceback
        print(f"  ⚠ Client error: {e}")
        traceback.print_exc()
    finally:
        connected_clients.discard(websocket)
        print(f"\n✗ Quest 3 disconnected: {client_ip}  (total={len(connected_clients)})")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

async def main():
    if not os.path.exists(CERT_FILE) or not os.path.exists(KEY_FILE):
        print("=" * 70)
        print("  ERROR: SSL certificates not found!")
        print("=" * 70)
        print("  Generate with:")
        print("  openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem \\")
        print("          -days 365 -nodes -subj '/CN=192.168.100.10'")
        print("=" * 70)
        sys.exit(1)

    ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_ctx.load_cert_chain(CERT_FILE, KEY_FILE)

    print("=" * 70)
    print("  WEBSOCKET SERVER  ─  AR Robot Control (5 Modes)")
    print("=" * 70)
    print(f"\n  Listening:  wss://0.0.0.0:{PORT}")
    print(f"\n  Commands handled:")
    print(f"    MODE_SELECTED      all modes – log mode switch")
    print(f"    GENERATE_COMMANDS  mode 2    – process user trajectory")
    print(f"    EXECUTE_M25        mode 3    – auto-run M25 ring")
    print(f"    ROBOT_POSITION     mode 4    – Kalman controller pose → log")
    print(f"    TRACKING_STOPPED   mode 4    – stop signal from Quest 3")
    print(f"    ANCHOR_POSITION    mode 5    – spatial anchor pose → log")
    print(f"\n  Messages sent to Quest 3:")
    print(f"    commands_ready / command_execute / execution_complete")
    print(f"    m25_ready / M25_COMMAND")
    print(f"\n  Waiting for Quest 3 …")
    print("=" * 70 + "\n")

    async with websockets.serve(handle_client, HOST, PORT, ssl=ssl_ctx):
        await asyncio.Future()   # run forever


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n" + "=" * 70)
        print("  SERVER STOPPED")
        print("=" * 70)
        sys.exit(0)
