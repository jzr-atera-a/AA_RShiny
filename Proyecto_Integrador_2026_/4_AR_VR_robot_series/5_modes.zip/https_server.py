#!/usr/bin/env python3
"""
HTTPS server to serve trajectory_5modes.html to Quest 3
Supports all 5 AR robot control modes
"""

import http.server
import ssl
import os
import sys

HOST = '0.0.0.0'
PORT = 8000
CERT_FILE = 'cert.pem'
KEY_FILE  = 'key.pem'
DEFAULT_PAGE = 'trajectory_5modes.html'


class CORSHandler(http.server.SimpleHTTPRequestHandler):
    """SimpleHTTPRequestHandler with CORS + cache-control headers."""

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def log_message(self, fmt, *args):
        # Suppress noisy 200/304 per-request logs; show errors only
        if str(args[1]) not in ('200', '304'):
            super().log_message(fmt, *args)


def main():
    # ── Certificate check ────────────────────────────────────────────────────
    if not os.path.exists(CERT_FILE) or not os.path.exists(KEY_FILE):
        print("=" * 60)
        print("  ERROR: SSL certificates not found!")
        print("=" * 60)
        print("\n  Generate with:")
        print("  openssl req -x509 -newkey rsa:2048 -keyout key.pem \\")
        print("          -out cert.pem -days 365 -nodes \\")
        print("          -subj '/CN=192.168.100.10'")
        print("=" * 60)
        sys.exit(1)

    # ── HTML check ───────────────────────────────────────────────────────────
    if not os.path.exists(DEFAULT_PAGE):
        print(f"  WARNING: {DEFAULT_PAGE} not found in current directory!")
        print(f"  Ensure this server runs from the folder containing the HTML file.")

    # ── HTTPS server ─────────────────────────────────────────────────────────
    httpd = http.server.HTTPServer((HOST, PORT), CORSHandler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(CERT_FILE, KEY_FILE)
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

    local_ip = '192.168.100.10'

    print("=" * 70)
    print("  HTTPS SERVER  ─  AR Robot Control (5 Modes)")
    print("=" * 70)
    print(f"\n  Serving:  https://{local_ip}:{PORT}/")
    print(f"\n  Quest 3 → open in browser:")
    print(f"    https://{local_ip}:{PORT}/{DEFAULT_PAGE}")
    print()
    print("  Modes served:")
    print("    1  Manual Control          (joystick)")
    print("    2  User Trajectory         (draw with trigger)")
    print("    3  M25 Highway             (auto from Sevenoaks)")
    print("    4  Track Robot (Ctrl)      (left controller + Kalman)")
    print("    5  Spatial Anchor Track    (place anchor on marker)")
    print()
    print("  ⚠️  Accept the self-signed certificate warning on Quest 3")
    print("  WebSocket server should be running on wss://192.168.100.10:8443")
    print("\n  Press Ctrl+C to stop")
    print("=" * 70)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\nHTTPS server stopped.")


if __name__ == '__main__':
    main()
