#!/usr/bin/env python3
"""
HTTPS server for Robot AR WebXR viewer
Serves all files in current directory over HTTPS (required for WebXR on MetaQuest)

Usage:
  python https_server.py                  # Uses default IP: 10.5.21.31
  python https_server.py 192.168.1.50     # Uses custom IP
  python https_server.py --ip 192.168.1.50
  python https_server.py --port 8443      # Custom port (default: 8443)

On MetaQuest Browser, navigate to:
  https://<ip>:<port>/robot_ar_map.html
  (Accept the self-signed certificate warning)
"""

import http.server
import ssl
import os
import sys
import argparse
import socket

# ── DEFAULTS ──────────────────────────────────────────────────────────────────
DEFAULT_IP   = '10.5.21.31'
DEFAULT_PORT = 8443
CERT_FILE    = 'cert.pem'
KEY_FILE     = 'key.pem'
MAIN_HTML    = 'robot_ar_map.html'


def get_local_ip():
    """Auto-detect local IP as fallback."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


def parse_args():
    parser = argparse.ArgumentParser(
        description='HTTPS server for Robot AR WebXR',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument(
        'ip', nargs='?', default=None,
        help=f'Server IP address (default: {DEFAULT_IP})'
    )
    parser.add_argument(
        '--ip', dest='ip_flag', default=None,
        help='Server IP address (alternative flag form)'
    )
    parser.add_argument(
        '--port', '-p', type=int, default=DEFAULT_PORT,
        help=f'Port number (default: {DEFAULT_PORT})'
    )
    parser.add_argument(
        '--auto-ip', action='store_true',
        help='Auto-detect local IP address'
    )
    return parser.parse_args()


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP handler with minimal logging and correct MIME types."""

    def log_message(self, format, *args):
        # Only log non-asset requests
        path = args[0] if args else ''
        if any(ext in str(path) for ext in ['.html', '.py', '.geojson']):
            print(f'  [{self.address_string()}] {format % args}')

    def end_headers(self):
        # Add CORS and security headers needed for WebXR
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        super().end_headers()

    def guess_type(self, path):
        mime, _ = super().guess_type(path)
        if str(path).endswith('.geojson'):
            return 'application/json'
        if str(path).endswith('.stl'):
            return 'model/stl'
        return mime


def main():
    args = parse_args()

    # Resolve IP: positional > --ip flag > auto-detect > default
    if args.auto_ip:
        host_ip = get_local_ip()
        print(f'  Auto-detected IP: {host_ip}')
    elif args.ip:
        host_ip = args.ip
    elif args.ip_flag:
        host_ip = args.ip_flag
    else:
        host_ip = DEFAULT_IP

    port = args.port

    # Change to script directory so relative file paths work
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    # Check certificates
    if not os.path.exists(CERT_FILE) or not os.path.exists(KEY_FILE):
        print('=' * 65)
        print('  ERROR: SSL certificates not found!')
        print('=' * 65)
        print('\n  Generate new certificates with:')
        print()
        print('  Windows (PowerShell):')
        print(f'    openssl req -x509 -newkey rsa:2048 -keyout key.pem \\')
        print(f'            -out cert.pem -days 365 -nodes \\')
        print(f'            -subj "/CN={host_ip}"')
        print()
        print('  OR install OpenSSL for Windows from: https://slproweb.com/products/Win32OpenSSL.html')
        print('=' * 65)
        sys.exit(1)

    # Check main HTML exists
    if not os.path.exists(MAIN_HTML):
        print(f'  WARNING: {MAIN_HTML} not found in {script_dir}')

    # Create and configure HTTPS server
    server_address = ('0.0.0.0', port)
    httpd = http.server.HTTPServer(server_address, QuietHandler)

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(CERT_FILE, KEY_FILE)
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

    url = f'https://{host_ip}:{port}'

    print()
    print('=' * 65)
    print('  🤖  ROBOT AR  —  HTTPS SERVER RUNNING')
    print('=' * 65)
    print()
    print(f'  Server IP   : {host_ip}')
    print(f'  Port        : {port}')
    print(f'  Serving dir : {script_dir}')
    print()
    print('  ─────────────────────────────────────────────────────────')
    print(f'  🥽  MetaQuest URL:')
    print(f'      {url}/{MAIN_HTML}')
    print('  ─────────────────────────────────────────────────────────')
    print()
    print('  ⚠️  On MetaQuest Browser:')
    print('       1. Make sure MetaQuest is on the SAME WiFi network')
    print('       2. Navigate to the URL above')
    print('       3. Tap "Advanced" → "Proceed" to accept the')
    print('          self-signed certificate warning')
    print('       4. Tap  START AR  to begin the AR session')
    print()
    print('  Files available:')
    for f in sorted(os.listdir('.')):
        if not f.startswith('.'):
            size = os.path.getsize(f) // 1024
            print(f'      {url}/{f}  ({size} KB)')
    print()
    print('  Press Ctrl+C to stop')
    print('=' * 65)
    print()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\n\n  Server stopped.\n')


if __name__ == '__main__':
    main()
