# Commodities for Mobility — module package

Everything needed to run or re-integrate the "Commodities for Mobility" sidebar
group (4 tabs: Copper, Lithium Hydroxide, Brent Crude Oil, Approaching the
Unit 1 Questions) from the LAT Trading Analysis F1 app.

## What's in this zip

```
modules/mobility_commodities.R   <- the module itself (UI + server for all 4 tabs)
R/utils_synthetic.R              <- chart engine the module calls (syn_path, syn_chart,
                                     spec_to_plotly, etc.) — pre-existing app file, included
                                     as-is because the module depends on it directly
R/utils_academic.R               <- UI helpers the module calls (ua_intro, ua_task, ua_table,
                                     ua_callout, ua_ref, ua_references) — pre-existing app
                                     file, included as-is for the same reason
www/css/global.css               <- stylesheet defining the .ua-* classes used above
                                     (pre-existing app file, included as-is)
app.R                            <- the FULL app, already wired up — use this if you just
                                     want to run the app as-is
```

`modules/mobility_commodities.R` does not stand alone — it calls functions
defined in the two `R/` files, and its HTML relies on the CSS classes in
`global.css`. All three are included so the module is self-contained if you
want to drop it into a different copy of the app.

## Dependencies used (already present in the app's `library()` calls)

- `shiny`, `shinydashboard`, `plotly`, `shinycssloaders` (`withSpinner`)
- `zoo` (`zoo::rollmean` — moving-average indicator)
- `TTR` (`TTR::RSI`, `TTR::MACD` — indicator panels)

No new packages beyond what the main app already loads.

## How it's wired into `app.R` (if integrating into a fresh copy)

**1. Sidebar — inside `sidebarMenu(...)`, after the "Unit Assignments" `menuItem`:**
```r
menuItem("Commodities for Mobility", icon = icon("car-battery"),
  menuSubItem("Copper",                        tabName = "mobility_copper",   icon = icon("industry")),
  menuSubItem("Lithium Hydroxide",              tabName = "mobility_lithium", icon = icon("car-battery")),
  menuSubItem("Brent Crude Oil",                tabName = "mobility_oil",     icon = icon("oil-can")),
  menuSubItem("Approaching the Unit 1 Questions", tabName = "mobility_approach", icon = icon("route"))
)
```

**2. Tab bodies — inside `tabItems(...)`:**
```r
# -- Commodities for Mobility --
tabItem(tabName = "mobility_copper",   mobility_copper_ui("mobility_commodities")),
tabItem(tabName = "mobility_lithium",  mobility_lithium_ui("mobility_commodities")),
tabItem(tabName = "mobility_oil",      mobility_oil_ui("mobility_commodities")),
tabItem(tabName = "mobility_approach", mobility_approach_ui("mobility_commodities"))
```

**3. Server — inside `server <- function(input, output, session) { ... }`:**
```r
# -- Commodities for Mobility --
mobility_commodities_server("mobility_commodities", data_manager)
```

Note all four UI functions are called with the **same** module id
(`"mobility_commodities"`) — they share one namespace, so the single
`moduleServer()` call above serves outputs to all four tabs even though each
renders in a different `tabItem`.

## Module content summary

- **Copper** (LME), **Lithium Hydroxide** (LME), **Brent Crude Oil** (ICE
  Futures Europe) — three distinct asset classes, each with: a market
  identification table (exchange, contract, ticker, contract unit, trading
  hours), a political-event reaction chart, a macro-data reaction chart, and
  a technical indicator overlay (MA crossover / RSI / MACD respectively).
  All price charts are simulated, seeded, and labelled as illustrative.
- **Approaching the Unit 1 Questions** — a plain-English study guide (not
  filled-in answers) to Unit 1's four tasks, plus 15 verified, clickable
  Harvard-style references to real regulatory, central-bank, and academic
  sources.

## App-wide validation already run on this content

- Bracket balance: clean.
- Every `tabName` in `app.R` appears exactly twice (sidebar ↔ tabItem).
- No `render*`/`reactive()` block in this module calls `get_data()`, so the
  app's `state_trigger()` convention doesn't apply here.
