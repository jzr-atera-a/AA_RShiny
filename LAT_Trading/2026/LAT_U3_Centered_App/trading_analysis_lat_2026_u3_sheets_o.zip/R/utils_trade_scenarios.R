# Claude trade scenarios (Trades tab, above "A. Open a trade"): the saved Morning Sheet + a fresh IG chart screenshot
# -> one BUY and one SELL scenario with entry, stop, limit and an estimated success rate. The user picks one; only
# direction, entry, size, stop and target go into the form (the reasoning boxes stay the user's own words).

tr_scn_morning_text <- function(hdr, lv) {
  f <- function(x) if (is.null(x) || !length(x) || is.na(x[1]) || !nzchar(as.character(x[1]))) "-" else as.character(x[1])
  out <- c(sprintf("Date: %s", f(hdr$sheet_date)),
           sprintf("Dow: %s (%s%%), Nikkei: %s (%s%%)", f(hdr$dow_price), f(hdr$dow_change_pct), f(hdr$nikkei_price), f(hdr$nikkei_change_pct)),
           paste("Overnight news:", f(hdr$overnight_news)), paste("Overnight calendar:", f(hdr$overnight_calendar)),
           paste("Today's releases:", f(hdr$todays_releases)), paste("Releases in the trading window:", f(hdr$releases_in_window)),
           paste("Regime summary:", f(hdr$regime_summary)), paste("Planned set-ups:", f(hdr$planned_setups)),
           paste("Exposure:", f(hdr$exposure_note)), paste("Combined open risk %:", f(hdr$combined_open_risk_pct)))
  if (!is.null(lv) && nrow(lv)) {
    out <- c(out, "Levels (instrument | overnight low | overnight high | current | ADX14 | regime | prior H/L/C | PP R1 S1 R2 S2):")
    for (i in seq_len(nrow(lv))) { r <- lv[i, ]
      out <- c(out, sprintf("%s | %s | %s | %s | %s | %s | %s/%s/%s | %s %s %s %s %s", r$instrument, f(r$overnight_low), f(r$overnight_high), f(r$current_price),
                            f(r$adx14), f(r$regime_label), f(r$prior_high), f(r$prior_low), f(r$prior_close),
                            f(round(r$pivot_pp, 1)), f(round(r$pivot_r1, 1)), f(round(r$pivot_s1, 1)), f(round(r$pivot_r2, 1)), f(round(r$pivot_s2, 1)))) }
  }
  paste(out, collapse = "\n")
}

tr_scn_prompt <- function(asset, price, size, morning_txt, duration_h = NA, notes = "") {
  paste0(
    "You are helping a trading student on an IG DEMO spread-bet account prepare two alternative trade scenarios. ",
    "The image is the student's current IG candle chart of ", asset, ". Prices are IG points.\n\n",
    "Current price (given by the student): ", price, "\nSize: GBP ", size, " per point\n",
    if (is.finite(duration_h)) paste0("Planned holding time: about ", duration_h, " hours\n") else "",
    if (nzchar(notes)) paste0("Student notes: ", notes, "\n") else "",
    "\nThe student's Morning Sheet for today:\n", morning_txt, "\n\n",
    "Read the chart (timeframe, recent swing highs/lows, trend, support and resistance) and use the Morning Sheet levels ",
    "(pivots, prior high/low/close, overnight range, ADX regime, releases in the window).\n",
    "Return ONE BUY scenario and ONE SELL scenario, both entered at the current price. For each give a stop and a limit at ",
    "real chart or sheet levels (a stop is beyond a level, not at it), the reward:risk, the GBP risk and reward at the given size, and an ",
    "estimated probability (0-100) that the limit is hit before the stop. Be honest: the two probabilities may both be low, and say ",
    "which levels you used. Do not invent figures you cannot see.\n",
    "Reply with JSON only, no other text:\n",
    '{"chart_read":"<what you see on the chart, 1-2 sentences>","scenarios":[',
    '{"side":"BUY","entry":0,"stop":0,"limit":0,"reward_risk":0,"risk_gbp":0,"reward_gbp":0,"success_pct":0,"basis":"<levels used and why, 2-3 sentences>","risks":"<main risk, e.g. a release in the window>"},',
    '{"side":"SELL","entry":0,"stop":0,"limit":0,"reward_risk":0,"risk_gbp":0,"reward_gbp":0,"success_pct":0,"basis":"...","risks":"..."}]}')
}

# reply text -> data.frame(side, entry, stop, limit, reward_risk, risk_gbp, reward_gbp, success_pct, basis, risks) + attr chart_read
tr_scn_parse <- function(txt, price = NA, size = NA) {
  j <- tr_parse_vision_json(txt); if (is.null(j) || !length(j$scenarios)) return(NULL)
  n <- function(x) suppressWarnings(as.numeric(if (is.null(x)) NA else x))
  s <- function(x) if (is.null(x)) "" else as.character(x)
  rows <- lapply(j$scenarios, function(z) {
    side <- toupper(s(z$side)); side <- if (grepl("^B", side)) "BUY" else if (grepl("^S", side)) "SELL" else NA
    en <- n(z$entry); if (!is.finite(en) || en == 0) en <- n(price)
    st <- n(z$stop); lm <- n(z$limit)
    risk <- abs(en - st); rew <- abs(lm - en)
    data.frame(side = side, entry = en, stop = st, limit = lm,
               reward_risk = if (is.finite(risk) && risk > 0) round(rew / risk, 2) else n(z$reward_risk),
               risk_gbp = if (is.finite(size)) round(risk * size, 2) else n(z$risk_gbp),
               reward_gbp = if (is.finite(size)) round(rew * size, 2) else n(z$reward_gbp),
               success_pct = n(z$success_pct), basis = s(z$basis), risks = s(z$risks), stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, rows); out <- out[!is.na(out$side), , drop = FALSE]
  # a scenario whose stop/limit are on the wrong side of the entry is flagged
  ok <- ifelse(out$side == "BUY", out$stop < out$entry & out$limit > out$entry, out$stop > out$entry & out$limit < out$entry)
  out$valid <- !is.na(ok) & ok
  attr(out, "chart_read") <- s(j$chart_read)
  if (!nrow(out)) NULL else out
}
