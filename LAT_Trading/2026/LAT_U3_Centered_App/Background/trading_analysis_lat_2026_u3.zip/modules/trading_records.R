# modules/trading_records.R
# Trading Records: durable (BigQuery-backed) record-keeping for the 4-week trading period.
# Morning Sheet, trades (open / manage / partial exit / close), Blotter-style statistics,
# and the schema. (Plan text, reviews and statement import are deliberately not stored here.)
# Storage + maths live in R/utils_trading_records.R. All content is entered by the user.

tr_or <- function(a, b) if (is.null(a) || length(a) == 0 || (length(a) == 1 && is.na(a))) b else a
tr_uk_now <- function() format(Sys.time(), "%H:%M", tz = "Europe/London")
tr_blank_choice <- function(extra = character(0)) c(list(`(blank)` = ""), tr_asset_choices(extra))
tr_contract_choices <- c("Not stated" = "", "Daily funded bet (DFB / Undated)" = "DFB", "Futures (dated)" = "FUTURES")
tr_account_choices <- c("Not stated" = "", "Spread bet" = "SPREAD_BET", "CFD" = "CFD")
tr_device_choices <- c("Typed by hand" = "MANUAL", "Mobile app screenshot" = "mobile", "Desktop website screenshot" = "desktop")
tr_purpose_choices <- c("Choose..." = "", "Assessed trade (Unit 3 trading period)" = "ASSESSED", "Practice trade (not assessed)" = "PRACTICE")
tr_strategies <- c("Pivot Point Bounce" = "PIVOT_BOUNCE", "Holy Grail" = "HOLY_GRAIL", "Straddle" = "STRADDLE", "Other" = "OTHER")
tr_deviations <- c("Moved stop", "Exited early", "Held past target/stop plan", "Entered without full trigger",
                   "Ignored a signal", "Oversized / over risk cap", "Traded during stand-aside", "Other")

tr_lab <- function(x) tags$span(style = "color:#2c3e50; font-weight:600; font-size:12.5px;", x)
tr_h <- function(x) tags$h4(style = "color:#002C3C; font-weight:800; margin:6px 0 10px 0;", x)
tr_note <- function(...) tags$div(style = "font-size:12px; color:#64748b; margin:4px 0 10px 0; line-height:1.5;", ...)
tr_tile <- function(label, value, sub = NULL, colour = "#002C3C") {
  tags$div(style = "flex:1 1 150px; background:#ffffff; border:1px solid #e2e8f0; border-top:4px solid #008A82; border-radius:8px; padding:10px 12px; margin:0 8px 8px 0; min-width:140px;",
    tags$div(style = "font-size:11px; color:#64748b; text-transform:uppercase; letter-spacing:.4px;", label),
    tags$div(style = paste0("font-size:22px; font-weight:800; color:", colour, ";"), value),
    if (!is.null(sub)) tags$div(style = "font-size:11px; color:#64748b;", sub))
}
tr_fmt_pct <- function(x, d = 1) if (is.finite(x)) sprintf(paste0("%.", d, "f%%"), 100 * x) else "—"
tr_fmt_num <- function(x, d = 2) if (is.finite(x)) formatC(x, format = "f", digits = d, big.mark = ",") else "—"

trading_records_ui <- function(id) {
  ns <- NS(id)
  ta <- function(i, l, r = 2) textAreaInput(ns(i), tr_lab(l), rows = r, width = "100%")
  num <- function(i, l, v = NA, ...) numericInput(ns(i), tr_lab(l), v, ...)

  inst_row <- function(i, default_inst) {
    tags$div(style = "background:#f6f8fb; border-radius:8px; padding:8px 12px; margin-bottom:8px;",
      fluidRow(
        column(3, selectizeInput(ns(paste0("ml", i, "_inst")), tr_lab("Instrument"), tr_blank_choice(default_inst), selected = default_inst, options = list(create = TRUE))),
        column(3, num(paste0("ml", i, "_low"), "Overnight low")), column(3, num(paste0("ml", i, "_high"), "Overnight high")),
        column(3, num(paste0("ml", i, "_cur"), "Current price"))),
      fluidRow(
        column(3, textInput(ns(paste0("ml", i, "_time")), tr_lab("Time now (UK)"), tr_uk_now())),
        column(3, num(paste0("ml", i, "_adx"), "ADX(14)")),
        column(2, num(paste0("ml", i, "_ph"), "Prior high")), column(2, num(paste0("ml", i, "_pl"), "Prior low")),
        column(2, num(paste0("ml", i, "_pc"), "Prior close"))))
  }

  tagList(
    tags$div(style = "background: linear-gradient(135deg, #002C3C 0%, #008A82 100%); border-radius: 12px; padding: 18px 22px; margin-bottom: 16px; color: #ffffff;",
      tags$h3(style = "margin: 0 0 6px 0; font-size: 19px; font-weight: 800; color: #ffffff;", "Trading Records: durable records for the trading period"),
      tags$div(style = "font-size: 13px; color: #eafffb; line-height: 1.6;",
        "Your own morning sheets and trades, stored in BigQuery so they survive restarts, plus Blotter-style statistics worked out from what you record. Everything here is entered by you; the app never creates or suggests trades or results.")),
    uiOutput(ns("statusBar")),

    tabBox(width = 12, id = ns("tabs"),
      # ---------------------------------------------------------------- 1 SETUP
      tabPanel("1. Connection & Setup",
        tr_h("Storage"),
        tr_note("Records are saved to BigQuery as soon as a connection exists (API Configuration → BigQuery → Connect). If it isn't connected, records are kept in this session only and queued; use Sync once connected. Session-only records are lost if the app restarts, so download a backup."),
        fluidRow(column(12,
          actionButton(ns("ensureTables"), "Create / verify tables", icon = icon("database"), class = "btn-primary", style = "color:#ffffff; font-weight:700;"),
          actionButton(ns("syncPending"), "Sync pending records", icon = icon("cloud-arrow-up")),
          actionButton(ns("reload"), "Reload from BigQuery", icon = icon("rotate")),
          downloadButton(ns("dlBackup"), "Download session backup (.rds)"))),
        tags$br(), uiOutput(ns("setupMsg")),
        tr_h("Period settings"),
        fluidRow(
          column(3, textInput(ns("s_name"), tr_lab("Your name"), "Jose F Zubizarreta")),
          column(3, textInput(ns("s_id"), tr_lab("LAT student ID"), "D1005749")),
          column(3, num("s_balance", "Opening balance (GBP)", 10000, min = 0, step = 100)),
          column(3, dateInput(ns("s_start"), tr_lab("Period start"), as.Date("2026-10-12")))),
        fluidRow(
          column(3, dateInput(ns("s_end"), tr_lab("Period end"), as.Date("2026-11-06")))),
        tr_note("Your plan numbers (from your own Task 1 plan). They are used for the regime label (ADX) and for warnings before you save a trade."),
        fluidRow(
          column(3, num("s_adx_t", "ADX above = trend", 30)), column(3, num("s_adx_r", "ADX below = range", 20)),
          column(3, num("s_risk", "Risk per trade (% equity)", 1, step = 0.25)), column(3, num("s_cap", "Combined open-risk cap (%)", 2, step = 0.25))),
        fluidRow(column(3, num("s_minrrr", "Minimum reward : risk (optional)", NA, step = 0.25))),
        tr_h("Dropbox (where the finished sheets are saved)"),
        tr_note("Folder = your Dropbox folder as it appears on the computer running the app (for example C:/Users/you/Dropbox/LAT/Unit3). Dropbox path = a folder inside your Dropbox for upload through the Dropbox API; it needs the access token in the environment variable DROPBOX_ACCESS_TOKEN (the token is never stored in BigQuery). Fill either or both."),
        fluidRow(column(6, textInput(ns("s_dbx"), tr_lab("Dropbox folder on this computer"), "", placeholder = "C:/Users/you/Dropbox/LAT/Unit3")),
                 column(6, textInput(ns("s_dbxapi"), tr_lab("Dropbox path (API upload)"), "", placeholder = "/LAT/Unit3"))),
        actionButton(ns("saveSettings"), "Save settings", icon = icon("floppy-disk"), class = "btn-success", style = "color:#ffffff; font-weight:700;")),

      # ------------------------------------------------------- 2 MORNING SHEET
      tabPanel("2. Morning Sheet",
        tr_note("Same sections as your Morning Sheet template. Pivot points and the regime label are worked out when you save, from the prior-day high/low/close and ADX you enter. Saving the same date again creates a new version; the latest is used."),
        fluidRow(
          column(3, dateInput(ns("ms_date"), tr_lab("Date"), tr_london_today())),
          column(3, selectInput(ns("ms_load"), tr_lab("Load a saved sheet"), choices = c("(none)"))),
          column(3, tags$div(style = "margin-top:25px;", actionButton(ns("ms_loadBtn"), "Load", icon = icon("folder-open"))))),
        tr_h("Where should the market levels and the economic calendar come from?"),
        radioButtons(ns("ms_src"), NULL, inline = TRUE, choices = c("I will upload screenshots" = "shots", "Let Claude find it online (web search)" = "web")),
        tr_note("Either way Claude only fills in the boxes below. Check every value (against the screenshot, or against a second source for web results) before saving: web figures are approximate and are not read from your IG platform."),
        conditionalPanel(sprintf("input['%s'] == 'shots'", ns("ms_src")),
          fluidRow(column(6, fileInput(ns("ms_shots"), tr_lab("IG market screenshots (watchlist or charts, one or several)"), multiple = TRUE, accept = c("image/png", "image/jpeg", "image/webp", ".png", ".jpg", ".jpeg", ".webp"))),
                   column(3, tags$div(style = "margin-top:25px;", actionButton(ns("ms_read"), "Read levels with Claude", icon = icon("wand-magic-sparkles"), class = "btn-primary", style = "color:#ffffff; font-weight:700;")))),
          fluidRow(column(5, fileInput(ns("ms_cal_img_o"), tr_lab("Calendar screenshot(s): YESTERDAY / overnight"), multiple = TRUE, accept = c("image/png", "image/jpeg", "image/webp", ".png", ".jpg", ".jpeg", ".webp"))),
                   column(5, fileInput(ns("ms_cal_img_t"), tr_lab("Calendar screenshot(s): TODAY"), multiple = TRUE, accept = c("image/png", "image/jpeg", "image/webp", ".png", ".jpg", ".jpeg", ".webp"))),
                   column(2, tags$div(style = "margin-top:25px;", actionButton(ns("ms_cal_read"), "Read calendar", icon = icon("table"), class = "btn-primary", style = "color:#ffffff; font-weight:700;")))),
          tr_note("The same calendar pictures are attached to the exported Morning Sheet automatically (you can still add others in the Exports tab).")),
        conditionalPanel(sprintf("input['%s'] == 'web'", ns("ms_src")),
          tr_note("Claude searches the web for the date chosen above: market levels at about 07:00 UK, short overnight headlines, yesterday's calendar (with actual, forecast and previous) and today's calendar. This can take one to three minutes."),
          fluidRow(column(4, actionButton(ns("ms_web_mk"), "Find market levels + headlines", icon = icon("globe"), class = "btn-primary", style = "color:#ffffff; font-weight:700;")),
                   column(4, actionButton(ns("ms_web_cal"), "Find yesterday + today calendar", icon = icon("globe"), class = "btn-primary", style = "color:#ffffff; font-weight:700;")))),
        uiOutput(ns("ms_read_out")),
        tr_h("Overnight markets"),
        fluidRow(column(3, num("ms_dow", "Dow Jones price")), column(3, num("ms_dowc", "Dow change (%)")),
                 column(3, num("ms_nik", "Nikkei price")), column(3, num("ms_nikc", "Nikkei change (%)"))),
        fluidRow(column(3, tags$span()), column(3, num("ms_dowp", "Dow change (points, optional)")),
                 column(3, tags$span()), column(3, num("ms_nikp", "Nikkei change (points, optional)"))),
        tr_note("The template's Change column: type it as your platform shows it. If you enter the percentage and the points, both go on the exported sheet."),
        tr_h("Forex (rows as in the Morning Sheet template)"),
        inst_row(1, "EURUSD"), inst_row(2, "USDJPY"), inst_row(3, "GBPUSD"), inst_row(4, "AUDUSD"),
        tr_h("Commodities (rows as in the template)"),
        inst_row(5, "WTI"), inst_row(6, "GOLD"),
        tr_h("Extra rows: any other market you trade (for example Brent, natural gas, an index)"),
        inst_row(7, ""), inst_row(8, ""),
        tr_h("News and calendar"),
        ta("ms_news", "Overnight news (your own notes)", 3),
        tr_h("Economic calendar: yesterday (overnight)"), DT::DTOutput(ns("cal_tbl_o")),
        ta("ms_cal_o", "Economic calendar from overnight (filled by the buttons above, or paste/type)", 3),
        tr_h("Economic calendar: today"), DT::DTOutput(ns("cal_tbl_t")),
        ta("ms_cal_t", "Today's data releases (filled by the buttons above, or paste/type)", 3),
        ta("ms_win", "Releases inside your trading window", 2),
        tr_h("Plan for the day"),
        ta("ms_regime", "Regime read per instrument", 2), ta("ms_setups", "Set-ups you will look for", 2),
        fluidRow(column(4, num("ms_risk", "Combined open risk now (% of equity)", 0, min = 0, step = 0.25)),
                 column(8, ta("ms_expo", "Exposure note (correlated markets)", 2))),
        checkboxInput(ns("ms_stand"), tr_lab("Standing aside today"), FALSE),
        conditionalPanel(sprintf("input['%s']", ns("ms_stand")), ta("ms_stand_why", "Reason for standing aside", 2)),
        actionButton(ns("ms_save"), "Save morning sheet", icon = icon("floppy-disk"), class = "btn-success", style = "color:#ffffff; font-weight:700;"),
        tags$hr(), tr_h("Saved sheets"), DT::DTOutput(ns("ms_table"))),

      # ------------------------------------------------------------- 3 TRADES
      tabPanel("3. Trades",
        tr_h("A. Open a trade"),
        tr_note("Fill in at the time you enter, as in the top half of your Trade Sheet. Times are UK time. Sizing is your stake per pip; pip size is the price move that equals one pip on YOUR platform (defaults are only a guide)."),
        fluidRow(
          column(3, selectizeInput(ns("t_asset"), tr_lab("Asset"), tr_asset_choices(), selected = "BRENT", options = list(create = TRUE))),
          column(3, selectInput(ns("t_strategy"), tr_lab("Strategy"), tr_strategies)),
          column(3, radioButtons(ns("t_dir"), tr_lab("Direction"), c("Buy" = "B", "Sell" = "S"), inline = TRUE)),
          column(3, textInput(ns("t_chart"), tr_lab("Chart period"), "15 Min"))),
        fluidRow(
          column(3, dateInput(ns("t_date"), tr_lab("Entry date"), tr_london_today())),
          column(3, textInput(ns("t_time"), tr_lab("Entry time (UK, HH:MM)"), tr_uk_now())),
          column(3, num("t_dur", "Expected duration (hours)", 2, min = 0)),
          column(3, selectInput(ns("t_basis"), tr_lab("Prices are quoted as"), tr_price_bases))),
        fluidRow(
          column(3, num("t_pip", "Pip size (price units)", 1, min = 0)),
          column(3, num("t_stake", "Stake per pip (GBP): the size in \u00a3 per point", 2, min = 0)),
          column(3, selectInput(ns("t_purpose"), tr_lab("Assessed or practice?"), tr_purpose_choices)),
          column(3, tags$div(style = "margin-top:22px;", uiOutput(ns("t_class_note"))))),
        fluidRow(
          column(3, num("t_entry", "Entry price")), column(3, num("t_stop", "Stop loss")), column(3, num("t_target", "Target"))),
        tags$details(open = NA, style = "background:#f6f8fb; border-radius:8px; padding:8px 12px; margin-bottom:10px; color:#2c3e50;",
          tags$summary(style = "font-weight:700; cursor:pointer;", "Platform details (filled from screenshots; check or type them)"),
          tags$div(style = "margin-top:8px;",
            fluidRow(column(3, selectInput(ns("t_class"), tr_lab("Asset class"), tr_asset_classes)), column(3, textInput(ns("t_market"), tr_lab("Market"), "")),
                     column(3, textInput(ns("t_rawname"), tr_lab("Market name on the platform"), "")), column(3, textInput(ns("t_dealref"), tr_lab("Deal reference"), ""))),
            fluidRow(column(3, selectInput(ns("t_contract"), tr_lab("Contract type"), tr_contract_choices)), column(3, selectInput(ns("t_acct"), tr_lab("Account type"), tr_account_choices, selected = "SPREAD_BET")),
                     column(3, selectInput(ns("t_device"), tr_lab("Where the entry came from"), tr_device_choices)), column(3, checkboxInput(ns("t_demo"), tr_lab("Demo account"), TRUE))),
            fluidRow(column(3, textInput(ns("t_unit"), tr_lab("Size unit"), "GBP per point")), column(3, num("t_spread", "Spread (points)")),
                     column(3, num("t_margin", "Margin (GBP)")), column(3, num("t_notional", "Notional value (GBP)"))),
            fluidRow(column(3, num("t_costs", "Indicative costs (GBP)"))),
            tr_note("Optional points-system scores for the Blotter (your own marks, only if your tutor's system uses them):"),
            fluidRow(column(2, num("t_s1", "Patterns (10)", NA, min = 0, max = 10)), column(2, num("t_s2", "S/R (10)", NA, min = 0, max = 10)), column(2, num("t_s3", "Candles (3)", NA, min = 0, max = 3)),
                     column(2, num("t_s4", "RSI (3)", NA, min = 0, max = 3)), column(2, num("t_s5", "Fibs (3)", NA, min = 0, max = 3))))),
        fluidRow(
          column(3, num("t_adx", "ADX(14) at entry")),
          column(3, num("t_corr", "Other open risk in correlated markets (% equity)", 0, min = 0, step = 0.25)),
          column(3, sliderInput(ns("t_mood"), tr_lab("Mood at entry (1–5)"), 1, 5, 3, step = 1)),
          column(3, textInput(ns("t_parent"), tr_lab("Parent trade ID (only if this is a separate leg)"), ""))),
        ta("t_fund", "Set-up (fundamental)", 2), ta("t_tech", "Set-up (technical)", 3),
        fluidRow(column(6, ta("t_trigger", "Trigger", 2)), column(6, ta("t_exec", "Execution", 2))),
        fluidRow(column(6, ta("t_stopwhy", "Reason for stop-loss placement", 2)), column(6, ta("t_tgtwhy", "Reason for target placement", 2))),
        uiOutput(ns("t_preview")),
        actionButton(ns("t_save"), "Save open trade", icon = icon("floppy-disk"), class = "btn-success", style = "color:#ffffff; font-weight:700;"),
        tags$hr(),

        tr_h("B. Manage, partially exit or close an open trade"),
        selectInput(ns("m_trade"), tr_lab("Open trade"), choices = c("(no open trades)" = "")),
        uiOutput(ns("m_summary")),
        radioButtons(ns("m_action"), tr_lab("What happened?"), inline = TRUE,
                     c("Edit entry details" = "edit", "Moved stop" = "stop", "Partial exit" = "partial", "Closed" = "close", "Cancelled (never filled)" = "cancel"), selected = "stop"),
        conditionalPanel(sprintf("input['%s'] != 'edit'", ns("m_action")),
          fluidRow(column(3, dateInput(ns("m_date"), tr_lab("Date"), tr_london_today())),
                   column(3, textInput(ns("m_time"), tr_lab("Time (UK, HH:MM)"), tr_uk_now())))),
        conditionalPanel(sprintf("input['%s'] == 'edit'", ns("m_action")),
          tr_note("Correct or complete the entry details of the selected open trade (entry time, purpose, platform details, your own set-up text). Saving adds a new version of the trade; nothing is overwritten."),
          fluidRow(column(3, dateInput(ns("e_date"), tr_lab("Entry date"), tr_london_today())), column(3, textInput(ns("e_time"), tr_lab("Entry time (UK, HH:MM)"), "")),
                   column(3, selectInput(ns("e_purpose"), tr_lab("Assessed or practice?"), tr_purpose_choices)), column(3, textInput(ns("e_dealref"), tr_lab("Deal reference"), ""))),
          fluidRow(column(3, selectInput(ns("e_contract"), tr_lab("Contract type"), tr_contract_choices)), column(3, num("e_spread", "Spread (points)")),
                   column(3, num("e_margin", "Margin (GBP)")), column(3, num("e_notional", "Notional value (GBP)"))),
          fluidRow(column(3, num("e_costs", "Indicative costs (GBP)"))),
          ta("e_fund", "Set-up (fundamental)", 2), ta("e_tech", "Set-up (technical)", 3),
          fluidRow(column(6, ta("e_trigger", "Trigger", 2)), column(6, ta("e_exec", "Execution", 2))),
          fluidRow(column(6, ta("e_stopwhy", "Reason for stop-loss placement", 2)), column(6, ta("e_tgtwhy", "Reason for target placement", 2)))),
        conditionalPanel(sprintf("input['%s'] == 'stop'", ns("m_action")),
          fluidRow(column(3, num("m_newstop", "New stop price")),
                   column(3, radioButtons(ns("m_permitted"), tr_lab("Allowed by my written management rule?"), c("Yes" = "Y", "No" = "N"), inline = TRUE))),
          ta("m_stopwhy", "Why (with the chart you saved)", 2)),
        conditionalPanel(sprintf("input['%s'] == 'partial' || input['%s'] == 'close'", ns("m_action"), ns("m_action")),
          fluidRow(column(3, conditionalPanel(sprintf("input['%s'] == 'partial'", ns("m_action")), num("m_pstake", "Stake per pip closed (GBP)"))),
                   column(3, num("m_exit", "Exit price")),
                   column(3, num("m_pnl", "Net P/L shown by the platform (GBP, optional)")),
                   column(3, radioButtons(ns("m_code"), tr_lab("Exit code"), c("S1 hit initial stop" = "S1", "S2+ hit trailing stop" = "S2+", "ME manual exit" = "ME", "T target hit" = "T")))),
          conditionalPanel(sprintf("input['%s'] == 'ME'", ns("m_code")),
            radioButtons(ns("m_post"), tr_lab("After your manual exit, did the market reach your stop or your target? (from your post-exit chart)"), inline = TRUE,
                         c("Not checked / neither" = "", "It then hit my stop" = "stop", "It then hit my target" = "target"))),
          fluidRow(column(3, sliderInput(ns("m_mood"), tr_lab("Mood at exit (1–5)"), 1, 5, 3, step = 1)),
                   column(3, radioButtons(ns("m_followed"), tr_lab("Did you follow your plan on this trade?"), c("Yes" = "Y", "No" = "N"), inline = TRUE)),
                   column(6, conditionalPanel(sprintf("input['%s'] == 'N'", ns("m_followed")),
                     selectInput(ns("m_devtype"), tr_lab("Deviation type"), tr_deviations)))),
          conditionalPanel(sprintf("input['%s'] == 'N'", ns("m_followed")), ta("m_devnote", "What happened and why (be specific and honest)", 2)),
          fluidRow(column(6, ta("m_why", "Reason for exit", 2)), column(6, ta("m_lessons", "Lessons learned", 2)))),
        actionButton(ns("m_save"), "Save", icon = icon("floppy-disk"), class = "btn-success", style = "color:#ffffff; font-weight:700;"),
        tags$hr(), tr_h("All trades"),
        downloadButton(ns("dlTrades"), "Download trades (CSV)"), tags$br(), tags$br(),
        DT::DTOutput(ns("tr_table"))),

      # ------------------------------------------------------------- 4 STATS
      tabPanel("4. Statistics",
        fluidRow(column(3, selectInput(ns("st_week"), tr_lab("Show"), c("Whole period" = "all", "Week 1" = "1", "Week 2" = "2", "Week 3" = "3", "Week 4" = "4"))),
                 column(3, selectInput(ns("st_scope"), tr_lab("Trades"), c("Assessed trades only" = "ASSESSED", "Practice trades only" = "PRACTICE", "All trades" = "ALL")))),
        uiOutput(ns("st_tiles")),
        uiOutput(ns("st_caution")),
        fluidRow(column(6, plotly::plotlyOutput(ns("st_equity"), height = "300px")), column(6, plotly::plotlyOutput(ns("st_r"), height = "300px"))),
        fluidRow(column(6, tr_h("By strategy"), tableOutput(ns("st_strat"))), column(6, tr_h("By asset"), tableOutput(ns("st_asset")))),
        fluidRow(column(4, tr_h("By exit code"), tableOutput(ns("st_exit"))), column(4, tr_h("By weekday (entry)"), tableOutput(ns("st_wd"))),
                 column(4, tr_h("By entry time (UK)"), tableOutput(ns("st_hr")))),
        fluidRow(column(6, tr_h("Mood at entry vs Real R"), tableOutput(ns("st_mood")))),
        tr_note("Real R = net P/L divided by the money risked at the initial stop (negative for a loss). Planned RRR = reward pips / risk pips at entry. Sharpe and Sortino here are per trade, not annualised, and are not reliable on a small number of trades; the trade-by-trade review and adherence matter more.")),

      # ---------------------------------------------------------- 5 EXPORTS
      tabPanel("5. Exports (LAT files)",
        tr_note("These files are filled from the records you saved, in the layout of your LAT documents. Nothing is written for you: text fields are exactly what you typed, and empty stays empty. Check your course rules about AI-assisted record keeping and describe it honestly in your submission."),
        fluidRow(column(4, selectInput(ns("ex_scope"), tr_lab("Trades to include"), c("Assessed trades only" = "ASSESSED", "Practice trades only" = "PRACTICE", "All trades" = "ALL")))),
        tr_h("Trade Blotter (Excel)"),
        tr_note("Same columns A to AK as the 'Trade Blotter' sheet. Copy the input columns into your LAT workbook, or use this file to check your own figures."),
        downloadButton(ns("dlBlotter"), "Download Blotter (.xlsx)"),
        tags$hr(), tr_h("Individual Trade Sheet (Word)"),
        selectInput(ns("ex_trade"), tr_lab("Trade"), choices = c("(no trades yet)" = "")),
        tr_note("The sheet is filled into your LAT Trade Sheet template. Add pictures for each part (PNG or JPEG, several allowed, shown in the order selected): ENTRY = the chart with your stop and limit, the Positions row, the deal confirmation; IN-TRADE = charts for a stop move or partial exit; EXIT = the History screenshot or an exit chart. Crop out account names and numbers. Pictures are placed where the template says [Insert chart picture here] and are not stored in BigQuery; the originals stay in your Screenshots folder."),
        fluidRow(column(4, fileInput(ns("ch_entry"), tr_lab("Entry pictures"), multiple = TRUE, accept = c("image/png", "image/jpeg"))),
                 column(4, fileInput(ns("ch_trade"), tr_lab("In-trade pictures"), multiple = TRUE, accept = c("image/png", "image/jpeg"))),
                 column(4, fileInput(ns("ch_exit"), tr_lab("Exit pictures"), multiple = TRUE, accept = c("image/png", "image/jpeg")))),
        downloadButton(ns("dlTradeSheet"), "Download Trade Sheet (.docx)"), downloadButton(ns("dlTradeSheetPdf"), "Download Trade Sheet (PDF)"),
        actionButton(ns("sv_trade"), "Save Word + PDF to Dropbox", icon = icon("dropbox")),
        tags$hr(), tr_h("Morning Sheet (Word)"),
        selectInput(ns("ex_sheet"), tr_lab("Saved sheet"), choices = c("(no sheets yet)" = "")),
        tr_note("Filled into your LAT Morning Sheet template. Add the two calendar screenshots (PNG or JPEG): they go under 'Economic Calendar from overnight' and 'Economic Calendar for today'. Text you saved in the Morning Sheet tab for those boxes is placed above the pictures."),
        fluidRow(column(6, fileInput(ns("cal_o"), tr_lab("Overnight calendar / news pictures"), multiple = TRUE, accept = c("image/png", "image/jpeg"))),
                 column(6, fileInput(ns("cal_t"), tr_lab("Today's calendar pictures"), multiple = TRUE, accept = c("image/png", "image/jpeg")))),
        downloadButton(ns("dlMorning"), "Download Morning Sheet (.docx)"), downloadButton(ns("dlMorningPdf"), "Download Morning Sheet (PDF)"),
        actionButton(ns("sv_morning"), "Save Word + PDF to Dropbox", icon = icon("dropbox")),
        tr_note("PDF files are made from the Word file with LibreOffice, which must be installed on the computer running the app. Without it you still get the Word file; open it and use Save as PDF. Files are named like Morning_Sheet_20-10-2026 and Individual_Trade_Sheet_Brent_19-10-2026, and saved again with the same name when you re-export."),
        uiOutput(ns("sv_out")),
        tags$hr(), tr_h("Statistics (Excel)"),
        tr_note("Summary, by asset, strategy, exit code, weekday, entry time and mood, the equity series, the trade list and the deviations you wrote. Use it for the numbers in Tasks 2 and 3; the evaluation is yours to write."),
        downloadButton(ns("dlStatsX"), "Download statistics (.xlsx)")),

      # ---------------------------------------------------------- 6 SCHEMA
      tabPanel("6. Schema & SQL",
        tr_note("Six append-only tables (settings, morning sheets, morning levels, trades, trade events and the screenshot evidence log) in the BigQuery dataset set under API Configuration. Each also gets a `_current` view that returns the latest row per key. Editing a record writes a new row; nothing is updated or deleted."),
        uiOutput(ns("schemaTables")), tr_h("DDL"), downloadButton(ns("dlDDL"), "Download SQL (.sql)"), tags$br(), tags$br(),
        verbatimTextOutput(ns("ddlText")))
    )
  )
}

# =============================================================================== SERVER
trading_records_server <- function(id, api_manager = NULL, store = NULL, quiet = FALSE, bus = NULL, vision_fn = NULL, text_fn = NULL) {
  moduleServer(id, function(input, output, session) {
    if (is.null(store)) store <- tr_make_store(tr_bq_backend(api_manager))
    refresh <- reactiveVal(0); bump <- function() refresh(isolate(refresh()) + 1)
    msg <- function(text, type = "message") if (!quiet) showNotification(text, type = type, duration = 6)
    report <- function(res, what) {
      if (identical(res, "bigquery")) msg(paste(what, "saved to BigQuery."))
      else if (identical(res, "pending")) msg(paste(what, "saved in this session only (BigQuery not connected). Sync later."), "warning")
      else msg(paste(what, "- BigQuery write failed, kept in this session:", res), "error")
    }

    # ---- order-evidence integration (screenshots sent from the Order Evidence tab) ------------
    ev_open <- reactiveVal(character(0)); ev_close <- reactiveVal(NULL)
    link_evidence <- function(ev_id, trade_id) {
      if (is.null(ev_id) || !nzchar(ev_id)) return(invisible())
      ev <- tr_read_current(store, "evidence"); r <- ev[ev$evidence_id == ev_id, , drop = FALSE]
      if (!nrow(r)) return(invisible())
      r <- r[1, ]; r$status <- "LINKED"; r$trade_id <- trade_id; r$record_version <- r$record_version + 1L
      store$write("evidence", r)
    }
    link_all <- function(ids, trade_id) for (i in ids) link_evidence(i, trade_id)
    if (!is.null(bus)) observeEvent(bus$ts, {
      v <- bus$values; req(v)
      if (identical(bus$kind, "open")) {
        ev_open(unique(c(ev_open(), bus$evidence_id)))
        if (!is.na(tr_or(v$asset, NA))) updateSelectizeInput(session, "t_asset", choices = tr_asset_choices(v$asset), selected = v$asset, options = list(create = TRUE))
        fill_txt <- function(id, val) if (!is.null(val) && length(val) == 1 && !is.na(val) && nzchar(as.character(val))) updateTextInput(session, id, value = as.character(val))
        fill_sel <- function(id, val) if (!is.null(val) && length(val) == 1 && !is.na(val) && nzchar(as.character(val))) updateSelectInput(session, id, selected = as.character(val))
        fill_num <- function(id, val) if (is.finite(tr_num(val))) updateNumericInput(session, id, value = tr_num(val))
        if (isTRUE(v$per_point)) updateSelectInput(session, "t_basis", selected = "ig")
        fill_sel("t_contract", v$contract); fill_sel("t_acct", v$account_type); fill_sel("t_device", tr_or(v$source, NA)); fill_sel("t_class", v$asset_class)
        fill_txt("t_market", v$market); fill_txt("t_rawname", v$asset_raw); fill_txt("t_dealref", v$deal_ref)
        if (isTRUE(v$per_point)) fill_txt("t_unit", "GBP per point") else fill_txt("t_unit", v$size_unit)
        if (!is.na(tr_or(v$demo, NA))) updateCheckboxInput(session, "t_demo", value = isTRUE(v$demo))
        fill_num("t_spread", v$spread); fill_num("t_margin", v$margin); fill_num("t_notional", v$notional); fill_num("t_costs", v$costs)
        if (!is.na(tr_or(v$direction, NA))) updateRadioButtons(session, "t_dir", selected = v$direction)
        if (!is.na(tr_or(v$date, NA))) updateDateInput(session, "t_date", value = as.Date(v$date))
        if (!is.na(tr_or(v$time, NA))) updateTextInput(session, "t_time", value = v$time) else updateTextInput(session, "t_time", value = tr_uk_now())   # no clock on the screen: now, UK time
        if (is.finite(tr_num(v$entry))) updateNumericInput(session, "t_entry", value = v$entry)
        if (is.finite(tr_num(v$stop))) updateNumericInput(session, "t_stop", value = v$stop)
        if (is.finite(tr_num(v$limit))) updateNumericInput(session, "t_target", value = v$limit)
        if (is.finite(tr_num(v$size))) updateNumericInput(session, "t_stake", value = v$size)
        updateTabsetPanel(session, "tabs", selected = "3. Trades")
        msg(paste0("Entry details filled in from the screenshot", if (is.na(tr_or(v$time, NA))) " (entry time set to now, UK time: change it if the trade was placed earlier)" else "", ". Check them, then write your own set-up, trigger and reasons before saving."))
      } else if (identical(bus$kind, "close")) {
        ev_close(bus$evidence_id)
        o <- open_trades(); hit <- o[o$asset == tr_or(v$asset, "") & (is.na(tr_or(v$direction, NA)) | o$direction == tr_or(v$direction, "")), , drop = FALSE]
        if (nrow(hit) >= 1) updateSelectInput(session, "m_trade", selected = hit$trade_id[which.max(hit$entry_ts)])
        updateRadioButtons(session, "m_action", selected = "close")
        if (is.finite(tr_num(v$exit))) updateNumericInput(session, "m_exit", value = v$exit)
        if (is.finite(tr_num(v$pnl))) updateNumericInput(session, "m_pnl", value = v$pnl)
        if (!is.na(tr_or(v$date, NA))) updateDateInput(session, "m_date", value = as.Date(v$date))
        if (!is.na(tr_or(v$time, NA))) updateTextInput(session, "m_time", value = v$time)
        updateTabsetPanel(session, "tabs", selected = "3. Trades")
        msg("Exit details filled in from the screenshot. Choose the trade if needed, then add your own reason for exit and lessons before saving.")
      }
    }, ignoreInit = TRUE)

    # connection watcher
    conn <- reactive({ invalidateLater(3000); store$connected() })
    last_conn <- reactiveVal(FALSE)
    observe({ cn <- conn(); if (cn && !isolate(last_conn())) { last_conn(TRUE); bump() } else if (!cn) last_conn(FALSE) })

    rd <- function(name) reactive({ refresh(); tr_read_current(store, name) })
    settings_df <- rd("settings"); sheets_df <- rd("morning_sheets")
    levels_df <- rd("morning_levels"); trades_df <- rd("trades"); events_df <- rd("trade_events")

    sv <- reactive({ s <- settings_df(); setNames(as.list(s$setting_value), s$setting_key) })
    opening <- reactive(tr_or(tr_num(sv()$opening_balance), 10000))
    p_start <- reactive(tryCatch(as.Date(tr_or(sv()$period_start, "2026-10-12")), error = function(e) as.Date("2026-10-12")))
    # plan numbers come from the Setup tab (saved in trading_settings)
    adx_cfg <- reactive({ c(tr_or(tr_num(sv()$adx_trend_min), 30), tr_or(tr_num(sv()$adx_range_max), 20)) })
    limits <- reactive(list(risk_pct = tr_num(sv()$risk_pct), cap_pct = tr_num(sv()$combined_cap_pct), min_rrr = tr_num(sv()$min_rrr)))
    equity_now <- reactive({ t <- trades_df(); cl <- t[t$status == "CLOSED" & !is.na(t$net_pnl_gbp), ]; opening() + sum(cl$net_pnl_gbp) })

    # ---------------------------------------------------------------- status & setup
    output$statusBar <- renderUI({
      cn <- conn(); refresh(); pc <- store$pending_count()
      bg <- if (cn) "#15803d" else "#b45309"
      txt <- if (cn) "Connected to BigQuery: records are saved permanently." else "Not connected to BigQuery: records are kept in this session only."
      tags$div(style = paste0("background:", bg, "; color:#ffffff; border-radius:8px; padding:8px 14px; margin-bottom:12px; font-size:13px;"),
               txt, if (pc > 0) sprintf(" %d record(s) waiting to sync.", pc))
    })
    observeEvent(input$ensureTables, {
      tryCatch({ req(store$connected()); store$ensure(); msg("Tables and views are ready.") },
               error = function(e) msg(paste("Could not prepare tables:", conditionMessage(e)), "error"))
      if (!store$connected()) msg("Connect BigQuery first (API Configuration).", "warning")
    })
    observeEvent(input$syncPending, {
      tryCatch({ n <- store$sync(); bump(); msg(sprintf("Synced %d record(s) to BigQuery.", n)) },
               error = function(e) msg(paste("Sync failed:", conditionMessage(e)), "error"))
    })
    observeEvent(input$reload, { bump(); msg("Reloaded.") })
    output$dlBackup <- downloadHandler(filename = function() paste0("trading_records_session_", format(Sys.Date()), ".rds"),
                                       content = function(file) saveRDS(store$pending_data(), file))
    output$setupMsg <- renderUI(NULL)
    observeEvent(input$saveSettings, {
      df <- data.frame(setting_key = c("trader_name", "student_id", "opening_balance", "period_start", "period_end", "adx_trend_min", "adx_range_max", "risk_pct", "combined_cap_pct", "min_rrr", "dropbox_dir", "dropbox_api_path"),
                       setting_value = c(as.character(tr_or(input$s_name, NA)), as.character(tr_or(input$s_id, NA)), as.character(tr_or(input$s_balance, NA)), as.character(tr_or(input$s_start, NA)), as.character(tr_or(input$s_end, NA)),
                                         as.character(tr_or(input$s_adx_t, NA)), as.character(tr_or(input$s_adx_r, NA)), as.character(tr_or(input$s_risk, NA)),
                                         as.character(tr_or(input$s_cap, NA)), as.character(tr_or(input$s_minrrr, NA)), as.character(tr_or(input$s_dbx, NA)), as.character(tr_or(input$s_dbxapi, NA))),
                       stringsAsFactors = FALSE)
      df <- df[!is.na(df$setting_value) & nzchar(df$setting_value) & df$setting_value != "NA", , drop = FALSE]
      report(store$write("settings", df), "Settings"); bump()
    })
    observeEvent(settings_df(), {   # restore saved settings into the form
      s <- sv()
      if (!is.null(s$trader_name)) updateTextInput(session, "s_name", value = s$trader_name)
      if (!is.null(s$student_id)) updateTextInput(session, "s_id", value = s$student_id)
      if (!is.null(s$dropbox_dir)) updateTextInput(session, "s_dbx", value = s$dropbox_dir)
      if (!is.null(s$dropbox_api_path)) updateTextInput(session, "s_dbxapi", value = s$dropbox_api_path)
      if (!is.null(s$opening_balance)) updateNumericInput(session, "s_balance", value = as.numeric(s$opening_balance))
      if (!is.null(s$period_start)) updateDateInput(session, "s_start", value = as.Date(s$period_start))
      if (!is.null(s$period_end)) updateDateInput(session, "s_end", value = as.Date(s$period_end))
      for (p in list(c("adx_trend_min", "s_adx_t"), c("adx_range_max", "s_adx_r"), c("risk_pct", "s_risk"), c("combined_cap_pct", "s_cap"), c("min_rrr", "s_minrrr")))
        if (!is.null(s[[p[1]]]) && is.finite(tr_num(s[[p[1]]]))) updateNumericInput(session, p[2], value = tr_num(s[[p[1]]]))
    }, once = TRUE, ignoreInit = TRUE)

    # ---------------------------------------------------------------- morning sheet
    observe({
      s <- sheets_df(); ch <- if (nrow(s)) format(sort(s$sheet_date, decreasing = TRUE)) else character(0)
      updateSelectInput(session, "ms_load", choices = c("(none)", ch))
    })
    observeEvent(input$ms_save, {
      d <- input$ms_date; sid <- paste0("MS_", format(d))
      prev <- sheets_df(); rv <- if (sid %in% prev$sheet_id) prev$record_version[prev$sheet_id == sid][1] + 1L else 1L
      thr <- adx_cfg(); lv <- list()
      for (i in 1:8) {
        inst <- toupper(trimws(tr_or(input[[paste0("ml", i, "_inst")]], "")))
        if (!nzchar(inst)) next
        vals <- vapply(c("_low", "_high", "_cur", "_adx", "_ph", "_pl", "_pc"), function(z) tr_num(input[[paste0("ml", i, z)]]), 0)
        if (all(is.na(vals))) next   # a template row you left empty is not saved
        h <- tr_num(input[[paste0("ml", i, "_ph")]]); l <- tr_num(input[[paste0("ml", i, "_pl")]]); c_ <- tr_num(input[[paste0("ml", i, "_pc")]])
        pv <- tr_pivots(h, l, c_); adx <- tr_num(input[[paste0("ml", i, "_adx")]])
        lv[[length(lv) + 1]] <- data.frame(level_id = paste0(sid, "_", inst), sheet_id = sid, sheet_date = d, instrument = inst,
          overnight_low = tr_num(input[[paste0("ml", i, "_low")]]), overnight_high = tr_num(input[[paste0("ml", i, "_high")]]),
          current_price = tr_num(input[[paste0("ml", i, "_cur")]]), time_now_uk = input[[paste0("ml", i, "_time")]], adx14 = adx,
          regime_label = tr_regime(adx, thr[1], thr[2]), prior_high = h, prior_low = l, prior_close = c_,
          pivot_pp = pv$pp, pivot_r1 = pv$r1, pivot_s1 = pv$s1, pivot_r2 = pv$r2, pivot_s2 = pv$s2, pivot_r3 = pv$r3, pivot_s3 = pv$s3, stringsAsFactors = FALSE)
      }
      hdr <- data.frame(sheet_id = sid, record_version = rv, sheet_date = d, week_no = tr_week_no(d, p_start()),
        dow_price = tr_num(input$ms_dow), dow_change_pct = tr_num(input$ms_dowc), nikkei_price = tr_num(input$ms_nik), nikkei_change_pct = tr_num(input$ms_nikc),
        dow_change_pts = tr_num(input$ms_dowp), nikkei_change_pts = tr_num(input$ms_nikp), trader_name = tr_blank_na(input$s_name),
        overnight_news = tr_blank_na(input$ms_news), overnight_calendar = tr_blank_na(input$ms_cal_o), todays_releases = tr_blank_na(input$ms_cal_t),
        releases_in_window = tr_blank_na(input$ms_win), regime_summary = tr_blank_na(input$ms_regime), planned_setups = tr_blank_na(input$ms_setups),
        exposure_note = tr_blank_na(input$ms_expo), combined_open_risk_pct = tr_num(input$ms_risk), stand_aside = isTRUE(input$ms_stand),
        stand_aside_reason = tr_blank_na(input$ms_stand_why), stringsAsFactors = FALSE)
      r1 <- store$write("morning_sheets", hdr)
      if (length(lv)) store$write("morning_levels", do.call(rbind, lv))
      report(r1, "Morning sheet"); bump()
    })
    observeEvent(input$ms_loadBtn, {
      req(input$ms_load != "(none)")
      s <- sheets_df(); h <- s[format(s$sheet_date) == input$ms_load, ][1, ]; req(nrow(h) == 1)
      updateDateInput(session, "ms_date", value = h$sheet_date)
      for (p in list(c("ms_dow", "dow_price"), c("ms_dowc", "dow_change_pct"), c("ms_nik", "nikkei_price"), c("ms_nikc", "nikkei_change_pct"), c("ms_dowp", "dow_change_pts"), c("ms_nikp", "nikkei_change_pts"), c("ms_risk", "combined_open_risk_pct")))
        updateNumericInput(session, p[1], value = h[[p[2]]])
      for (p in list(c("ms_news", "overnight_news"), c("ms_cal_o", "overnight_calendar"), c("ms_cal_t", "todays_releases"), c("ms_win", "releases_in_window"),
                     c("ms_regime", "regime_summary"), c("ms_setups", "planned_setups"), c("ms_expo", "exposure_note"), c("ms_stand_why", "stand_aside_reason")))
        updateTextAreaInput(session, p[1], value = tr_or(h[[p[2]]], ""))
      updateCheckboxInput(session, "ms_stand", value = isTRUE(h$stand_aside))
      lv <- levels_df(); lv <- lv[lv$sheet_id == h$sheet_id, ]
      defaults <- c("EURUSD", "USDJPY", "GBPUSD", "AUDUSD", "WTI", "GOLD", "", "")
      for (i in 1:8) {
        r <- lv[lv$instrument == defaults[i], ]; r <- if (nrow(r) && nzchar(defaults[i])) r[1, ] else NULL
        if (is.null(r) && i > 6) { rest <- lv[!lv$instrument %in% defaults[1:6], ]; if (i - 6 <= nrow(rest)) r <- rest[i - 6, ] }
        if (!is.null(r)) {
          updateSelectizeInput(session, paste0("ml", i, "_inst"), selected = r$instrument, choices = tr_blank_choice(r$instrument), options = list(create = TRUE))
          for (p in list(c("_low", "overnight_low"), c("_high", "overnight_high"), c("_cur", "current_price"), c("_adx", "adx14"), c("_ph", "prior_high"), c("_pl", "prior_low"), c("_pc", "prior_close")))
            updateNumericInput(session, paste0("ml", i, p[1]), value = r[[p[2]]])
          updateTextInput(session, paste0("ml", i, "_time"), value = tr_or(r$time_now_uk, ""))
        } else {
          updateSelectizeInput(session, paste0("ml", i, "_inst"), selected = defaults[i], choices = tr_blank_choice(defaults[i]), options = list(create = TRUE))
          for (z in c("_low", "_high", "_cur", "_adx", "_ph", "_pl", "_pc")) updateNumericInput(session, paste0("ml", i, z), value = NA)
        }
      }
      msg("Sheet loaded. Saving again creates a new version.")
    })
    output$ms_table <- DT::renderDT({
      s <- sheets_df(); lv <- levels_df()
      if (!nrow(s)) return(DT::datatable(data.frame(Message = "No morning sheets saved yet."), rownames = FALSE, options = list(dom = "t")))
      s <- s[order(s$sheet_date, decreasing = TRUE), ]
      s$Instruments <- vapply(s$sheet_id, function(i) paste(lv$instrument[lv$sheet_id == i], collapse = ", "), "")
      DT::datatable(s[, c("sheet_date", "week_no", "Instruments", "stand_aside", "combined_open_risk_pct", "record_version")], rownames = FALSE,
                    options = list(pageLength = 10, scrollX = TRUE))
    })

    # ---------------------------------------------------------------- trades: open
    set_pip <- function() { p <- tr_pip_for(input$t_asset, tr_or(input$t_basis, "ig")); if (is.finite(p)) updateNumericInput(session, "t_pip", value = p) }
    observeEvent(list(input$t_asset, input$t_basis), set_pip(), ignoreInit = TRUE)
    observeEvent(input$t_asset, {
      a <- toupper(trimws(tr_or(input$t_asset, ""))); cl <- tr_asset_class(a); mk <- tr_market_of(a)
      if (!is.na(cl)) updateSelectInput(session, "t_class", selected = cl)
      if (!is.na(mk)) updateTextInput(session, "t_market", value = mk)
    }, ignoreInit = FALSE)
    output$t_class_note <- renderUI({
      a <- toupper(trimws(tr_or(input$t_asset, ""))); i <- tr_instrument(a)
      tags$div(style = "font-size:12px; color:#64748b; line-height:1.4;", if (is.null(i)) "Not in the list: choose its asset class under Platform details." else sprintf("%s | %s | %s", i$label, i$asset_class, i$market))
    })
    t_entry_ts <- reactive(tr_parse_ts(input$t_date, tr_or(input$t_time, "")))
    t_calc <- reactive(tr_entry_calc(input$t_dir, tr_num(input$t_entry), tr_num(input$t_stop), tr_num(input$t_target), tr_num(input$t_pip), tr_num(input$t_stake)))
    output$t_preview <- renderUI({
      if (all(is.na(c(tr_num(input$t_entry), tr_num(input$t_stop), tr_num(input$t_target)))))
        return(tags$div(style = "color:#64748b; font-size:12.5px; margin-bottom:8px;", "Enter entry, stop and target to see risk, reward and RRR before you save."))
      if (all(is.na(c(tr_num(input$t_entry), tr_num(input$t_stop), tr_num(input$t_target)))))
        return(tags$div(style = "color:#64748b; font-size:12.5px; margin-bottom:8px;", "Enter entry, stop and target to see risk, reward and RRR before you save."))
      e <- t_calc(); errs <- tr_validate_entry(input$t_dir, tr_num(input$t_entry), tr_num(input$t_stop), tr_num(input$t_target),
                                              tr_num(input$t_pip), tr_num(input$t_stake), input$t_mood, t_entry_ts())
      if (length(errs)) return(tags$div(style = "color:#b45309; font-size:12.5px; margin-bottom:8px;", paste(errs, collapse = " ")))
      eq <- equity_now(); rp <- 100 * e$risk_gbp / eq; g <- limits(); warn <- character(0)
      if (is.finite(g$risk_pct) && rp > g$risk_pct + 1e-9) warn <- c(warn, sprintf("Risk %.2f%% is above your plan's %.2f%% per trade.", rp, g$risk_pct))
      tot <- rp + tr_or(tr_num(input$t_corr), 0)
      if (is.finite(g$cap_pct) && tot > g$cap_pct + 1e-9) warn <- c(warn, sprintf("Combined risk %.2f%% would exceed your %.2f%% cap.", tot, g$cap_pct))
      if (is.finite(g$min_rrr) && is.finite(e$rrr) && e$rrr < g$min_rrr - 1e-9) warn <- c(warn, sprintf("Planned RRR %.2f is below your plan's minimum of %.2f.", e$rrr, g$min_rrr))
      tags$div(style = "background:#f6f8fb; border-radius:8px; padding:8px 12px; margin-bottom:8px; font-size:13px; color:#2c3e50;",
        sprintf("Risk %.1f pips (GBP %.2f, %.2f%% of equity) | Reward %.1f pips | Planned RRR %.2f", e$risk_pips, e$risk_gbp, rp, e$reward_pips, e$rrr),
        if (length(warn)) tags$div(style = "color:#b91c1c; font-weight:600; margin-top:4px;", paste(warn, collapse = " ")))
    })
    observeEvent(input$t_save, {
      ts <- t_entry_ts(); en <- tr_num(input$t_entry); st <- tr_num(input$t_stop); tg <- tr_num(input$t_target); pip <- tr_num(input$t_pip); stake <- tr_num(input$t_stake)
      errs <- tr_validate_entry(input$t_dir, en, st, tg, pip, stake, input$t_mood, ts)
      if (!nzchar(tr_or(input$t_purpose, ""))) errs <- c(errs, "Choose whether this is an assessed trade or a practice trade.")
      if (length(errs)) { msg(paste(errs, collapse = " "), "error"); return() }
      e <- tr_entry_calc(input$t_dir, en, st, tg, pip, stake); asset <- toupper(trimws(input$t_asset))
      sc <- function(id) { v <- tr_num(input[[id]]); if (is.finite(v)) as.integer(v) else NA_integer_ }
      adx <- tr_num(input$t_adx); thr <- adx_cfg()
      row <- data.frame(trade_id = tr_id("T"), record_version = 1L, parent_trade_id = tr_blank_na(input$t_parent), status = "OPEN",
        week_no = tr_week_no(as.Date(format(ts, tz = "Europe/London")), p_start()), asset = asset, strategy = input$t_strategy, direction = input$t_dir,
        chart_period = input$t_chart, entry_ts = ts, expected_duration_hours = tr_num(input$t_dur), pip_size = pip, stake_per_pip_gbp = stake,
        entry_price = en, stop1 = st, target = tg, initial_risk_pips = e$risk_pips, initial_reward_pips = e$reward_pips, initial_rrr = e$rrr,
        initial_risk_gbp = e$risk_gbp, risk_pct_equity = 100 * e$risk_gbp / equity_now(), regime_adx = adx, regime_label = tr_regime(adx, thr[1], thr[2]),
        correlated_open_risk_pct = tr_num(input$t_corr), mood_entry = as.integer(input$t_mood), setup_fundamental = tr_blank_na(input$t_fund),
        setup_technical = tr_blank_na(input$t_tech), trigger_text = tr_blank_na(input$t_trigger), execution_text = tr_blank_na(input$t_exec),
        stop_reason = tr_blank_na(input$t_stopwhy), target_reason = tr_blank_na(input$t_tgtwhy),
        trade_sheet_name = sprintf("%s - %s", asset, format(ts, "%d/%m/%Y %H:%M", tz = "Europe/London")),
        entry_source = if (!length(ev_open())) "MANUAL" else "SCREENSHOT_VERIFIED", evidence_ids = if (!length(ev_open())) NA_character_ else paste(ev_open(), collapse = ","),
        verified_by_user = if (!length(ev_open())) NA else TRUE,
        asset_class = tr_blank_na(input$t_class), market = tr_blank_na(input$t_market), market_name_raw = tr_blank_na(input$t_rawname),
        contract_type = tr_blank_na(input$t_contract), account_type = tr_blank_na(input$t_acct), is_demo = isTRUE(input$t_demo),
        source_device = tr_blank_na(input$t_device), deal_reference = tr_blank_na(input$t_dealref), size_unit = tr_blank_na(input$t_unit),
        price_basis = tr_blank_na(input$t_basis), spread_pts = tr_num(input$t_spread), margin_gbp = tr_num(input$t_margin),
        notional_gbp = tr_num(input$t_notional), costs_gbp = tr_num(input$t_costs), trade_purpose = input$t_purpose,
        charts_dropbox_path = NA_character_,
        score_patterns = sc("t_s1"), score_sr = sc("t_s2"), score_candles = sc("t_s3"), score_rsi = sc("t_s4"), score_fibs = sc("t_s5"), stringsAsFactors = FALSE)
      report(store$write("trades", row), "Trade")
      if (length(ev_open())) { link_all(ev_open(), row$trade_id); ev_open(character(0)) }
      bump()
    })

    # ---------------------------------------------------------------- trades: manage
    open_trades <- reactive({ t <- trades_df(); t[t$status == "OPEN", , drop = FALSE] })
    trade_label <- function(t) sprintf("%s %s %s (%s)", t$asset, ifelse(t$direction == "B", "Buy", "Sell"), format(t$entry_ts, "%d/%m %H:%M", tz = "Europe/London"), t$trade_id)
    observe({
      o <- open_trades(); ch <- if (nrow(o)) setNames(o$trade_id, trade_label(o)) else c("(no open trades)" = "")
      updateSelectInput(session, "m_trade", choices = ch, selected = isolate(input$m_trade))
    })
    sel <- reactive({ o <- open_trades(); req(nzchar(input$m_trade)); r <- o[o$trade_id == input$m_trade, ]; req(nrow(r) == 1); r })
    output$m_summary <- renderUI({
      o <- open_trades(); if (!nrow(o) || !nzchar(tr_or(input$m_trade, ""))) return(NULL); r <- sel()
      stops <- na.omit(c(r$stop1, r$stop2, r$stop3, r$stop4))
      tags$div(style = "background:#f6f8fb; border-radius:8px; padding:8px 12px; margin-bottom:8px; font-size:13px; color:#2c3e50;",
        sprintf("%s %s at %s | stake GBP %.2f/pip | stops so far: %s | target %s | risk GBP %.2f | planned RRR %.2f",
                r$asset, ifelse(r$direction == "B", "buy", "sell"), r$entry_price, r$stake_per_pip_gbp, paste(stops, collapse = " → "), r$target, r$initial_risk_gbp, r$initial_rrr))
    })
    # edit entry details of the selected open trade: load its current values into the form
    observeEvent(list(input$m_trade, input$m_action), {
      if (!identical(input$m_action, "edit") || !nzchar(tr_or(input$m_trade, ""))) return()
      r <- tryCatch(sel(), error = function(e) NULL); if (is.null(r)) return()
      tx <- function(v) if (is.null(v) || is.na(v)) "" else as.character(v)
      loc <- format(r$entry_ts, "%Y-%m-%d", tz = "Europe/London")
      updateDateInput(session, "e_date", value = as.Date(loc)); updateTextInput(session, "e_time", value = format(r$entry_ts, "%H:%M", tz = "Europe/London"))
      updateSelectInput(session, "e_purpose", selected = tx(r$trade_purpose)); updateSelectInput(session, "e_contract", selected = tx(r$contract_type))
      updateTextInput(session, "e_dealref", value = tx(r$deal_reference))
      for (p in list(c("e_spread", "spread_pts"), c("e_margin", "margin_gbp"), c("e_notional", "notional_gbp"), c("e_costs", "costs_gbp")))
        updateNumericInput(session, p[1], value = if (is.na(r[[p[2]]])) NA else r[[p[2]]])
      for (p in list(c("e_fund", "setup_fundamental"), c("e_tech", "setup_technical"), c("e_trigger", "trigger_text"), c("e_exec", "execution_text"),
                     c("e_stopwhy", "stop_reason"), c("e_tgtwhy", "target_reason")))
        updateTextAreaInput(session, p[1], value = tx(r[[p[2]]]))
    })
    observeEvent(input$m_save, {
      if (identical(input$m_action, "edit")) {
        r <- sel(); ts2 <- tr_parse_ts(input$e_date, tr_or(input$e_time, ""))
        if (is.na(ts2)) { msg("The entry date/time is not valid (use HH:MM, UK time).", "error"); return() }
        if (!nzchar(tr_or(input$e_purpose, ""))) { msg("Choose whether this is an assessed trade or a practice trade.", "error"); return() }
        nxt <- r; nxt$record_version <- r$record_version + 1L
        nxt$entry_ts <- ts2; nxt$week_no <- tr_week_no(as.Date(format(ts2, tz = "Europe/London")), p_start())
        nxt$trade_sheet_name <- sprintf("%s - %s", r$asset, format(ts2, "%d/%m/%Y %H:%M", tz = "Europe/London"))
        nxt$trade_purpose <- input$e_purpose; nxt$contract_type <- tr_blank_na(input$e_contract); nxt$deal_reference <- tr_blank_na(input$e_dealref)
        nxt$spread_pts <- tr_num(input$e_spread); nxt$margin_gbp <- tr_num(input$e_margin); nxt$notional_gbp <- tr_num(input$e_notional); nxt$costs_gbp <- tr_num(input$e_costs)
        nxt$setup_fundamental <- tr_blank_na(input$e_fund); nxt$setup_technical <- tr_blank_na(input$e_tech); nxt$trigger_text <- tr_blank_na(input$e_trigger)
        nxt$execution_text <- tr_blank_na(input$e_exec); nxt$stop_reason <- tr_blank_na(input$e_stopwhy); nxt$target_reason <- tr_blank_na(input$e_tgtwhy)
        report(store$write("trades", nxt), "Entry details"); bump(); return()
      }
      act <- input$m_action; r <- sel(); ts <- tr_parse_ts(input$m_date, tr_or(input$m_time, ""))
      if (is.na(ts)) { msg("The date/time is not valid (use HH:MM, UK time).", "error"); return() }
      nxt <- r; nxt$record_version <- r$record_version + 1L
      if (act == "stop") {
        ns_ <- tr_num(input$m_newstop); if (!is.finite(ns_)) { msg("Enter the new stop price.", "error"); return() }
        slot <- which(is.na(c(r$stop2, r$stop3, r$stop4)))[1]
        if (is.na(slot)) { msg("All four stop slots are used.", "error"); return() }
        cur <- tail(na.omit(c(r$stop1, r$stop2, r$stop3, r$stop4)), 1)
        nxt[[c("stop2", "stop3", "stop4")[slot]]] <- ns_
        ev <- data.frame(event_id = tr_id("E"), trade_id = r$trade_id, event_ts = ts, event_type = "STOP_MOVE", old_stop = cur, new_stop = ns_,
                         reason = tr_blank_na(input$m_stopwhy), permitted_by_spec = input$m_permitted == "Y", stringsAsFactors = FALSE)
        store$write("trade_events", ev); report(store$write("trades", nxt), "Stop move")
      } else if (act == "cancel") {
        nxt$status <- "CANCELLED"; report(store$write("trades", nxt), "Cancellation")
      } else {
        px <- tr_num(input$m_exit); if (!is.finite(px)) { msg("Enter the exit price.", "error"); return() }
        if (!is.na(r$entry_ts) && ts < r$entry_ts) { msg("Exit is before the entry time.", "error"); return() }
        followed <- input$m_followed == "Y"
        if (!followed && !nzchar(trimws(tr_or(input$m_devnote, "")))) { msg("Describe the deviation (what happened and why).", "error"); return() }
        fill <- function(row, stake, risk_gbp) {
          cc <- tr_close_calc(row$direction, row$entry_price, px, row$pip_size, stake, risk_gbp, tr_num(input$m_pnl))
          row$status <- "CLOSED"; row$exit_ts <- ts; row$exit_price <- px; row$exit_code <- input$m_code
          row$pips_result <- cc$pips; row$net_pnl_gbp <- cc$net; row$pnl_source <- cc$source; row$real_r <- cc$real_r
          row$duration_hours <- as.numeric(difftime(ts, row$entry_ts, units = "hours")); row$mood_exit <- as.integer(input$m_mood)
          row$plan_followed <- followed; row$deviation_type <- if (followed) NA_character_ else input$m_devtype
          row$deviation_note <- if (followed) NA_character_ else tr_blank_na(input$m_devnote)
          row$reason_for_exit <- tr_blank_na(input$m_why); row$lessons_learned <- tr_blank_na(input$m_lessons)
          me <- identical(input$m_code, "ME"); pf <- tr_or(input$m_post, "")
          row$me_then_hit_stop <- if (me) identical(pf, "stop") else NA; row$me_then_hit_target <- if (me) identical(pf, "target") else NA
          if (!is.null(ev_close())) { row$evidence_ids <- paste(na.omit(c(row$evidence_ids, ev_close())), collapse = ","); row$verified_by_user <- TRUE }
          row }
        if (act == "close") {
          report(store$write("trades", fill(nxt, r$stake_per_pip_gbp, r$initial_risk_gbp)), "Closed trade")
          if (!is.null(ev_close())) { link_evidence(ev_close(), r$trade_id); ev_close(NULL) }
        } else {
          ps <- tr_num(input$m_pstake)
          if (!is.finite(ps) || ps <= 0 || ps >= r$stake_per_pip_gbp - 1e-12) { msg("Partial stake must be above zero and below the open stake. Use Closed to exit everything.", "error"); return() }
          child <- r; child$trade_id <- tr_id("T"); child$record_version <- 1L; child$parent_trade_id <- r$trade_id
          child$stake_per_pip_gbp <- ps; child$initial_risk_gbp <- r$initial_risk_pips * ps
          child$trade_sheet_name <- paste0(r$trade_sheet_name, " (partial)")
          child <- fill(child, ps, child$initial_risk_gbp)
          nxt$stake_per_pip_gbp <- r$stake_per_pip_gbp - ps; nxt$initial_risk_gbp <- r$initial_risk_pips * nxt$stake_per_pip_gbp
          store$write("trade_events", data.frame(event_id = tr_id("E"), trade_id = r$trade_id, event_ts = ts, event_type = "PARTIAL_EXIT",
            size_closed_per_pip = ps, price = px, reason = tr_blank_na(input$m_why), permitted_by_spec = followed, stringsAsFactors = FALSE))
          store$write("trades", child); report(store$write("trades", nxt), "Partial exit")
          if (!is.null(ev_close())) { link_evidence(ev_close(), child$trade_id); ev_close(NULL) }
        }
      }
      bump()
    })
    output$tr_table <- DT::renderDT({
      t <- trades_df()
      if (!nrow(t)) return(DT::datatable(data.frame(Message = "No trades saved yet."), rownames = FALSE, options = list(dom = "t")))
      t <- t[order(t$entry_ts, decreasing = TRUE), ]
      t$entry <- format(t$entry_ts, "%d/%m %H:%M", tz = "Europe/London"); t$exit <- format(t$exit_ts, "%d/%m %H:%M", tz = "Europe/London")
      t$purpose <- ifelse(is.na(t$trade_purpose) | !nzchar(t$trade_purpose), "ASSESSED", t$trade_purpose)
      DT::datatable(t[, c("trade_sheet_name", "purpose", "status", "asset_class", "contract_type", "strategy", "direction", "entry_price", "stop1", "target", "initial_rrr", "exit_price", "exit_code",
                          "net_pnl_gbp", "real_r", "plan_followed", "week_no")], rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE)) |>
        DT::formatRound(c("initial_rrr", "net_pnl_gbp", "real_r"), 2)
    })
    output$dlTrades <- downloadHandler(filename = function() paste0("trading_trades_", format(Sys.Date()), ".csv"),
                                       content = function(file) write.csv(trades_df(), file, row.names = FALSE, na = ""))

    # ---------------------------------------------------------------- statistics
    stats <- reactive({
      t <- tr_scope_filter(trades_df(), tr_or(input$st_scope, "ASSESSED")); cl <- t[t$status == "CLOSED" & !is.na(t$net_pnl_gbp), , drop = FALSE]
      if (!identical(input$st_week, "all") && !is.null(input$st_week)) cl <- cl[!is.na(cl$week_no) & cl$week_no == as.integer(input$st_week), , drop = FALSE]
      tr_stats(cl, opening())
    })
    output$st_tiles <- renderUI({
      s <- stats(); if (is.null(s)) return(tags$div(style = "color:#2c3e50; padding:12px;", "No closed trades yet. Statistics appear as soon as you close a trade."))
      m <- s$summary
      tags$div(style = "display:flex; flex-wrap:wrap;",
        tr_tile("Trades", m$trades, sprintf("%d won · %d lost", m$wins, m$losses)), tr_tile("Win rate", tr_fmt_pct(m$win_rate)),
        tr_tile("Avg planned RRR", tr_fmt_num(m$avg_initial_rrr)), tr_tile("Avg Real R", tr_fmt_num(m$avg_real_r), "expectancy per trade, in R"),
        tr_tile("Net P/L", paste0("£", tr_fmt_num(m$total_pnl_gbp)), tr_fmt_pct(m$return_pct, 2), if (m$total_pnl_gbp >= 0) "#15803d" else "#b91c1c"),
        tr_tile("Max drawdown", tr_fmt_pct(m$max_drawdown_pct, 2), paste0("£", tr_fmt_num(m$max_drawdown_gbp))),
        tr_tile("Adherence", tr_fmt_pct(m$adherence_rate), sprintf("%d followed · %d deviations", m$followed, m$deviations)),
        tr_tile("Profit factor", tr_fmt_num(m$profit_factor)), tr_tile("Avg win / loss", paste0("£", tr_fmt_num(m$avg_win_gbp, 0), " / £", tr_fmt_num(m$avg_loss_gbp, 0))),
        tr_tile("Sharpe / Sortino", paste(tr_fmt_num(m$sharpe_per_trade), "/", tr_fmt_num(m$sortino_per_trade)), "per trade, secondary"))
    })
    output$st_caution <- renderUI({
      s <- stats(); if (is.null(s) || s$summary$trades >= 20) return(NULL)
      ua_callout(sprintf("Only %d closed trade(s): ratios and percentages move a lot with each new trade. Lean on the individual trade reviews, adherence and consistency.", s$summary$trades))
    })
    output$st_equity <- plotly::renderPlotly({
      s <- stats(); req(s); e <- s$equity
      plotly::plot_ly(e, x = ~trade_no, y = ~equity, type = "scatter", mode = "lines+markers", line = list(color = "#008A82"), name = "Equity") |>
        plotly::layout(title = list(text = "Equity by trade", font = list(size = 13)), xaxis = list(title = "Trade number", dtick = 1), yaxis = list(title = "GBP"))
    })
    output$st_r <- plotly::renderPlotly({
      s <- stats(); req(s); t <- s$trades; t$n <- seq_len(nrow(t))
      plotly::plot_ly(t, x = ~n, y = ~real_r, type = "bar", marker = list(color = ifelse(t$real_r >= 0, "#15803d", "#b91c1c")), name = "Real R") |>
        plotly::layout(title = list(text = "Real R by trade", font = list(size = 13)), xaxis = list(title = "Trade number", dtick = 1), yaxis = list(title = "R"))
    })
    fmt_tbl <- function(d) { if (is.null(d)) return(NULL); d$`Win rate` <- if ("Win rate" %in% names(d)) sprintf("%.0f%%", 100 * d$`Win rate`); d }
    tbl <- function(key, fix = TRUE) renderTable({ s <- stats(); req(s); d <- s[[key]]; if (fix && !is.null(d) && "Win rate" %in% names(d)) d$`Win rate` <- sprintf("%.0f%%", 100 * d$`Win rate`); d },
                                                  striped = TRUE, bordered = TRUE, spacing = "s", digits = 2)
    output$st_strat <- tbl("by_strategy"); output$st_asset <- tbl("by_asset"); output$st_exit <- tbl("by_exit")
    output$st_wd <- tbl("by_weekday", FALSE); output$st_hr <- tbl("by_hour", FALSE); output$st_mood <- tbl("by_mood", FALSE)

    # ---------------------------------------------------------------- exports
    ex_trades <- reactive(tr_scope_filter(trades_df(), tr_or(input$ex_scope, "ASSESSED")))
    observe({
      t <- ex_trades(); t <- t[t$status %in% c("OPEN", "CLOSED") & is.na(t$parent_trade_id), , drop = FALSE]
      ch <- if (nrow(t)) { t <- t[order(t$entry_ts, decreasing = TRUE), ]; setNames(t$trade_id, paste0(t$trade_sheet_name, " [", t$status, "]")) } else c("(no trades yet)" = "")
      updateSelectInput(session, "ex_trade", choices = ch, selected = isolate(input$ex_trade))
    })
    observe({
      s <- sheets_df(); ch <- if (nrow(s)) setNames(format(sort(s$sheet_date, decreasing = TRUE)), format(sort(s$sheet_date, decreasing = TRUE), "%d/%m/%Y")) else c("(no sheets yet)" = "")
      updateSelectInput(session, "ex_sheet", choices = ch, selected = isolate(input$ex_sheet))
    })
    trader <- reactive(tr_or(input$s_name, tr_or(sv()$trader_name, "")))
    trader_label <- reactive({ n <- trader(); i <- tr_or(input$s_id, tr_or(sv()$student_id, "")); if (nzchar(i)) paste0(n, " (", i, ")") else n })
    output$dlBlotter <- downloadHandler(filename = function() paste0("trade_blotter_", format(Sys.Date()), ".xlsx"),
      content = function(file) tr_write_blotter(ex_trades(), file, trader()))
    output$dlStatsX <- downloadHandler(filename = function() paste0("trading_statistics_", format(Sys.Date()), ".xlsx"),
      content = function(file) tr_stats_xlsx(ex_trades(), opening(), file, trader()))
    pths <- function(id) { f <- input[[id]]; if (is.null(f) || !NROW(f)) character(0) else f$datapath }
    pths_cal <- function(id, alt) { p <- pths(id); if (length(p)) p else pths(alt) }   # Morning-tab calendar pictures are reused when none are added here
    morning_day <- function() tryCatch(as.Date(input$ex_sheet), error = function(e) tr_london_today())
    build_morning <- function(file) {
      s <- sheets_df(); h <- s[format(s$sheet_date) == tr_or(input$ex_sheet, ""), , drop = FALSE]
      if (!nrow(h)) stop("Choose a saved morning sheet first.")
      h <- h[1, ]; lv <- levels_df(); lv <- lv[lv$sheet_id == h$sheet_id, , drop = FALSE]
      tr_morning_docx(h, lv, trader_label(), file, cal_o = pths_cal("cal_o", "ms_cal_img_o"), cal_t = pths_cal("cal_t", "ms_cal_img_t"))
    }
    trade_row <- function() { t <- trades_df(); t[t$trade_id == tr_or(input$ex_trade, ""), , drop = FALSE] }
    trade_name <- function(ext) { r <- trade_row(); if (nrow(r) == 1) tr_trade_filename(r$asset, format(r$entry_ts, "%Y-%m-%d", tz = "Europe/London"), ext) else paste0("Individual_Trade_Sheet.", ext) }
    build_trade <- function(file) {
      t <- trades_df(); tid <- tr_or(input$ex_trade, ""); tr1 <- t[t$trade_id == tid, , drop = FALSE]
      if (nrow(tr1) != 1) stop("Choose a trade first.")
      legs <- t[(t$trade_id == tid | (!is.na(t$parent_trade_id) & t$parent_trade_id == tid)) & t$status == "CLOSED", , drop = FALSE]
      ev <- events_df(); ev <- ev[ev$trade_id == tid, , drop = FALSE]
      tr_trade_sheet_docx(tr1, legs, ev, trader_label(), list(entry = pths("ch_entry"), trade = pths("ch_trade"), exit = pths("ch_exit")), file)
    }
    pdf_of <- function(builder, name) {   # build the Word file under its final name in a temp folder, then convert
      d <- tempfile("sheet_"); dir.create(d); f <- file.path(d, name); builder(f); p <- tr_docx_to_pdf(f, d); list(docx = f, pdf = p)
    }
    output$dlMorning <- downloadHandler(filename = function() tr_morning_filename(morning_day()), content = function(file) build_morning(file))
    output$dlTradeSheet <- downloadHandler(filename = function() trade_name("docx"), content = function(file) build_trade(file))
    output$dlMorningPdf <- downloadHandler(filename = function() tr_morning_filename(morning_day(), "pdf"),
      content = function(file) { r <- pdf_of(build_morning, tr_morning_filename(morning_day())); if (is.na(r$pdf)) stop("PDF conversion needs LibreOffice on this computer. Download the Word file and use Save as PDF."); file.copy(r$pdf, file, overwrite = TRUE) })
    output$dlTradeSheetPdf <- downloadHandler(filename = function() trade_name("pdf"),
      content = function(file) { r <- pdf_of(build_trade, trade_name("docx")); if (is.na(r$pdf)) stop("PDF conversion needs LibreOffice on this computer. Download the Word file and use Save as PDF."); file.copy(r$pdf, file, overwrite = TRUE) })
    sv_res <- reactiveVal(NULL)
    save_dbx <- function(builder, name) {
      r <- tryCatch(pdf_of(builder, name), error = function(e) { msg(conditionMessage(e), "error"); NULL }); if (is.null(r)) return()
      res <- tr_save_to_dropbox(c(r$docx, r$pdf), tr_or(input$s_dbx, tr_or(sv()$dropbox_dir, "")), tr_or(input$s_dbxapi, tr_or(sv()$dropbox_api_path, "")))
      if (is.na(r$pdf)) res <- rbind(res, data.frame(file = sub("\\.docx$", ".pdf", name), where = "", ok = FALSE, note = "PDF not made: LibreOffice was not found on this computer", stringsAsFactors = FALSE))
      sv_res(res); msg(if (all(res$ok)) "Saved." else "Some files were not saved: see the list below.", if (all(res$ok)) "message" else "warning")
    }
    observeEvent(input$sv_morning, save_dbx(build_morning, tr_morning_filename(morning_day())))
    observeEvent(input$sv_trade, save_dbx(build_trade, trade_name("docx")))
    output$sv_out <- renderUI({ r <- sv_res(); if (is.null(r)) return(NULL)
      tags$div(style = "font-size:12.5px; background:#f6f8fb; border-radius:8px; padding:8px 12px; margin:8px 0; color:#2c3e50;",
               lapply(seq_len(nrow(r)), function(i) tags$div(paste0(if (r$ok[i]) "✓ " else "✗ ", r$file[i], if (nzchar(r$where[i])) paste0(" → ", r$where[i]) else "", ": ", r$note[i])))) })

    # ---------------------------------------------------------------- morning sheet: read levels from IG screenshots
    if (is.null(vision_fn)) vision_fn <- function(images, prompt) api_manager$call_claude_vision(images, prompt)
    ms_read_df <- reactiveVal(NULL)
    apply_markets <- function(all) {
      fin <- function(v) if (is.finite(v)) v else NA
      for (k in seq_len(nrow(all))) { r <- all[k, ]
        if (identical(r$code, "DOW")) { updateNumericInput(session, "ms_dow", value = fin(r$cur)); updateNumericInput(session, "ms_dowc", value = fin(r$chg_pct)); updateNumericInput(session, "ms_dowp", value = fin(r$chg_pts)) }
        else if (identical(r$code, "JP225")) { updateNumericInput(session, "ms_nik", value = fin(r$cur)); updateNumericInput(session, "ms_nikc", value = fin(r$chg_pct)); updateNumericInput(session, "ms_nikp", value = fin(r$chg_pts)) }
        else {
          slots <- vapply(1:8, function(i) tr_or(input[[paste0("ml", i, "_inst")]], ""), "")
          i <- which(toupper(slots) == r$code)[1]
          if (is.na(i)) i <- which(!nzchar(slots) & !(seq_along(slots) %in% which(toupper(slots) %in% all$code)))[1]
          if (is.na(i)) { msg(paste0("No free row for ", r$name, ". Clear one of the extra rows first."), "warning"); next }
          updateSelectizeInput(session, paste0("ml", i, "_inst"), choices = tr_blank_choice(r$code), selected = r$code, options = list(create = TRUE))
          updateNumericInput(session, paste0("ml", i, "_low"), value = fin(r$low)); updateNumericInput(session, paste0("ml", i, "_high"), value = fin(r$high)); updateNumericInput(session, paste0("ml", i, "_cur"), value = fin(r$cur))
          if (!is.na(r$time)) updateTextInput(session, paste0("ml", i, "_time"), value = r$time)
        }
      }
      ms_read_df(all)
    }
    observeEvent(input$ms_read, {
      f <- input$ms_shots; if (is.null(f) || !NROW(f)) { msg("Select one or more screenshots first.", "warning"); return() }
      parts <- list()
      withProgress(message = "Reading the screenshots with Claude...", value = 0, {
        for (i in seq_len(nrow(f))) {
          incProgress(1 / nrow(f), detail = f$name[i])
          img <- tryCatch(tr_read_image(f$datapath[i], f$name[i]), error = function(e) { msg(paste0(f$name[i], ": ", conditionMessage(e)), "error"); NULL }); if (is.null(img)) next
          res <- tryCatch(vision_fn(list(list(media_type = img$media_type, data = img$data)), tr_morning_vision_prompt()),
                          error = function(e) { cat("[Records] Claude call failed:", conditionMessage(e), "\n"); msg(paste0(f$name[i], ": Claude could not read the image: ", conditionMessage(e)), "error"); NULL }); if (is.null(res)) next
          parsed <- tr_parse_vision_json(res$text)
          if (is.null(parsed)) { msg(paste0(f$name[i], ": the reply could not be read as values. Try a clearer screenshot."), "error"); next }
          parts[[length(parts) + 1]] <- tr_morning_assign(parsed)
        }
      })
      parts <- Filter(function(d) NROW(d) > 0, parts)
      if (!length(parts)) { msg("No market prices were read.", "warning"); return() }
      all <- do.call(rbind, parts); all <- all[!duplicated(all$code, fromLast = TRUE), , drop = FALSE]
      apply_markets(all); msg(sprintf("%d market(s) read. Compare every value with the screenshot before saving.", nrow(all)))
    })
    output$ms_read_out <- renderUI({
      d <- ms_read_df(); if (is.null(d) || !nrow(d)) return(NULL)
      f <- function(v) ifelse(is.finite(v), format(v, trim = TRUE), "")
      tags$div(style = "font-size:12.5px; background:#f6f8fb; border-radius:8px; padding:8px 12px; margin-bottom:10px; color:#2c3e50;",
        tags$div(style = "font-weight:800; color:#002C3C; margin-bottom:4px;", "Read from the screenshots"),
        lapply(seq_len(nrow(d)), function(i) { r <- d[i, ]
          tags$div(paste0(r$name, " (", r$code, "): low ", f(r$low), ", high ", f(r$high), ", price ", f(r$cur), if (is.finite(r$chg_pct)) paste0(", change ", format(r$chg_pct), "%") else "", if (!is.na(r$time)) paste0(", time ", r$time) else "",
                          if (identical(r$basis, "candle")) "  [low/high are from one candle, not the overnight range: check]" else "")) }))
    })

    # ---------------------------------------------------------------- morning sheet: web search + calendar
    if (is.null(text_fn)) text_fn <- function(prompt) list(text = api_manager$call_claude(prompt, max_tokens = 6000, enable_web_search = TRUE))
    cal_o_df <- reactiveVal(NULL); cal_t_df <- reactiveVal(NULL)
    day_sel <- reactive({ d <- input$ms_date; if (is.null(d) || is.na(d)) tr_london_today() else as.Date(d) })
    ask_web <- function(prompt, what) {
      res <- tryCatch(text_fn(prompt), error = function(e) { cat("[Records] web search failed:", conditionMessage(e), "\n"); msg(paste0(what, ": Claude could not complete the search: ", conditionMessage(e)), "error"); NULL })
      if (is.null(res)) return(NULL)
      p <- tr_parse_vision_json(if (is.list(res)) res$text else res)
      if (is.null(p)) { msg(paste0(what, ": the reply could not be read. Try again."), "error"); return(NULL) }
      p
    }
    set_cal <- function(which, df, label) {
      if (which == "o") { cal_o_df(df); updateTextAreaInput(session, "ms_cal_o", value = tr_calendar_text(df)) } else { cal_t_df(df); updateTextAreaInput(session, "ms_cal_t", value = tr_calendar_text(df)) }
      msg(sprintf("%s calendar: %d event(s). Check them against the source before saving.", label, nrow(df)), if (nrow(df)) "message" else "warning")
    }
    observeEvent(input$ms_web_mk, {
      d <- day_sel()
      withProgress(message = "Claude is searching the web for market levels...", value = 0.3, {
        p <- ask_web(tr_morning_web_prompt(d), "Market levels"); if (is.null(p)) return()
        all <- tr_morning_assign(p); if (!NROW(all)) { msg("No market levels were found. Try again, or use screenshots.", "warning"); return() }
        apply_markets(all)
        hl <- unlist(p$headlines); hl <- hl[!is.na(hl) & nzchar(hl)]
        if (length(hl)) updateTextAreaInput(session, "ms_news", value = paste(c(hl, paste0("Note: approximate levels and headlines found online for ", format(d, "%d/%m/%Y"), " (", paste(unlist(p$sources), collapse = ", "), "), not read from the IG platform.")), collapse = "\n"))
        msg(sprintf("%d market(s) found online. They are approximate: compare with your IG platform before saving.", nrow(all)))
      })
    })
    observeEvent(input$ms_web_cal, {
      d <- day_sel()
      withProgress(message = "Claude is searching the web for the calendar...", value = 0, {
        incProgress(0.1, detail = "yesterday"); py <- ask_web(tr_calendar_web_prompt(d - 1, "yesterday"), "Yesterday's calendar")
        if (!is.null(py)) set_cal("o", tr_calendar_df(py), "Yesterday's")
        incProgress(0.5, detail = "today"); pt <- ask_web(tr_calendar_web_prompt(d, "today"), "Today's calendar")
        if (!is.null(pt)) set_cal("t", tr_calendar_df(pt), "Today's")
      })
    })
    observeEvent(input$ms_cal_read, {
      one <- function(f, which, label) {
        if (is.null(f) || !NROW(f)) return(invisible())
        parts <- list()
        for (i in seq_len(nrow(f))) {
          img <- tryCatch(tr_read_image(f$datapath[i], f$name[i]), error = function(e) { msg(paste0(f$name[i], ": ", conditionMessage(e)), "error"); NULL }); if (is.null(img)) next
          res <- tryCatch(vision_fn(list(list(media_type = img$media_type, data = img$data)), tr_calendar_vision_prompt()),
                          error = function(e) { msg(paste0(f$name[i], ": Claude could not read the image: ", conditionMessage(e)), "error"); NULL }); if (is.null(res)) next
          p <- tr_parse_vision_json(res$text); if (is.null(p)) { msg(paste0(f$name[i], ": the reply could not be read."), "error"); next }
          parts[[length(parts) + 1]] <- tr_calendar_df(p)
        }
        parts <- Filter(function(x) NROW(x) > 0, parts); if (length(parts)) set_cal(which, do.call(rbind, parts), label)
      }
      if (is.null(input$ms_cal_img_o) && is.null(input$ms_cal_img_t)) { msg("Select the calendar screenshot(s) first.", "warning"); return() }
      withProgress(message = "Reading the calendar screenshots with Claude...", value = 0.3, { one(input$ms_cal_img_o, "o", "Yesterday's"); one(input$ms_cal_img_t, "t", "Today's") })
    })
    # the tables follow the text boxes (so a loaded sheet or a hand edit shows too)
    cal_show <- function(txt) { d <- tr_calendar_parse_text(txt); if (!nrow(d)) NULL else setNames(d, c("Time", "Country", "Importance", "Event", "Actual", "Forecast", "Previous")) }
    cal_dt <- function(txt) { d <- cal_show(txt); if (is.null(d)) return(DT::datatable(data.frame(Note = "No calendar yet: use the buttons above, or paste lines in the box below."), rownames = FALSE, options = list(dom = "t")))
      DT::datatable(d, rownames = FALSE, options = list(dom = "t", pageLength = 60, ordering = FALSE)) |> DT::formatStyle("Importance", color = DT::styleEqual(c("High", "Medium", "Low"), c("#c0392b", "#b9770e", "#7f8c8d")), fontWeight = "bold") }
    output$cal_tbl_o <- DT::renderDT(cal_dt(input$ms_cal_o)); output$cal_tbl_t <- DT::renderDT(cal_dt(input$ms_cal_t))

    # ---------------------------------------------------------------- schema
    proj <- function() tr_or(tryCatch(api_manager$bq_project_id, error = function(e) NULL), "atera-2")
    dset <- function() tr_or(tryCatch(api_manager$bq_dataset_id, error = function(e) NULL), "business_strategy")
    output$schemaTables <- renderUI({
      tagList(lapply(names(tr_tables), function(n) { tb <- tr_tables[[n]]
        tags$details(style = "background:#f6f8fb; border-radius:8px; padding:8px 12px; margin-bottom:8px; color:#2c3e50;",
          tags$summary(style = "font-weight:700; cursor:pointer;", sprintf("%s  (key: %s, %d columns)", tb$table, tb$key, length(tb$cols))),
          tags$div(style = "font-size:12px; line-height:1.6; margin-top:6px;", paste(sprintf("%s %s", names(tb$cols), tb$cols), collapse = " · ")))
      }))
    })
    ddl_text <- reactive(paste(paste0(tr_ddl(proj(), dset()), ";"), collapse = "\n\n"))
    output$ddlText <- renderText(ddl_text())
    output$dlDDL <- downloadHandler(filename = function() "trading_records_schema.sql", content = function(file) writeLines(ddl_text(), file))
  })
}
