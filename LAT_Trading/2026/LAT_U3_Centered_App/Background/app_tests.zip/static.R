# static whole-app checks
src <- readLines("app.R"); txt <- paste(src, collapse="\n")
tabs_menu <- regmatches(txt, gregexpr('tabName = "([a-z0-9_]+)"', txt))[[1]]
m <- unique(sub('tabName = "(.*)"','\\1', tabs_menu))
items <- unique(sub('tabItem\\(tabName = "(.*)"','\\1', regmatches(txt, gregexpr('tabItem\\(tabName = "[a-z0-9_]+"', txt))[[1]]))
menu_only <- setdiff(m, items); cat("menu without tabItem:", menu_only, "\n"); cat("tabItem without menu:", setdiff(items, m), "\n")
dups <- tabs_menu[duplicated(tabs_menu)]; cat("duplicate menu tabNames:", dups, "\n")
fl <- list.files(c("R","modules"), "\\.R$", full.names=TRUE)
fn <- unlist(lapply(fl, function(f) { e <- parse(f); n <- vapply(e, function(x) if (is.call(x) && as.character(x[[1]]) %in% c("<-","=") && is.symbol(x[[2]]) && is.call(x[[3]]) && identical(x[[3]][[1]], as.name("function"))) as.character(x[[2]]) else NA_character_, ""); paste0(basename(f), "::", n[!is.na(n)]) }))
nm <- sub(".*::","",fn); d <- unique(nm[duplicated(nm)]); cat("duplicate fn names:\n"); for (x in d) cat(" ", x, ":", fn[nm==x], "\n")
for (f in c(fl,"app.R","global.R")) invisible(parse(f)); cat("all files parse\n")
cat("banned libs:", unlist(lapply(c(fl,"app.R","global.R"), function(f) { l <- readLines(f, warn=FALSE); l <- l[!grepl("^\\s*#", l)]; if (any(grepl("library\\((terra|raster|leaflet|sf)\\)|(terra|raster|leaflet|sf)::", l))) f })), "\n")
