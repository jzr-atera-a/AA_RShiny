suppressPackageStartupMessages({library(shiny); library(shinydashboard); library(DT); library(plotly)})
setwd("app")
source("R/utils_academic.R"); source("R/utils_trading_records.R"); source("R/utils_trading_exports.R"); source("R/utils_trading_templates.R"); source("modules/trading_records.R")
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
near <- function(a, b, t = 1e-9) isTRUE(all(abs(a - b) < t))

# ---- fake BigQuery
env <- new.env(); env$connected <- FALSE; env$tables <- list(); env$fail <- FALSE; env$ensured <- 0
fake <- list(connected = function() env$connected,
  ensure = function() env$ensured <- env$ensured + 1,
  write = function(name, df) { if (env$fail) stop("boom"); env$tables[[name]] <- rbind(env$tables[[name]], df); nrow(df) },
  read = function(name) { if (is.null(env$tables[[name]])) tr_coerce(name, NULL) else env$tables[[name]] })
store <- tr_make_store(fake)

# store-level behaviour
r <- store$write("settings", data.frame(setting_key = "k", setting_value = "1")); ok(r == "pending" && store$pending_count() == 1, "offline write -> pending")
ok(nrow(store$read("settings")) == 1, "pending rows readable")
env$connected <- TRUE; n <- store$sync(); ok(n == 1 && store$pending_count() == 0 && nrow(env$tables$settings) == 1, "sync pushes pending to BQ")
r <- store$write("settings", data.frame(setting_key = "k", setting_value = "2")); ok(r == "bigquery", "connected write -> BQ")
cur <- tr_latest("settings", store$read("settings")); ok(nrow(cur) == 1 && cur$setting_value == "2", "latest setting wins")
env$fail <- TRUE; r <- store$write("settings", data.frame(setting_key = "k", setting_value = "3")); ok(grepl("queued", r) && store$pending_count() == 1, "BQ failure -> queued, not lost")
env$fail <- FALSE; store$sync(); cur <- tr_latest("settings", store$read("settings")); ok(cur$setting_value == "3", "after sync latest is 3")
env$tables <- list(); env$connected <- TRUE

args <- list(api_manager = NULL, store = store, quiet = TRUE)
testServer(trading_records_server, args = args, {
  session$setInputs(s_name = "Test", s_balance = 10000, s_start = as.Date("2026-10-12"), s_end = as.Date("2026-11-06"))
  session$setInputs(saveSettings = 1); ok(nrow(settings_df()) == 4 && near(opening(), 10000), "settings saved")
  # plan numbers live in Setup (saved in trading_settings)
  session$setInputs(s_adx_t = 30, s_adx_r = 20, s_risk = 1, s_cap = 1.5, s_minrrr = 1.5); session$setInputs(saveSettings = 2)
  ok(near(limits()$cap_pct, 1.5) && near(limits()$risk_pct, 1) && near(limits()$min_rrr, 1.5) && all(adx_cfg() == c(30, 20)), "plan numbers saved in settings and read back")
  # morning sheet
  session$setInputs(ms_date = as.Date("2026-10-12"), ms_dow = 44000, ms_dowc = -0.5, ms_nik = 39000, ms_nikc = 0.2,
    ml1_inst = "WTI", ml1_low = 79, ml1_high = 81, ml1_cur = 80, ml1_time = "07:30", ml1_adx = 35, ml1_ph = 110, ml1_pl = 100, ml1_pc = 104,
    ml2_inst = "NATGAS", ml2_low = 3, ml2_high = 3.1, ml2_cur = 3.05, ml2_time = "07:30", ml2_adx = 25, ml2_ph = NA, ml2_pl = NA, ml2_pc = NA,
    ml3_inst = "", ml3_low = NA, ml3_high = NA, ml3_cur = NA, ml3_time = "", ml3_adx = NA, ml3_ph = NA, ml3_pl = NA, ml3_pc = NA,
    ml4_inst = "", ml4_low = NA, ml4_high = NA, ml4_cur = NA, ml4_time = "", ml4_adx = NA, ml4_ph = NA, ml4_pl = NA, ml4_pc = NA,
    ms_news = "n", ms_cal_o = "", ms_cal_t = "t", ms_win = "", ms_regime = "r", ms_setups = "s", ms_expo = "", ms_risk = 0, ms_stand = FALSE, ms_stand_why = "")
  session$setInputs(ms_save = 1)
  ok(nrow(sheets_df()) == 1 && sheets_df()$week_no == 1L && sheets_df()$record_version == 1L, "morning sheet saved, week 1")
  lv <- levels_df(); ok(nrow(lv) == 2 && lv$regime_label[lv$instrument == "WTI"] == "TREND" && lv$regime_label[lv$instrument == "NATGAS"] == "UNCLEAR_NO_TRADE", "regime from ADX 35 / 25")
  ok(near(lv$pivot_pp[lv$instrument == "WTI"], 314/3, 1e-6) && near(lv$pivot_s1[lv$instrument == "WTI"], 2*314/3 - 110, 1e-6), "WTI pivots")
  session$setInputs(ms_save = 2); ok(nrow(sheets_df()) == 1 && sheets_df()$record_version == 2L, "re-save = version 2, still one current sheet")
  # trade 1: EURUSD buy, then stop move, partial, close
  session$setInputs(t_purpose = "ASSESSED", t_asset = "EURUSD", t_strategy = "HOLY_GRAIL", t_dir = "B", t_chart = "15 Min", t_date = as.Date("2026-10-13"), t_time = "09:40", t_dur = 2,
    t_pip = 0.0001, t_stake = 5, t_entry = 1.1, t_stop = 1.098, t_target = 1.104, t_adx = 33, t_corr = 0, t_mood = 4, t_parent = "",
    t_fund = "f", t_tech = "t", t_trigger = "tr", t_exec = "ex", t_stopwhy = "sw", t_tgtwhy = "tw")
  session$setInputs(t_save = 1)
  t <- trades_df(); ok(nrow(t) == 1 && t$status == "OPEN" && near(t$initial_risk_gbp, 100) && near(t$initial_rrr, 2) && t$regime_label == "TREND" && t$week_no == 1L, "trade opened with computed fields")
  ok(t$trade_sheet_name == "EURUSD - 13/10/2026 09:40", "trade sheet name matches Blotter format")
  ok(near(equity_now(), 10000) && nrow(open_trades()) == 1, "equity unchanged, one open trade")
  tid <- t$trade_id
  session$setInputs(m_trade = tid, m_action = "stop", m_date = as.Date("2026-10-13"), m_time = "10:30", m_newstop = 1.1, m_permitted = "Y", m_stopwhy = "to breakeven")
  session$setInputs(m_save = 1)
  t <- trades_df(); ok(near(t$stop2, 1.1) && t$record_version == 2L && nrow(events_df()) == 1 && events_df()$permitted_by_spec, "stop moved to stop2 with event")
  # partial: close 2 of 5 at 1.1030
  session$setInputs(m_action = "partial", m_pstake = 2, m_exit = 1.103, m_pnl = NA, m_code = "ME", m_mood = 4, m_followed = "Y", m_devtype = "Other", m_devnote = "", m_why = "partial", m_lessons = "l", m_date = as.Date("2026-10-13"), m_time = "11:00")
  session$setInputs(m_save = 2)
  t <- trades_df(); child <- t[!is.na(t$parent_trade_id), ]; par <- t[t$trade_id == tid, ]
  ok(nrow(t) == 2 && nrow(child) == 1 && child$status == "CLOSED" && near(child$net_pnl_gbp, 60) && near(child$initial_risk_gbp, 40) && near(child$real_r, 1.5), "partial child: 30 pips x 2 = 60, risk 40, R 1.5")
  ok(near(par$stake_per_pip_gbp, 3) && near(par$initial_risk_gbp, 60) && par$status == "OPEN", "parent reduced to stake 3, risk 60")
  # close remainder at stop2 (breakeven) as ME but flagged deviation
  session$setInputs(m_action = "close", m_exit = 1.1, m_code = "S2+", m_followed = "N", m_devtype = "Exited early", m_devnote = "", m_time = "12:00")
  session$setInputs(m_save = 3); ok(trades_df()[trades_df()$trade_id == tid, ]$status == "OPEN", "deviation without note rejected")
  session$setInputs(m_devnote = "closed on a wobble")
  session$setInputs(m_save = 4)
  par <- trades_df()[trades_df()$trade_id == tid, ]
  ok(par$status == "CLOSED" && near(par$net_pnl_gbp, 0) && near(par$real_r, 0) && par$plan_followed == FALSE && par$exit_code == "S2+" && near(par$duration_hours, 2.333333, 1e-4), "remainder closed at breakeven, deviation recorded, 2h20 duration")
  # trade 2: WTI sell stopped out (loss -100)
  session$setInputs(t_purpose = "ASSESSED", t_asset = "WTI", t_strategy = "PIVOT_BOUNCE", t_dir = "S", t_date = as.Date("2026-10-14"), t_time = "14:00", t_pip = 0.01, t_stake = 2, t_entry = 80, t_stop = 80.5, t_target = 78.5, t_adx = 15, t_mood = 3)
  session$setInputs(t_save = 2); w <- trades_df(); w <- w[w$asset == "WTI", ]
  ok(nrow(w) == 1 && near(w$initial_risk_gbp, 100) && near(w$initial_rrr, 3) && w$regime_label == "RANGE", "WTI sell opened (ADX 15 = RANGE)")
  session$setInputs(m_trade = w$trade_id, m_action = "close", m_exit = 80.5, m_pnl = NA, m_code = "S1", m_mood = 2, m_followed = "Y", m_date = as.Date("2026-10-14"), m_time = "15:00", m_why = "stopped", m_lessons = "")
  session$setInputs(m_save = 5)
  s <- stats()$summary
  ok(s$trades == 3 && s$wins == 1 && s$losses == 1 && s$breakeven == 1, "stats counts: 1W 1L 1BE")
  ok(near(s$total_pnl_gbp, -40) && near(equity_now(), 9960), "total P/L = 60 + 0 - 100 = -40")
  ok(near(s$adherence_rate, 2/3) && s$deviations == 1, "adherence 2 of 3")
  ok(near(s$max_drawdown_gbp, -100, 1e-6), "drawdown: peak 10060 -> trough 9960 = -100")
  # ordering: child closed 11:00 (+60), parent 12:00 (0), WTI 15:00 (-100)
  ok(near(stats()$equity$equity, c(10000, 10060, 10060, 9960)), "equity path ordered by exit time")
  session$setInputs(st_week = "1"); ok(stats()$summary$trades == 3, "week filter 1 includes all (all in week 1)")
  session$setInputs(st_week = "2"); ok(is.null(stats()), "week 2 empty -> NULL")
  session$setInputs(st_week = "all")
  # validation guard on open
  session$setInputs(t_stop = 79.0); session$setInputs(t_save = 3); ok(nrow(trades_df()) == 3, "sell with stop below entry rejected")
  # UI tables render
  ok(nchar(as.character(output$st_tiles$html)) > 500, "stat tiles render")
  ok(!is.null(output$ddlText) && grepl("trading_trades", output$ddlText), "DDL text")
  ok(any(grepl("MS_2026-10-12", env$tables$morning_sheets$sheet_id, fixed = TRUE)) && nrow(env$tables$morning_sheets) == 2, "append-only: 2 morning rows in BQ")
  ok(nrow(env$tables$trades) >= 7, "append-only: trade versions accumulate")
  session$setInputs(ensureTables = 1); ok(env$ensured >= 1, "ensure tables calls backend")
})
ui <- trading_records_ui("x"); h <- as.character(ui); ok(nchar(h) > 30000 && grepl("Create / verify tables", h, fixed = TRUE), "UI renders")
cat("ALL PASS\n")
