suppressPackageStartupMessages({library(shiny); library(shinydashboard); library(DT); library(plotly)})
setwd("app")
source("R/utils_academic.R"); source("R/utils_trading_records.R"); source("R/utils_trading_exports.R"); source("R/utils_trading_templates.R"); source("modules/trading_records.R"); source("modules/trading_evidence.R")
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
near <- function(a, b, t = 1e-9) isTRUE(all(abs(a - b) < t))
env <- new.env(); env$tables <- list()
fake <- list(connected = function() TRUE, ensure = function() NULL,
  write = function(name, df) { env$tables[[name]] <- rbind(env$tables[[name]], tr_coerce(name, df)); nrow(df) },
  read = function(name) if (is.null(env$tables[[name]])) tr_coerce(name, NULL) else env$tables[[name]])
store <- tr_make_store(fake)
bus <- reactiveValues(ts = 0, kind = NULL, values = NULL, evidence_id = NULL)
png <- tempfile(fileext = ".png"); writeBin(jsonlite::base64_dec("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), png)
calls <- 0
reply <- list(text = '```json\n{"platform":"IG","deal_reference":"DIAX1","asset":"EUR/USD","direction":"BUY","size":5,"date_text":"13/10/2026","time_text":"09:40","entry_price":1.1000,"stop_price":1.098,"limit_price":1.104,"confidence":{"entry_price":"high"}}\n```',
              model = "claude-test", usage = list(input_tokens = 1200, output_tokens = 150))
vf <- function(images, prompt) { calls <<- calls + 1; stopifnot(length(images) == 1, nzchar(images[[1]]$data), grepl("open position or a deal confirmation", prompt)); reply }

testServer(trading_evidence_server, args = list(api_manager = NULL, store = store, bus = bus, vision_fn = vf, quiet = TRUE), {
  session$setInputs(ex_kind = "open", ex_notes = "")
  session$setInputs(ex_file = data.frame(name = "a.png", datapath = png, size = 70, type = "image/png"))
  session$setInputs(ex_read = 1)
  ok(calls == 1, "vision_fn called once")
  ev <- env$tables$evidence; ok(nrow(ev) == 1 && ev$status == "EXTRACTED" && ev$model == "claude-test" && ev$input_tokens == 1200L && nchar(ev$file_md5) == 32, "EXTRACTED row logged in evidence table")
  ok(rv$ext$asset == "EURUSD" && near(rv$ext$entry, 1.1), "fields normalised")
  # user confirms fields as shown
  session$setInputs(f_asset = "EURUSD", f_dir = "B", f_size = 5, f_entry = 1.1, f_stop = 1.098, f_limit = 1.104, f_exit = NA, f_pnl = NA, f_ref = "DIAX1", f_platform = "IG", f_date = as.Date("2026-10-13"), f_time = "09:40")
  ok(!any(checks()$level == "error"), "no errors in checks")
  # a wrong stop blocks sending
  session$setInputs(f_stop = 1.102); session$setInputs(ex_send_open = 1)
  ok(bus$ts == 0 && nrow(env$tables$evidence) == 1, "wrong-side stop blocks send; nothing logged")
  session$setInputs(f_stop = 1.098); session$setInputs(ex_send_open = 2)
  ok(bus$ts == 1 && bus$kind == "open" && near(bus$values$entry, 1.1) && grepl("^EV_", bus$evidence_id), "bus carries confirmed values")
  ev <- tr_latest("evidence", env$tables$evidence); ok(nrow(ev) == 1 && ev$status == "CONFIRMED" && ev$record_version == 2L && grepl("DIAX1", ev$confirmed_json), "CONFIRMED version 2 (append-only)")
  # duplicate image warns but still works
  session$setInputs(ex_read = 2); ok(calls == 2, "second read allowed (duplicate warned)")
  # failure path
  reply_bad <- reply; reply <<- list(text = "I cannot read this", model = "m", usage = list())
  session$setInputs(ex_read = 3); ev <- tr_latest("evidence", env$tables$evidence); ok(any(ev$status == "FAILED"), "unparseable reply logged as FAILED")
  reply <<- reply_bad
})

# --- the source switch and the four IG mobile screens of one trade
js <- list(
  pos = '{"screen_type":"position_detail","asset":"Oil - Brent Crude","size":3,"size_text":"+3","size_unit":"per point","entry_price":10368.9,"current_price":10363.5,"stop_price":10356.9,"limit_price":10378.9,"unrealised_pnl":-16.2,"currency":"GBP"}',
  tkt = '{"screen_type":"new_trade_ticket","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude","size":3,"size_text":"3","stop_distance":12,"limit_distance":10,"sell_price":10365.7,"buy_price":10370.9,"quote_time_text":"U:22:25:58"}',
  mkt = '{"screen_type":"market_detail","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude","sell_price":10365.2,"buy_price":10370.4,"quote_time_text":"22:25:44"}',
  cls = '{"screen_type":"closed_trades","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude DFB","size_text":"+3","pnl":26.4,"open_date_text":"15/10/2026","close_date_text":"15/10/2026","entry_price":10368.9,"exit_price":10377.7,"deal_reference":"DIAAAAYN3A2X5B7"}')
seen <- character(0); cur <- "pos"; cnt <- 100
vf2 <- function(images, prompt) { seen <<- c(seen, prompt); list(text = js[[cur]], model = "claude-test", usage = list(input_tokens = 900, output_tokens = 200)) }
env$tables <- list(); bus2 <- reactiveValues(ts = 0, kind = NULL, values = NULL, evidence_id = NULL); store2 <- tr_make_store(fake)
testServer(trading_evidence_server, args = list(api_manager = NULL, store = store2, bus = bus2, vision_fn = vf2, quiet = TRUE), {
  rd <- function(name, src = "mobile", kind = "auto") { cur <<- name; session$setInputs(ex_kind = kind, ex_source = src, ex_notes = "")
    session$setInputs(ex_file = data.frame(name = paste0(name, ".png"), datapath = png, size = 70, type = "image/png")); session$setInputs(ex_read = (cnt <<- cnt + 1)) }
  # 1 ticket (auto-detect)
  rd("tkt"); ok(rv$kind == "ticket" && rv$source == "mobile" && grepl("IG mobile app", seen[length(seen)]) && grepl("First decide which screen", seen[length(seen)]), "auto-detect: ticket; mobile prompt used")
  session$setInputs(f_asset = "BRENT", f_dir = "", f_size = 3, f_entry = NA, f_stop = NA, f_limit = NA, f_exit = NA, f_pnl = NA, f_ref = "", f_platform = "IG", f_date = as.Date(NA), f_time = "")
  ok(!any(checks()$level == "error"), "ticket has no errors")
  session$setInputs(ex_send_close = 1); ok(bus2$ts == 0, "a ticket cannot be sent to the exit form")
  session$setInputs(ex_save_only = 1); ev <- tr_latest("evidence", env$tables$evidence)
  ok(nrow(ev) == 1 && ev$status == "CONFIRMED" && grepl('"stop_distance":12', ev$confirmed_json) && grepl('"source":"mobile"', ev$confirmed_json) && grepl('"screen":"ticket"', ev$confirmed_json) && ev$kind == "ticket", "ticket saved as evidence only with its distances")
  # 2 market detail
  rd("mkt"); ok(rv$kind == "market", "auto-detect: market screen")
  # 3 position detail
  rd("pos"); ok(rv$kind == "open" && rv$ext$direction == "B" && near(rv$ext$stop, 10356.9), "auto-detect: position detail, buy from +3")
  session$setInputs(f_asset = "BRENT", f_dir = "B", f_size = 3, f_entry = 10368.9, f_stop = 10356.9, f_limit = 10378.9, f_exit = NA, f_pnl = NA, f_ref = "", f_platform = "IG", f_date = as.Date("2026-10-15"), f_time = "22:26")
  ok(!any(checks()$level == "error"), "position detail passes the checks")
  session$setInputs(ex_send_open = 1); ok(bus2$ts == 1 && bus2$kind == "open" && near(bus2$values$stop, 10356.9) && near(bus2$values$size, 3), "position detail sent to the open-trade form")
  # 4 closed list, desktop switch changes the prompt
  rd("cls", src = "desktop"); ok(rv$kind == "close" && rv$source == "desktop" && grepl("IG website", seen[length(seen)]) && !grepl("IG mobile app", seen[length(seen)]), "desktop switch: website prompt sent")
  ok(near(rv$ext$exit, 10377.7) && rv$ext$date == as.Date("2026-10-15") && rv$ext$deal_ref == "DIAAAAYN3A2X5B7", "closed row values")
  session$setInputs(f_asset = "BRENT", f_dir = "B", f_size = 3, f_entry = 10368.9, f_stop = NA, f_limit = NA, f_exit = 10377.7, f_pnl = 26.4, f_ref = "DIAAAAYN3A2X5B7", f_platform = "IG", f_date = as.Date("2026-10-15"), f_time = "23:10")
  ok(any(grepl("agrees with the prices", checks()$message)), "closed row: P/L agrees with points x size")
  session$setInputs(ex_send_close = 1); ok(bus2$ts == 2 && bus2$kind == "close" && near(bus2$values$pnl, 26.4), "closed trade sent to the exit form")
  ev <- tr_latest("evidence", env$tables$evidence); ok(nrow(ev) == 4 && sum(ev$status == "CONFIRMED") == 3, "four screens logged, append-only")
  lg <- output$log_table; ok(!is.null(lg), "evidence log renders with a source column")
  h <- as.character(output$ex_source_hint$html); ok(grepl("Desktop website", h), "hint follows the switch (desktop)")
  session$setInputs(ex_source = "mobile"); h <- as.character(output$ex_source_hint$html); ok(grepl("Mobile app", h) && grepl("four screens", h), "hint follows the switch (mobile)")
})
ui_h <- as.character(trading_evidence_ui("x")); ok(grepl("Mobile app", ui_h) && grepl("Desktop website", ui_h) && grepl("ex_source", ui_h) || grepl("x-ex_source", ui_h), "UI has the Mobile app / Desktop website switch")

ev_id <- tr_latest("evidence", env$tables$evidence)$evidence_id[1]

# --- trading records receives the bus: prefill + link
testServer(trading_records_server, args = list(api_manager = NULL, store = store, quiet = TRUE, bus = bus), {
  session$setInputs(s_name = "T", s_balance = 10000, s_start = as.Date("2026-10-12"), s_end = as.Date("2026-11-06")); session$setInputs(saveSettings = 1)
  eid <- tr_latest("evidence", env$tables$evidence); eid <- eid$evidence_id[eid$status == "CONFIRMED"][1]
  bus$kind <- "open"; bus$values <- list(asset = "EURUSD", direction = "B", size = 5, entry = 1.1, stop = 1.098, limit = 1.104, date = as.Date("2026-10-13"), time = "09:40", deal_ref = "DIAX1"); bus$evidence_id <- eid; bus$ts <- 5
  session$flushReact()
  session$setInputs(t_purpose = "ASSESSED", t_asset = "EURUSD", t_strategy = "HOLY_GRAIL", t_dir = "B", t_chart = "15 Min", t_date = as.Date("2026-10-13"), t_time = "09:40", t_dur = 2,
    t_pip = 0.0001, t_stake = 5, t_entry = 1.1, t_stop = 1.098, t_target = 1.104, t_adx = 33, t_corr = 0, t_mood = 4, t_parent = "",
    t_fund = "f", t_tech = "t", t_trigger = "tr", t_exec = "ex", t_stopwhy = "sw", t_tgtwhy = "tw")
  session$setInputs(t_save = 1)
  t <- trades_df(); ok(nrow(t) == 1 && grepl(eid, t$evidence_ids, fixed = TRUE) && t$entry_source == "SCREENSHOT_VERIFIED", paste("trade stores evidence id; source =", t$entry_source))
  ev <- tr_latest("evidence", env$tables$evidence); ok(ev$status[ev$evidence_id == eid] == "LINKED" && ev$trade_id[ev$evidence_id == eid] == t$trade_id, "evidence row LINKED to trade")
  # close from screenshot
  bus$kind <- "close"; bus$values <- list(asset = "EURUSD", direction = "B", exit = 1.103, pnl = 15, date = as.Date("2026-10-13"), time = "11:20"); bus$evidence_id <- eid; bus$ts <- 6
  session$flushReact()
  session$setInputs(m_trade = t$trade_id, m_action = "close", m_exit = 1.103, m_pnl = 15, m_code = "T1", m_mood = 4, m_followed = "Y", m_devtype = "Other", m_devnote = "", m_why = "target", m_lessons = "l", m_date = as.Date("2026-10-13"), m_time = "11:20")
  session$setInputs(m_save = 1)
  t <- trades_df(); ok(t$status == "CLOSED" && near(t$net_pnl_gbp, 15) && t$pnl_source == "PLATFORM", paste("closed; pnl source", t$pnl_source))
})

h <- as.character(trading_evidence_ui("x")); ok(nchar(h) > 5000, "evidence UI renders"); 
cat("ALL PASS\n")

# --- several screenshots in one go
seen3 <- 0; js3 <- c(js[["tkt"]], js[["pos"]], "garbage")
vf3 <- function(images, prompt) { seen3 <<- seen3 + 1; list(text = js3[seen3], model = "claude-test", usage = list(input_tokens = 10, output_tokens = 5)) }
env$tables <- list(); bus3 <- reactiveValues(ts = 0, kind = NULL, values = NULL, evidence_id = NULL)
png2 <- tempfile(fileext = ".png"); file.copy(png, png2)
testServer(trading_evidence_server, args = list(api_manager = NULL, store = tr_make_store(fake), bus = bus3, vision_fn = vf3, quiet = TRUE), {
  session$setInputs(ex_kind = "auto", ex_source = "mobile", ex_notes = "")
  session$setInputs(ex_file = data.frame(name = c("t.png", "p.png", "bad.png"), datapath = c(png, png2, png), size = 70, type = "image/png"))
  session$setInputs(ex_read = 1)
  ok(seen3 == 3 && length(rv$items) == 3, "three screenshots read in one go")
  ev <- env$tables$evidence; ok(nrow(ev) == 3 && sum(ev$status == "EXTRACTED") == 2 && sum(ev$status == "FAILED") == 1 && all(is.na(ev$dropbox_path)), "three evidence rows (2 extracted, 1 failed), no Dropbox path")
  ok(rv$items[[1]]$kind == "ticket" && rv$items[[2]]$kind == "open" && rv$cur == 1, "each screen auto-classified; first loaded")
  session$setInputs(ex_pick = "2"); ok(rv$cur == 2 && rv$kind == "open" && rv$ext$asset == "BRENT", "picking item 2 loads the open position")
  session$setInputs(f_asset = "BRENT", f_dir = "B", f_size = 3, f_entry = 10368.9, f_stop = 10356.9, f_limit = 10378.9, f_exit = NA, f_pnl = NA, f_ref = "", f_platform = "IG", f_date = as.Date(NA), f_time = "")
  session$setInputs(ex_send_auto = 1); ok(bus3$ts == 1 && bus3$kind == "open", "smart send routes an open position to the open form")
  ok(rv$items[[2]]$status == "sent", "item marked sent")
})

# --- ticket + position of one trade: merge, London date fallback, unrealised P/L field, tokens kept
tk <- '{"screen_type":"deal_ticket","asset":"Oil - Brent Crude","contract_type_text":"Futures","direction":"SELL","size":3,"size_unit":"per point","stop_price":10392.2,"limit_price":10362.2,"stop_distance":18,"limit_distance":12,"sell_price":10374.2,"buy_price":10379.4,"margin":3112.98,"notional":31122.6,"costs":7.8,"currency":"GBP","confidence":{"asset":"high"}}'
ps <- '{"screen_type":"positions_table","asset":"Oil - Brent Crude","size":-3,"size_text":"-3","entry_price":10375.5,"current_price":10375.7,"stop_price":10393.5,"limit_price":10363.5,"unrealised_pnl":-0.6,"currency":"GBP","confidence":{"asset":"high"}}'
js4 <- c(ps, tk); n4 <- 0
vf4 <- function(images, prompt) { n4 <<- n4 + 1; stopifnot(grepl("Today's date in London", prompt), grepl("Read EVERY value", prompt)); list(text = js4[n4], model = "claude-test", usage = list(input_tokens = 111, output_tokens = 22)) }
env$tables <- list(); bus4 <- reactiveValues(ts = 0, kind = NULL, values = NULL, evidence_id = NULL)
testServer(trading_evidence_server, args = list(api_manager = NULL, store = tr_make_store(fake), bus = bus4, vision_fn = vf4, quiet = TRUE), {
  session$setInputs(ex_kind = "auto", ex_source = "desktop", ex_notes = "")
  session$setInputs(ex_file = data.frame(name = c("pos.png", "tkt.png"), datapath = c(png, png2), size = 70, type = "image/png"))
  session$setInputs(ex_read = 1)
  ok(rv$items[[1]]$ext$date == tr_london_today() && isTRUE(rv$items[[1]]$ext$date_assumed), "no date on the screen: today's London date is filled in")
  ok(is.finite(rv$ext$unrealised) && near(rv$ext$unrealised, -0.6) && near(rv$ext$current, 10375.7), "unrealised P/L and current price are extracted")
  session$setInputs(f_asset = "BRENT", f_dir = "S", f_size = 3, f_entry = 10375.5, f_stop = 10393.5, f_limit = 10363.5, f_exit = NA, f_pnl = NA, f_cur = 10375.7, f_upnl = -0.6, f_ref = "", f_platform = "IG", f_date = tr_london_today(), f_time = "21:18")
  ok(any(grepl("today's date in London", checks()$message)), "info note says the date was filled in")
  session$setInputs(ex_send_auto = 1)
  ok(bus4$ts == 1 && bus4$kind == "open" && near(bus4$values$margin, 3112.98) && near(bus4$values$notional, 31122.6) && near(bus4$values$costs, 7.8) && bus4$values$contract == "FUTURES" && near(bus4$values$spread, 5.2), "ticket platform details merged into the position send")
  ok(length(bus4$evidence_id) == 2, "both screenshots are carried to the trade")
  ev <- tr_latest("evidence", env$tables$evidence); pos <- ev[ev$file_name == "pos.png", ]
  ok(pos$input_tokens == 111L && pos$output_tokens == 22L, "token counts kept on the later version")
  ok(grepl('"unrealised_pnl":-0.6', pos$confirmed_json), "unrealised P/L saved with the confirmed evidence")
})
am_src <- paste(readLines("R/utils_api_manager.R"), collapse = "\n")
ok(grepl("claude_timeout        = 3000", am_src, fixed = TRUE) && grepl("min(max(as.numeric(timeout), 30), 3000)", am_src, fixed = TRUE) && !grepl("min(self$claude_timeout, 120)", am_src, fixed = TRUE), "Claude timeout: default 3000 s, capped at 3000 s, vision call no longer limited to 120 s")
app_src <- paste(readLines("app.R"), collapse = "\n")
ok(grepl('tabName = "trading_records", icon = icon("database"), selected = TRUE', app_src, fixed = TRUE) && !grepl('"unit3_assignment", icon = icon("3"), selected = TRUE', app_src, fixed = TRUE), "the BigQuery Trading Records tab opens first")
# --- IG desktop History page ("Closed in the last 24 hours") goes to the exit form
hist <- '{"screen_type":"closed_trades","asset":"Oil - Brent Crude","size_text":"+0.37","date_text":"19/10/2026 18:06","entry_price":10532.3,"exit_price":10797.3,"pnl":98.05,"currency":"GBP","confidence":{"asset":"high"}}'
vf5 <- function(images, prompt) { stopifnot(grepl("closed_trades", prompt), grepl("CLOSING date and time", prompt)); list(text = hist, model = "m", usage = list()) }
env$tables <- list(); bus5 <- reactiveValues(ts = 0, kind = NULL, values = NULL, evidence_id = NULL)
testServer(trading_evidence_server, args = list(api_manager = NULL, store = tr_make_store(fake), bus = bus5, vision_fn = vf5, quiet = TRUE), {
  session$setInputs(ex_kind = "auto", ex_source = "desktop", ex_notes = "")
  session$setInputs(ex_file = data.frame(name = "h.png", datapath = png, size = 70, type = "image/png")); session$setInputs(ex_read = 1)
  ok(rv$kind == "close" && rv$ext$direction == "B" && rv$ext$time == "18:06" && rv$ext$date == as.Date("2026-10-19") && near(rv$ext$exit, 10797.3) && near(rv$ext$pnl, 98.05), "History closed row: exit form with date, 18:06, exit price and P/L")
  session$setInputs(f_asset = "BRENT", f_dir = "B", f_size = 0.37, f_entry = 10532.3, f_stop = NA, f_limit = NA, f_exit = 10797.3, f_pnl = 98.05, f_cur = NA, f_upnl = NA, f_ref = "", f_platform = "IG", f_date = as.Date("2026-10-19"), f_time = "18:06")
  session$setInputs(ex_send_auto = 1); ok(bus5$ts == 1 && bus5$kind == "close" && near(bus5$values$pnl, 98.05), "smart send routes it to the exit form")
})
cat("ALL EV SERVER TESTS PASSED\n")
