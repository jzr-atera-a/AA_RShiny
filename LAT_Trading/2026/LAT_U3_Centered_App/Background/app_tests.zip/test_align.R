suppressPackageStartupMessages({library(shiny); library(shinydashboard); library(DT); library(plotly)})
setwd("app")
source("R/utils_academic.R"); source("R/utils_trading_records.R"); source("R/utils_trading_exports.R"); source("R/utils_trading_templates.R"); source("modules/trading_records.R"); source("modules/trading_evidence.R")
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
near <- function(a, b, t = 1e-9) isTRUE(all(abs(a - b) < t))

# ---- A. catalogue, names, contract, pip basis
nm <- tr_norm_asset(c("Oil - US Crude", "Oil - Brent Crude", "Oil - Brent Crude DFB", "Natural Gas", "Natural Gas - UK", "Spot Gold", "Wall Street Cash", "Germany 40 Cash", "EUR/USD", "GBP/JPY", "Cocoa", "Something Else"))
ok(identical(nm, c("WTI", "BRENT", "BRENT", "NATGAS", "NATGAS_UK", "GOLD", "DOW", "GER40", "EURUSD", "GBPJPY", "COCOA", "SOMETHINGELSE")), "market names map to asset codes (Brent/WTI and the two gases kept apart)")
ok(tr_asset_class("BRENT") == "Commodity" && tr_market_of("BRENT") == "Energy" && tr_asset_class("EURUSD") == "Forex" && tr_asset_class("DOW") == "Equity index" && is.na(tr_asset_class("ZZZ")), "asset class and market from the catalogue")
ok(tr_contract_type("Undated") == "DFB" && tr_contract_type("Oil - Brent Crude DFB") == "DFB" && tr_contract_type("Futures") == "FUTURES" && tr_contract_type("Brent Crude Dec-26") == "FUTURES" && is.na(tr_contract_type(NA)), "contract type: DFB vs futures")
ok(tr_account_type("Spread bet DEMO") == "SPREAD_BET" && tr_account_type("CFD") == "CFD" && is.na(tr_account_type(NA)), "account type")
ok(tr_pip_for("WTI") == 1 && tr_pip_for("EURUSD", "ig") == 1 && near(tr_pip_for("EURUSD", "standard"), 0.0001) && near(tr_pip_for("WTI", "standard"), 0.01), "pip size: 1 point on IG, instrument default on a decimal quote")
c1 <- tr_entry_calc("S", 10375.5, 10393.5, 10363.5, tr_pip_for("BRENT"), 3); ok(near(c1$risk_pips, 18) && near(c1$reward_pips, 12) && near(c1$risk_gbp, 54) && near(c1$rrr, 12/18), "desktop Brent: 18 pts, 12 pts, GBP 54, LAT RRR 0.67 (not IG's 1.5)")
ch <- tr_asset_choices("FOO"); ok("Other" %in% names(ch) && "BRENT" %in% unlist(ch) && all(tr_catalogue$code %in% unlist(ch)), "asset picker: grouped, custom assets kept")

# ---- prompts
pd <- tr_vision_prompt("auto", "desktop"); pm <- tr_vision_prompt("auto", "mobile")
ok(grepl("DEAL TICKET", pd) && grepl("POSITIONS table", pd) && grepl("Undated", pd) && grepl("risk_reward_text", pd) && grepl("margin", pd) && grepl("pts away", pd), "desktop prompt describes the real desktop layout and asks for the new fields")
ok(grepl("Position Detail", pm) && grepl("risk_reward_text", pm) && !grepl("DEAL TICKET", pm), "mobile prompt unchanged in layout, same key list")
ok(all(c("positions_table", "deal_ticket") %in% c("positions_table", "deal_ticket")) && tr_screen_to_kind("positions_table") == "open" && tr_screen_to_kind("deal_ticket") == "ticket", "new screen types map to the right form")

# ---- B. desktop flow through the evidence module + records module
env <- new.env(); env$tables <- list()
fake <- list(connected = function() TRUE, ensure = function() NULL,
  write = function(name, df) { env$tables[[name]] <- rbind(env$tables[[name]], tr_coerce(name, df)); nrow(df) },
  read = function(name) if (is.null(env$tables[[name]])) tr_coerce(name, NULL) else env$tables[[name]])
store <- tr_make_store(fake); bus <- reactiveValues(ts = 0, kind = NULL, values = NULL, evidence_id = NULL)
png <- tempfile(fileext = ".png"); writeBin(jsonlite::base64_dec("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), png)
js <- list(
  tkt = '{"screen_type":"deal_ticket","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude","contract_type_text":"Undated","size":3,"size_text":"3","size_unit":"GBP per point","sell_price":10374.2,"buy_price":10379.4,"stop_distance":18,"stop_price":10392.2,"limit_distance":12,"limit_price":10362.2,"risk_amount":54,"reward_amount":36,"margin":3112.98,"notional":31122.60,"costs":7.8,"risk_reward_text":"1.5:1","resulting_position":-3}',
  pos = '{"screen_type":"positions_table","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude","size_text":"-3","entry_price":10375.5,"current_price":10375.7,"stop_price":10393.5,"limit_price":10363.5,"unrealised_pnl":-0.6,"open_date_text":"16/10/2026"}')
cur <- "tkt"; seen <- character(0); cnt <- 0
vf <- function(images, prompt) { seen <<- c(seen, prompt); list(text = js[[cur]], model = "claude-test", usage = list(input_tokens = 800, output_tokens = 200)) }
rdx <- function(session, name) { cur <<- name; session$setInputs(ex_kind = "auto", ex_source = "desktop", ex_notes = "")
  session$setInputs(ex_file = data.frame(name = paste0(name, ".png"), datapath = png, size = 70, type = "image/png")); session$setInputs(ex_read = (cnt <<- cnt + 1)) }
testServer(trading_evidence_server, args = list(api_manager = NULL, store = store, bus = bus, vision_fn = vf, quiet = TRUE), {
  rdx(session, "tkt")
  ok(rv$kind == "ticket" && rv$source == "desktop" && grepl("DEAL TICKET", seen[length(seen)]), "desktop ticket read; desktop prompt used")
  e <- rv$ext; ok(e$asset == "BRENT" && e$asset_class == "Commodity" && e$market == "Energy" && e$contract == "DFB" && e$account_type == "SPREAD_BET" && near(e$margin, 3112.98) && near(e$notional, 31122.6) && near(e$costs, 7.8) && near(e$spread, 5.2), "ticket fields aligned: class, market, asset, contract, account, margin, notional, costs, spread")
  ev <- tr_latest("evidence", env$tables$evidence)
  ok(ev$source_device == "desktop" && ev$screen_type == "deal_ticket" && ev$asset_code == "BRENT" && ev$asset_class == "Commodity" && ev$market == "Energy" && ev$contract_type == "DFB", "evidence row carries source, screen, asset code, class, market, contract")
  ck <- checks(); ok(!any(ck$level == "error") && any(grepl("1.5:1", ck$message)) && any(grepl("never saves the platform", ck$message)), "IG risk:reward label is flagged, not used")
  session$setInputs(f_asset = "BRENT", f_dir = "", f_size = 3, f_entry = NA, f_stop = 10392.2, f_limit = 10362.2, f_exit = NA, f_pnl = NA, f_ref = "", f_platform = "IG", f_date = as.Date(NA), f_time = "")
  session$setInputs(ex_send_open = 1)
  ok(bus$ts == 1 && bus$kind == "open" && is.na(bus$values$entry) && is.na(bus$values$stop) && is.na(bus$values$limit) && near(bus$values$margin, 3112.98) && bus$values$contract == "DFB", "ticket sent to the open form: size and platform details only, no indicative levels")
  tkt_id <<- isolate(bus$evidence_id)
  rdx(session, "pos")
  session$setInputs(f_asset = "BRENT", f_dir = "S", f_size = 3, f_entry = 10375.5, f_stop = 10393.5, f_limit = 10363.5, f_exit = NA, f_pnl = NA, f_cur = 10375.7, f_upnl = -0.6, f_ref = "", f_platform = "IG", f_date = as.Date("2026-10-16"), f_time = "22:30")
  ok(rv$kind == "open" && rv$ext$direction == "S" && near(rv$ext$entry, 10375.5) && any(grepl("Unrealised profit/loss agrees", checks()$message)), "positions table: sell from -3, entry 10375.5, unrealised P/L agrees with the prices")
  session$setInputs(ex_send_open = 2); ok(bus$ts == 2 && near(bus$values$entry, 10375.5), "open-position screen sent")
  pos_id <<- isolate(bus$evidence_id)
})
testServer(trading_records_server, args = list(api_manager = NULL, store = store, quiet = TRUE, bus = bus), {
  session$setInputs(s_name = "Test Student", s_balance = 10000, s_start = as.Date("2026-10-12"), s_end = as.Date("2026-11-06")); session$setInputs(saveSettings = 1)
  tb <- list(kind = "open", values = list(asset = "BRENT", direction = "S", size = 3, entry = NA, contract = "DFB", margin = 3112.98), id = tkt_id)
  bus$kind <- "open"; bus$values <- list(asset = "BRENT", direction = NA, size = 3, entry = NA_real_, stop = NA_real_, limit = NA_real_, contract = "DFB", account_type = "SPREAD_BET", source = "desktop", asset_class = "Commodity", market = "Energy",
                                         asset_raw = "Oil - Brent Crude", per_point = TRUE, demo = TRUE, margin = 3112.98, notional = 31122.6, costs = 7.8, spread = 5.2); bus$evidence_id <- tkt_id; bus$ts <- 11
  session$flushReact()
  bus$kind <- "open"; bus$values <- list(asset = "BRENT", direction = "S", size = 3, entry = 10375.5, stop = 10393.5, limit = 10363.5, date = as.Date("2026-10-16"), time = "22:30", per_point = TRUE, demo = TRUE, source = "desktop"); bus$evidence_id <- pos_id; bus$ts <- 12
  session$flushReact()
  # the form as it would look after the fill; purpose not chosen yet -> must be refused
  base <- list(t_asset = "BRENT", t_strategy = "OTHER", t_dir = "S", t_chart = "15 Min", t_date = as.Date("2026-10-16"), t_time = "22:30", t_dur = 2, t_basis = "ig", t_pip = 1, t_stake = 3,
    t_entry = 10375.5, t_stop = 10393.5, t_target = 10363.5, t_adx = 25, t_corr = 0, t_mood = 3, t_parent = "", t_fund = "", t_tech = "", t_trigger = "", t_exec = "", t_stopwhy = "", t_tgtwhy = "",
    t_class = "Commodity", t_market = "Energy", t_rawname = "Oil - Brent Crude", t_dealref = "", t_contract = "DFB", t_acct = "SPREAD_BET", t_device = "desktop", t_demo = TRUE, t_unit = "GBP per point",
    t_spread = 5.2, t_margin = 3112.98, t_notional = 31122.6, t_costs = 7.8, t_s1 = NA, t_s2 = NA, t_s3 = NA, t_s4 = NA, t_s5 = NA)
  do.call(session$setInputs, c(base, list(t_purpose = ""))); session$setInputs(t_save = 1)
  ok(nrow(trades_df()) == 0, "a trade without 'assessed or practice' is refused")
  session$setInputs(t_purpose = "PRACTICE"); session$setInputs(t_save = 2)
  t <- trades_df(); ok(nrow(t) == 1 && t$trade_purpose == "PRACTICE" && t$asset == "BRENT" && t$asset_class == "Commodity" && t$market == "Energy" && t$contract_type == "DFB" && t$account_type == "SPREAD_BET" && isTRUE(t$is_demo) && t$source_device == "desktop" && t$price_basis == "ig" && t$size_unit == "GBP per point", "trade saved with class, market, asset, contract, account type, demo flag, source, basis, unit")
  ok(near(t$spread_pts, 5.2) && near(t$margin_gbp, 3112.98) && near(t$notional_gbp, 31122.6) && near(t$costs_gbp, 7.8) && near(t$initial_risk_pips, 18) && near(t$initial_risk_gbp, 54) && near(t$initial_reward_pips, 12) && near(t$initial_rrr, 2/3, 1e-9), "trade saved with platform costs and LAT maths (18 pts, GBP 54, RRR 0.67)")
  ok(grepl(tkt_id, t$evidence_ids, fixed = TRUE) && grepl(pos_id, t$evidence_ids, fixed = TRUE), "both screenshots (ticket and position) are linked to the trade")
  ev <- tr_latest("evidence", env$tables$evidence); ok(all(ev$status[ev$evidence_id %in% c(tkt_id, pos_id)] == "LINKED"), "both evidence rows LINKED")
  tid <- t$trade_id
  # assessed trade, closed by manual exit, market then hit target
  do.call(session$setInputs, modifyList(base, list(t_purpose = "ASSESSED", t_date = as.Date("2026-10-19"), t_time = "09:10"))); session$setInputs(t_save = 3)
  a <- trades_df(); a <- a[a$trade_purpose == "ASSESSED", ]; ok(nrow(a) == 1, "assessed trade saved")
  session$setInputs(m_trade = a$trade_id, m_action = "stop", m_date = as.Date("2026-10-19"), m_time = "09:40", m_newstop = 10380, m_permitted = "Y", m_stopwhy = "trail"); session$setInputs(m_save = 1)
  session$setInputs(m_action = "close", m_exit = 10370, m_pnl = NA, m_code = "ME", m_post = "target", m_mood = 3, m_followed = "Y", m_devtype = "Other", m_devnote = "", m_why = "mine", m_lessons = "mine2", m_date = as.Date("2026-10-19"), m_time = "11:30")
  session$setInputs(m_save = 2)
  c2 <- trades_df(); c2 <- c2[c2$trade_id == a$trade_id, ]
  ok(c2$status == "CLOSED" && near(c2$pips_result, 5.5) && near(c2$net_pnl_gbp, 16.5) && isTRUE(c2$me_then_hit_target) && isFALSE(c2$me_then_hit_stop), "close: 5.5 pts x GBP 3 = 16.50; manual exit then target flag recorded")
  # stats scope
  session$setInputs(st_week = "all", st_scope = "ASSESSED"); ok(is.null(stats()) || stats()$summary$trades == 1, "statistics default to assessed trades only")
  # ---- exports
  tr_all <- trades_df()
  x1 <- tempfile(fileext = ".xlsx"); tr_write_blotter(tr_scope_filter(tr_all, "ASSESSED"), x1, "Test Student")
  w <- openxlsx::read.xlsx(x1, sheet = "Trade Blotter", colNames = FALSE, startRow = 3, skipEmptyRows = FALSE)
  ok(w[1, 1] == "Asset" && w[1, 37] == "TOTAL" && w[2, 1] == "BRENT" && w[2, 4] == "S" && near(as.numeric(w[2, 5]), 3) && near(as.numeric(w[2, 6]), 10375.5) && near(as.numeric(w[2, 8]), 18) && near(as.numeric(w[2, 9]), 10380) && near(as.numeric(w[2, 16]), 12) && w[2, 23] == "ME" && w[2, 25] == "Y" && near(as.numeric(w[2, 28]), 16.5) && near(as.numeric(w[2, 29]), 5.5), "Blotter xlsx: columns A-AK filled in LAT order, assessed trade only")
  wbk <- openxlsx::loadWorkbook(x1); frm <- openxlsx::read.xlsx(x1, sheet = "Trade Blotter", colNames = FALSE, startRow = 4, skipEmptyRows = FALSE)
  ok(nrow(openxlsx::read.xlsx(x1, sheet = "Trade Blotter", colNames = FALSE, startRow = 4)) == 1, "Blotter has one row (the practice trade is excluded)")
  xa <- tempfile(fileext = ".xlsx"); tr_write_blotter(tr_scope_filter(tr_all, "ALL"), xa); ok(nrow(openxlsx::read.xlsx(xa, sheet = "Trade Blotter", colNames = FALSE, startRow = 4)) == 1, "all-trades scope: only closed trades appear in the Blotter")
  d1 <- tempfile(fileext = ".docx"); ev_all <- events_df()
  tr_trade_sheet_docx(tr_all[tr_all$trade_id == a$trade_id, ], tr_all[tr_all$trade_id == a$trade_id & tr_all$status == "CLOSED", ], ev_all[ev_all$trade_id == a$trade_id, ], "Test Student", list(), d1)
  txt <- paste(officer::docx_summary(officer::read_docx(d1))$text, collapse = " | ")
  ok(file.exists(d1) && grepl("Individual Trade Sheet", txt) && grepl("Test Student", txt) && grepl("Initial RRR", txt) && grepl("0.67", txt) && grepl("0910", txt) && grepl("1130", txt) && grepl("10375.5", txt) && grepl("stop moved from 10393.5 to 10380", txt) && grepl("mine2", txt) && grepl("Insert chart picture here", txt), "Trade Sheet docx: template sections, B/S exit side, times as HHMM, stop move, your own text")
  m <- tempfile(fileext = ".docx")
  h <- data.frame(sheet_id = "MS_1", record_version = 1L, sheet_date = as.Date("2026-10-19"), dow_price = 44000, dow_change_pct = -0.5, dow_change_pts = -220, nikkei_price = 39000, nikkei_change_pct = 0.2, nikkei_change_pts = NA_real_, overnight_news = "n1", overnight_calendar = "c1", todays_releases = "r1", stringsAsFactors = FALSE)
  lv <- data.frame(instrument = c("WTI", "EURUSD", "BRENT"), overnight_low = c(79, 1.09, 100), overnight_high = c(81, 1.1, 101), current_price = c(80, 1.095, 100.5), time_now_uk = c("07:30", "07:30", "07:30"), stringsAsFactors = FALSE)
  tr_morning_docx(h, lv, "Test Student", m); mt <- paste(officer::docx_summary(officer::read_docx(m))$text, collapse = " | ")
  ok(grepl("Dow Jones", mt) && grepl("Nikkei", mt) && grepl("EUR-USD", mt) && grepl("AUD-USD", mt) && grepl("WTI Crude", mt) && grepl("Gold", mt) && grepl("Brent Crude", mt) && grepl("-0.50%", mt) && grepl("n1", mt) && grepl("r1", mt), "Morning Sheet docx: template rows (EUR-USD...Gold) plus extra rows")
  sx <- tempfile(fileext = ".xlsx"); tr_stats_xlsx(tr_scope_filter(tr_all, "ALL"), 10000, sx); ok("Summary" %in% openxlsx::getSheetNames(sx) && "Trades" %in% openxlsx::getSheetNames(sx), "statistics workbook")
})
ui <- as.character(trading_records_ui("tr")); ok(grepl("Exports", ui) && !grepl("Plan Spec", ui) && !grepl("Reviews", ui) && grepl("Forex \\(rows as in the Morning Sheet template\\)", ui) && grepl("Assessed or practice", ui) && grepl("Platform details", ui), "UI: exports tab, template morning rows, purpose, platform details")

ev_ui <- as.character(trading_evidence_ui("x")); ok(!grepl("Platform statement", ev_ui) && grepl("Evidence log", ev_ui), "Order Evidence has no statement-import tab")
ok(identical(names(tr_tables), c("settings", "morning_sheets", "morning_levels", "trades", "trade_events", "evidence")) && length(tr_ddl("p", "d")) == 12 && !any(grepl("ALTER", tr_ddl("p", "d"))), "six tables, 12 statements, no ALTERs")
cat("ALL PASS\n")
big <- tempfile(fileext = ".png"); writeBin(as.raw(sample(0:255, 5000, TRUE)), big)
im <- tr_read_image(big, "big.png"); ok(!grepl("[[:space:]]", im$data), "base64 has no line breaks")
