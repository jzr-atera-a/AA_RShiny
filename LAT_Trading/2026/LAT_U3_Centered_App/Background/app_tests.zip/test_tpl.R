suppressPackageStartupMessages({library(shiny); library(shinydashboard); library(DT); library(plotly)})
setwd("app")
source("R/utils_academic.R"); source("R/utils_trading_records.R"); source("R/utils_trading_exports.R"); source("R/utils_trading_templates.R"); source("R/utils_trading_calendar.R")
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
ts <- function(s) as.POSIXct(s, tz = "Europe/London")
tr <- data.frame(trade_id = "T1", asset = "BRENT", direction = "B", chart_period = "Daily", expected_duration_hours = 36, pip_size = 1, stake_per_pip_gbp = 0.37, entry_ts = ts("2026-10-19 07:58:00"),
  entry_price = 10532.3, stop1 = 10397.3, target = 10797.3, initial_risk_pips = 135, initial_reward_pips = 265, initial_rrr = 265/135, initial_risk_gbp = 49.95,
  setup_fundamental = "FUND line1\nline2", setup_technical = "TECH & <ok>", trigger_text = "TRIG", execution_text = "EXEC", stop_reason = "SR", target_reason = "TR",
  exit_code = "T", reason_for_exit = "my reason", lessons_learned = "my lessons", stringsAsFactors = FALSE)
legs <- transform(tr, exit_ts = ts("2026-10-19 18:06:00"), exit_price = 10797.3, pips_result = 265, net_pnl_gbp = 98.05, duration_hours = 10.133)
png1 <- "../png1.png"; png::writePNG(array(runif(300*200*3), c(200, 300, 3)), png1)
png2 <- "../png2.png"; png::writePNG(array(0.5, c(100, 400, 3)), png2)
out <- tempfile(fileext = ".docx")
tr_trade_sheet_docx(tr, legs, NULL, "Jose F Zubizarreta (D1005749)", list(entry = c(png1, png2), exit = png2), out)
ok(file.exists(out) && file.size(out) > 20000, "trade sheet written from the template")
file.copy(out, "../out_trade.docx", overwrite = TRUE)
sh <- data.frame(sheet_id = "S1", sheet_date = as.Date("2026-10-19"), dow_price = 52002.41, dow_change_pct = -0.34, dow_change_pts = -175.28, nikkei_price = 64850, nikkei_change_pct = -0.7, nikkei_change_pts = NA_real_,
  overnight_news = "news one\\nnews two", overnight_calendar = NA, todays_releases = "rel", releases_in_window = NA, stringsAsFactors = FALSE)
lv <- data.frame(instrument = c("EURUSD", "WTI", "BRENT"), overnight_low = c(1.119, 96.9, 105), overnight_high = c(1.124, 99.3, 107), current_price = c(1.122, 97.5, 105.3), time_now_uk = "07:00", stringsAsFactors = FALSE)
out2 <- tempfile(fileext = ".docx"); tr_morning_docx(sh, lv, "Jose F Zubizarreta (D1005749)", out2, cal_o = png2, cal_t = c(png1))
file.copy(out2, "../out_morning.docx", overwrite = TRUE)
ok(file.exists(out2), "morning sheet written from the template")

txt <- function(f) { ds <- officer::docx_summary(officer::read_docx(f)); paste(ds$text[!is.na(ds$text)], collapse = " | ") }
tt <- txt("../out_trade.docx"); mm <- txt("../out_morning.docx")
ok(grepl("Jose F Zubizarreta \\(D1005749\\)", tt) && grepl("135 pips \\(\u00a349.95\\)", tt) && grepl("265 pips \\(\u00a398.05\\)", tt) && grepl("10Hr 8 Mins", tt) && grepl("T hit. my reason", tt) && grepl("TECH & <ok>", tt), "trade sheet: name+ID, pips with GBP, duration, exit code with own reason, special characters kept")
ok(!grepl("Insert chart picture here]", tt, fixed = TRUE) && grepl("Not applicable", tt), "trade sheet: both chart placeholders replaced; in-trade says not applicable")
z <- tempfile(); utils::unzip("../out_trade.docx", exdir = z); ok(length(list.files(file.path(z, "word", "media"), pattern = "lat_img")) == 3, "trade sheet: three pictures embedded (two entry, one exit)")
ok(grepl("52,002.41", mm) && grepl("-175.28 \\(-0.34%\\)", mm) && grepl("Brent Crude", mm) && grepl("EUR-USD \\| 1.119", gsub("\\s+", " ", mm)) || grepl("1.119", mm), "morning sheet: Dow with thousands separator and change, extra Brent row, FX values")
z2 <- tempfile(); utils::unzip("../out_morning.docx", exdir = z2); ok(length(list.files(file.path(z2, "word", "media"), pattern = "lat_img")) == 2, "morning sheet: two calendar pictures embedded")
# a second leg (partial exit) adds an exit row
legs2 <- rbind(legs, transform(legs, exit_ts = ts("2026-10-19 18:30:00"), exit_price = 10600, pips_result = 67.7, net_pnl_gbp = 25))
legs2 <- rbind(legs2, legs2[2, ], legs2[2, ])
out3 <- tempfile(fileext = ".docx"); tr_trade_sheet_docx(tr, legs2, NULL, "N", list(), out3)
ok(sum(grepl("19/10/2026", officer::docx_summary(officer::read_docx(out3))$text)) >= 4, "more exit legs than template rows: rows are added")
# a template with no pictures leaves the template's own prompts
out4 <- tempfile(fileext = ".docx"); tr_trade_sheet_docx(tr, legs, NULL, "N", list(), out4)
ok(grepl("Insert chart picture here", txt(out4), fixed = TRUE), "no pictures: the template prompt stays")
cat("ALL TEMPLATE TESTS PASSED\n")
