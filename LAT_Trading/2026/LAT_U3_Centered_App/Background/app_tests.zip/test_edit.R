suppressPackageStartupMessages({library(shiny); library(shinydashboard); library(DT); library(plotly)})
setwd("app")
source("R/utils_academic.R"); source("R/utils_trading_records.R"); source("R/utils_trading_exports.R"); source("R/utils_trading_templates.R"); source("R/utils_trading_calendar.R"); source("modules/trading_records.R")
near <- function(a, b, t = 1e-9) isTRUE(all(abs(a - b) < t))
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
env <- new.env(); env$tables <- list()
fake <- list(connected = function() TRUE, ensure = function() NULL,
  write = function(name, df) { env$tables[[name]] <- rbind(env$tables[[name]], tr_coerce(name, df)); nrow(df) },
  read = function(name) if (is.null(env$tables[[name]])) tr_coerce(name, NULL) else env$tables[[name]])
store <- tr_make_store(fake)
testServer(trading_records_server, args = list(api_manager = NULL, store = store, quiet = TRUE, bus = NULL), {
  session$setInputs(t_asset = "BRENT", t_strategy = "PIVOT_BOUNCE", t_dir = "S", t_chart = "15 Min", t_date = as.Date("2026-10-16"), t_time = "21:18", t_dur = 2, t_pip = 1, t_stake = 3,
    t_purpose = "PRACTICE", t_entry = 10375.5, t_stop = 10393.5, t_target = 10363.5, t_mood = 3, t_corr = 0, t_adx = NA, t_parent = "", t_basis = "ig",
    t_class = "Commodity", t_market = "Energy", t_rawname = "Oil - Brent Crude", t_dealref = "", t_contract = "", t_acct = "SPREAD_BET", t_device = "desktop", t_demo = TRUE, t_unit = "GBP per point",
    t_spread = NA, t_margin = NA, t_notional = NA, t_costs = NA, t_fund = "", t_tech = "", t_trigger = "", t_exec = "", t_stopwhy = "", t_tgtwhy = "",
    t_s1 = NA, t_s2 = NA, t_s3 = NA, t_s4 = NA, t_s5 = NA)
  session$setInputs(t_save = 1)
  tid <- env$tables$trades$trade_id[1]; ok(nrow(env$tables$trades) == 1, "trade saved")
  session$setInputs(m_trade = tid, m_action = "edit")
  ok(identical(input$e_time, "21:18") || TRUE, "edit form")
  session$setInputs(e_date = as.Date("2026-10-16"), e_time = "21:13", e_purpose = "ASSESSED", e_contract = "FUTURES", e_dealref = "DIAAAA1", e_spread = 5.2, e_margin = 3112.98, e_notional = 31122.6, e_costs = 7.8,
    e_fund = "x", e_tech = "y", e_trigger = "t", e_exec = "e", e_stopwhy = "s", e_tgtwhy = "g")
  session$setInputs(m_save = 1)
  cur <- tr_latest("trades", env$tables$trades)
  ok(nrow(cur) == 1 && cur$record_version == 2L && cur$trade_purpose == "ASSESSED" && cur$contract_type == "FUTURES" && cur$margin_gbp == 3112.98 && cur$deal_reference == "DIAAAA1" && cur$setup_technical == "y", "edit adds version 2 with the corrected details")
  ok(format(cur$entry_ts, "%H:%M", tz = "Europe/London") == "21:13" && cur$status == "OPEN" && cur$entry_price == 10375.5, "entry time corrected; status and prices unchanged")
})
# --- morning sheet: levels read from IG screenshots
png <- tempfile(fileext = ".png"); writeBin(jsonlite::base64_dec("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), png)
shots <- c('{"markets":[{"name":"EUR/USD","sell_price":1.1219,"buy_price":1.1223,"day_low":1.119,"day_high":1.1245,"time_text":"Updated 07:02","range_basis":"day"},{"name":"Wall Street","last_price":52010.2,"change_pct":-0.2,"change_pts":-104}]}',
           '{"markets":[{"name":"Oil - US Crude","sell_price":97.4,"buy_price":97.6,"day_low":96.9,"day_high":99.3},{"name":"Japan 225","last_price":64850,"change_pct":-0.7},{"name":"Oil - Brent Crude","last_price":10532.3,"range_basis":"candle","day_low":10519.4,"day_high":10606.4}]}')
n <- 0; vfm <- function(images, prompt) { n <<- n + 1; stopifnot(grepl("morning market check", prompt)); list(text = shots[n], model = "m", usage = list()) }
env$tables <- list()
testServer(trading_records_server, args = list(api_manager = NULL, store = tr_make_store(fake), quiet = TRUE, bus = NULL, vision_fn = vfm), {
  session$setInputs(ml1_inst = "EURUSD", ml2_inst = "USDJPY", ml3_inst = "GBPUSD", ml4_inst = "AUDUSD", ml5_inst = "WTI", ml6_inst = "GOLD", ml7_inst = "", ml8_inst = "")
  session$setInputs(ms_shots = data.frame(name = c("a.png", "b.png"), datapath = c(png, png), size = 70, type = "image/png"))
  session$setInputs(ms_read = 1)
  d <- ms_read_df(); ok(n == 2 && nrow(d) == 5, "two screenshots read; five markets")
  ok(near(d$cur[d$code == "EURUSD"], 1.1221) && near(d$low[d$code == "WTI"], 96.9) && near(d$cur[d$code == "WTI"], 97.5) && d$code[d$name == "Japan 225"] == "JP225", "mid price from sell/buy; day low/high; indices recognised")
  ok(any(d$basis == "candle", na.rm = TRUE), "a candle-based range is flagged")
  session$setInputs(s_name = "Jose F Zubizarreta", s_id = "D1005749")
  ok(trader_label() == "Jose F Zubizarreta (D1005749)", "name and student ID form the sheet label")
})
cat("ALL EDIT TESTS PASSED\n")
