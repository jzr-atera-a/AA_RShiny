suppressPackageStartupMessages({library(jsonlite)})
setwd("app"); source("R/utils_trading_records.R")
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
near <- function(a, b, t = 1e-9) isTRUE(all(abs(a - b) < t))
# --- replies a faithful reader would give for the four real IG mobile screenshots of the Brent trade
js_pos <- '{"screen_type":"position_detail","platform":"IG","account_mode_text":null,"asset":"Oil - Brent Crude","direction":null,"size":3,"size_text":"+3","size_unit":"per point","entry_price":10368.9,"current_price":10363.5,"stop_price":10356.9,"limit_price":10378.9,"sell_price":10363.5,"buy_price":10368.7,"unrealised_pnl":"-£16.20","currency":"GBP","date_text":null,"confidence":{"entry_price":"high","stop_price":"high"},"not_visible":["time_text"],"notes":null}'
js_tkt <- '{"screen_type":"new_trade_ticket","platform":"IG","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude","size":3,"size_text":"3","stop_distance":12,"limit_distance":10,"sell_price":10365.7,"buy_price":10370.9,"quote_time_text":"U:22:25:58","currency":"GBP","order_type":"Normal stop"}'
js_mkt <- '{"screen_type":"market_detail","platform":"IG","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude","sell_price":10365.2,"buy_price":10370.4,"quote_time_text":"22:25:44","currency":"GBP"}'
js_cls <- '{"screen_type":"closed_trades","platform":"IG","account_mode_text":"Spread bet DEMO","asset":"Oil - Brent Crude DFB","size_text":"+3","pnl":26.40,"open_date_text":"15/10/2026","close_date_text":"15/10/2026","entry_price":10368.9,"exit_price":10377.7,"deal_reference":"DIAAAAYN3A2X5B7"}'
P <- function(j) tr_parse_vision_json(j)
# screen type -> form
ok(identical(unname(vapply(c("position_detail","new_trade_ticket","market_detail","closed_trades","history","other",NA), tr_screen_to_kind, "")), c("open","ticket","market","close","history","history","history")), "screen type -> kind")
# position detail
e <- tr_normalise_extraction(P(js_pos), "open")
ok(e$asset=="BRENT" && e$direction=="B" && near(e$size,3) && near(e$entry,10368.9) && near(e$stop,10356.9) && near(e$limit,10378.9) && near(e$unrealised,-16.2) && is.na(e$pnl) && is.na(e$exit), "position detail: entry/stop/limit; direction from +3; unrealised P/L kept apart")
ok(isTRUE(e$per_point) && length(e$derived)==1, "per point from the unit; derived direction flagged")
ck <- tr_check_extraction(e,"open"); print(ck)
ok(!any(ck$level=="error") && any(grepl("Risk if the stop is hit: 12.00 points x £3 per point = £36.00", ck$message)) && any(grepl("reward:risk 0.83", ck$message)), "open checks: 12 pts x £3 = £36 risk; reward:risk 0.83")
ok(any(ck$level=="warn" & grepl("Time of day", ck$message)) , "no time on screen -> asks you to enter it")
# wrong side stop for a signed -3 (sell) is caught
e2 <- tr_normalise_extraction(P(sub('"+3"','"-3"',js_pos,fixed=TRUE)), "open"); ok(e2$direction=="S" && any(tr_check_extraction(e2,"open")$level=="error"), "-3 means sell; stop below entry then errors")
# ticket
t <- tr_normalise_extraction(P(js_tkt), "ticket"); ck <- tr_check_extraction(t,"ticket"); print(ck)
ok(is.na(t$direction) && t$demo && t$per_point && near(t$stop_dist,12) && near(t$limit_dist,10) && is.na(t$entry), "ticket: distances kept, no entry price, no direction")
ok(!any(ck$level=="error") && any(grepl("Risk if the stop is hit: 12.00 points x £3 per point = £36.00", ck$message)) && any(grepl("spread 5.20", ck$message)) && any(grepl("indicative", ck$message)), "ticket checks: £36 risk, spread 5.2, indicative note")
# market
m <- tr_normalise_extraction(P(js_mkt), "market"); ck <- tr_check_extraction(m,"market"); ok(!any(ck$level=="error") && m$quote_time=="22:25" && any(grepl("snapshot", ck$message)), "market snapshot: no errors, quote time read")
# closed list
c1 <- tr_normalise_extraction(P(js_cls), "close"); ck <- tr_check_extraction(c1,"close"); print(ck)
ok(c1$asset=="BRENT" && c1$direction=="B" && near(c1$size,3) && c1$date==as.Date("2026-10-15") && c1$deal_ref=="DIAAAAYN3A2X5B7" && near(c1$pnl,26.4) && near(c1$exit,10377.7), "closed row: values, closing date, deal reference")
ok(any(grepl("agrees with the prices: 8.80 points x £3 per point = £26.40", ck$message)) && !any(ck$level=="error"), "closed row: P/L = 8.8 pts x £3 = £26.40 agrees")
c2 <- c1; c2$pnl <- 25.4; ok(any(tr_check_extraction(c2,"close")$level=="warn" & grepl("does not equal", tr_check_extraction(c2,"close")$message)), "wrong P/L is flagged")
# live account warning
l <- tr_normalise_extraction(P('{"screen_type":"closed_trades","account_mode_text":"Spread bet LIVE","asset":"Oil - Brent Crude","size_text":"+3","entry_price":1,"exit_price":2,"close_date_text":"15/10/2026"}'),"close"); ok(any(tr_check_extraction(l,"close")$level=="warn" & grepl("DEMO", tr_check_extraction(l,"close")$message)), "non-demo badge -> warning")
# prompts: switch changes the instruction
pm <- tr_vision_prompt("auto","mobile"); pd <- tr_vision_prompt("auto","desktop")
ok(grepl("IG mobile app", pm) && !grepl("IG website", pm) && grepl("IG website", pd) && !grepl("IG mobile app", pd), "prompt follows the source switch")
ok(all(sapply(c("auto","open","ticket","close","market","history"), function(k) nzchar(tr_vision_prompt(k,"mobile")))) && grepl("screen_type", pm) && grepl("Never put a live Sell/Buy quote into entry_price", pm), "prompt for every kind carries the rules")
ok(identical(unname(tr_vision_sources), c("mobile","desktop")) && tr_vision_kinds[[1]]=="auto", "source + kind lists")
cat("ALL PASS\n")
