suppressPackageStartupMessages({library(shiny); library(shinydashboard); library(DT); library(plotly)})
setwd("app")
for (f in c("R/utils_academic.R","R/utils_trading_records.R","R/utils_trading_exports.R","R/utils_trading_templates.R","R/utils_trading_calendar.R","modules/trading_records.R")) source(f)
near <- function(a, b, t = 1e-9) isTRUE(all(abs(a - b) < t))
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
# ---- calendar df / text round trip
cj <- '{"day_label":"Oct 20, 2026 (Today)","events":[{"time":"07:00","country":"United Kingdom","importance":"High","event":"Unemployment Rate","actual":"4.7%","forecast":"4.9%","previous":"4.9%"},{"time":"21:30","country":"United States","importance":"Medium","event":"API Crude Oil Stock Change","actual":null,"forecast":null,"previous":"-11.1M"}]}'
d <- tr_calendar_df(tr_parse_vision_json(cj)); ok(nrow(d) == 2 && d$actual[1] == "4.7%" && d$actual[2] == "", "calendar json -> table")
txt <- tr_calendar_text(d); ok(grepl("07:00 | United Kingdom | High | Unemployment Rate | Actual 4.7% | Forecast 4.9% | Previous 4.9%", txt, fixed = TRUE), "one text line per event")
d2 <- tr_calendar_parse_text(txt); ok(identical(d2, d) , "text parses back to the same table")
ok(!tr_calendar_is_table("my own note") && tr_calendar_is_table(txt), "typed notes are not mistaken for a calendar table")
ok(nrow(tr_calendar_df(list(events = list()))) == 0 && tr_calendar_text(NULL) == "", "empty calendar is empty")
ok(grepl("2026", tr_calendar_web_prompt(as.Date("2026-10-20"), "today")) && grepl("Do NOT invent", tr_morning_web_prompt(as.Date("2026-10-20"))), "web prompts carry the date and forbid invention")
# ---- names
ok(tr_morning_filename(as.Date("2026-10-20")) == "Morning_Sheet_20-10-2026.docx" && tr_trade_filename("BRENT", "2026-10-19", "pdf") == "Individual_Trade_Sheet_Brent_19-10-2026.pdf" && tr_trade_filename("EURUSD", "2026-10-19") == "Individual_Trade_Sheet_EURUSD_19-10-2026.docx", "file names follow the earlier ones")
# ---- dropbox
src <- tempfile(fileext = ".docx"); writeLines("x", src); loc <- file.path(tempdir(), "dbx", "LAT")
r <- tr_save_to_dropbox(src, local_dir = loc, api_dir = "", token = ""); ok(all(r$ok) && file.exists(file.path(loc, basename(src))), "copied into the local Dropbox folder (created if missing)")
up <- NULL; r <- tr_save_to_dropbox(src, "", "/LAT/Unit3", "tok", upload = function(f, d, t) { up <<- c(f, d, t); paste0(d, "/", basename(f)) }); ok(all(r$ok) && up[2] == "/LAT/Unit3" && up[3] == "tok", "API upload path used when a token is set")
r <- tr_save_to_dropbox(src, "", "/LAT", "", upload = function(...) stop("no")); ok(!any(r$ok) && grepl("no Dropbox", r$note[1]), "nothing set: says so instead of pretending")
r <- tr_save_to_dropbox(src, "", "/LAT", "t", upload = function(...) stop("HTTP 401")); ok(!r$ok && grepl("401", r$note), "API failure is reported")
# ---- pdf
so <- tr_find_soffice(); cat("soffice:", so, "\n")
if (!is.na(so)) { dd <- tempfile(); dir.create(dd); f <- file.path(dd, "T.docx"); sh <- data.frame(sheet_id = "S", sheet_date = as.Date("2026-10-20"), dow_price = 1, dow_change_pct = NA_real_, dow_change_pts = NA_real_, nikkei_price = 1, nikkei_change_pct = NA_real_, nikkei_change_pts = NA_real_, releases_in_window = NA, overnight_news = "n", overnight_calendar = txt, todays_releases = NA, stringsAsFactors = FALSE)
  tr_morning_docx(sh, NULL, "N (D1)", f); p <- tr_docx_to_pdf(f, dd); ok(!is.na(p) && file.exists(p) && file.size(p) > 1000, "docx converted to PDF")
  ok(grepl("Unemployment Rate", paste(system2("pdftotext", c(p, "-"), stdout = TRUE), collapse = " ")), "calendar table text appears in the sheet when no picture is attached")
  png <- tempfile(fileext = ".png"); png::writePNG(array(0.4, c(60, 200, 3)), png); f2 <- file.path(dd, "T2.docx"); tr_morning_docx(sh, NULL, "N (D1)", f2, cal_o = png, cal_t = png)
  t2 <- paste(officer::docx_summary(officer::read_docx(f2))$text, collapse = " "); ok(!grepl("Unemployment Rate", t2), "with a picture attached the typed calendar lines are not duplicated") }
# ---- module: web search + calendar reading + export saving
fe <- new.env(); fe$tables <- list()
fake <- list(connected = function() TRUE, ensure = function() NULL, write = function(n, d) { fe$tables[[n]] <- rbind(fe$tables[[n]], tr_coerce(n, d)); nrow(d) },
             read = function(n) if (is.null(fe$tables[[n]])) tr_coerce(n, NULL) else fe$tables[[n]])
mk <- '{"markets":[{"name":"EUR/USD","last_price":1.1234,"day_low":1.119,"day_high":1.1245,"time_text":"07:00"},{"name":"Dow Jones","last_price":51966.03,"change_pts":-36.38,"change_pct":-0.07},{"name":"Brent Crude","last_price":109.7}],"headlines":["Brent steady near 109.7","US eases Russian energy sanctions"],"sources":["Newsquawk"]}'
calls <- character(0)
tf <- function(prompt) { calls <<- c(calls, prompt); list(text = if (grepl("market levels", prompt)) paste("Here you go:", mk) else cj) }
png1 <- tempfile(fileext = ".png"); writeBin(jsonlite::base64_dec("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), png1)
vf <- function(images, prompt) { stopifnot(grepl("economic calendar", prompt)); list(text = cj, model = "m", usage = list()) }
testServer(trading_records_server, args = list(api_manager = NULL, store = tr_make_store(fake), quiet = TRUE, bus = NULL, vision_fn = vf, text_fn = tf), {
  session$setInputs(ms_date = as.Date("2026-10-20"), ml1_inst = "EURUSD", ml2_inst = "USDJPY", ml3_inst = "GBPUSD", ml4_inst = "AUDUSD", ml5_inst = "WTI", ml6_inst = "GOLD", ml7_inst = "", ml8_inst = "", ms_src = "web")
  session$setInputs(ms_web_mk = 1)
  d <- ms_read_df(); ok(nrow(d) == 3 && near(d$cur[d$code == "EURUSD"], 1.1234) && near(d$cur[d$code == "DOW"], 51966.03), "web search reply (with surrounding prose) is read into the market boxes")
  ok(length(calls) == 1 && grepl("Tuesday 20 October 2026", calls[1]), "the search asks for the sheet date")
  session$setInputs(ms_web_cal = 1)
  ok(length(calls) == 3 && grepl("19 October 2026", calls[2]) && grepl("20 October 2026", calls[3]), "calendar search asks for yesterday and today")
  ok(nrow(cal_o_df()) == 2 && nrow(cal_t_df()) == 2, "both calendars stored as tables")
  session$setInputs(ms_src = "shots", ms_cal_img_o = data.frame(name = "o.png", datapath = png1, size = 70, type = "image/png"), ms_cal_img_t = data.frame(name = "t.png", datapath = png1, size = 70, type = "image/png"))
  session$setInputs(ms_cal_read = 1); ok(nrow(cal_o_df()) == 2 && nrow(cal_t_df()) == 2, "calendar screenshots read with Claude vision")
  # save the morning sheet (text boxes carry the calendar), then save to Dropbox
  session$setInputs(ms_dow = 51966.03, ms_dowc = -0.07, ms_nik = 64185.5, ms_nikc = -1.74, ms_dowp = NA, ms_nikp = NA, ms_news = "n", ms_cal_o = tr_calendar_text(cal_o_df()), ms_cal_t = tr_calendar_text(cal_t_df()), ms_win = "", ms_regime = "", ms_setups = "", ms_risk = 0, ms_expo = "", ms_stand = FALSE, ms_stand_why = "",
    ml1_cur = 1.1234, ml1_low = NA, ml1_high = NA, ml1_time = "07:00", s_name = "Jose F Zubizarreta", s_id = "D1005749")
  session$setInputs(ms_save = 1)
  h <- tr_latest("morning_sheets", fe$tables$morning_sheets); ok(nrow(h) == 1 && grepl("Unemployment Rate", h$overnight_calendar) && grepl("API Crude", h$todays_releases), "calendar text saved in the existing BigQuery columns")
  dbx <- file.path(tempdir(), "dbx2")
  session$setInputs(ex_sheet = "2026-10-20", s_dbx = dbx, s_dbxapi = "", cal_o = NULL, cal_t = NULL)
  session$setInputs(sv_morning = 1)
  ok(file.exists(file.path(dbx, "Morning_Sheet_20-10-2026.docx")) && (is.na(tr_find_soffice()) || file.exists(file.path(dbx, "Morning_Sheet_20-10-2026.pdf"))), "Word + PDF saved to the Dropbox folder under the dated name")
})
cat("ALL CALENDAR TESTS PASSED\n")
