suppressPackageStartupMessages(library(TTR)); setwd("app"); source("R/utils_unit3_rules.R")
ok <- function(c, m) { cat(if (isTRUE(c)) "PASS" else "FAIL", "-", m, "\n"); if (!isTRUE(c)) quit(status = 1) }
near <- function(a, b, t = 1e-6) isTRUE(all(abs(a - b) < t))
# --- Pivots: slide example
p <- u3r_pivots(1.5438, 1.5332, 1.5413)
ok(near(round(p, 4), c(R3=1.5563,R2=1.5500,R1=1.5457,PP=1.5394,S1=1.5351,S2=1.5288,S3=1.5245), 1e-9), "pivots match the course slide (R3 1.5563 ... S3 1.5245)")
ok(near(p[["PP"]] , (1.5438+1.5332+1.5413)/3), "PP = (H+L+C)/3")
# --- Straddle: manual's worked example (overnight H 1.18587 bid, spread 1 pip, L 1.18368, buffers 1 pip)
s <- u3r_straddle(1.18587, 1.18368, spread = 1, buffer = 1)
ok(near(s$range_pips, 22.9, 1e-6), "straddle: overnight range 22.9 pips (manual)")
ok(near(s$risk_pips, 24.9, 1e-6), "straddle: risk = 22.9 + 1 + 1 = 24.9 pips (manual)")
ok(near(s$buy_entry, 1.18607) && near(s$sell_entry, 1.18358) && near(s$buy_stop, s$sell_entry) && near(s$sell_stop, s$buy_entry), "straddle: entries 1 pip beyond range, each stop = other leg's entry")
ok(near(s$buy_target, 1.18607 + 0.00249) && near(s$sell_target, 1.18358 - 0.00249) && s$rrr == 1, "straddle: target = risk (RRR 1.0)")
ok(is.null(u3r_straddle(1.1, 1.2)), "straddle: bad range rejected")
# --- Overnight range in London time (BST: 22:00 London = 21:00 UTC)
tt <- seq(as.POSIXct("2026-10-13 18:00", tz = "UTC"), as.POSIXct("2026-10-14 08:00", tz = "UTC"), by = "15 min")  # BST until 25 Oct
d <- data.frame(Date = tt, Open = 1, High = 1.1, Low = 1.0, Close = 1.05)
d$High[tt == as.POSIXct("2026-10-13 20:30", tz = "UTC")] <- 9   # 21:30 London: before 22:00 -> must be excluded
d$High[tt == as.POSIXct("2026-10-13 21:00", tz = "UTC")] <- 1.3 # 22:00 London: included
d$Low[tt == as.POSIXct("2026-10-14 04:45", tz = "UTC")] <- 0.9  # 05:45 London: included
d$Low[tt == as.POSIXct("2026-10-14 05:00", tz = "UTC")] <- 0.1  # 06:00 London: excluded
r <- u3r_overnight_range(d, as.Date("2026-10-14")); ok(near(r$high, 1.3) && near(r$low, 0.9), "overnight range uses 22:00-06:00 London (BST handled)")
# --- LAT lot-size examples
ok(near(u3r_trade_size_usd(800, 40), 200000) && near(u3r_risk_usd(100000, 65), 650), "lot size: $800/40 pips = $200,000; $100,000 x 65 pips = $650")
# --- Rule of five
ok(u3r_rule_of_five$Major[u3r_rule_of_five$Base == "1 day"] == "1 week" && u3r_rule_of_five$Minor[u3r_rule_of_five$Base == "2 hours"] == "30 minutes", "rule of five table")
# --- Session id (FX day starts 22:00 GMT)
ok(u3r_session_id(as.POSIXct("2026-10-13 22:00", tz = "UTC")) == as.Date("2026-10-14") && u3r_session_id(as.POSIXct("2026-10-13 21:59", tz = "UTC")) == as.Date("2026-10-13"), "FX session boundary 22:00 GMT")
# --- Regime
mk <- function(cl) data.frame(Date = as.Date("2026-01-01") + seq_along(cl), Open = cl, High = cl + 0.5, Low = cl - 0.5, Close = cl)
set.seed(3); up <- mk(100 + cumsum(rep(0.6, 80)) + rnorm(80, 0, 0.05))
rg <- u3r_regime(up); ok(rg$ok && rg$regime == "Trending" && rg$di_pos > rg$di_neg, "regime: steady uptrend = Trending")
flat <- mk(100 + sin(seq_len(120) / 2) * 0.3); ok(u3r_regime(flat)$regime %in% c("Range-bound", "Unclear (no trade)"), "regime: oscillating = not Trending")
# --- Holy Grail: build an uptrend, then a gentle pullback to the 20 EMA
n_up <- 70; px <- 100 + cumsum(rep(0.5, n_up)); pb <- tail(px, 1) - cumsum(rep(0.28, 8)); cl <- c(px, pb)
hg <- u3r_holy_grail(mk(cl)); print(hg$checks[, 1:2]); cat(hg$reason, "\n")
ok(hg$direction == "Long" && !is.null(hg$checks) && nrow(hg$checks) == 6, "holy grail: long direction, six rule checks")
ok(hg$entry == max(tail(mk(cl), 2)$High) && near(hg$target, max(tail(mk(cl), 15)$High)) && hg$stop_swing == min(tail(mk(cl)$Low, 5)), "holy grail: entry above 2-bar high, target previous high, stop below retracement low")
# a sell-side mirror
hs <- u3r_holy_grail(mk(200 - (cl - 100))); ok(hs$direction == "Short" && hs$entry == min(tail(mk(200 - (cl - 100)), 2)$Low), "holy grail: short mirror, entry below 2-bar low")
# no trend -> NONE
hn <- u3r_holy_grail(flat); ok(hn$status == "NONE" && !hn$ready, "holy grail: no ADX trend -> no signal")
# --- Pivot bounce: price rises to R1, Candle 1 fails to make a new high, next bar breaks Candle 1's low
lv <- c(R3 = 112, R2 = 110, R1 = 108, PP = 106, S1 = 104, S2 = 102, S3 = 100)
base <- 105 + sin(seq_len(40) / 3) * 0.3
H <- base + 0.2; L <- base - 0.2; C <- base; O <- base
H <- c(H, 107.9, 108.05, 107.9, 107.6); L <- c(L, 107.3, 107.5, 107.4, 107.1); C <- c(C, 107.8, 107.7, 107.5, 107.2); O <- c(O, 107.5, 107.8, 107.7, 107.5)
b <- data.frame(Date = as.POSIXct("2026-10-13 08:00", tz = "UTC") + 300 * seq_along(H), Open = O, High = H, Low = L, Close = C)
pbn <- u3r_pivot_bounce(b, lv); print(pbn[c("status","direction","level","entry","stop","target")])
ok(pbn$ready && pbn$direction == "Short" && pbn$level == "R1" && near(pbn$entry, 107.4) && near(pbn$stop, 108.05) && near(pbn$target, 106), "bounce: sell below Candle 1 low (107.4), stop above recent high (108.05), target next pivot PP (106)")
bw <- b[1:(nrow(b) - 1), ]; pw <- u3r_pivot_bounce(bw, lv); ok(pw$status == "WATCH" && near(pw$entry, 107.4), "bounce: Candle 1 formed, entry not yet broken -> WATCH with pending entry")
mirror <- b; mirror[, c("Open","High","Low","Close")] <- 212 - b[, c("Open","Low","High","Close")]
lv2 <- sort(212 - lv, decreasing = TRUE); names(lv2) <- c("R3","R2","R1","PP","S1","S2","S3")
pm <- u3r_pivot_bounce(mirror, lv2); ok(pm$ready && pm$direction == "Long" && near(pm$entry, 212 - 107.4), "bounce: buy mirror (touch support, Candle 1 fails new low, break above Candle 1 high)")
cat("ALL PASS\n")
