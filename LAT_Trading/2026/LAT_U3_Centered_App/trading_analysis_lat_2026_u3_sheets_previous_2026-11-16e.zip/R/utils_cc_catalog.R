# R/utils_cc_catalog.R
# The pattern catalogue of the "T Records C.C" tab: every one of the 141 rows of the Claude Pattern Matrix
# (claude/U3_Claude_Pattern_Matrix.md), each with the numeric rule the R engine (utils_cc_patterns.R) applies.
# ATR = Wilder ATR(14) of the candles shown. "Prior trend" = close change over the 10 candles before the pattern,
# in ATR (down <= -1, up >= +1). Pivots = zig-zag swing points that reversed by at least 1.5 ATR.
# Columns:
#   step, key, label, bias (bullish / bearish / trend), group
#   family  : one setup counts once per family in the bias tally (avoids the five squeeze rows voting five times)
#   regime  : "trend" = shown as in-regime when ADX >= the trend threshold; "range" = when ADX <= the range threshold;
#             "any" = always
#   recency : how many of the last candles the signal may sit in to count as "now" (3 for candles, 10 for structures)
#   kind    : candle / structure / indicator / state / strategy. "state" rows have no structure: their stop and target
#             are the ATR template (stop 1.5 ATR, target 2 x risk) and they are labelled so
#   rule    : the rule as coded (shown in the tab)

cc_catalog <- local({
  r <- function(step, key, label, bias, group, family, regime, recency, kind, rule)
    data.frame(step = step, key = key, label = label, bias = bias, group = group, family = family, regime = regime,
               recency = recency, kind = kind, rule = rule, stringsAsFactors = FALSE)
  rbind(
  # ---------------------------------------------------------------- STEP 1: trend & market structure
  r(1, "dow_up", "Uptrend (Dow Theory)", "bullish", "Trend", "trend_dow", "any", 10, "structure", "Last two pivot highs higher AND last two pivot lows higher. 'Early' when the lows rise but no new higher high yet. Stop: below the last pivot low. Target: last high + the last up-leg."),
  r(1, "dow_down", "Downtrend (Dow Theory)", "bearish", "Trend", "trend_dow", "any", 10, "structure", "Last two pivot highs lower AND last two pivot lows lower. Stop: above the last pivot high. Target: last low - the last down-leg."),
  r(1, "support", "Support level", "bullish", "Support & resistance", "level_bounce", "range", 10, "structure", "3+ separate pivot lows within 0.5 ATR of each other, no close more than 0.3 ATR below the level since the first touch, price above it and within 3 ATR now. Stop: level - 0.5 ATR. Target: nearest resistance above, else 2 x risk."),
  r(1, "resistance", "Resistance level", "bearish", "Support & resistance", "level_bounce", "range", 10, "structure", "Mirror of support with pivot highs."),
  r(1, "sup_to_res", "Old support now resistance", "bearish", "Support & resistance", "role_reversal", "any", 10, "structure", "2+ pivot lows at a level, a close 0.3 ATR below it (break), then a pivot high back within 0.5 ATR of it in the last 10 candles; price below now. Stop: level + 0.5 ATR. Target: 2 x risk or nearest support."),
  r(1, "res_to_sup", "Old resistance now support", "bullish", "Support & resistance", "role_reversal", "any", 10, "structure", "Mirror: broken resistance retested from above and holding."),
  r(1, "uptrend_line", "Uptrend line", "bullish", "Trend lines", "trendline", "trend", 10, "structure", "Line through rising pivot lows with 3+ touches (within 0.35 ATR), slope at most 0.6 ATR per candle, no close more than 0.35 ATR below it; it reaches the last candle with price above it. Stop: line - 0.5 ATR. Target: last pivot high or 2 x risk."),
  r(1, "downtrend_line", "Downtrend line", "bearish", "Trend lines", "trendline", "trend", 10, "structure", "Mirror through falling pivot highs."),
  r(1, "broken_uptrend", "Broken uptrend line", "bearish", "Trend lines", "trendline_break", "any", 5, "structure", "A valid uptrend line (3+ touches) closed through by 0.2 ATR within the last 5 candles and still below. Stop: back above the line + 0.3 ATR. Target: last pivot low below."),
  r(1, "broken_downtrend", "Broken downtrend line", "bullish", "Trend lines", "trendline_break", "any", 5, "structure", "Mirror."),
  r(1, "ctr_break_up", "Broken countertrend line (uptrend continues)", "bullish", "Trend lines", "trendline_break", "trend", 5, "structure", "Main trend up (EMA50 rising, price above EMA200 when available); a falling line through 2+ pullback pivot highs in the last 40 candles is closed through upward in the last 5 candles. Stop: pullback low - 0.2 ATR. Target: prior high, else 2 x risk."),
  r(1, "ctr_break_down", "Broken countertrend line (downtrend continues)", "bearish", "Trend lines", "trendline_break", "trend", 5, "structure", "Mirror."),
  r(1, "bull_channel", "Bullish (ascending) channel", "bullish", "Channels", "channel", "trend", 10, "structure", "Valid uptrend line (3+ touches) plus a parallel line through 3+ pivot highs (within 0.5 ATR); price inside now. Stop: lower line - 0.5 ATR. Target: upper line."),
  r(1, "bear_channel", "Bearish (descending) channel", "bearish", "Channels", "channel", "trend", 10, "structure", "Mirror."),
  r(1, "bull_engulfing", "Bullish Engulfing", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend down; candle 1 down, candle 2 up with open <= candle 1 close and close >= candle 1 open, bigger body. Stop: pattern low - 0.1 ATR. Target: nearest resistance, else 2 x risk."),
  r(1, "bear_engulfing", "Bearish Engulfing", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror after an up move."),
  r(1, "piercing", "Piercing Pattern", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend down; candle 1 down with body >= 0.6 ATR; candle 2 up, opens at or below candle 1 close (a 24-hour market rarely gaps below the low), closes above candle 1's body midpoint but below its open."),
  r(1, "dark_cloud", "Dark Cloud Cover", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror after an up move."),
  r(1, "bull_harami", "Bullish Harami", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend down; candle 1 down with body >= 0.6 ATR; candle 2 up with body <= half of candle 1's, inside candle 1's body."),
  r(1, "bear_harami", "Bearish Harami", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror after an up move."),
  r(1, "harami_cross", "Harami Cross", "trend", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Candle 1 body >= 0.6 ATR, candle 2 a doji (body <= 10% of its range) inside candle 1's body. Indecision: no side of its own (shown, not counted)."),
  r(1, "morning_star", "Morning Star", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend down; candle 1 down body >= 0.6 ATR; candle 2 body <= 30% of candle 1's, sitting at or below candle 1's close; candle 3 up, closing above candle 1's body midpoint."),
  r(1, "evening_star", "Evening Star", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror after an up move."),
  r(1, "three_white_soldiers", "Three White Soldiers", "bullish", "Candles (2-3)", "candle_run", "any", 3, "candle", "Not after an up move of more than 1 ATR; 3 up candles, bodies >= 0.5 ATR, each opening inside the prior body and closing higher, upper wick <= 30% of range."),
  r(1, "three_black_crows", "Three Black Crows", "bearish", "Candles (2-3)", "candle_run", "any", 3, "candle", "Mirror."),
  r(1, "tweezer_top", "Tweezer Top", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend up; up candle then down candle with highs within 0.1 ATR, at the highest high of the last 10 candles."),
  r(1, "tweezer_bottom", "Tweezer Bottom", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror at the lowest low of the last 10 candles."),
  r(1, "rising_three", "Rising Three Methods", "bullish", "Candles (2-3)", "candle_cont", "trend", 3, "candle", "Not in a downtrend; candle 1 up body >= 1 ATR; 3 small candles (body <= half) inside candle 1's range, at least 2 of them down; candle 5 up closing above candle 1's close."),
  r(1, "falling_three", "Falling Three Methods", "bearish", "Candles (2-3)", "candle_cont", "trend", 3, "candle", "Mirror."),
  r(1, "three_inside_up", "Three Inside Up", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "A bullish harami (candles 1-2) and candle 3 closing above candle 1's open."),
  r(1, "three_inside_down", "Three Inside Down", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror."),
  r(1, "three_outside_up", "Three Outside Up", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "A bullish engulfing (candles 1-2) and candle 3 closing above candle 2's close."),
  r(1, "three_outside_down", "Three Outside Down", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror."),
  r(1, "bull_kicker", "Bullish Kicker", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Candle 1 down; candle 2 up, body >= 0.5 ATR, opening at or above candle 1's open with its low not below candle 1's open (no overlap)."),
  r(1, "bear_kicker", "Bearish Kicker", "bearish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Mirror."),
  r(1, "stick_sandwich", "Stick Sandwich", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend down; down, up, down candles with the two down closes within 0.1 ATR."),
  r(1, "matching_low", "Matching Low", "bullish", "Candles (2-3)", "candle_rev", "any", 3, "candle", "Prior trend down; two down candles closing within 0.05 ATR of each other."),
  r(1, "sep_lines_bull", "Separating Lines (bullish)", "bullish", "Candles (2-3)", "candle_cont", "trend", 3, "candle", "Prior trend up; down candle, then an up candle with body >= 0.5 ATR opening within 0.1 ATR of the down candle's open."),
  r(1, "sep_lines_bear", "Separating Lines (bearish)", "bearish", "Candles (2-3)", "candle_cont", "trend", 3, "candle", "Mirror in a downtrend."),
  # ---------------------------------------------------------------- STEP 2: Fibonacci & classic price patterns
  r(2, "fib_retracement", "Fibonacci retracement", "trend", "Fibonacci", "fib", "trend", 10, "structure", "Last completed leg >= 3 ATR; price has pulled back to 38.2-61.8% of it and touched a level (within 0.3 ATR) in the last 5 candles without closing beyond 78.6%. Direction = the leg's. Stop: 78.6% level. Target: the leg's end."),
  r(2, "fib_expansion", "Fibonacci 100% expansion", "trend", "Fibonacci", "fib", "trend", 10, "structure", "After a retracement pivot C, target = C + the prior leg (100%); 127.2% and 161.8% also shown. Active while price is between C and the 100% target. Stop: beyond C."),
  r(2, "sym_triangle", "Symmetrical triangle", "trend", "Triangles & wedges", "triangle", "any", 10, "structure", "5+ turning points; line through highs falling and line through lows rising (each fit within 0.5 ATR); they converge; price inside, or broke out in the last 3 candles. Stop: the opposite line. Target: breakout side + the triangle's starting height."),
  r(2, "asc_triangle", "Ascending triangle", "bullish", "Triangles & wedges", "triangle", "any", 10, "structure", "5+ turning points; flat highs (slope <= 0.03 ATR per candle) and rising lows. Stop: lower line. Target: top + height."),
  r(2, "desc_triangle", "Descending triangle", "bearish", "Triangles & wedges", "triangle", "any", 10, "structure", "5+ turning points; flat lows and falling highs. Stop: upper line. Target: bottom - height."),
  r(2, "rising_wedge", "Rising wedge", "bearish", "Triangles & wedges", "wedge", "any", 10, "structure", "5+ turning points; both lines rising and converging, the upper line less steep. Stop: upper line + 0.3 ATR. Target: wedge start."),
  r(2, "falling_wedge", "Falling wedge", "bullish", "Triangles & wedges", "wedge", "any", 10, "structure", "Mirror: both falling, converging, the lower line less steep."),
  r(2, "bull_flag", "Bullish flag", "bullish", "Flags", "flag", "trend", 10, "structure", "Pole: a rise of >= 4 ATR within 8 candles; then 5-15 candles drifting flat or down in a channel no wider than half the pole, retracing <= 50% of it. Stop: flag low - 0.2 ATR. Target: flag high + pole."),
  r(2, "bear_flag", "Bearish flag", "bearish", "Flags", "flag", "trend", 10, "structure", "Mirror."),
  r(2, "pennant", "Pennant", "trend", "Flags", "flag", "trend", 10, "structure", "Pole as for a flag (either direction), then 5-15 candles whose highs fall and lows rise (converging). Direction = the pole's."),
  r(2, "double_top", "Double top", "bearish", "Reversal shapes", "double", "any", 10, "structure", "Two pivot highs within 1 ATR, 4+ candles apart, the valley between at least 3 ATR below the lower peak; second peak in the last 20 candles. 'Confirmed' on a close below the valley. Stop: higher peak + 0.3 ATR. Target: valley - height."),
  r(2, "double_bottom", "Double bottom", "bullish", "Reversal shapes", "double", "any", 10, "structure", "Mirror."),
  r(2, "head_shoulders", "Head & Shoulders", "bearish", "Reversal shapes", "hs", "any", 10, "structure", "Pivots H1 L1 H2 L2 H3: head H2 at least 1 ATR above both shoulders, shoulders within 1.5 ATR, spacing ratio 0.5-2; neckline through L1-L2. 'Confirmed' on a close below the neckline. Stop: right shoulder + 0.3 ATR. Target: neckline - (head - neckline)."),
  r(2, "inv_head_shoulders", "Inverse Head & Shoulders", "bullish", "Reversal shapes", "hs", "any", 10, "structure", "Mirror."),
  # ---------------------------------------------------------------- STEP 3
  r(3, "triple_top", "Triple top", "bearish", "Reversal shapes", "double", "any", 10, "structure", "Three pivot highs within 0.5 ATR of their mean, each pair separated by a pivot low >= 2 ATR below. Stop: highest peak + 0.3 ATR. Target: lower valley - height."),
  r(3, "triple_bottom", "Triple bottom", "bullish", "Reversal shapes", "double", "any", 10, "structure", "Mirror."),
  r(3, "rectangle", "Rectangle / trading range", "trend", "Ranges", "range_box", "range", 10, "structure", "3+ pivot highs within 0.5 ATR and 3+ pivot lows within 0.5 ATR, spanning 15+ candles, height >= 2 ATR, price inside now. Stop/target: the far edge / the height beyond the near edge."),
  r(3, "cup_handle", "Cup and handle", "bullish", "Rounded shapes", "rounded", "any", 10, "structure", "Left rim pivot high, a cup bottom 3+ ATR deep whose lowest third lasts >= 30% of the cup (rounded, not a V), right rim within 1 ATR of the left; then a 3-15 candle handle retracing <= 1/3 of the cup in its upper half. Stop: handle low - 0.2 ATR. Target: rim + depth."),
  r(3, "inv_cup_handle", "Inverted cup and handle", "bearish", "Rounded shapes", "rounded", "any", 10, "structure", "Mirror."),
  r(3, "rounding_bottom", "Rounding bottom (saucer)", "bullish", "Rounded shapes", "rounded", "any", 10, "structure", "A quadratic fit to the last 30-80 closes opens upward with R-squared >= 0.8, its low in the middle third, depth >= 3 ATR, price in the right half and rising. Stop: the low. Target: start level."),
  r(3, "rounding_top", "Rounding top", "bearish", "Rounded shapes", "rounded", "any", 10, "structure", "Mirror."),
  r(3, "diamond_top", "Diamond top", "bearish", "Rare shapes", "diamond", "any", 10, "structure", "Over 20-60 candles at a high: the first half widens (pivot highs rise, lows fall) and the second half narrows (highs fall, lows rise). Stop: diamond high. Target: break level - height. A rare shape: always low confidence."),
  r(3, "diamond_bottom", "Diamond bottom", "bullish", "Rare shapes", "diamond", "any", 10, "structure", "Mirror at a low."),
  r(3, "broadening_top", "Broadening top (megaphone)", "bearish", "Rare shapes", "broadening", "any", 10, "structure", "5+ turning points after an up move: pivot highs rising and pivot lows falling. Stop: last high + 0.3 ATR. Target: lower line."),
  r(3, "broadening_bottom", "Broadening bottom", "bullish", "Rare shapes", "broadening", "any", 10, "structure", "Mirror after a down move."),
  r(3, "island_top", "Island reversal top", "bearish", "Gaps", "gap", "any", 10, "structure", "A gap up (low above the prior high), 1-10 candles above it, then a gap down (high below the prior low). Real gaps only. Stop: island high. Target: 2 x risk."),
  r(3, "island_bottom", "Island reversal bottom", "bullish", "Gaps", "gap", "any", 10, "structure", "Mirror."),
  r(3, "measured_up", "Measured move up", "bullish", "Legs", "measured", "trend", 10, "structure", "Leg 1 up >= 3 ATR (pivot A to B), correction to C retracing 30-70%, price now rising from C. Stop: C - 0.2 ATR. Target: C + leg 1."),
  r(3, "measured_down", "Measured move down", "bearish", "Legs", "measured", "trend", 10, "structure", "Mirror."),
  r(3, "round_number", "Round-number level", "trend", "Support & resistance", "level_bounce", "any", 10, "structure", "A round price (multiple of a 'round' step for the price size) with 3+ pivots within 0.3 ATR of it and price within 2 ATR now. Facts only (no side)."),
  r(3, "vol_squeeze", "Volatility squeeze / coil", "trend", "Volatility", "squeeze", "any", 3, "state", "ATR(14) at its lowest of the last 30 candles and each of the last 5 candle ranges below 70% of the median range. Context only."),
  r(3, "failed_breakout", "Failed breakout (bull trap)", "bearish", "Traps & retests", "trap", "any", 6, "structure", "A resistance (2+ pivot highs) closed above by 0.2 ATR, then closed back below within 3 candles, all in the last 6 candles; still below. Stop: the trap high + 0.2 ATR. Target: nearest support, else 2 x risk."),
  r(3, "failed_breakdown", "Failed breakdown (bear trap)", "bullish", "Traps & retests", "trap", "any", 6, "structure", "Mirror below support."),
  r(3, "throwback", "Throwback to a broken level", "trend", "Traps & retests", "retest", "trend", 6, "structure", "A level (2+ pivots) broken by a 0.3 ATR close 3-20 candles ago, price moved >= 1 ATR away, and is now back within 0.3 ATR of it from the new side without closing through. Direction = the break's."),
  r(3, "pullback_breakout", "Pullback to the breakout level", "trend", "Traps & retests", "retest", "trend", 6, "structure", "The same set-up as the throwback (the matrix lists it twice): one detection, reported under both names, counted once."),
  r(3, "breakaway_gap_up", "Breakaway gap up", "bullish", "Gaps", "gap", "any", 10, "structure", "A real gap up (low above the prior high, or open above the prior high after a session break) out of a base whose last 15 candles span <= 3 ATR, not filled in the next 3 candles. Stop: below the gap. Target: 2 x risk."),
  r(3, "breakaway_gap_down", "Breakaway gap down", "bearish", "Gaps", "gap", "any", 10, "structure", "Mirror."),
  r(3, "runaway_gap_up", "Runaway (measuring) gap up", "bullish", "Gaps", "gap", "trend", 10, "structure", "A real gap up after a rise of 3-5 ATR over 15 candles, not filled. Target: the gap + the move before it."),
  r(3, "runaway_gap_down", "Runaway (measuring) gap down", "bearish", "Gaps", "gap", "trend", 10, "structure", "Mirror."),
  r(3, "exhaustion_gap_up", "Exhaustion gap up", "bearish", "Gaps", "gap", "any", 10, "structure", "A real gap up after a rise of 5+ ATR over 15 candles, filled (close back below the prior high) within 3 candles."),
  r(3, "exhaustion_gap_down", "Exhaustion gap down", "bullish", "Gaps", "gap", "any", 10, "structure", "Mirror."),
  r(3, "spike_top", "Spike reversal top", "bearish", "Reversal shapes", "spike", "any", 5, "structure", "Two candles: candle 1's high 0.5 ATR above the highest of the 20 before and its range >= 1.5 ATR; candle 2 closes below candle 1's midpoint. Stop: spike high + 0.2 ATR. Target: 2 x risk."),
  r(3, "spike_bottom", "Spike reversal bottom", "bullish", "Reversal shapes", "spike", "any", 5, "structure", "Mirror."),
  # ---------------------------------------------------------------- STEP 4: harmonic & Elliott
  r(4, "abcd_bull", "Bullish AB=CD", "bullish", "Harmonic & Elliott", "harmonic", "any", 10, "structure", "Pivots A(high) B(low) C(high) D(low): BC retraces 38.2-88.6% of AB, CD 85-115% of AB, D is the latest pivot (or price within 0.5 ATR of the projected D). Stop: D - 0.5 ATR. Target: 61.8% of AD."),
  r(4, "abcd_bear", "Bearish AB=CD", "bearish", "Harmonic & Elliott", "harmonic", "any", 10, "structure", "Mirror."),
  r(4, "three_drives_up", "Three drives up (exhaustion)", "bearish", "Harmonic & Elliott", "harmonic", "any", 10, "structure", "Three rising pivot highs; each drive 70-140% of the one before; pullbacks 50-80%; the third high in the last 10 candles. Stop: third high + 0.3 ATR. Target: start of the third drive."),
  r(4, "three_drives_down", "Three drives down (exhaustion)", "bullish", "Harmonic & Elliott", "harmonic", "any", 10, "structure", "Mirror."),
  r(4, "wolfe_bull", "Bullish Wolfe wave", "bullish", "Harmonic & Elliott", "wolfe", "any", 10, "structure", "Pivots 1(L) 2(H) 3(L, below 1) 4(H, below 2, above 1) 5(L, below 3 and below the 1-3 line); lines 1-3 and 2-4 converge; point 5 in the last 10 candles. Stop: 5 - 0.5 ATR. Target: the 1-4 line projected forward."),
  r(4, "wolfe_bear", "Bearish Wolfe wave", "bearish", "Harmonic & Elliott", "wolfe", "any", 10, "structure", "Mirror."),
  r(4, "elliott_up", "Elliott impulse up (1-5)", "bullish", "Harmonic & Elliott", "elliott", "trend", 10, "structure", "Pivots P0(L) P1 P2 P3 P4: P2 above P0, P3 above P1, P4 above P1 (wave 4 does not overlap wave 1), wave 3 not the shortest; price now in wave 5 above P4. Stop: P4 - 0.2 ATR. Target: P4 + wave 1. A count, not a certainty: low confidence."),
  r(4, "elliott_down", "Elliott impulse down (1-5)", "bearish", "Harmonic & Elliott", "elliott", "trend", 10, "structure", "Mirror."),
  r(4, "elliott_abc", "Elliott ABC correction", "trend", "Harmonic & Elliott", "elliott", "any", 10, "structure", "After a prior leg >= 5 ATR: A against it, B retracing 38-79% of A, C beyond A's end with C = 62-162% of A, C in the last 10 candles. Direction = the prior leg's (the trend resumes). Target: start of A."),
  # ---------------------------------------------------------------- STEP 5: indicators (computed in R)
  r(5, "golden_cross", "Golden cross (50 over 200)", "bullish", "Moving averages", "ma_cross_long", "trend", 10, "indicator", "EMA50 crosses above EMA200 (only when 200+ candles of warm-up exist before the window)."),
  r(5, "death_cross", "Death cross (50 under 200)", "bearish", "Moving averages", "ma_cross_long", "trend", 10, "indicator", "EMA50 crosses below EMA200 (same warm-up rule)."),
  r(5, "ma_pullback_up", "Pullback to the moving average (uptrend)", "bullish", "Moving averages", "ma_pullback", "trend", 5, "indicator", "Close above EMA50, EMA50 rising over 10 candles; the low touches EMA20 or EMA50 (within 0.2 ATR) and the close holds above it. Stop: below that EMA - 0.5 ATR."),
  r(5, "ma_pullback_down", "Pullback to the moving average (downtrend)", "bearish", "Moving averages", "ma_pullback", "trend", 5, "indicator", "Mirror."),
  r(5, "ma_stack_bull", "Moving averages stacked bullish", "bullish", "Moving averages", "ma_stack", "trend", 1, "state", "EMA20 > EMA50 > EMA200, all three higher than 5 candles ago (needs EMA200 warm-up)."),
  r(5, "ma_stack_bear", "Moving averages stacked bearish", "bearish", "Moving averages", "ma_stack", "trend", 1, "state", "Mirror, all falling."),
  r(5, "ma_ribbon_squeeze", "Moving-average ribbon squeeze", "trend", "Moving averages", "squeeze", "any", 1, "state", "EMA20, EMA50 and EMA200 within 1 ATR of each other and EMA50 almost flat (moved < 0.5 ATR over 10 candles)."),
  r(5, "price_x_ma_up", "Price crossed above the moving average", "bullish", "Moving averages", "ma_pullback", "trend", 3, "indicator", "Close crosses from below to above EMA20 or EMA50."),
  r(5, "price_x_ma_down", "Price crossed below the moving average", "bearish", "Moving averages", "ma_pullback", "trend", 3, "indicator", "Mirror."),
  r(5, "holy_grail_long", "Holy Grail long (ADX > 30, pullback to the 20 EMA)", "bullish", "Moving averages", "holy_grail", "trend", 3, "indicator", "ADX(14) >= 30 and higher than 3 candles ago, DI+ > DI- (ADX alone has no direction), the low touches EMA20 (within 0.1 ATR) and the close holds above it. Entry: above the pullback candle's high. Stop: pullback low - 0.2 ATR. Target: recent swing high."),
  r(5, "holy_grail_short", "Holy Grail short", "bearish", "Moving averages", "holy_grail", "trend", 3, "indicator", "Mirror with DI- > DI+."),
  r(5, "macd_x_signal_up", "MACD crossed above its signal", "bullish", "MACD", "macd_cross", "trend", 3, "indicator", "MACD(12,26,9) line crosses above the signal line."),
  r(5, "macd_x_signal_down", "MACD crossed below its signal", "bearish", "MACD", "macd_cross", "trend", 3, "indicator", "Mirror."),
  r(5, "macd_x_zero_up", "MACD crossed above zero", "bullish", "MACD", "macd_cross", "trend", 3, "indicator", "MACD line crosses above 0."),
  r(5, "macd_x_zero_down", "MACD crossed below zero", "bearish", "MACD", "macd_cross", "trend", 3, "indicator", "MACD line crosses below 0."),
  r(5, "macd_div_bull", "Bullish MACD divergence", "bullish", "Divergence", "divergence", "any", 10, "indicator", "Two price pivot lows (1 ATR swings) within 40 candles: lower low in price, higher MACD at the second; the second in the last 10 candles."),
  r(5, "macd_div_bear", "Bearish MACD divergence", "bearish", "Divergence", "divergence", "any", 10, "indicator", "Mirror with pivot highs."),
  r(5, "rsi_ob", "RSI overbought", "bearish", "RSI", "rsi_extreme", "range", 1, "state", "RSI(14) > 70 on the last candle. Counts only in range conditions; in a trend it is momentum, not a sell signal."),
  r(5, "rsi_os", "RSI oversold", "bullish", "RSI", "rsi_extreme", "range", 1, "state", "RSI(14) < 30 on the last candle (range conditions only)."),
  r(5, "rsi_div_bull", "Bullish RSI divergence", "bullish", "Divergence", "divergence", "any", 10, "indicator", "Price lower low, RSI higher low (as for MACD)."),
  r(5, "rsi_div_bear", "Bearish RSI divergence", "bearish", "Divergence", "divergence", "any", 10, "indicator", "Price higher high, RSI lower high."),
  r(5, "rsi_fail_bull", "RSI bullish failure swing", "bullish", "RSI", "rsi_swing", "any", 5, "indicator", "RSI below 30, rallies to a peak X, pulls back staying above 30, then crosses above X (Wilder)."),
  r(5, "rsi_fail_bear", "RSI bearish failure swing", "bearish", "RSI", "rsi_swing", "any", 5, "indicator", "Mirror above 70."),
  r(5, "rsi_x50_up", "RSI crossed above 50", "bullish", "RSI", "rsi_mid", "trend", 3, "indicator", "RSI(14) crosses above 50."),
  r(5, "rsi_x50_down", "RSI crossed below 50", "bearish", "RSI", "rsi_mid", "trend", 3, "indicator", "RSI(14) crosses below 50."),
  r(5, "stoch_x_up_os", "Stochastic crossed up from oversold", "bullish", "Stochastic", "stoch", "range", 3, "indicator", "Slow %K(14,3) crosses above %D(3) with both below 20."),
  r(5, "stoch_x_down_ob", "Stochastic crossed down from overbought", "bearish", "Stochastic", "stoch", "range", 3, "indicator", "Slow %K crosses below %D with both above 80."),
  r(5, "stoch_div_bull", "Bullish stochastic divergence", "bullish", "Divergence", "divergence", "any", 10, "indicator", "Price lower low, slow %K higher low."),
  r(5, "stoch_div_bear", "Bearish stochastic divergence", "bearish", "Divergence", "divergence", "any", 10, "indicator", "Price higher high, slow %K lower high."),
  r(5, "momentum_exhaustion", "Momentum exhaustion", "trend", "Divergence", "divergence", "any", 3, "state", "Close at a 20-candle high (or low) while at least 2 of RSI, MACD histogram and %K are weaker than at the previous 20-candle extreme. A warning: not counted for a side."),
  r(5, "bb_squeeze", "Bollinger squeeze", "trend", "Volatility", "squeeze", "any", 3, "state", "Bollinger(20,2) band width within 10% of its lowest of the last 100 candles."),
  r(5, "bb_break_up", "Bollinger breakout up", "bullish", "Volatility", "bb_break", "trend", 3, "indicator", "Close above the upper band with a squeeze in the 10 candles before."),
  r(5, "bb_break_down", "Bollinger breakout down", "bearish", "Volatility", "bb_break", "trend", 3, "indicator", "Close below the lower band after a squeeze."),
  r(5, "bb_walk_up", "Walking the upper Bollinger band", "bullish", "Volatility", "bb_walk", "trend", 1, "state", "3+ consecutive closes within 0.2 ATR of (or above) the upper band."),
  r(5, "bb_walk_down", "Walking the lower Bollinger band", "bearish", "Volatility", "bb_walk", "trend", 1, "state", "Mirror at the lower band."),
  r(5, "bb_snap_lower", "Snap back from the lower band", "bullish", "Volatility", "bb_snap", "range", 3, "indicator", "A low at or below the lower band in the last 3 candles, then an up candle closing at least halfway back to the middle band."),
  r(5, "bb_snap_upper", "Snap back from the upper band", "bearish", "Volatility", "bb_snap", "range", 3, "indicator", "Mirror."),
  r(5, "keltner_squeeze", "Keltner channel squeeze", "trend", "Volatility", "squeeze", "any", 1, "state", "Both Bollinger bands inside the Keltner channel (EMA20 +/- 1.5 ATR)."),
  r(5, "atr_rising", "Volatility expanding (ATR rising)", "trend", "Volatility", "atr_trend", "any", 1, "state", "ATR(14) at least 15% above 10 candles ago and up on each of the last 3 candles."),
  r(5, "atr_falling", "Volatility contracting (ATR falling)", "trend", "Volatility", "squeeze", "any", 1, "state", "ATR(14) at least 15% below 10 candles ago and down on each of the last 3 candles."),
  r(5, "adx_strong", "ADX above 25: the trend is strong", "trend", "Trend strength", "adx", "any", 1, "state", "ADX(14) >= your trend threshold (Setup, default 25). Sets the regime."),
  r(5, "adx_weak", "ADX below 20: no trend, range conditions", "trend", "Trend strength", "adx", "any", 1, "state", "ADX(14) <= your range threshold (default 20). Sets the regime."),
  r(5, "di_x_up", "DI+ crossed above DI-", "bullish", "Trend strength", "di_cross", "trend", 3, "indicator", "DI+ crosses above DI-; noted when ADX is rising."),
  r(5, "di_x_down", "DI- crossed above DI+", "bearish", "Trend strength", "di_cross", "trend", 3, "indicator", "Mirror."),
  # ---------------------------------------------------------------- STEP 6: course strategies
  r(6, "pivot_bounce_long", "Pivot point bounce (long)", "bullish", "Course strategies", "pivot", "range", 5, "strategy", "Classic pivots from the previous day's high/low/close (Capital.com daily candles). The low touched PP, S1 or S2 (within 0.3 ATR) in the last 5 candles and the close is now 0.5 ATR above it. Stop: that level - 0.5 ATR. Target: the next pivot above."),
  r(6, "pivot_bounce_short", "Pivot point bounce (short)", "bearish", "Course strategies", "pivot", "range", 5, "strategy", "Mirror off PP, R1 or R2."),
  r(6, "on_straddle_up", "Overnight-range straddle, upper side", "bullish", "Course strategies", "straddle", "any", 10, "strategy", "Overnight range 22:00-06:00 UK (set in Setup); after 06:00 a close above its high. Stop: the overnight low. Target: high + the range height."),
  r(6, "on_straddle_down", "Overnight-range straddle, lower side", "bearish", "Course strategies", "straddle", "any", 10, "strategy", "Mirror below the overnight low."),
  r(6, "orb_up", "Opening-range breakout up", "bullish", "Course strategies", "orb", "any", 10, "strategy", "Opening range = the first 60 minutes from 08:00 UK (set in Setup); after it, a close above its high. Stop: the range low. Target: high + the range height."),
  r(6, "orb_down", "Opening-range breakout down", "bearish", "Course strategies", "orb", "any", 10, "strategy", "Mirror below the range low.")
  )
})
stopifnot(nrow(cc_catalog) == 141, !anyDuplicated(cc_catalog$key))
cc_cat_row <- function(key) cc_catalog[match(key, cc_catalog$key), , drop = FALSE]

# ************* the course step each pattern is taught in (the same split as the Step-by-Step Practice tabs) and the
# pattern groups with their steps: used by the "course tools in the analysis" choice of the Trading Desk
cc_key_course_step <- function(keys = cc_catalog$key) { k <- cc_catalog$key; st <- cc_catalog$step
  s6 <- c(k[st == 6], "holy_grail_long", "holy_grail_short", "adx_strong", "adx_weak", "di_x_up", "di_x_down")
  s1 <- c(k[st == 1], "failed_breakout", "failed_breakdown", "throwback", "pullback_breakout", "round_number")
  s3 <- c(setdiff(k[st == 5], s6), "vol_squeeze")
  ifelse(keys %in% s6, 6L, ifelse(keys %in% s1, 1L, ifelse(keys %in% s3, 3L, ifelse(keys %in% k, 2L, NA_integer_)))) }
cc_group_tbl <- function() { cs <- cc_key_course_step(); g <- unique(cc_catalog$group)
  x <- do.call(rbind, lapply(g, function(gr) { s <- sort(unique(cs[cc_catalog$group == gr])); n <- sum(cc_catalog$group == gr)
    data.frame(group = gr, n = n, first_step = s[1], steps = paste(sprintf("Step %d", s), collapse = " + "),
               detail = paste(vapply(s, function(z) sprintf("Step %d: %d", z, sum(cs == z & cc_catalog$group == gr)), ""), collapse = ", "), stringsAsFactors = FALSE) }))
  x[order(x$first_step, x$group), , drop = FALSE] }
cc_course_step_names <- c("1" = "Support & resistance, trend lines, candles", "2" = "Fibonacci & price patterns", "3" = "Indicators", "6" = "Straddles, pivots, Holy Grail, ADX")
# keep only the patterns of the chosen groups (NULL or all groups = everything)
cc_groups_ok <- function(keys, groups) if (is.null(groups) || !length(groups)) rep(TRUE, length(keys)) else cc_catalog$group[match(keys, cc_catalog$key)] %in% groups
