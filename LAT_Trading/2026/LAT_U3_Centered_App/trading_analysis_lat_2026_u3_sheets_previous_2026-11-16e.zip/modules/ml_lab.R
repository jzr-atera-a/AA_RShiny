# ************** H. Machine Learning: two models trained on candle history, checked against your own records --------------
ml_lab_ui <- function(id) { ns <- NS(id)
  tagList(
    tags$div(style = "background:#eef2ff; border:1px solid #c7d2fe; border-radius:10px; padding:10px 14px; margin-bottom:10px;",
      tags$div(style = "font-weight:800; font-size:16px; color:#312e81;", "H. Machine learning on the market's history"),
      tags$div(style = "font-size:12.5px; color:#334155; line-height:1.5;",
        "Your own records are still too few to train on, so the models learn from the candle history of the market and of its related markets, and your trades, Morning Sheets and trade sheets are used to check them. ",
        tags$b("Model 1: gradient boosted trees. Model 2: a hidden Markov model of the market state. Model 3: a Kalman filter of the trend. Model 4: a GARCH volatility model. Models 5 to 8 ****************: a neural network, a stacked ensemble that learns how much to trust each forecaster, a latent factor model of the related markets, and structural-break detection. "),
        "Models 1, 2, 3, 5 and 6 forecast; 4, 7 and 8 describe volatility, the common market move and whether the history still applies. Each forecast says how often a BUY or a SELL opened now would reach its target before its stop. All are tested walk-forward (trained on the past, tested on the next block, never on candles they have seen). ",
        tags$b("A model with no proven edge says so: its forecast is then not a reason to trade."))),
    cc_rec_box(1, "Data and settings", tint = "#f8fafc",
      fluidRow(column(3, textInput(ns("epic"), cc_rec_lab("Market (Capital.com epic)"), "OIL_BRENT")),
               column(5, textInput(ns("rel"), cc_rec_lab("Related markets (epics, comma separated)"), "OIL_CRUDE, NATURALGAS, EURUSD")),
               column(2, selectInput(ns("res"), cc_rec_lab("Candle size"), c("15 min" = "MINUTE_15", "30 min" = "MINUTE_30", "1 hour" = "HOUR"))),
               column(2, numericInput(ns("days"), cc_rec_lab("Days of history"), 60, min = 20, max = 200))),
      fluidRow(column(3, numericInput(ns("rrr"), cc_rec_lab("Reward:Risk of the trade"), 1.5, min = 0.5, step = 0.1)),
               column(3, numericInput(ns("stop"), cc_rec_lab("Stop distance (x ATR)"), 1.5, min = 0.5, step = 0.25)),
               column(3, numericInput(ns("hours"), cc_rec_lab("Holding time (hours)"), 10, min = 1)),
               column(3, tags$div(style = "margin-top:25px;", actionButton(ns("train"), "Train and test the models", icon = icon("brain"), class = "btn-primary", style = "color:#fff; font-weight:700; white-space:normal; width:100%;")))),
      uiOutput(ns("inventory"))),
    cc_rec_box(2, "Forecast now and verdict", tint = "#f0fdf4", uiOutput(ns("now"))),
    cc_rec_box(3, "Advice per course strategy (tested cases on this market)", tint = "#fffbeb", DT::DTOutput(ns("strat")),
      cc_rec_note("Cases are candles of the tested period where the strategy's conditions were met; the result is whether the target came before the stop, after the spread. 'Models agree' keeps only the cases where the four forecasting models' average chance was at or above break-even. Proven = the low end of the likely range is above break-even. Neighbouring candles share much of their outcome, so the cases are less independent than their number suggests: read 'proven' with care under about 100 cases.")),
    cc_rec_box(4, "How good are the models? (out of sample) ****************", tint = "#f8fafc",
      fluidRow(column(3, radioButtons(ns("v_side"), cc_rec_lab("Side shown in the charts"), c("BUY", "SELL"), inline = TRUE)), column(9, uiOutput(ns("best")))),
      tabsetPanel(id = ns("v_tabs"),
        tabPanel("Verdicts", DT::DTOutput(ns("metrics")),
          cc_rec_note("AUC 0.50 = no better than chance, 1.00 = perfect. Skill = how much better than always forecasting the past average (0 or less = no better). Picked = cases where the model's chance was 5 points or more above break-even; their hit rate, its low end and the R per trade after the spread decide the verdict. The stacked ensemble is tested on fewer cases: it needs one tested block to learn from.")),
        tabPanel("Accuracy", fluidRow(column(6, plotly::plotlyOutput(ns("g_auc"), height = "320px")), column(6, plotly::plotlyOutput(ns("g_hit"), height = "320px"))),
          cc_rec_note("Left: ranking power of each model, BUY and SELL; the dotted line is chance. Right: hit rate of the picked cases with its likely range; a bar is proven only when the whole range is above the break-even line.")),
        tabPanel("ROC curves", plotly::plotlyOutput(ns("g_roc"), height = "360px"), cc_rec_note("The further a curve bows above the diagonal, the better the model separates trades that reach the target from those that are stopped.")),
        tabPanel("Results over time", fluidRow(column(7, plotly::plotlyOutput(ns("g_eq"), height = "340px")), column(5, plotly::plotlyOutput(ns("g_fold"), height = "340px"))),
          cc_rec_note("Left: running total in R if every picked case had been traded at the stated stop and target, after the spread. Cases overlap, so read the shape (steady or one lucky stretch), not the total. Right: AUC in each tested block; a model that is good in one block only is not reliable.")),
        tabPanel("Calibration & drivers", fluidRow(column(4, plotly::plotlyOutput(ns("cal"), height = "320px")), column(4, plotly::plotlyOutput(ns("imp"), height = "320px")), column(4, plotly::plotlyOutput(ns("g_stack"), height = "320px"))),
          cc_rec_note("Left: forecast against what happened. Middle: what the boosted trees used most. Right: how much the stacked ensemble trusts each forecaster (a bar below zero means it bets against that model).")))),
    cc_rec_box(5, "Market structure: common factor and structural breaks ****************", tint = "#eff6ff",
      fluidRow(column(5, uiOutput(ns("fac_txt")), plotly::plotlyOutput(ns("g_fac"), height = "260px")), column(7, uiOutput(ns("brk_txt")), plotly::plotlyOutput(ns("g_brk"), height = "260px")))),
    cc_rec_box(6, "Your own closed trades against the models", tint = "#f8fafc", DT::DTOutput(ns("mine")),
      cc_rec_note("The models' chance at the candle of your entry, from the walk-forward test only. With few trades this is a check, not a proof.")))
}

ml_lab_server <- function(id, client, store = NULL, records_store = NULL, fetch_bars = NULL, now_fn = Sys.time) {
  moduleServer(id, function(input, output, session) {
    if (is.null(fetch_bars)) fetch_bars <- function(epic, res, from, to) cc_fetch_bars(client, epic, res, from, to)
    run <- reactiveVal(NULL); meta <- reactiveVal(NULL)
    note <- function(m, type = "message") showNotification(m, type = type, duration = 8)
    cnt <- function(st, name) { x <- tryCatch(st$current(name), error = function(e) NULL); if (is.null(x)) 0L else nrow(x) }
    output$inventory <- renderUI({ run(); tr <- if (is.null(store)) NULL else tryCatch(store$current("trades"), error = function(e) NULL)
      closed <- if (is.null(tr)) 0L else sum(tr$status %in% "CLOSED"); m <- meta()
      tags$div(style = "font-size:12.5px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:6px 10px;",
        tags$b("Your records in BigQuery: "), sprintf("%d Capital.com trade(s), %d closed; %d Morning Sheet(s); %d IG / screenshot trade(s); %d saved chart scan(s); %d scenario row(s). ",
          if (is.null(tr)) 0L else nrow(tr), closed, if (is.null(records_store)) 0L else cnt(records_store, "morning_sheets"), if (is.null(records_store)) 0L else cnt(records_store, "trades"),
          if (is.null(store)) 0L else cnt(store, "scans"), if (is.null(store)) 0L else cnt(store, "scenarios")),
        tags$span(style = sprintf("font-weight:700; color:%s;", if (closed >= 100) "#166534" else "#b45309"),
          if (closed >= 100) "Enough closed trades to start training on them: ask for that build." else sprintf("%d closed trade(s) is too few to train on (about 100 are needed), so the models learn from candle history.", closed)),
        if (!is.null(m)) tags$div(sprintf("Last run: %s, %d candles from %s to %s UK, %d tested out of sample; related markets read: %s.", m$epic, m$n, m$from, m$to, m$tested, m$rel))) })
    observeEvent(input$train, withProgress(message = "Reading the candle history from Capital.com...", value = 0.02, tryCatch({
      if (!client$connected()) { note("Connect Capital.com first (API Configuration > Capital.com).", "warning"); return() }
      epic <- toupper(trimws(input$epic)); res <- input$res; mins <- cc_res_minutes[[res]]; to <- now_fn(); from <- to - max(20, min(200, input$days %||% 60)) * 86400
      b <- fetch_bars(epic, res, from, to); if (is.null(b) || nrow(b) < 800) stop(sprintf("Capital.com returned %d candles for %s: at least 800 are needed. Use more days or check the epic.", NROW(b), epic))
      eps <- setdiff(toupper(trimws(unlist(strsplit(input$rel %||% "", "[,;]")))), c("", epic)); rel <- list()
      for (e in eps) { setProgress(0.04, message = sprintf("Reading the related market %s...", e)); rb <- tryCatch(fetch_bars(e, res, from, to), error = function(x) NULL); if (!is.null(rb) && nrow(rb) >= 200) rel[[e]] <- rb }
      px <- tryCatch(cc_market_facts(client$market(epic)), error = function(e) NULL); spread <- suppressWarnings(as.numeric(px$offer - px$bid)); if (!length(spread) || !is.finite(spread)) spread <- 0
      r <- ml_run(b, rel, rrr = input$rrr %||% 1.5, stop_atr = input$stop %||% 1.5, horizon = max(4L, as.integer(round((input$hours %||% 10) * 60 / mins))), spread = spread,
                  progress = function(v, m) setProgress(v, message = m))
      fm <- function(t) format(t, "%d/%m/%Y %H:%M", tz = "Europe/London")
      meta(list(epic = epic, res = res, n = r$n, tested = r$tested, from = fm(r$from), to = fm(r$to), rel = if (length(rel)) paste(names(rel), collapse = ", ") else "none", missed = setdiff(eps, names(rel)))); run(r)
      if (length(setdiff(eps, names(rel)))) note(sprintf("No candles for: %s (check the epic). The models ran without it.", paste(setdiff(eps, names(rel)), collapse = ", ")), "warning")
      if (!is.null(store)) { setProgress(0.95, message = "Saving the run to BigQuery (cc_ml_runs)..."); rid <- format(to, "ML%Y%m%d%H%M%S", tz = "UTC"); m <- r$metrics
        key <- stats::setNames(names(r$models), r$models)
        store$write("ml_runs", data.frame(run_id = paste(rid, key[m$model], m$side, sep = "-"), epic = epic, resolution = res, related = paste(names(rel), collapse = ","), candles = r$n, tested = r$tested, rrr = r$rrr,
          stop_atr = r$stop_atr, horizon = r$horizon, model = m$model, side = m$side, cases = m$cases, base_rate = m$base_rate, auc = m$auc, skill_pct = m$skill_pct, picked = m$picked, picked_hit = m$picked_hit,
          picked_r = m$picked_r, verdict = m$verdict, chance_now = vapply(seq_len(nrow(m)), function(i) r$now[[tolower(m$side[i])]][[key[[m$model[i]]]]], 0),
          strategies_json = as.character(jsonlite::toJSON(r$strategies, auto_unbox = TRUE)), stringsAsFactors = FALSE)) }
      note(sprintf("Models trained and tested on %d candles of %s.", r$n, epic))
    }, error = function(e) note(paste("Machine learning run failed:", conditionMessage(e)), "error"))))
    output$now <- renderUI({ r <- run(); if (is.null(r)) return(cc_rec_note("Press 'Train and test the models'. It reads the history, tests the models walk-forward and takes about a minute."))
      be <- 100 / (1 + r$rrr); m <- r$metrics
      card <- function(side) { v <- r$now[[tolower(side)]]; avg <- v[["both"]]; vd <- m$verdict[m$model == r$models[["both"]] & m$side == side]; edge <- vd %in% "EDGE"; weak <- grepl("WEAK", vd)
        col <- if (edge && avg >= be) "#16a34a" else if ((edge || weak) && avg >= be) "#d97706" else "#64748b"
        column(6, tags$div(style = sprintf("border:2px solid %s; border-radius:10px; background:#fff; padding:8px 12px;", col),
          tags$div(style = "font-weight:800; font-size:15px;", sprintf("%s now: %.0f%% chance of target first", side, avg)),
          tags$div(style = "font-size:12.5px;", sprintf("Boosted trees %.0f%% | hidden Markov model %.0f%% | Kalman trend %.0f%% | neural network %.0f%% | stacked ensemble %s | break-even %.0f%%%s", v[["gbm"]], v[["hmm"]], v[["kal"]], v[["nn"]], if (is.finite(v[["stk"]])) sprintf("%.0f%%", v[["stk"]]) else "-", be, if (diff(range(v[r$forecasters], na.rm = TRUE)) > 20) " | THE MODELS DISAGREE by more than 20 points" else "")),
          tags$div(style = sprintf("font-weight:700; color:%s;", col), sprintf("Tested verdict: %s. %s", vd,
            if (edge && avg >= be) "The models have a proven edge on this side and the chance now is above break-even."
            else if (edge || weak) (if (avg >= be) "Above break-even now, but the edge is not proven: treat it as a weak reason only." else "The chance now is below break-even: no reason to trade this side from the models.")
            else "The models have shown no edge on this side, so this forecast is not a reason to trade.")))) }
      g <- r$garch; tr <- r$trend; box <- function(title, ...) column(6, tags$div(style = "border:1px solid #cbd5e1; border-radius:10px; background:#fff; padding:8px 12px; margin-top:8px; font-size:12.5px;", tags$div(style = "font-weight:800; font-size:14px;", title), ...))
      tagList(fluidRow(card("BUY"), card("SELL")),
        fluidRow(
          box(sprintf("Trend (Kalman filter): %s", if (!is.finite(tr$t)) "-" else if (tr$t >= 2) "UP, clear" else if (tr$t <= -2) "DOWN, clear" else if (abs(tr$t) >= 1) paste(if (tr$t > 0) "up" else "down", "but weak") else "none"),
            sprintf("Hidden slope %+.3f per candle (%+.2f ATR), %.1f times its own uncertainty. Under 1 is noise; 2 or more is a clear trend. ", tr$slope, tr$slope / tr$atr, abs(tr$t)),
            tags$b(if (!is.finite(tr$t)) "" else if (abs(tr$t) < 1) "No trend the filter can tell from noise: a Holy Grail trade has little behind it now." else sprintf("A %s is with this trend; a %s is against it.", if (tr$t > 0) "BUY" else "SELL", if (tr$t > 0) "SELL" else "BUY"))),
          if (is.null(g)) box("Volatility (GARCH)", "Could not be fitted on this history.") else box(sprintf("Volatility (GARCH): %.0f%% of its usual level", 100 * g$vol_ratio),
            sprintf("Likely move in your holding time: about %.3f (1 standard deviation) = %.1f times your stop distance. Chance that price travels as far as the stop %.0f%%, as far as the target %.0f%%. ", g$move, g$move_vs_stop, g$p_stop, g$p_target),
            tags$b(if (g$p_target < 35) "The target is far for this holding time: expect many trades to end at neither level. Consider a longer holding time or a nearer target. " else if (g$move_vs_stop > 2.5) "Price is likely to travel well beyond the stop distance: the stop is tight for this volatility. " else "Stop and target are in proportion to the likely move. "),
            if (!is.finite(g$cor_garch)) sprintf("No volatility clustering was found in this history, so GARCH adds nothing over ATR here (tested on %d candles).", g$tested)
            else sprintf("A volatility shock halves in about %.0f candles. Tested out of sample on %d candles: GARCH ranks the size of the coming move with correlation %.2f (ATR alone %.2f)%s.", g$half_life, g$tested, g$cor_garch, g$cor_atr, if (g$cor_garch <= g$cor_atr) ": no better than ATR on this history" else ""))),
        cc_rec_note(sprintf("For a trade opened at the last candle's close with a stop %.2g ATR away, a target at R:R %.2g and %d candles of holding time. Market state now (hidden Markov model): %s. The spread costs about %.2f R per trade and is charged in every result.",
          r$stop_atr, r$rrr, r$horizon, paste(sprintf("state %d %d%%", seq_along(r$states), r$states), collapse = ", "), r$cost_r))) })
    tbl <- function(x, ...) DT::datatable(x, rownames = FALSE, options = list(dom = "t", scrollX = TRUE, pageLength = 20), ...)
    output$strat <- DT::renderDT({ r <- run(); if (is.null(r)) return(NULL); s <- r$strategies; s$met_now <- ifelse(s$met_now, "YES", "no")
      names(s) <- c("Strategy", "Cases", "Target first %", "Likely at least %", "Break-even %", "R per trade", "Cases (models agree)", "Target first % (models agree)", "R per trade (models agree)", "Conditions met now?", "Advice")
      DT::formatStyle(tbl(s[, c(11, 1:10)]), "Advice", fontWeight = "800", color = DT::styleEqual(unique(s$Advice), ifelse(grepl("^TRADE", unique(s$Advice)), "#166534", ifelse(grepl("^HALF", unique(s$Advice)), "#b45309", ifelse(grepl("^LEAVE", unique(s$Advice)), "#b91c1c", "#475569"))))) })
    output$metrics <- DT::renderDT({ r <- run(); if (is.null(r)) return(NULL); m <- r$metrics
      names(m) <- c("Model", "Side", "Cases tested", "Target first % (all)", "AUC", "Skill %", "Break-even %", "Picked", "Picked: target first %", "Picked: likely at least %", "Picked: R per trade", "Verdict")
      DT::formatStyle(tbl(m[, c(12, 1:11)]), "Verdict", fontWeight = "800", color = DT::styleEqual(c("EDGE", "WEAK EDGE (not proven)", "NO EDGE", "TOO FEW CASES"), c("#166534", "#b45309", "#b91c1c", "#475569"))) })
    output$cal <- plotly::renderPlotly({ r <- run(); if (is.null(r) || is.null(r$calibration)) return(NULL); c0 <- r$calibration; p <- plotly::plot_ly()
      for (s in unique(c0$side)) { d <- c0[c0$side == s, ]; p <- plotly::add_trace(p, x = d$forecast, y = d$actual, type = "scatter", mode = "lines+markers", name = s, text = sprintf("%d cases", d$n)) }
      rg <- range(c(c0$forecast, c0$actual)); p <- plotly::add_trace(p, x = rg, y = rg, type = "scatter", mode = "lines", name = "perfect", line = list(dash = "dot", color = "#94a3b8"))
      plotly::layout(p, title = list(text = "Forecast against what happened (tested period)", font = list(size = 13)), xaxis = list(title = "Models' chance %"), yaxis = list(title = "Target first %"), margin = list(t = 40)) })
    output$imp <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); v <- utils::head(r$importance$buy, 12); v2 <- r$importance$sell[names(v)]; v2[is.na(v2)] <- 0; o <- rev(seq_along(v))
      p <- plotly::plot_ly(y = factor(names(v)[o], levels = names(v)[o]), x = as.numeric(v)[o], type = "bar", orientation = "h", name = "BUY model"); p <- plotly::add_trace(p, x = as.numeric(v2)[o], name = "SELL model")
      plotly::layout(p, barmode = "group", title = list(text = "What the boosted trees used most (% of importance)", font = list(size = 13)), margin = list(t = 40, l = 110)) })
    pal <- c(gbm = "#2563eb", hmm = "#7c3aed", kal = "#0d9488", nn = "#db2777", both = "#475569", stk = "#d97706")
    lay <- function(p, title, ...) plotly::layout(p, title = list(text = title, font = list(size = 13)), margin = list(t = 40), legend = list(orientation = "h", y = -0.25), ...)
    side_k <- reactive(tolower(input$v_side %||% "BUY"))
    output$best <- renderUI({ r <- run(); if (is.null(r)) return(NULL); m <- r$metrics[r$metrics$side == toupper(side_k()), ]; rk <- match(m$verdict, c("EDGE", "WEAK EDGE (not proven)", "NO EDGE", "TOO FEW CASES")); o <- order(rk, -m$picked_r, -m$auc)[1]
      tags$div(style = "font-size:12.5px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:6px 10px; margin-top:4px;", tags$b(sprintf("Best on %s: %s (%s). ", toupper(side_k()), m$model[o], m$verdict[o])),
        sprintf("AUC %.2f; %d picked cases, %s%% reached the target against a break-even of %.0f%%, %s R per trade. %d of %d models show a proven edge on this side.", m$auc[o], m$picked[o], m$picked_hit[o], m$break_even[o], m$picked_r[o], sum(m$verdict == "EDGE"), nrow(m))) })
    output$g_auc <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); m <- r$metrics; p <- plotly::plot_ly()
      for (sd in c("BUY", "SELL")) { d <- m[m$side == sd, ]; p <- plotly::add_trace(p, x = d$model, y = d$auc, type = "bar", name = sd, text = sprintf("%.2f", d$auc), textposition = "outside") }
      lay(p, "Ranking power (AUC) by model", barmode = "group", yaxis = list(title = "AUC", range = c(0.3, 0.9)), xaxis = list(title = "", categoryorder = "array", categoryarray = unname(r$models)),
          shapes = list(list(type = "line", x0 = -0.5, x1 = length(r$models) - 0.5, y0 = 0.5, y1 = 0.5, line = list(dash = "dot", color = "#94a3b8")))) })
    output$g_hit <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); d <- r$metrics[r$metrics$side == toupper(side_k()) & is.finite(r$metrics$picked_hit), ]; if (!nrow(d)) return(NULL)
      hi <- vapply(seq_len(nrow(d)), function(i) cc_wilson(d$picked_hit[i], d$picked[i])$hi, 0)
      p <- plotly::plot_ly(x = d$model, y = d$picked_hit, type = "bar", marker = list(color = ifelse(d$verdict == "EDGE", "#16a34a", ifelse(grepl("WEAK", d$verdict), "#d97706", "#94a3b8"))), hovertext = sprintf("%d cases, %s", d$picked, d$verdict),
        error_y = list(type = "data", symmetric = FALSE, array = hi - d$picked_hit, arrayminus = d$picked_hit - d$picked_lo, color = "#334155"))
      lay(p, sprintf("%s: hit rate of the picked cases against break-even", toupper(side_k())), yaxis = list(title = "Target first %"), xaxis = list(title = "", categoryorder = "array", categoryarray = unname(r$models)), showlegend = FALSE,
          shapes = list(list(type = "line", x0 = -0.5, x1 = nrow(d) - 0.5, y0 = d$break_even[1], y1 = d$break_even[1], line = list(dash = "dash", color = "#dc2626")))) })
    output$g_roc <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); P <- r$pred[[side_k()]]; p <- plotly::plot_ly()
      for (k in names(r$models)) { z <- ml_roc(P[[k]], P$y); if (!is.null(z)) p <- plotly::add_trace(p, x = z$fpr, y = z$tpr, type = "scatter", mode = "lines", name = sprintf("%s (%.2f)", r$models[[k]], ml_auc(P[[k]], P$y)), line = list(color = pal[[k]])) }
      p <- plotly::add_trace(p, x = c(0, 1), y = c(0, 1), type = "scatter", mode = "lines", name = "chance", line = list(dash = "dot", color = "#94a3b8"))
      lay(p, sprintf("%s: ROC curve of each model (AUC in brackets)", toupper(side_k())), xaxis = list(title = "Stopped trades wrongly picked"), yaxis = list(title = "Target trades picked")) })
    output$g_eq <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); P <- r$pred[[side_k()]]; be <- 100 / (1 + r$rrr); p <- plotly::plot_ly()
      for (k in names(r$models)) { i <- which(is.finite(P[[k]]) & is.finite(P$y) & P[[k]] >= be + 5); if (length(i) < 5) next
        p <- plotly::add_trace(p, x = r$times[i], y = cumsum(P$y[i] * (1 + r$rrr) - 1 - r$cost_r), type = "scatter", mode = "lines", name = r$models[[k]], line = list(color = pal[[k]])) }
      lay(p, sprintf("%s: running result of the picked cases (R)", toupper(side_k())), xaxis = list(title = ""), yaxis = list(title = "Cumulative R")) })
    output$g_fold <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); P <- r$pred[[side_k()]]; f <- sort(unique(stats::na.omit(r$fold))); p <- plotly::plot_ly()
      for (k in names(r$models)) p <- plotly::add_trace(p, x = paste("Block", f), y = vapply(f, function(j) { v <- ml_auc(P[[k]][r$fold %in% j], P$y[r$fold %in% j]); if (is.null(v)) NA_real_ else v }, 0), type = "scatter", mode = "lines+markers", name = r$models[[k]], line = list(color = pal[[k]]), marker = list(color = pal[[k]]), showlegend = FALSE)
      lay(p, sprintf("%s: AUC in each tested block", toupper(side_k())), yaxis = list(title = "AUC"), xaxis = list(title = ""), shapes = list(list(type = "line", x0 = -0.5, x1 = length(f) - 0.5, y0 = 0.5, y1 = 0.5, line = list(dash = "dot", color = "#94a3b8")))) })
    output$g_stack <- plotly::renderPlotly({ r <- run(); if (is.null(r)) return(NULL); w <- r$stack_weights[[side_k()]]; if (is.null(w)) return(NULL)
      lay(plotly::plot_ly(x = unname(r$models[names(w)]), y = as.numeric(w), type = "bar", marker = list(color = unname(pal[names(w)]))), sprintf("%s: trust of the stacked ensemble in each model", toupper(side_k())), xaxis = list(title = ""), yaxis = list(title = "Weight"), showlegend = FALSE) })
    info <- function(...) tags$div(style = "font-size:12.5px; background:#fff; border:1px solid #cbd5e1; border-radius:8px; padding:6px 10px; margin-bottom:6px;", ...)
    output$fac_txt <- renderUI({ r <- run(); if (is.null(r)) return(cc_rec_note("Run the models first.")); f <- r$factor; if (is.null(f)) return(info(tags$b("Latent factor model: "), "no related market with enough candles was read, so there is no common factor."))
      info(tags$b(sprintf("Latent factor model: %.0f%% of this market's moves are shared with its related markets. ", f$r2)),
        sprintf("Over the last move measured, the common factor accounts for %+.2f%% and the market's own part for %+.2f%% (%.1f standard deviations). ", f$common_now, f$own_now, f$resid_z),
        tags$b(if (abs(f$resid_z) >= 2) "The market has moved on its own, away from its related markets: such moves often fade back, so be careful chasing it." else if (f$r2 >= 50) "The market is moving with its group: check the related markets before trading against them." else "The market mostly moves on its own: the related markets say little about it.")) })
    output$g_fac <- plotly::renderPlotly({ r <- run(); if (is.null(r) || is.null(r$factor)) return(NULL); f <- r$factor; nm <- names(f$loadings); nm[nm == "own"] <- "this market"
      p <- plotly::plot_ly(x = nm, y = as.numeric(f$loadings), type = "bar", name = "Weight in the common factor", marker = list(color = "#2563eb")); p <- plotly::add_trace(p, x = nm, y = as.numeric(f$cor), name = "Correlation with this market", marker = list(color = "#94a3b8"))
      lay(p, sprintf("Common factor: %.0f%% of all the moves", f$explained[1]), barmode = "group", xaxis = list(title = "")) })
    output$brk_txt <- renderUI({ r <- run(); if (is.null(r)) return(NULL); k <- r$breaks; if (is.null(k)) return(NULL); nb <- length(k$breaks)
      info(tags$b(sprintf("Structural breaks: %d change(s) of volatility found in %d candles. ", nb, k$n)),
        if (!nb) "The history behaves as one period, so the models' training data is consistent." else sprintf("The last one was %d candles ago, at %s UK; volatility since is %.0f%% of the period before. ", k$since, format(r$times[max(k$breaks)], "%d/%m %H:%M", tz = "Europe/London"), 100 * k$vol_now_vs_before),
        tags$b(if (nb && k$since < 300) "The market changed recently: the models learned mostly from the earlier behaviour, so trust their forecasts less until more candles build up." else if (nb) "Enough candles have built up since the last change for the models to have learned the present behaviour." else "")) })
    output$g_brk <- plotly::renderPlotly({ r <- run(); if (is.null(r) || is.null(r$breaks)) return(NULL); k <- r$breaks; sg <- k$segments; p <- plotly::plot_ly()
      for (i in seq_len(nrow(sg))) { j <- sg$from[i]:sg$to[i]; p <- plotly::add_trace(p, x = r$times[j], y = r$close[j], type = "scatter", mode = "lines", name = sprintf("Period %d: volatility %.3f%% per candle", i, sg$vol[i])) }
      lay(p, "Price, one colour per volatility period", xaxis = list(title = ""), yaxis = list(title = "")) })
    output$mine <- DT::renderDT({ r <- run(); m <- meta(); if (is.null(r) || is.null(store)) return(NULL); x <- ml_trades_check(tryCatch(store$current("trades"), error = function(e) NULL), r, m$epic)
      if (is.null(x)) return(tbl(data.frame(Note = sprintf("No closed Capital.com trade on %s in your records.", m$epic))))
      names(x) <- c("Entry (UK)", "Side", "Models' chance at entry", "Result (R)", "Outcome"); tbl(x) })
    invisible(list(run = run))
  })
}
