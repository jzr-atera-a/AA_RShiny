# Stand-in app for tab H: synthetic candles, no broker. Run: shiny::runApp(source("tests/harness_ml_app.R")$value, port = 8843)
suppressMessages({ library(shiny); library(shinydashboard) }); `%||%` <- function(x, y) if (is.null(x)) y else x
for (f in c("R/utils_cc_catalog.R", "R/utils_cc_api.R", "R/utils_cc_patterns.R", "R/utils_cc_records.R", "R/utils_cc_advice.R", "R/utils_ml.R", "modules/cc_trading_records.R", "modules/ml_lab.R")) source(f)
fake_bars <- function(epic, res, from, to) { set.seed(sum(utf8ToInt(epic))); N <- 1800; tm <- as.POSIXct("2026-10-01 00:00", tz = "UTC") + (1:N) * 900; if (epic == "NOPE") return(NULL)
  r <- rnorm(N, 0, 0.1) + 0.03 * sin((1:N) / 40); c0 <- 90 + cumsum(r); b <- data.frame(time = tm, open = c(90, c0[-N]), close = c0)
  b$high <- pmax(b$open, b$close) + abs(rnorm(N, 0, 0.05)); b$low <- pmin(b$open, b$close) - abs(rnorm(N, 0, 0.05)); b }
store <- cc_make_store(cc_mem_backend())
store$write("trades", data.frame(trade_id = "T1", epic = "OIL_BRENT", status = "CLOSED", direction = "BUY", entry_ts = as.POSIXct("2026-10-01 00:00", tz = "UTC") + 1500 * 900, entry_level = 90, exit_level = 91, stop_initial = 89.5, stringsAsFactors = FALSE))
client <- list(connected = function() TRUE, market = function(e) stop("no market in the stand-in"))
shinyApp(fluidPage(ml_lab_ui("ml")), function(input, output, session) ml_lab_server("ml", client, store, fetch_bars = fake_bars))
