# modules/weekly_activity_week2.R
# Covers every point in the Week 2 Activity Sheet: Fibonacci retracements/expansions
# (8 examples) and 14 named Price Patterns x hit-target/failed (28 examples) = 36 total.
# All charts use synthetic OHLC data — see R/utils_synthetic.R for the generation engine.

# ══════════════════════════════════════════════════════════════════════════
# FIBONACCI GENERATORS
# ══════════════════════════════════════════════════════════════════════════

# direction: "down" or "up" (the primary trend). touch_level: 0.5 or 0.618.
w2_fib_retracement <- function(direction, touch_level, seed) {
  set.seed(seed)
  down <- direction == "down"
  leg1 <- if (down) syn_path(26, start = 140, drift = -1.1, vol = 1, seed = seed)
          else syn_path(26, start = 100, drift = 1.1, vol = 1, seed = seed)
  
  leg_top <- max(leg1$Close[1], leg1$Close); leg_bottom <- min(leg1$Close)
  top <- if (down) leg1$Close[1] else tail(leg1$Close, 1)
  bottom <- if (down) tail(leg1$Close, 1) else leg1$Close[1]
  rng <- top - bottom
  
  fib_price <- if (down) bottom + rng * touch_level else top - rng * touch_level
  
  # Retrace toward the fib level, touch it, then resume the primary trend
  retr_target <- fib_price
  retr <- syn_path(14, start = tail(leg1$Close, 1), drift = ((retr_target - tail(leg1$Close, 1)) / 14), vol = 0.5, seed = seed + 30)
  cont_drift <- if (down) -1.0 else 1.0
  cont <- syn_path(18, start = tail(retr$Close, 1), drift = cont_drift, vol = 1, seed = seed + 60)
  
  df <- syn_concat(leg1, retr, cont)
  
  fib_levels <- c(0, 0.236, 0.382, 0.5, 0.618, 0.786, 1)
  shapes <- lapply(fib_levels, function(l) {
    y <- if (down) bottom + rng * l else top - rng * l
    col <- if (abs(l - touch_level) < 0.001) "#f39c12" else "#bdc3c7"
    syn_hline(df$Date[1], tail(df$Date, 1), y, col, if (abs(l - touch_level) < 0.001) "solid" else "dot",
              if (abs(l - touch_level) < 0.001) 2 else 1)
  })
  ann <- list(syn_tag(retr$Date[1], fib_price, paste0(touch_level * 100, "% Fib Touch \u2192 ", ifelse(down, "Downtrend", "Uptrend"), " Resumes"),
                       if (down) "#e74c3c" else "#27ae60", 10))
  
  title <- paste0(ifelse(down, "Downtrend", "Uptrend"), " Retracement to ", touch_level * 100,
                   "% Fibonacci, Then ", ifelse(down, "Continues Down", "Continues Up"))
  syn_chart(df, title, shapes, ann)
}

w2_fib_expansion <- function(direction, seed) {
  set.seed(seed)
  down <- direction == "down"
  legA <- if (down) syn_path(22, start = 130, drift = -1.1, vol = 1, seed = seed)
          else syn_path(22, start = 100, drift = 1.1, vol = 1, seed = seed)
  legA_size <- abs(legA$Close[1] - tail(legA$Close, 1))
  
  retr_drift <- if (down) 0.6 else -0.6
  retr <- syn_path(12, start = tail(legA$Close, 1), drift = retr_drift, vol = 0.6, seed = seed + 30)
  retr_end <- tail(retr$Close, 1)
  
  target_price <- if (down) retr_end - legA_size else retr_end + legA_size
  legB_drift <- if (down) -1.1 else 1.1
  legB <- syn_path(20, start = retr_end, drift = legB_drift * 1.05, vol = 1, seed = seed + 60)
  
  df <- syn_concat(legA, retr, legB)
  shapes <- list(
    syn_hline(retr$Date[1], tail(df$Date, 1), retr_end, "#7f8c8d", "dot", 1),
    syn_hline(legB$Date[1], tail(df$Date, 1), target_price, "#f39c12", "dash", 2)
  )
  ann <- list(syn_tag(legB$Date[round(nrow(legB) * 0.6)], target_price,
                       "100% Fib Expansion Target", "#f39c12", 10))
  title <- paste0(ifelse(down, "Downtrend", "Uptrend"), " — 100% Fibonacci Expansion of Prior ", ifelse(down, "Downward", "Upward"), " Leg")
  syn_chart(df, title, shapes, ann)
}

# ══════════════════════════════════════════════════════════════════════════
# PRICE PATTERN GENERATORS
# ══════════════════════════════════════════════════════════════════════════

# -- Triangles: symmetrical (with up/down context) and ascending --
w2_triangle <- function(kind, context, hit, seed) {
  set.seed(seed)
  n_lead <- 16
  lead <- if (context == "down") syn_path(n_lead, start = 140, drift = -1.0, vol = 1, seed = seed)
          else if (context == "up") syn_path(n_lead, start = 100, drift = 1.0, vol = 1, seed = seed)
          else syn_path(n_lead, start = 100, drift = 0.3, vol = 1, seed = seed)
  
  mid <- tail(lead$Close, 1)
  n_pat <- 24
  set.seed(seed + 10)
  pat_close <- numeric(n_pat)
  height0 <- 8
  for (i in seq_len(n_pat)) {
    frac <- i / n_pat
    if (kind == "symmetrical") { hi <- mid + height0 * (1 - 0.85 * frac); lo <- mid - height0 * (1 - 0.85 * frac) }
    else { hi <- mid + height0 * 0.35; lo <- mid - height0 * (1 - 0.85 * frac) }  # ascending: flat top, rising lows
    pat_close[i] <- runif(1, lo + 0.3, hi - 0.3)
  }
  pat <- data.frame(Date = seq(lead$Date[1], by = "day", length.out = n_pat),
                     Open = pat_close + rnorm(n_pat, 0, 0.3), Close = pat_close + rnorm(n_pat, 0, 0.3))
  pat$High <- pmax(pat$Open, pat$Close) + abs(rnorm(n_pat, 0.3, 0.15))
  pat$Low  <- pmin(pat$Open, pat$Close) - abs(rnorm(n_pat, 0.3, 0.15))
  pat$Date <- seq(as.Date("2024-03-01"), by = "day", length.out = n_pat)
  
  breakout_dir <- if (context == "down") -1 else 1
  target_dist <- height0 * 1.9
  breakout_price <- mid + breakout_dir * height0 * 0.35
  outc <- syn_outcome_tail(breakout_price, breakout_dir, target_dist, hit, seed + 200)
  
  df <- syn_concat(lead, pat, outc$df)
  
  # boundary lines over the pattern segment
  x0 <- pat$Date[1]; x1 <- pat$Date[n_pat]
  if (kind == "symmetrical") {
    shapes <- list(
      syn_line(x0, x1, mid + height0, mid + height0 * 0.15, "#e67e22", "solid", 2),
      syn_line(x0, x1, mid - height0, mid - height0 * 0.15, "#e67e22", "solid", 2)
    )
  } else {
    shapes <- list(
      syn_line(x0, x1, mid + height0 * 0.35, mid + height0 * 0.35, "#e67e22", "solid", 2),
      syn_line(x0, x1, mid - height0, mid - height0 * 0.15, "#e67e22", "solid", 2)
    )
  }
  shapes[[length(shapes)+1]] <- syn_hline(outc$df$Date[1], tail(df$Date,1), outc$target_price, "#f39c12", "dash", 1.5)
  ann <- list(syn_tag(outc$df$Date[1], breakout_price, ifelse(hit, "Breakout \u2192 Target Hit", "Breakout \u2192 Target Missed"),
                       ifelse(hit, "#27ae60", "#e74c3c"), 10))
  
  label <- if (kind == "symmetrical") paste0("Symmetrical Triangle in a ", ifelse(context == "down", "Downtrend", "Uptrend"))
           else "Ascending Triangle"
  syn_chart(df, paste0(label, " — ", ifelse(hit, "Hit Target", "Failed to Reach Target")), shapes, ann)
}

# -- Wedges: rising/falling, each with up/down context --
w2_wedge <- function(kind, context, hit, seed) {
  set.seed(seed)
  rising <- kind == "rising"
  lead <- if (context == "down") syn_path(14, start = 140, drift = -1.0, vol = 1, seed = seed)
          else syn_path(14, start = 100, drift = 1.0, vol = 1, seed = seed)
  mid <- tail(lead$Close, 1)
  
  n_pat <- 22
  set.seed(seed + 10)
  width0 <- 7
  pat_close <- numeric(n_pat)
  for (i in seq_len(n_pat)) {
    frac <- i / n_pat
    slope <- if (rising) 0.35 else -0.35
    center <- mid + slope * frac * 12
    half_w <- width0 * (1 - 0.75 * frac)
    pat_close[i] <- center + runif(1, -half_w, half_w) * 0.5
  }
  pat <- data.frame(Open = pat_close + rnorm(n_pat, 0, 0.3), Close = pat_close + rnorm(n_pat, 0, 0.3))
  pat$High <- pmax(pat$Open, pat$Close) + abs(rnorm(n_pat, 0.3, 0.15))
  pat$Low  <- pmin(pat$Open, pat$Close) - abs(rnorm(n_pat, 0.3, 0.15))
  pat$Date <- seq(as.Date("2024-03-01"), by = "day", length.out = n_pat)
  
  # Wedges typically break AGAINST their own slope direction
  breakout_dir <- if (rising) -1 else 1
  target_dist <- width0 * 1.7
  final_center <- mid + (if (rising) 0.35 else -0.35) * 12
  breakout_price <- final_center
  outc <- syn_outcome_tail(breakout_price, breakout_dir, target_dist, hit, seed + 200)
  
  df <- syn_concat(lead, pat, outc$df)
  x0 <- pat$Date[1]; x1 <- pat$Date[n_pat]
  slope_dir <- if (rising) 0.35 else -0.35
  upper0 <- mid + width0; upper1 <- mid + slope_dir * 12 + width0 * 0.25
  lower0 <- mid - width0; lower1 <- mid + slope_dir * 12 - width0 * 0.25
  shapes <- list(
    syn_line(x0, x1, upper0, upper1, "#9b59b6", "solid", 2),
    syn_line(x0, x1, lower0, lower1, "#9b59b6", "solid", 2),
    syn_hline(outc$df$Date[1], tail(df$Date,1), outc$target_price, "#f39c12", "dash", 1.5)
  )
  ann <- list(syn_tag(outc$df$Date[1], breakout_price, ifelse(hit, "Breakout \u2192 Target Hit", "Breakout \u2192 Target Missed"),
                       ifelse(hit, "#27ae60", "#e74c3c"), 10))
  
  label <- paste0(ifelse(rising, "Rising", "Falling"), " Wedge in a ", ifelse(context == "down", "Downtrend", "Uptrend"))
  syn_chart(df, paste0(label, " — ", ifelse(hit, "Hit Target", "Failed to Reach Target")), shapes, ann)
}

# -- Flags & Pennant: sharp pole then a small consolidation, breakout continues the pole --
w2_flag_pennant <- function(kind, hit, seed) {
  set.seed(seed)
  bullish <- kind == "bull_flag"
  pole_drift <- if (bullish) 2.2 else -2.2
  pole <- syn_path(10, start = if (bullish) 95 else 135, drift = pole_drift, vol = 1.1, seed = seed)
  pole_size <- abs(tail(pole$Close,1) - pole$Close[1])
  mid <- tail(pole$Close, 1)
  
  n_pat <- 14
  set.seed(seed + 10)
  cons_drift <- if (kind == "bull_flag") -0.25 else if (kind == "bear_flag") 0.25 else 0
  cons <- syn_path(n_pat, start = mid, drift = cons_drift, vol = 0.6, seed = seed + 10)
  
  breakout_dir <- if (bullish) 1 else -1
  outc <- syn_outcome_tail(tail(cons$Close,1), breakout_dir, pole_size * 0.95, hit, seed + 200)
  
  df <- syn_concat(pole, cons, outc$df)
  x0 <- cons$Date[1]; x1 <- cons$Date[n_pat]
  width0 <- max(1.5, sd(cons$Close) * 2.2)
  if (kind == "pennant") {
    shapes <- list(
      syn_line(x0, x1, mid + width0, mid + width0 * 0.15, "#3498db", "solid", 2),
      syn_line(x0, x1, mid - width0, mid - width0 * 0.15, "#3498db", "solid", 2)
    )
  } else {
    slope <- cons_drift
    shapes <- list(
      syn_line(x0, x1, mid + width0, mid + width0 + slope * n_pat, "#3498db", "solid", 2),
      syn_line(x0, x1, mid - width0, mid - width0 + slope * n_pat, "#3498db", "solid", 2)
    )
  }
  shapes[[length(shapes)+1]] <- syn_hline(outc$df$Date[1], tail(df$Date,1), outc$target_price, "#f39c12", "dash", 1.5)
  ann <- list(syn_tag(outc$df$Date[1], tail(cons$Close,1), ifelse(hit, "Breakout \u2192 Target Hit", "Breakout \u2192 Target Missed"),
                       ifelse(hit, "#27ae60", "#e74c3c"), 10))
  
  label <- switch(kind, bull_flag = "Bullish Flag", bear_flag = "Bearish Flag", pennant = "Bearish Pennant")
  syn_chart(df, paste0(label, " — ", ifelse(hit, "Hit Target", "Failed to Reach Target")), shapes, ann)
}

# -- Head & Shoulders (regular / inverse) --
w2_hs <- function(inverse, hit, seed) {
  set.seed(seed)
  lead <- if (inverse) syn_path(14, start = 130, drift = -0.9, vol = 1, seed = seed)
          else syn_path(14, start = 100, drift = 0.9, vol = 1, seed = seed)
  base <- tail(lead$Close, 1)
  sgn <- if (inverse) -1 else 1  # peaks point down (inverse) or up (regular)
  
  shoulder1 <- syn_path(8, start = base, drift = sgn * 1.0, vol = 0.5, seed = seed + 5)
  s1_peak <- tail(shoulder1$Close, 1)
  dip1 <- syn_path(6, start = s1_peak, drift = -sgn * 0.9, vol = 0.4, seed = seed + 15)
  neckline_l <- tail(dip1$Close, 1)
  head <- syn_path(8, start = neckline_l, drift = sgn * 1.6, vol = 0.5, seed = seed + 25)
  h_peak <- tail(head$Close, 1)
  dip2 <- syn_path(6, start = h_peak, drift = -sgn * 1.5, vol = 0.4, seed = seed + 35)
  neckline_r <- tail(dip2$Close, 1)
  shoulder2 <- syn_path(8, start = neckline_r, drift = sgn * 0.95, vol = 0.5, seed = seed + 45)
  s2_peak <- tail(shoulder2$Close, 1)
  down2 <- syn_path(6, start = s2_peak, drift = -sgn * 1.5, vol = 0.5, seed = seed + 55)
  
  neckline <- mean(c(neckline_l, neckline_r))
  head_dist <- abs(h_peak - neckline)
  breakout_price <- tail(down2$Close, 1)
  breakout_dir <- -sgn
  outc <- syn_outcome_tail(breakout_price, breakout_dir, head_dist, hit, seed + 200)
  
  df <- syn_concat(lead, shoulder1, dip1, head, dip2, shoulder2, down2, outc$df)
  neck_x0 <- dip1$Date[nrow(dip1)]; neck_x1 <- dip2$Date[nrow(dip2)]
  # find those dates in df for the hline span (use full width for clarity)
  shapes <- list(
    syn_hline(df$Date[1], tail(df$Date,1), neckline, "#9b59b6", "solid", 2),
    syn_hline(outc$df$Date[1], tail(df$Date,1), outc$target_price, "#f39c12", "dash", 1.5)
  )
  ann <- list(
    syn_tag(head$Date[round(nrow(head)/2)], h_peak, "Head", "#002C3C", 10),
    syn_tag(outc$df$Date[1], breakout_price, ifelse(hit, "Neckline Break \u2192 Target Hit", "Neckline Break \u2192 Target Missed"),
            ifelse(hit, "#27ae60", "#e74c3c"), 10)
  )
  label <- if (inverse) "Inverse Head & Shoulders" else "Head & Shoulders"
  syn_chart(df, paste0(label, " — ", ifelse(hit, "Hit Target", "Failed to Reach Target")), shapes, ann)
}

# -- Double Top / Double Bottom --
w2_double <- function(kind, hit, seed) {
  set.seed(seed)
  top <- kind == "top"
  lead <- if (top) syn_path(14, start = 100, drift = 0.9, vol = 1, seed = seed)
          else syn_path(14, start = 130, drift = -0.9, vol = 1, seed = seed)
  sgn <- if (top) 1 else -1
  peak1 <- syn_path(8, start = tail(lead$Close,1), drift = sgn * 1.1, vol = 0.5, seed = seed + 5)
  p1 <- tail(peak1$Close, 1)
  trough <- syn_path(10, start = p1, drift = -sgn * 1.3, vol = 0.5, seed = seed + 15)
  mid_level <- tail(trough$Close, 1)
  peak2 <- syn_path(8, start = mid_level, drift = sgn * 1.15, vol = 0.5, seed = seed + 25)
  p2 <- tail(peak2$Close, 1)
  # optional retest bounce back toward peak level before breaking down (double top only, per doc)
  retest <- syn_path(6, start = p2, drift = -sgn * 0.6, vol = 0.4, seed = seed + 35)
  
  height <- abs(p1 - mid_level)
  breakout_price <- tail(retest$Close, 1)
  breakout_dir <- -sgn
  outc <- syn_outcome_tail(breakout_price, breakout_dir, height, hit, seed + 200)
  
  df <- syn_concat(lead, peak1, trough, peak2, retest, outc$df)
  shapes <- list(
    syn_hline(trough$Date[nrow(trough)], tail(df$Date,1), mid_level, "#9b59b6", "solid", 2),
    syn_hline(outc$df$Date[1], tail(df$Date,1), outc$target_price, "#f39c12", "dash", 1.5)
  )
  ann <- list(
    syn_tag(peak1$Date[nrow(peak1)], p1, "Peak/Trough 1", "#002C3C", 9),
    syn_tag(peak2$Date[nrow(peak2)], p2, "Peak/Trough 2", "#002C3C", 9),
    syn_tag(outc$df$Date[1], breakout_price, ifelse(hit, "Breakdown \u2192 Target Hit", "Breakdown \u2192 Target Missed"),
            ifelse(hit, "#27ae60", "#e74c3c"), 10)
  )
  label <- if (top) "Double Top (with Retest)" else "Double Bottom"
  syn_chart(df, paste0(label, " — ", ifelse(hit, "Hit Target", "Failed to Reach Target")), shapes, ann)
}

# ══════════════════════════════════════════════════════════════════════════
# CANONICAL SECTIONS
# ══════════════════════════════════════════════════════════════════════════

w2_sections <- function() {
  fib_specs <- list(
    list(id = "fib1", title = "Downtrend Retracement to 50% Fib", desc = "Retraces to the 50% Fibonacci level, then the downtrend resumes.",
         gen = function() w2_fib_retracement("down", 0.5, 301)),
    list(id = "fib2", title = "Downtrend Retracement to 61.8% Fib", desc = "Retraces to the 61.8% Fibonacci level, then the downtrend resumes.",
         gen = function() w2_fib_retracement("down", 0.618, 302)),
    list(id = "fib3", title = "Uptrend Retracement to 50% Fib", desc = "Retraces to the 50% Fibonacci level, then the uptrend resumes.",
         gen = function() w2_fib_retracement("up", 0.5, 303)),
    list(id = "fib4", title = "Uptrend Retracement to 61.8% Fib", desc = "Retraces to the 61.8% Fibonacci level, then the uptrend resumes.",
         gen = function() w2_fib_retracement("up", 0.618, 304)),
    list(id = "fib5", title = "Downtrend — 100% Fib Expansion (Ex. 1)", desc = "100% expansion of the prior downward leg, projected from the retracement high.",
         gen = function() w2_fib_expansion("down", 305)),
    list(id = "fib6", title = "Downtrend — 100% Fib Expansion (Ex. 2)", desc = "A second downtrend expansion example.",
         gen = function() w2_fib_expansion("down", 306)),
    list(id = "fib7", title = "Uptrend — 100% Fib Expansion (Ex. 1)", desc = "100% expansion of the prior upward leg, projected from the retracement low.",
         gen = function() w2_fib_expansion("up", 307)),
    list(id = "fib8", title = "Uptrend — 100% Fib Expansion (Ex. 2)", desc = "A second uptrend expansion example.",
         gen = function() w2_fib_expansion("up", 308))
  )
  
  pp_defs <- list(
    list(id = "pp_symdown", gen = function(hit, seed) w2_triangle("symmetrical", "down", hit, seed), label = "Symmetrical Triangle in a Downtrend"),
    list(id = "pp_symup",   gen = function(hit, seed) w2_triangle("symmetrical", "up",   hit, seed), label = "Symmetrical Triangle in an Uptrend"),
    list(id = "pp_asc",     gen = function(hit, seed) w2_triangle("ascending", "flat",   hit, seed), label = "Ascending Triangle"),
    list(id = "pp_ihs",     gen = function(hit, seed) w2_hs(TRUE, hit, seed),                        label = "Inverse Head & Shoulders"),
    list(id = "pp_dtop",    gen = function(hit, seed) w2_double("top", hit, seed),                   label = "Double Top (with Retest)"),
    list(id = "pp_bearflag",gen = function(hit, seed) w2_flag_pennant("bear_flag", hit, seed),       label = "Bearish Flag"),
    list(id = "pp_bullflag",gen = function(hit, seed) w2_flag_pennant("bull_flag", hit, seed),       label = "Bullish Flag"),
    list(id = "pp_pennant", gen = function(hit, seed) w2_flag_pennant("pennant", hit, seed),         label = "Bearish Pennant"),
    list(id = "pp_rwdown",  gen = function(hit, seed) w2_wedge("rising", "down", hit, seed),         label = "Rising Wedge in a Downtrend"),
    list(id = "pp_rwup",    gen = function(hit, seed) w2_wedge("rising", "up",   hit, seed),         label = "Rising Wedge in an Uptrend"),
    list(id = "pp_fwdown",  gen = function(hit, seed) w2_wedge("falling", "down",hit, seed),         label = "Falling Wedge in a Downtrend"),
    list(id = "pp_fwup",    gen = function(hit, seed) w2_wedge("falling", "up",  hit, seed),         label = "Falling Wedge in an Uptrend"),
    list(id = "pp_hs",      gen = function(hit, seed) w2_hs(FALSE, hit, seed),                       label = "Head & Shoulders"),
    list(id = "pp_dbot",    gen = function(hit, seed) w2_double("bottom", hit, seed),                label = "Double Bottom")
  )
  pp_specs <- list()
  seed_i <- 400
  for (pd in pp_defs) {
    seed_i <- seed_i + 1
    local({
      d <- pd; s1 <- seed_i
      pp_specs[[length(pp_specs) + 1]] <<- list(
        id = paste0(d$id, "_hit"), title = paste0(d$label, " — Hit Target"),
        desc = "Pattern breaks out and reaches its measured-move price objective (MPO).",
        gen = function() d$gen(TRUE, s1)
      )
      pp_specs[[length(pp_specs) + 1]] <<- list(
        id = paste0(d$id, "_miss"), title = paste0(d$label, " — Failed to Reach Target"),
        desc = "Pattern breaks out but fails to reach its measured-move price objective.",
        gen = function() d$gen(FALSE, s1 + 500)
      )
    })
  }
  
  list(
    list(title = "Fibonacci", specs = fib_specs),
    list(title = "Price Patterns", specs = pp_specs)
  )
}

# ══════════════════════════════════════════════════════════════════════════
# UI / SERVER
# ══════════════════════════════════════════════════════════════════════════

weekly_activity_week2_ui <- function(id) {
  ns <- NS(id)
  sections <- w2_sections()
  
  tagList(
    fluidRow(
      box(
        width = 12, solidHeader = FALSE, status = "warning",
        div(style = "display:flex; align-items:flex-start; gap:14px;",
          icon("circle-info", style = "font-size:22px; color:#e67e22; margin-top:2px; flex-shrink:0;"),
          div(
            tags$strong("About this tab:", style = "color:#7d4a00; font-size:14px;"),
            tags$p(paste0(
              "Every chart below uses simulated OHLC data, deterministically generated to exhibit the exact ",
              "feature requested in the Week 2 Activity Sheet — Fibonacci retracements/expansions and 14 named ",
              "Price Patterns, each with a target-hit and a target-missed example (36 examples in total). This ",
              "is for practising pattern recognition, not a claim about real market history."
            ), style = "font-size:13px; color:#5a3500; margin:4px 0 0 0; line-height:1.6;")
          )
        )
      )
    ),
    weekly_download_ui(ns),
    lapply(sections, function(sec) weekly_grid_ui(ns, sec$specs, sec$title))
  )
}

weekly_activity_week2_server <- function(id, data_manager) {
  moduleServer(id, function(input, output, session) {
    sections <- w2_sections()
    for (sec in sections) weekly_grid_server(output, sec$specs)
    weekly_download_server(output, "Week 2 Activity Sheet", sections, "week2_activity")
    session$onSessionEnded(function() {})
  })
}
