# R/utils_synthetic.R
# Synthetic OHLC pattern-generation engine for the Weekly Activity tabs.
#
# The activity sheets ask for ~90 distinct, precisely-defined chart examples (a
# CONFIRMED vs FAILED Shooting Star, a Double Top that hits vs misses its measured-move
# target, an RSI bullish divergence, etc.). Hunting for a real historical instance of
# every exact combination isn't practical, so every chart here is built from a
# deterministically-seeded synthetic OHLC series shaped to exhibit the named feature.
# This is clearly simulated data for illustration, not a live market claim.
#
# Design: a small set of reusable PRIMITIVES (trend legs, candle shape injection,
# geometric pattern builders) plus a generic "spec list -> grid of boxes" renderer,
# so ~90 examples are built from a manageable number of parameterized functions
# rather than ~90 fully bespoke ones.

# ══════════════════════════════════════════════════════════════════════════
# PRIMITIVES
# ══════════════════════════════════════════════════════════════════════════

# A random-walk-with-drift base OHLC path.
syn_path <- function(n, start = 100, drift = 0, vol = 1, seed = 1) {
  set.seed(seed)
  close <- numeric(n)
  close[1] <- start
  for (i in 2:n) close[i] <- max(close[i - 1] + drift + rnorm(1, 0, vol), 0.5)
  open <- c(start, close[-n]) + rnorm(n, 0, vol * 0.15)
  high <- pmax(open, close) + abs(rnorm(n, vol * 0.5, vol * 0.25))
  low  <- pmin(open, close) - abs(rnorm(n, vol * 0.5, vol * 0.25))
  data.frame(
    Date = seq(as.Date("2024-01-01"), by = "day", length.out = n),
    Open = open, High = high, Low = low, Close = close
  )
}

# Overwrites a single bar's OHLC to match a named candlestick shape. base = reference
# price level for that bar; vol scales body/wick sizes; up = TRUE colours it bullish.
syn_candle <- function(base, vol, type, up = TRUE) {
  b <- vol * 1.1  # typical body size
  switch(type,
    doji_long_legged = list(o = base, c = base + 0.05 * vol, h = base + 2.2 * vol, l = base - 2.2 * vol),
    doji_dragonfly    = list(o = base, c = base + 0.03 * vol, h = base + 0.15 * vol, l = base - 2.6 * vol),
    hammer            = list(o = base, c = base + b, h = base + b + 0.15 * vol, l = base - 2.4 * vol),
    inverted_hammer   = list(o = base, c = base + b, h = base + 2.5 * vol, l = base - 0.15 * vol),
    shooting_star     = list(o = base + b, c = base, h = base + b + 2.4 * vol, l = base - 0.15 * vol),
    hanging_man       = list(o = base + b, c = base, h = base + b + 0.15 * vol, l = base - 2.4 * vol),
    marubozu_bull     = list(o = base, c = base + 3 * vol, h = base + 3 * vol + 0.05 * vol, l = base - 0.05 * vol),
    marubozu_bear     = list(o = base + 3 * vol, c = base, h = base + 3 * vol + 0.05 * vol, l = base - 0.05 * vol),
    spinning_top      = list(o = base, c = base + 0.3 * vol, h = base + 1.5 * vol, l = base - 1.5 * vol),
    list(o = base, c = base + b, h = base + b + 0.3 * vol, l = base - 0.3 * vol)
  )
}

# plot_ly candlestick + optional shapes/annotations, common layout.
# Builds a reusable CHART SPEC (not a plotly object) — every pattern generator ends by
# calling this. The same spec drives both the interactive plotly view (spec_to_plotly)
# and the static base-R render used for PDF export (base_candlestick_plot), so nothing
# has to be built twice. `indicator`, if supplied, is a secondary series (RSI/Stochastic/
# MACD/OBV) rendered as a sub-panel below price on-screen, and as a compressed inset at
# the bottom of the same panel in the static PDF render:
#   indicator = list(dates=, values=, label=, hlines=c(70,30), color="#3498db",
#                     values2=NULL, label2=NULL, color2=NULL, yrange=c(0,100))
syn_chart <- function(df, title, shapes = list(), annotations = list(), yrange = NULL, indicator = NULL) {
  list(df = df, title = title, shapes = shapes, annotations = annotations, yrange = yrange, indicator = indicator)
}

# Interactive plotly candlestick chart from a spec (used for on-screen rendering).
# Uses a stacked subplot (price on top, indicator below) when spec$indicator is present.
spec_to_plotly <- function(spec) {
  p1 <- plot_ly(spec$df, x = ~Date, type = "candlestick", open = ~Open, high = ~High, low = ~Low, close = ~Close,
                increasing = list(line = list(color = "#27ae60")),
                decreasing = list(line = list(color = "#e74c3c")), showlegend = FALSE) %>%
    layout(xaxis = list(title = "", rangeslider = list(visible = FALSE)),
           yaxis = list(title = "Price (simulated)", range = spec$yrange),
           shapes = spec$shapes, annotations = spec$annotations)
  
  if (is.null(spec$indicator)) {
    return(p1 %>% layout(title = list(text = spec$title, font = list(size = 13)),
                          plot_bgcolor = "white", paper_bgcolor = "white", margin = list(t = 40)))
  }
  
  ind <- spec$indicator
  p2 <- plot_ly(x = ind$dates, y = ind$values, type = "scatter", mode = "lines", name = ind$label,
                line = list(color = ind$color %||% "#3498db", width = 2), showlegend = FALSE)
  if (!is.null(ind$values2)) {
    p2 <- p2 %>% add_trace(x = ind$dates, y = ind$values2, type = "scatter", mode = "lines",
                            name = ind$label2, line = list(color = ind$color2 %||% "#e67e22", width = 1.5))
  }
  ind_shapes <- list()
  if (!is.null(ind$hlines)) {
    for (hl in ind$hlines) {
      ind_shapes[[length(ind_shapes) + 1]] <- list(
        type = "line", x0 = min(ind$dates), x1 = max(ind$dates), y0 = hl, y1 = hl, xref = "x2", yref = "y2",
        line = list(color = "#bdc3c7", width = 1, dash = "dash")
      )
    }
  }
  p2 <- p2 %>% layout(yaxis = list(title = ind$label, range = ind$yrange), xaxis = list(title = ""))
  
  subplot(p1, p2, nrows = 2, heights = c(0.65, 0.35), shareX = TRUE, titleY = TRUE) %>%
    layout(title = list(text = spec$title, font = list(size = 13)),
           shapes = c(spec$shapes, ind_shapes), annotations = spec$annotations,
           plot_bgcolor = "white", paper_bgcolor = "white", margin = list(t = 40), showlegend = FALSE)
}

# Static base-R candlestick render from a spec (used for PDF export — deliberately
# dependency-free: no webshot2/Chromium, no kaleido/Python, just base graphics, so it
# works on any plain R server without extra system dependencies).
base_candlestick_plot <- function(spec, caption = NULL) {
  df <- spec$df
  n <- nrow(df)
  x <- seq_len(n)
  price_yr <- if (!is.null(spec$yrange)) spec$yrange else range(c(df$Low, df$High), na.rm = TRUE)
  price_pad <- diff(price_yr) * 0.08
  price_yr <- c(price_yr[1] - price_pad, price_yr[2] + price_pad)
  
  has_ind <- !is.null(spec$indicator)
  # Reserve the bottom 26% of the panel for the indicator inset when present.
  if (has_ind) {
    band_h <- diff(price_yr) * 0.35
    yr <- c(price_yr[1] - band_h, price_yr[2])
  } else {
    yr <- price_yr
  }
  
  date_to_idx <- function(d) { idx <- match(d, df$Date); ifelse(is.na(idx), NA, idx) }
  lty_map <- function(dash) {
    if (is.null(dash)) return(1)
    if (dash == "dash") return(2) else if (dash == "dot") return(3) else return(1)
  }
  
  par(mar = c(1.2, 1.2, 2.4, 0.6))
  plot(x, df$Close, type = "n", xlim = c(0.5, n + 0.5), ylim = yr,
       xaxt = "n", yaxt = "n", xlab = "", ylab = "",
       main = spec$title, cex.main = 0.65, font.main = 2, col.main = "#002C3C")
  box(col = "#cccccc")
  
  up <- df$Close >= df$Open
  col_up <- "#27ae60"; col_down <- "#e74c3c"
  bar_col <- ifelse(up, col_up, col_down)
  segments(x, df$Low, x, df$High, col = bar_col, lwd = 1)
  body_lo <- pmin(df$Open, df$Close); body_hi <- pmax(df$Open, df$Close)
  w <- max(0.28, min(0.42, 18 / n))
  rect(x - w, body_lo, x + w, body_hi, col = bar_col, border = bar_col)
  
  for (sh in spec$shapes) {
    x0i <- date_to_idx(sh$x0); x1i <- date_to_idx(sh$x1)
    if (is.na(x0i)) x0i <- 1
    if (is.na(x1i)) x1i <- n
    segments(x0i, sh$y0, x1i, sh$y1, col = sh$line$color,
             lwd = max(1, (sh$line$width %||% 1.5) * 0.8), lty = lty_map(sh$line$dash))
  }
  
  for (an in spec$annotations) {
    xi <- date_to_idx(an$x)
    if (is.na(xi)) xi <- round(n * 0.15)
    lbl <- gsub("<b>|</b>", "", an$text)
    txt_col <- if (!is.null(an$font) && !is.null(an$font$color)) an$font$color else "#002C3C"
    text(xi, an$y, labels = lbl, col = txt_col, cex = 0.42, pos = 3, offset = 0.2, font = 2)
  }
  
  if (has_ind) {
    ind <- spec$indicator
    band_lo <- yr[1]; band_hi <- price_yr[1]
    rescale <- function(v) {
      rng <- ind$yrange %||% range(v, na.rm = TRUE)
      band_lo + (v - rng[1]) / diff(rng) * (band_hi - band_lo)
    }
    abline(h = band_hi, col = "#dddddd", lwd = 0.6)
    ind_x <- date_to_idx(ind$dates)
    ind_y <- rescale(ind$values)
    lines(ind_x, ind_y, col = ind$color %||% "#3498db", lwd = 1.2)
    if (!is.null(ind$values2)) lines(ind_x, rescale(ind$values2), col = ind$color2 %||% "#e67e22", lwd = 1)
    if (!is.null(ind$hlines)) {
      for (hl in ind$hlines) abline(h = rescale(hl), col = "#bbbbbb", lty = 2, lwd = 0.6)
    }
    text(1, band_lo + (band_hi - band_lo) * 0.5, labels = ind$label, col = "#666666", cex = 0.35, pos = 4, font = 3)
  }
  
  if (!is.null(caption)) {
    mtext(caption, side = 1, line = 0.3, cex = 0.36, col = "#666666")
  }
}

# Exports a full set of sections (each a named list of specs) to a multi-page, portrait
# A4 PDF. 4 charts per page (2x2), each with its title baked into the panel and its
# activity-sheet description as a one-line caption underneath. A section header prints
# at the top of every page that section spans. No external rendering dependencies.
export_weekly_pdf <- function(file, week_title, sections) {
  grDevices::pdf(file, width = 8.27, height = 11.69, onefile = TRUE)
  on.exit(grDevices::dev.off(), add = TRUE)
  
  per_page <- 4
  first_page <- TRUE
  
  for (section in sections) {
    specs <- section$specs
    n <- length(specs)
    if (n == 0) next
    n_pages <- ceiling(n / per_page)
    
    for (pg in seq_len(n_pages)) {
      i0 <- (pg - 1) * per_page + 1
      i1 <- min(pg * per_page, n)
      page_specs <- specs[i0:i1]
      
      graphics::par(mfrow = c(2, 2), oma = c(0, 0, 3.2, 0))
      for (s in page_specs) {
        cs <- s$gen()
        base_candlestick_plot(cs, caption = s$desc)
      }
      if (length(page_specs) < per_page) {
        for (k in seq_len(per_page - length(page_specs))) { graphics::plot.new() }
      }
      graphics::mtext(paste0(week_title, "  \u2014  ", section$title,
                              if (n_pages > 1) paste0("  (page ", pg, " of ", n_pages, ")") else ""),
                       outer = TRUE, cex = 1.0, font = 2, col = "#002C3C", line = 1)
      first_page <- FALSE
    }
  }
}

`%||%` <- function(x, y) if (is.null(x)) y else x

syn_line <- function(x0, x1, y0, y1, color = "#f39c12", dash = "solid", width = 2) {
  list(type = "line", x0 = x0, x1 = x1, y0 = y0, y1 = y1,
       line = list(color = color, width = width, dash = dash))
}

syn_hline <- function(x0, x1, y, color = "#7f8c8d", dash = "dash", width = 1.5) {
  syn_line(x0, x1, y, y, color, dash, width)
}

syn_label <- function(x, y, text, color = "#002C3C", size = 11, ay = -20) {
  list(x = x, y = y, text = text, showarrow = TRUE, arrowhead = 2, arrowcolor = color,
       ax = 0, ay = ay, font = list(color = color, size = size),
       bgcolor = "rgba(255,255,255,0.85)", bordercolor = color, borderwidth = 1, borderpad = 3)
}

# Concatenates OHLC segments end-to-end, re-sequencing dates so each segment continues
# immediately after the previous one (segment 2+ don't need their own Date column set).
syn_concat <- function(...) {
  segs <- list(...)
  out <- segs[[1]]
  if (length(segs) > 1) {
    for (i in 2:length(segs)) {
      seg <- segs[[i]]
      seg$Date <- seq(max(out$Date) + 1, by = "day", length.out = nrow(seg))
      out <- dplyr::bind_rows(out, seg)
    }
  }
  out
}

# Shared "breakout + hit/miss target" tail used across chart-pattern generators:
# drifts price from the breakout point toward (hit=TRUE) or short of (hit=FALSE) a
# measured-move target the given distance away in the given direction (+1 up, -1 down).
syn_outcome_tail <- function(breakout_price, direction, target_distance, hit, seed, n = 16) {
  target_price <- breakout_price + direction * target_distance
  frac <- if (hit) 1.15 else 0.45
  drift <- direction * (target_distance / n) * frac
  vol <- max(0.15, target_distance / n * 0.35)
  tail_df <- syn_path(n, start = breakout_price, drift = drift, vol = vol, seed = seed)
  list(df = tail_df, target_price = target_price)
}

syn_tag <- function(x, y, text, color, size = 12) {
  list(x = x, y = y, text = paste0("<b>", text, "</b>"), showarrow = FALSE, yanchor = "bottom",
       font = list(color = color, size = size), bgcolor = "rgba(255,255,255,0.9)",
       bordercolor = color, borderwidth = 1, borderpad = 3)
}

# ══════════════════════════════════════════════════════════════════════════
# GENERIC "SPEC LIST -> 2-PER-ROW GRID" RENDERER (shared by all 3 weeks)
# ══════════════════════════════════════════════════════════════════════════

# specs: list of list(id=, title=, desc=, gen=function())
weekly_grid_ui <- function(ns, specs, section_title = NULL) {
  boxes <- lapply(specs, function(s) {
    column(6,
      box(
        title = s$title, status = "primary", solidHeader = TRUE, width = 12,
        withSpinner(plotlyOutput(ns(s$id), height = "360px")),
        tags$p(s$desc, style = "font-size:11.5px; color:#666; margin-top:8px; line-height:1.5;")
      )
    )
  })
  # pair into rows of 2
  rows <- list()
  for (i in seq(1, length(boxes), by = 2)) {
    pair <- if (i + 1 <= length(boxes)) list(boxes[[i]], boxes[[i + 1]]) else list(boxes[[i]])
    rows[[length(rows) + 1]] <- do.call(fluidRow, pair)
  }
  tagList(
    if (!is.null(section_title)) tags$h4(section_title, style = "color:#002C3C; margin:18px 0 10px 0;"),
    rows
  )
}

# Reusable "Download PDF" button + status line, placed once at the top of each week's tab.
weekly_download_ui <- function(ns) {
  fluidRow(
    box(
      width = 12, solidHeader = FALSE, status = "primary",
      div(style = "display:flex; align-items:center; gap:16px; flex-wrap:wrap;",
          downloadButton(ns("downloadPdf"), "Download All Visualisations (PDF)", class = "btn-primary"),
          tags$span("Exports every chart on this tab to a multi-page, print-ready A4 PDF (4 charts per page).",
                    style = "font-size:12px; color:#666;")
      )
    )
  )
}

weekly_grid_server <- function(output, specs) {
  for (s in specs) {
    local({
      spec <- s
      output[[spec$id]] <- renderPlotly({ spec_to_plotly(spec$gen()) })
    })
  }
}

# Wires up the shared "Download PDF" button against a week's full section list
# (list of list(title=, specs=list(list(id=,gen=,desc=), ...))).
weekly_download_server <- function(output, week_title, sections, filename_prefix) {
  output$downloadPdf <- downloadHandler(
    filename = function() paste0(filename_prefix, "_", format(Sys.Date(), "%Y%m%d"), ".pdf"),
    content = function(file) {
      export_weekly_pdf(file, week_title, sections)
    },
    contentType = "application/pdf"
  )
}
