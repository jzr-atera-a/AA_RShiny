# modules/Travel Planning/travel_itinerary_planner/server.R
# Travel Itinerary Planner Server Logic with Claude API
# CORRECTED VERSION: Includes map rendering, saving, and proper export functionality

travel_itinerary_planner_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    ns <- session$ns
    
    # ==================
    # Reactive Values
    # ==================
    rv <- reactiveValues(
      discovered_places = NULL,
      selected_places = character(0),
      generated_itinerary = NULL,
      places_data = NULL,
      itinerary_data = NULL,        # NEW: Structured itinerary from JSON
      map_data = NULL,              # NEW: Map-ready data
      selected_attraction = NULL,   # NEW: Currently selected marker
      map_image_path = NULL         # NEW: Saved map image path
    )
    
    # ==================
    # DATE HANDLING
    # ==================
    
    # Calculate duration when dates change
    observeEvent(input$trip_start_date, {
      if (!is.null(input$trip_end_date)) {
        duration <- as.numeric(difftime(input$trip_end_date, input$trip_start_date, units = "days")) + 1
        duration <- max(1, min(duration, 7))
        updateSliderInput(session, "num_days", value = duration)
      }
    })
    
    observeEvent(input$trip_end_date, {
      if (!is.null(input$trip_start_date)) {
        duration <- as.numeric(difftime(input$trip_end_date, input$trip_start_date, units = "days")) + 1
        duration <- max(1, min(duration, 7))
        updateSliderInput(session, "num_days", value = duration)
      }
    })
    
    # Display calculated duration
    output$duration_display <- renderText({
      if (!is.null(input$trip_start_date) && !is.null(input$trip_end_date)) {
        duration <- as.numeric(difftime(input$trip_end_date, input$trip_start_date, units = "days")) + 1
        duration <- max(1, min(duration, 7))
        start_str <- format(input$trip_start_date, "%b %d, %Y")
        end_str <- format(input$trip_end_date, "%b %d, %Y")
        paste0(" <strong style='color: #27ae60;'>", duration, " day", 
               if(duration != 1) "s" else "", 
               "</strong> (", start_str, " to ", end_str, ")")
      } else {
        " (Select dates to calculate)"
      }
    })
    
    # ==================
    # STEP 1: DISCOVER PLACES
    # ==================
    observeEvent(input$discover_places, {
      req(input$destination, input$num_places)
      
      # Show loading spinner
      shinyjs::hide("places_checkboxes", anim = TRUE)
      shinyjs::show("loading_spinner", anim = TRUE)
      output$discovery_status <- renderUI({
        tags$div(class = "alert alert-info",
                tags$strong("Status: "), "Discovering attractions in ", input$destination, "...")
      })
      
      tryCatch({
        # Build prompt for Claude
        prompt <- paste0(
          "Please provide the top ", input$num_places, " places to visit in ", input$destination, 
          " according to TripAdvisor and other reputable tourism sources.\n\n",
          "Format your response EXACTLY as follows - one place per line, numbered:\n",
          "1. Attraction Name (Category)\n",
          "2. Another Attraction (Category)\n",
          "... and so on\n\n",
          "Categories can be: Museum, Park, Landmark, Restaurant, Historical Site, Shopping, ",
          "Entertainment, Nature, Cultural Site, etc.\n\n",
          "Only provide the numbered list with no additional text or explanations."
        )
        
        # Call Claude API
        if (!is.null(api_manager)) {
          response <- api_manager$call_claude_api(prompt)
        } else {
          stop("API Manager not available. Please configure Claude API credentials first.")
        }
        
        # Parse response into places
        lines <- strsplit(response, "\n")[[1]]
        places_list <- grep("^\\d+\\.", lines, value = TRUE)
        places_list <- trimws(places_list)
        places_list <- places_list[places_list != ""]
        
        if (length(places_list) == 0) {
          stop("No places found in response. Please try again.")
        }
        
        # Store places data
        rv$places_data <- data.frame(
          id = seq_along(places_list),
          name = places_list,
          selected = FALSE,
          stringsAsFactors = FALSE
        )
        
        rv$discovered_places <- places_list
        rv$selected_places <- character(0)
        
        # Hide loading, show places
        shinyjs::hide("loading_spinner", anim = TRUE)
        shinyjs::show("places_checkboxes", anim = TRUE)
        
        output$discovery_status <- renderUI({
          tags$div(class = "alert alert-success",
                  tags$strong("✓ Success! "), "Found ", length(places_list), " attractions in ", 
                  input$destination, ". Select the ones you want to visit.")
        })
        
        # Render checkboxes
        output$places_checkboxes <- renderUI({
          if (is.null(rv$places_data)) return(NULL)
          
          lapply(1:nrow(rv$places_data), function(i) {
            div(
              style = "margin-bottom: 10px;",
              checkboxInput(ns(paste0("place_", i)), 
                          rv$places_data$name[i],
                          value = FALSE),
              tags$small(class = "text-muted", style = "margin-left: 20px;")
            )
          })
        })
        
      }, error = function(e) {
        shinyjs::hide("loading_spinner", anim = TRUE)
        output$discovery_status <- renderUI({
          tags$div(class = "alert alert-danger",
                  tags$strong("Error: "), e$message)
        })
        showNotification(paste("Error discovering places:", e$message), type = "error", duration = 10)
      })
    })
    
    # Update selected places count
    output$places_counter <- renderUI({
      if (is.null(rv$places_data)) {
        tags$span("No places selected")
      } else {
        selected_count <- sum(sapply(1:nrow(rv$places_data), function(i) {
          isTRUE(input[[paste0("place_", i)]])
        }))
        tags$span(selected_count, " of ", nrow(rv$places_data), " attractions selected")
      }
    })
    
    # Select/Deselect all
    observeEvent(input$select_all_places, {
      if (!is.null(rv$places_data)) {
        for (i in 1:nrow(rv$places_data)) {
          updateCheckboxInput(session, paste0("place_", i), value = TRUE)
        }
      }
    })
    
    observeEvent(input$deselect_all_places, {
      if (!is.null(rv$places_data)) {
        for (i in 1:nrow(rv$places_data)) {
          updateCheckboxInput(session, paste0("place_", i), value = FALSE)
        }
      }
    })
    
    # ==================
    # STEP 2: GENERATE ITINERARY
    # ==================
    observeEvent(input$generate_itinerary, {
      req(input$destination, input$num_days)
      
      # Get selected places
      if (!is.null(rv$places_data)) {
        selected_indices <- which(sapply(1:nrow(rv$places_data), function(i) {
          isTRUE(input[[paste0("place_", i)]])
        }))
        
        if (length(selected_indices) == 0) {
          showNotification("Please select at least one place to visit!", type = "warning")
          return()
        }
        
        selected_places_list <- rv$places_data$name[selected_indices]
      } else {
        showNotification("Please discover places first!", type = "warning")
        return()
      }
      
      # Show loading spinner
      shinyjs::show("itinerary_loading_spinner", anim = TRUE)
      shinyjs::hide("itinerary_content", anim = TRUE)
      output$itinerary_status <- renderUI({
        tags$div(class = "alert alert-info",
                tags$strong("Status: "), "Generating your personalized itinerary...")
      })
      
      tryCatch({
        # Build comprehensive prompt for itinerary generation
        selected_places_text <- paste(sprintf("- %s", selected_places_list), collapse = "\n")
        
        constraints_text <- if (input$constraints == "") {
          "No specific constraints."
        } else {
          paste("User constraints:\n", input$constraints)
        }
        
        # CORRECTED PROMPT: Now asks for JSON with coordinates
        prompt <- paste0(
          "Create a detailed ", input$num_days, "-day itinerary for visiting ", input$destination, ".\n\n",
          "TRIP DATES:\n",
          "- Start Date: ", format(input$trip_start_date, "%A, %B %d, %Y"), "\n",
          "- End Date: ", format(input$trip_end_date, "%A, %B %d, %Y"), "\n",
          "- Total Days: ", input$num_days, "\n\n",
          "SELECTED ATTRACTIONS (must include all of these):\n",
          selected_places_text, "\n\n",
          "TRIP PARAMETERS:\n",
          "- Location: ", input$destination, "\n",
          "- Daily start time: ", input$start_time, "\n",
          "- Daily end time: ", input$end_time, "\n\n",
          "CONSTRAINTS & PREFERENCES:\n", constraints_text, "\n\n",
          "RESPONSE FORMAT: You MUST provide ONLY valid JSON (no markdown, no explanation, no additional text):\n\n",
          "{\n",
          '  \"itinerary\": [\n',
          '    {\n',
          '      \"day\": 1,\n',
          '      \"day_label\": \"Day 1: Monday, September 15\",\n',
          '      \"activities\": [\n',
          '        {\n',
          '          \"order\": 1,\n',
          '          \"name\": \"Attraction Name\",\n',
          '          \"time_start\": \"09:00\",\n',
          '          \"time_end\": \"11:00\",\n',
          '          \"description\": \"Brief description of the attraction and what to do there\",\n',
          '          \"latitude\": 43.6426,\n',
          '          \"longitude\": -79.3871\n',
          '        }\n',
          '      ]\n',
          '    }\n',
          '  ]\n',
          "}\n\n",
          "REQUIREMENTS:\n",
          "1. Create a day-by-day breakdown for each day from ", format(input$trip_start_date, "%B %d"), " to ", format(input$trip_end_date, "%B %d"), "\n",
          "2. Include ALL selected attractions in the itinerary\n",
          "3. Include exact times for each activity (HH:MM format)\n",
          "4. Include realistic travel time between attractions\n",
          "5. Include 1-2 meal breaks per day\n",
          "6. Provide accurate coordinates for each attraction\n",
          "7. Format day_label as: 'Day N: Weekday, Month Date'\n",
          "8. Ensure times span from ", input$start_time, " to ", input$end_time, " daily\n",
          "9. Include helpful descriptions for each activity\n",
          "10. Valid JSON only - NO OTHER TEXT"
        )
        
        # Call Claude API
        if (!is.null(api_manager)) {
          itinerary_response <- api_manager$call_claude_api(prompt)
        } else {
          stop("API Manager not available. Please configure Claude API credentials first.")
        }
        
        # Parse JSON response
        cat("\n📍 GENERATING: Processing itinerary response...\n")
        
        # Extract JSON from response (handle markdown blocks)
        json_text <- itinerary_response
        
        # Remove markdown code blocks if present
        json_text <- gsub("```json\\n?", "", json_text)
        json_text <- gsub("```\\n?", "", json_text)
        json_text <- trimws(json_text)
        
        # Try to parse JSON
        tryCatch({
          parsed <- jsonlite::fromJSON(json_text)
          rv$itinerary_data <- parsed$itinerary
          
          cat("✅ JSON parsed successfully\n")
          cat("📊 Found ", length(rv$itinerary_data), " days with attractions\n")
          
          # Prepare map data from structured itinerary
          map_data <- data.frame()
          for (day_idx in seq_along(rv$itinerary_data)) {
            day_obj <- rv$itinerary_data[[day_idx]]
            day_num <- day_obj$day %||% day_idx
            
            for (act_idx in seq_along(day_obj$activities)) {
              activity <- day_obj$activities[[act_idx]]
              
              lat <- as.numeric(activity$latitude %||% 0)
              lon <- as.numeric(activity$longitude %||% 0)
              
              map_data <- rbind(map_data, data.frame(
                day = day_num,
                day_label = day_obj$day_label %||% paste0("Day ", day_num),
                order = activity$order %||% act_idx,
                name = activity$name %||% "Unnamed",
                time_start = activity$time_start %||% "00:00",
                time_end = activity$time_end %||% "00:00",
                description = activity$description %||% "",
                latitude = lat,
                longitude = lon,
                marker_label = paste0(activity$order %||% act_idx),
                stringsAsFactors = FALSE
              ))
            }
          }
          
          # Filter out entries without coordinates
          rv$map_data <- map_data[map_data$latitude != 0 & map_data$longitude != 0, ]
          
          if (nrow(rv$map_data) > 0) {
            cat("🗺️ Map data prepared: ", nrow(rv$map_data), " locations with coordinates\n")
          } else {
            cat("⚠️ Warning: No locations with coordinates found\n")
          }
          
          # Format itinerary for display
          itinerary_text <- ""
          for (day in rv$itinerary_data) {
            itinerary_text <- paste0(itinerary_text, "<h3 style='color: #27ae60; margin-top: 20px;'>", 
                                    day$day_label, "</h3>")
            
            for (activity in day$activities) {
              itinerary_text <- paste0(itinerary_text,
                "<div style='margin-left: 20px; margin-bottom: 15px;'>",
                "<strong>", activity$time_start, " - ", activity$time_end, ": ", 
                activity$name, "</strong><br/>",
                "<em>", activity$description, "</em><br/>",
                "<small style='color: #666;'>📍 ", round(activity$latitude, 4), ", ", 
                round(activity$longitude, 4), "</small>",
                "</div>"
              )
            }
          }
          
          rv$generated_itinerary <- itinerary_text
          
        }, error = function(e) {
          cat("⚠️ JSON parse error:", e$message, "\n")
          # Fallback: use plain text response
          rv$generated_itinerary <- paste0(
            "<div style='background-color: #fff3cd; padding: 15px; border-radius: 4px;'>",
            "Note: Received response in text format (JSON parsing failed)<br/><br/>",
            gsub("\\n", "<br/>", gsub("<", "&lt;", gsub(">", "&gt;", itinerary_response))),
            "</div>"
          )
          cat("✓ Fallback: Using plain text format\n")
        })
        
        # Hide loading, show content
        shinyjs::hide("itinerary_loading_spinner", anim = TRUE)
        shinyjs::show("itinerary_content", anim = TRUE)
        
        output$itinerary_html <- renderUI({
          HTML(paste0(
            "<div style='background-color: #f9f9f9; padding: 20px; border-radius: 4px; ",
            "border-left: 4px solid #27ae60;'>",
            rv$generated_itinerary,
            "</div>"
          ))
        })
        
        output$itinerary_status <- renderUI({
          tags$div(class = "alert alert-success",
                  tags$strong("✓ Itinerary Generated! "),
                  "Your ", input$num_days, "-day plan is ready. ",
                  "Review the map below, save the map image, then download your itinerary.",
                  style = "margin-top: 20px;")
        })
        
      }, error = function(e) {
        shinyjs::hide("itinerary_loading_spinner", anim = TRUE)
        output$itinerary_status <- renderUI({
          tags$div(class = "alert alert-danger",
                  tags$strong("Error: "), e$message)
        })
        cat("❌ Itinerary generation failed:", e$message, "\n")
        showNotification(paste("Error generating itinerary:", e$message), type = "error", duration = 10)
      })
    })
    
    # ==================
    # MAP RENDERING
    # ==================
    
    output$trip_map <- plotly::renderPlotly({
      req(rv$map_data)
      md <- rv$map_data
      
      cat("🗺️ MAP RENDER: Rendering", nrow(md), "attractions\n")
      
      if (nrow(md) == 0) {
        cat("⚠️ MAP: No location data available\n")
        return(plotly::plot_ly() %>% 
          plotly::layout(title = "No location data available"))
      }
      
      # Color palette for days
      day_colors <- c("#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8", "#F7DC6F", "#BB8FCE")
      
      # Create map
      p <- plotly::plot_ly(source = "trip_map_click")
      
      # Add markers for each activity
      for (day_val in unique(md$day)) {
        day_data <- md[md$day == day_val, ]
        day_color <- day_colors[(day_val - 1) %% length(day_colors) + 1]
        
        p <- p %>%
          plotly::add_trace(
            data = day_data,
            type = "scattermapbox",
            lon = ~longitude,
            lat = ~latitude,
            mode = "markers+text",
            text = ~marker_label,
            textposition = "middle center",
            textfont = list(color = "white", size = 14, family = "Arial Black"),
            marker = list(
              size = 35,
              color = day_color,
              opacity = 0.85,
              line = list(color = "white", width = 2)
            ),
            customdata = ~paste0(day, "|", order),
            hovertemplate = paste0(
              "<b>%{text}</b><br>",
              "Name: %{customdata}<br>",
              "Lat: %{lat}<br>",
              "Lon: %{lon}<extra></extra>"
            ),
            name = paste0("Day ", day_val),
            showlegend = TRUE
          )
      }
      
      # Get center coordinates
      center_lat <- mean(md$latitude, na.rm = TRUE)
      center_lon <- mean(md$longitude, na.rm = TRUE)
      
      # Calculate zoom level based on spread
      lat_range <- max(md$latitude) - min(md$latitude)
      lon_range <- max(md$longitude) - min(md$longitude)
      max_range <- max(lat_range, lon_range)
      zoom <- ifelse(max_range > 2, 11, ifelse(max_range > 0.5, 12, 13))
      
      p %>%
        plotly::layout(
          mapbox = list(
            style = "open-street-map",
            center = list(lon = center_lon, lat = center_lat),
            zoom = zoom
          ),
          hovermode = "closest",
          margin = list(l = 0, r = 0, t = 0, b = 0),
          showlegend = TRUE,
          legend = list(orientation = "v", x = 0.02, y = 0.98)
        ) %>%
        plotly::config(displaylogo = FALSE, responsive = TRUE)
    })
    
    # ==================
    # MAP CLICK HANDLER & ATTRACTION DETAILS
    # ==================
    
    observeEvent(plotly::event_data("plotly_click", source = "trip_map_click"), {
      click <- plotly::event_data("plotly_click", source = "trip_map_click")
      
      if (!is.null(click) && !is.null(click$key)) {
        # Extract marker info from key
        parts <- strsplit(click$key, "_")[[1]]
        if (length(parts) == 2) {
          selected_day <- as.numeric(parts[1])
          selected_order <- as.numeric(parts[2])
          rv$selected_attraction <- paste0(selected_day, "_", selected_order)
          cat("📍 MAP CLICK: Day ", selected_day, " - Activity ", selected_order, "\n")
        }
      }
    })
    
    output$attraction_detail <- renderUI({
      req(rv$selected_attraction, rv$map_data)
      
      parts <- strsplit(rv$selected_attraction, "_")[[1]]
      selected_day <- as.numeric(parts[1])
      selected_order <- as.numeric(parts[2])
      
      attraction <- rv$map_data[rv$map_data$day == selected_day & rv$map_data$order == selected_order, ]
      
      if (nrow(attraction) == 0) {
        return(tags$p("Click on a marker to see details"))
      }
      
      attraction <- attraction[1, ]
      
      tagList(
        tags$h4(icon("map-pin"), " ", attraction$name),
        tags$hr(),
        tags$div(
          tags$strong("Date: "), tags$span(attraction$day_label), tags$br(),
          tags$strong("Stop: "), tags$span("#", attraction$order), tags$br(),
          tags$strong("Time: "), tags$span(attraction$time_start, " - ", attraction$time_end), tags$br(),
          tags$strong("Coords: "), tags$span("(", round(attraction$latitude, 4), ", ", 
                                            round(attraction$longitude, 4), ")"), tags$br(),
          tags$br(),
          tags$strong("Description:"), tags$br(),
          tags$p(attraction$description, style = "font-size: 0.95em; line-height: 1.5;")
        )
      )
    })
    
    # ==================
    # MAP SAVE BUTTON & FUNCTIONALITY
    # ==================
    
    output$save_map_button <- renderUI({
      if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
        actionButton(ns("save_map_image"), "💾 Save Map Image", 
                    class = "btn-info", style = "width: 100%; margin-top: 10px; margin-bottom: 10px;")
      }
    })
    
    observeEvent(input$save_map_image, {
      cat("\n📸 MAP SAVE: User clicked 'Save Map Image'\n")
      
      tryCatch({
        # Create temp directory for maps
        map_dir <- file.path(tempdir(), "travel_maps")
        if (!dir.exists(map_dir)) {
          dir.create(map_dir, showWarnings = FALSE)
        }
        
        # Create unique filename
        timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
        map_file <- file.path(map_dir, paste0("map_", timestamp, ".png"))
        
        # Attempt to export Plotly map as PNG
        # Using plotly::export() or webshot if available
        tryCatch({
          # Try webshot method first (more reliable)
          if (requireNamespace("webshot", quietly = TRUE)) {
            # For Plotly in Shiny, we'd need to capture the widget
            # This is complex; fallback to using API-based map
            cat("ℹ️ webshot available but using fallback method\n")
            
            # Generate Google Static Map as fallback
            if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
              md <- rv$map_data
              lat_center <- mean(md$latitude, na.rm = TRUE)
              lon_center <- mean(md$longitude, na.rm = TRUE)
              
              markers <- paste(
                sapply(1:nrow(md), function(i) {
                  paste0(md$latitude[i], ",", md$longitude[i])
                }),
                collapse = "|"
              )
              
              map_url <- paste0(
                "https://maps.googleapis.com/maps/api/staticmap?",
                "center=", lat_center, ",", lon_center,
                "&zoom=12&size=800x600",
                "&style=feature:water|color:0xb3d9ff",
                "&style=feature:land|color:0xf3f3f3",
                "&markers=", markers,
                "&format=png"
              )
              
              # Download map image
              download_result <- tryCatch({
                curl::curl_download(map_url, map_file, quiet = TRUE)
                TRUE
              }, error = function(e) FALSE)
              
              if (download_result && file.exists(map_file)) {
                file_size <- file.size(map_file)
                rv$map_image_path <- map_file
                cat("✅ Map image saved successfully\n")
                cat("📁 Path:", map_file, "\n")
                cat("📊 Size:", format(file_size, "bytes"), "\n")
                showNotification("✅ Map image saved! Ready for export.", type = "message")
              } else {
                cat("⚠️ Map download failed\n")
                rv$map_image_path <- ""  # Store URL fallback
                showNotification("⚠️ Map image download failed, using URL fallback for exports", type = "warning")
              }
            }
          }
        }, error = function(e) {
          cat("ℹ️ Using Google Static Maps URL fallback\n")
          
          if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
            md <- rv$map_data
            lat_center <- mean(md$latitude, na.rm = TRUE)
            lon_center <- mean(md$longitude, na.rm = TRUE)
            
            markers <- paste(
              sapply(1:nrow(md), function(i) {
                paste0(md$latitude[i], ",", md$longitude[i])
              }),
              collapse = "|"
            )
            
            map_url <- paste0(
              "https://maps.googleapis.com/maps/api/staticmap?",
              "center=", lat_center, ",", lon_center,
              "&zoom=12&size=800x600",
              "&style=feature:water|color:0xb3d9ff",
              "&style=feature:land|color:0xf3f3f3",
              "&markers=", markers,
              "&format=png"
            )
            
            rv$map_image_path <- map_url
            cat("✅ Map URL generated for export\n")
            showNotification("✅ Map image URL ready for export.", type = "message")
          }
        })
        
      }, error = function(e) {
        cat("❌ Error saving map:", e$message, "\n")
        showNotification(paste("Error saving map:", e$message), type = "error")
      })
    })
    
    # ==================
    # DOWNLOAD HANDLERS - HTML, PDF, ICS, KML, GPX
    # ==================
    
    # HTML Export with Map
    output$download_html <- downloadHandler(
      filename = function() { paste0(input$destination, "_itinerary.html") },
      content = function(file) {
        tryCatch({
          cat("\n📄 EXPORTING: HTML\n")
          cat("  Destination:", input$destination, "\n")
          
          # Get map URL or file path
          map_source <- ""
          if (!is.null(rv$map_image_path) && rv$map_image_path != "") {
            if (grepl("^http", rv$map_image_path)) {
              # It's a URL
              map_source <- rv$map_image_path
              cat("  🗺️ Map: Using URL\n")
            } else if (file.exists(rv$map_image_path)) {
              # It's a file - read and encode as base64
              tryCatch({
                img_data <- base64enc::base64encode(rv$map_image_path)
                map_source <- paste0("data:image/png;base64,", img_data)
                cat("  🗺️ Map: Using base64-encoded file\n")
              }, error = function(e) {
                cat("  ⚠️ Base64 encoding failed, using URL fallback\n")
              })
            }
          }
          
          # Generate Google Static Map if no saved image
          if (map_source == "" && !is.null(rv$map_data) && nrow(rv$map_data) > 0) {
            md <- rv$map_data
            lat_center <- mean(md$latitude, na.rm = TRUE)
            lon_center <- mean(md$longitude, na.rm = TRUE)
            
            markers <- paste(
              sapply(1:nrow(md), function(i) {
                paste0(md$latitude[i], ",", md$longitude[i])
              }),
              collapse = "|"
            )
            
            map_source <- paste0(
              "https://maps.googleapis.com/maps/api/staticmap?",
              "center=", lat_center, ",", lon_center,
              "&zoom=12&size=900x500",
              "&style=feature:water|color:0xb3d9ff",
              "&style=feature:land|color:0xf3f3f3",
              "&markers=", markers,
              "&format=png"
            )
            cat("  🗺️ Map: Generated from API\n")
          }
          
          # Build HTML content
          html_content <- c(
            "<!DOCTYPE html>",
            "<html lang=\"en\">",
            "<head>",
            "  <meta charset=\"UTF-8\">",
            "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">",
            paste0("  <title>", input$destination, " Itinerary</title>"),
            "  <style>",
            "    * { margin: 0; padding: 0; box-sizing: border-box; }",
            "    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; padding: 20px; }",
            "    .container { max-width: 1000px; margin: 0 auto; background-color: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }",
            "    .header { border-bottom: 3px solid #2196F3; padding-bottom: 20px; margin-bottom: 30px; }",
            "    .header h1 { color: #2196F3; font-size: 2.5em; margin-bottom: 10px; }",
            "    .trip-info { background-color: #e3f2fd; padding: 15px; border-radius: 4px; margin-bottom: 20px; }",
            "    .trip-info p { margin: 5px 0; }",
            "    .map-container { text-align: center; margin: 30px 0; }",
            "    .map-container img { max-width: 100%; height: auto; border-radius: 4px; border: 1px solid #ddd; }",
            "    .day-section { margin-bottom: 40px; page-break-inside: avoid; }",
            "    .day-header { background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 15px; border-radius: 4px; margin-bottom: 15px; font-size: 1.3em; font-weight: bold; }",
            "    .attraction { border-left: 4px solid #2196F3; padding: 15px; margin-bottom: 15px; background-color: #f9f9f9; border-radius: 4px; }",
            "    .attraction-name { font-size: 1.2em; font-weight: bold; color: #1976D2; margin-bottom: 8px; }",
            "    .attraction-time { background-color: #e3f2fd; padding: 8px 12px; border-radius: 4px; display: inline-block; font-weight: bold; color: #1976D2; margin-bottom: 10px; }",
            "    .attraction-description { margin: 10px 0; line-height: 1.6; }",
            "    .attraction-coords { font-size: 0.9em; color: #999; margin-top: 8px; }",
            "    .footer { border-top: 1px solid #ddd; padding-top: 20px; margin-top: 40px; text-align: center; color: #999; font-size: 0.9em; }",
            "    @media print { body { background: white; } .container { box-shadow: none; } }",
            "  </style>",
            "</head>",
            "<body>",
            "  <div class=\"container\">",
            "    <div class=\"header\">",
            paste0("      <h1>🌍 ", input$destination, " Itinerary</h1>"),
            "    </div>",
            "    <div class=\"trip-info\">",
            paste0("      <p><strong>Trip Duration:</strong> ", input$num_days, " day(s)</p>"),
            paste0("      <p><strong>Start Date:</strong> ", format(input$trip_start_date, "%A, %B %d, %Y"), "</p>"),
            paste0("      <p><strong>End Date:</strong> ", format(input$trip_end_date, "%A, %B %d, %Y"), "</p>"),
            "    </div>"
          )
          
          # Add map if available
          if (map_source != "") {
            html_content <- c(html_content,
              "    <div class=\"map-container\">",
              "      <h3>Trip Map</h3>",
              paste0("      <img src=\"", map_source, "\" alt=\"Trip Map\">"),
              "    </div>"
            )
            cat("  ✅ Map embedded\n")
          } else {
            cat("  ⚠️ No map available\n")
          }
          
          # Add attractions
          if (!is.null(rv$itinerary_data) && length(rv$itinerary_data) > 0) {
            attraction_count <- 0
            for (day in rv$itinerary_data) {
              html_content <- c(html_content,
                "    <div class=\"day-section\">",
                paste0("      <div class=\"day-header\">", day$day_label, "</div>")
              )
              
              if (!is.null(day$activities)) {
                for (activity in day$activities) {
                  html_content <- c(html_content,
                    "      <div class=\"attraction\">",
                    paste0("        <div class=\"attraction-name\">", activity$name, "</div>"),
                    paste0("        <div class=\"attraction-time\">🕐 ", activity$time_start, " - ", activity$time_end, "</div>"),
                    paste0("        <div class=\"attraction-description\">", activity$description, "</div>"),
                    paste0("        <div class=\"attraction-coords\">📍 ", round(activity$latitude, 4), ", ", round(activity$longitude, 4), "</div>"),
                    "      </div>"
                  )
                  attraction_count <- attraction_count + 1
                }
              }
              html_content <- c(html_content, "    </div>")
            }
            cat("  📍 Found", attraction_count, "attractions\n")
          }
          
          html_content <- c(html_content,
            "    <div class=\"footer\">",
            paste0("      <p>Generated on ", format(Sys.time(), "%A, %B %d, %Y at %H:%M %Z"), "</p>"),
            "      <p>Travel Itinerary Planner - Powered by Claude AI</p>",
            "    </div>",
            "  </div>",
            "</body>",
            "</html>"
          )
          
          writeLines(html_content, file)
          file_size <- file.size(file)
          cat("  ✅ HTML with map generated\n")
          cat("  📊 File size:", format(file_size, "bytes"), "\n\n")
          
        }, error = function(e) {
          cat("❌ HTML error:", e$message, "\n")
          writeLines("<html><body><p>Error generating HTML</p></body></html>", file)
        })
      }
    )
    
    # PDF Export with Map
    output$download_pdf <- downloadHandler(
      filename = function() { paste0(input$destination, "_itinerary.pdf") },
      content = function(file) {
        tryCatch({
          cat("\n📕 EXPORTING: PDF\n")
          cat("  Destination:", input$destination, "\n")
          
          # Get map source
          map_ref <- ""
          if (!is.null(rv$map_image_path) && rv$map_image_path != "" && grepl("^http", rv$map_image_path)) {
            map_ref <- rv$map_image_path
            cat("  🗺️ Map: Using URL\n")
          } else {
            # Generate URL for PDF
            if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
              md <- rv$map_data
              lat_center <- mean(md$latitude, na.rm = TRUE)
              lon_center <- mean(md$longitude, na.rm = TRUE)
              
              markers <- paste(
                sapply(1:nrow(md), function(i) {
                  paste0(md$latitude[i], ",", md$longitude[i])
                }),
                collapse = "|"
              )
              
              map_ref <- paste0(
                "https://maps.googleapis.com/maps/api/staticmap?",
                "center=", lat_center, ",", lon_center,
                "&zoom=12&size=800x500",
                "&style=feature:water|color:0xb3d9ff",
                "&style=feature:land|color:0xf3f3f3",
                "&markers=", markers,
                "&format=png"
              )
              cat("  🗺️ Map: Generated from API\n")
            }
          }
          
          # Create markdown content
          md_content <- c(
            "---",
            "title: \"Travel Itinerary\"",
            "author: \"Travel Planner\"",
            paste0("date: \"", format(Sys.Date(), "%B %d, %Y"), "\""),
            "output:",
            "  pdf_document:",
            "    fig_width: 7",
            "    fig_height: 5",
            "---",
            "",
            paste0("# ", input$destination, " Itinerary"),
            "",
            "## Trip Information",
            "",
            paste0("- **Duration:** ", input$num_days, " day(s)"),
            paste0("- **Start Date:** ", format(input$trip_start_date, "%A, %B %d, %Y")),
            paste0("- **End Date:** ", format(input$trip_end_date, "%A, %B %d, %Y")),
            ""
          )
          
          # Add map if available
          if (map_ref != "") {
            md_content <- c(md_content,
              "## Map",
              "",
              paste0("![Trip Map](", map_ref, ")"),
              ""
            )
            cat("  🗺️ Map embedded\n")
          } else {
            cat("  ⚠️ No map available\n")
          }
          
          # Add attractions
          attraction_count <- 0
          if (!is.null(rv$itinerary_data) && length(rv$itinerary_data) > 0) {
            for (day in rv$itinerary_data) {
              md_content <- c(md_content,
                paste0("## ", day$day_label),
                ""
              )
              
              if (!is.null(day$activities)) {
                for (idx in seq_along(day$activities)) {
                  activity <- day$activities[[idx]]
                  md_content <- c(md_content,
                    paste0("### ", idx, ". ", activity$name),
                    "",
                    paste0("**Time:** ", activity$time_start, " - ", activity$time_end),
                    "",
                    paste0("**Location:** ", round(activity$latitude, 4), ", ", round(activity$longitude, 4)),
                    "",
                    activity$description,
                    ""
                  )
                  attraction_count <- attraction_count + 1
                }
              }
            }
          }
          
          md_content <- c(md_content,
            "## Notes",
            "",
            "- Plan transportation between attractions",
            "- Check opening hours before visiting",
            "- Make reservations if needed",
            "",
            paste0("*Generated ", format(Sys.time(), "%A, %B %d, %Y at %H:%M"), "*")
          )
          
          # Write temp markdown file
          temp_md <- tempfile(fileext = ".md")
          writeLines(md_content, temp_md)
          
          # Try rendering to PDF
          cat("  ⏳ Rendering to PDF...\n")
          render_result <- tryCatch({
            rmarkdown::render(
              temp_md,
              output_file = file,
              output_format = "pdf_document",
              quiet = TRUE
            )
            TRUE
          }, error = function(e) {
            cat("  ⚠️ PDF render failed:", e$message, "\n")
            FALSE
          })
          
          if (render_result && file.exists(file)) {
            file_size <- file.size(file)
            cat("  ✅ PDF generated\n")
            cat("  📊 File size:", format(file_size, "bytes"), "\n\n")
          } else {
            cat("  ⚠️ PDF rendering failed, saving as HTML alternative\n")
            # Fallback: Save as HTML
            html_file <- paste0(tools::file_path_sans_ext(file), ".html")
            rmarkdown::render(
              temp_md,
              output_file = html_file,
              output_format = "html_document",
              quiet = TRUE
            )
            file.copy(html_file, file, overwrite = TRUE)
            file.remove(html_file)
            cat("  ✓ Saved as HTML with PDF extension\n\n")
          }
          
          unlink(temp_md)
          
        }, error = function(e) {
          cat("❌ PDF error:", e$message, "\n\n")
          writeLines("Error generating PDF", file)
        })
      }
    )
    
    # Calendar (.ics) Export
    output$download_calendar <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.ics")
      },
      content = function(file) {
        if (!is.null(rv$itinerary_data)) {
          tryCatch({
            cat("\n📅 EXPORTING: ICS Calendar\n")
            
            # Create iCalendar format
            ics_content <- c(
              "BEGIN:VCALENDAR",
              "VERSION:2.0",
              "PRODID:-//AI Travel Planner//Travel Itinerary//EN",
              "CALSCALE:GREGORIAN",
              paste0("X-WR-CALNAME:", input$destination, " Itinerary"),
              "X-WR-TIMEZONE:UTC",
              paste0("DESCRIPTION:", input$destination, " - ", input$num_days, " Day Travel Plan"),
              ""
            )
            
            # Parse events from itinerary
            event_count <- 0
            if (!is.null(rv$itinerary_data) && length(rv$itinerary_data) > 0) {
              for (day in rv$itinerary_data) {
                if (!is.null(day$activities)) {
                  event_date <- format(input$trip_start_date + (day$day - 1), "%Y%m%d")
                  
                  for (activity in day$activities) {
                    time_24hr <- gsub(":", "", activity$time_start)
                    event_start <- paste0(event_date, "T", time_24hr, "00Z")
                    
                    # End time is start time + 2 hours
                    time_parts <- strsplit(activity$time_end, ":")[[1]]
                    time_end <- paste0(event_date, "T", 
                                      formatC(as.numeric(time_parts[1]), width = 2, flag = "0"),
                                      formatC(as.numeric(time_parts[2]), width = 2, flag = "0"), "00Z")
                    
                    ics_content <- c(
                      ics_content,
                      "BEGIN:VEVENT",
                      paste0("UID:travel-", day$day, "-", activity$order, "@travelplanner.local"),
                      paste0("DTSTAMP:", format(Sys.time(), "%Y%m%dT%H%M%SZ")),
                      paste0("DTSTART:", event_start),
                      paste0("DTEND:", event_end),
                      paste0("SUMMARY:", activity$name),
                      paste0("DESCRIPTION:", activity$description),
                      paste0("LOCATION:", round(activity$latitude, 4), ",", round(activity$longitude, 4)),
                      "STATUS:CONFIRMED",
                      "SEQUENCE:0",
                      "END:VEVENT",
                      ""
                    )
                    event_count <- event_count + 1
                  }
                }
              }
            }
            
            ics_content <- c(ics_content, "END:VCALENDAR")
            writeLines(ics_content, file)
            
            cat("  ✅ ICS calendar exported with", event_count, "events\n\n")
            
          }, error = function(e) {
            cat("❌ ICS error:", e$message, "\n\n")
          })
        }
      }
    )
    
    # KML (Google Maps) Export
    output$download_kml <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.kml")
      },
      content = function(file) {
        tryCatch({
          cat("\n🗺️ EXPORTING: KML (Google Maps)\n")
          
          kml_content <- c(
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
            "<kml xmlns=\"http://www.opengis.net/kml/2.2\">",
            "  <Document>",
            paste0("    <name>", input$destination, " Itinerary</name>"),
            paste0("    <description>", input$num_days, "-Day Travel Plan</description>"),
            ""
          )
          
          placemark_count <- 0
          if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
            for (i in 1:nrow(rv$map_data)) {
              row <- rv$map_data[i, ]
              kml_content <- c(kml_content,
                "    <Placemark>",
                paste0("      <name>", row$order, ". ", row$name, "</name>"),
                paste0("      <description>", row$day_label, " (", row$time_start, " - ", row$time_end, "): ", row$description, "</description>"),
                "      <Point>",
                paste0("        <coordinates>", row$longitude, ",", row$latitude, ",0</coordinates>"),
                "      </Point>",
                "    </Placemark>",
                ""
              )
              placemark_count <- placemark_count + 1
            }
          }
          
          kml_content <- c(kml_content,
            "  </Document>",
            "</kml>"
          )
          
          writeLines(kml_content, file)
          cat("  ✅ KML exported with", placemark_count, "placemarks\n\n")
          
        }, error = function(e) {
          cat("❌ KML error:", e$message, "\n\n")
        })
      }
    )
    
    # GPX (GPS Navigation) Export
    output$download_gpx <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.gpx")
      },
      content = function(file) {
        tryCatch({
          cat("\n📍 EXPORTING: GPX (Navigation)\n")
          
          gpx_content <- c(
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
            "<gpx version=\"1.1\" creator=\"Travel Itinerary Planner\"",
            "  xmlns=\"http://www.topografix.com/GPX/1/1\"",
            "  xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"",
            "  xsi:schemaLocation=\"http://www.topografix.com/GPX/1/1",
            "    http://www.topografix.com/GPX/1/1/gpx.xsd\">",
            paste0("  <metadata><name>", input$destination, " Itinerary</name></metadata>",
            ""
          )
          
          waypoint_count <- 0
          if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
            for (i in 1:nrow(rv$map_data)) {
              row <- rv$map_data[i, ]
              gpx_content <- c(gpx_content,
                paste0("  <wpt lat=\"", row$latitude, "\" lon=\"", row$longitude, "\">"),
                paste0("    <name>", row$order, ". ", row$name, "</name>"),
                paste0("    <cmt>", row$day_label, " (", row$time_start, " - ", row$time_end, ")</cmt>"),
                paste0("    <desc>", row$description, "</desc>"),
                "  </wpt>",
                ""
              )
              waypoint_count <- waypoint_count + 1
            }
          }
          
          gpx_content <- c(gpx_content, "</gpx>")
          
          writeLines(gpx_content, file)
          cat("  ✅ GPX exported with", waypoint_count, "waypoints\n\n")
          
        }, error = function(e) {
          cat("❌ GPX error:", e$message, "\n\n")
        })
      }
    )
    
    # Google Maps URL Export
    output$download_google_maps_url <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_google_maps_link.txt")
      },
      content = function(file) {
        tryCatch({
          cat("\n🔗 EXPORTING: Google Maps Link\n")
          
          url_content <- c(
            paste0("Google Maps Navigation Link for: ", input$destination),
            paste0("Generated: ", format(Sys.time(), "%A, %B %d, %Y at %H:%M")),
            "",
            "DIRECTIONS:"
          )
          
          if (!is.null(rv$map_data) && nrow(rv$map_data) > 0) {
            # Build URL with waypoints
            waypoints <- ""
            
            for (i in 1:nrow(rv$map_data)) {
              row <- rv$map_data[i, ]
              if (i == 1) {
                # Start point
                origin <- paste0(row$latitude, ",", row$longitude)
              } else if (i == nrow(rv$map_data)) {
                # End point
                destination <- paste0(row$latitude, ",", row$longitude)
              } else {
                # Waypoint
                waypoints <- paste0(waypoints, "|", row$latitude, ",", row$longitude)
              }
              
              url_content <- c(url_content,
                paste0(i, ". ", row$name, " (", row$time_start, " - ", row$time_end, ")")
              )
            }
            
            if (exists("origin") && exists("destination")) {
              maps_url <- paste0(
                "https://www.google.com/maps/dir/?api=1",
                "&origin=", origin,
                "&destination=", destination,
                if (waypoints != "") paste0("&waypoints=", waypoints) else ""
              )
              
              url_content <- c(url_content,
                "",
                "GOOGLE MAPS LINK:",
                maps_url,
                "",
                "Copy and paste this link into your browser to view the full route."
              )
              
              cat("  ✅ Google Maps link generated\n\n")
            }
          }
          
          writeLines(url_content, file)
          
        }, error = function(e) {
          cat("❌ Google Maps URL error:", e$message, "\n\n")
        })
      }
    )
    
    # Initialize UI outputs
    output$discovery_status <- renderUI(NULL)
    output$places_checkboxes <- renderUI(NULL)
    output$itinerary_status <- renderUI(NULL)
    output$itinerary_html <- renderUI(NULL)
    output$attraction_detail <- renderUI({
      tags$p("Generate an itinerary and click on a map marker to see details.")
    })
    
    session$onSessionEnded(function() {
      # Cleanup
      cat("\n🧹 Cleaning up session resources\n")
    })
  })
}
