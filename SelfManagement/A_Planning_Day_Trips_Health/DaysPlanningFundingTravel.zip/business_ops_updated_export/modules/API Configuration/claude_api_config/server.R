# modules/API Configuration/claude_api_config/server.R

claude_api_config_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    observeEvent(input$test_connection, {
      req(input$api_key)

      output$status <- renderUI({
        tags$div(class = "status-info", tags$i(class = "fa fa-spinner fa-spin"), " Testing connection...")
      })

      tryCatch({
        api_manager$set_claude_credentials(
          api_key = input$api_key, model = input$model,
          max_tokens = input$max_tokens, timeout = input$timeout
        )
        api_manager$test_claude_connection()

        output$status <- renderUI({
          tags$div(class = "status-success", tags$i(class = "fa fa-check-circle"),
                   " ✓ Connection Successful!", tags$br(),
                   tags$small("Model: ", input$model), tags$br(),
                   tags$small("Timeout: ", input$timeout, " seconds"), tags$br(),
                   tags$small("Status: Ready for all three suites"))
        })

        showNotification("✓ Claude API connection successful!", type = "message")

      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error", tags$i(class = "fa fa-times-circle"),
                   " Connection Failed: ", tags$br(), tags$small(e$message))
        })
        showNotification(paste("Error:", e$message), type = "error", duration = 10)
      })
    })

    observeEvent(input$save_credentials, {
      req(input$api_key)

      api_manager$set_claude_credentials(
        api_key = input$api_key, model = input$model,
        max_tokens = input$max_tokens, timeout = input$timeout
      )

      showNotification("✓ Credentials saved successfully!", type = "message")

      output$status <- renderUI({
        tags$div(class = "status-success", tags$i(class = "fa fa-check-circle"),
                 " Credentials Saved", tags$br(),
                 tags$small("Model: ", input$model), tags$br(),
                 tags$small("Max Tokens: ", input$max_tokens), tags$br(),
                 tags$small("Timeout: ", input$timeout, " seconds"))
      })
    })

    observeEvent(input$run_diagnostics, {
      output$diagnostics_output <- renderText({ "Running diagnostics... check the R console for live detail." })

      lines <- tryCatch({
        api_manager$diagnose_network()
      }, error = function(e) {
        c(paste("Diagnostics failed to run:", e$message))
      })

      output$diagnostics_output <- renderText({ paste(lines, collapse = "\n") })
    })

    output$status <- renderUI({ tags$div() })
    output$diagnostics_output <- renderText({ "" })

    session$onSessionEnded(function() {})
  })
}
