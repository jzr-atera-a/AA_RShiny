# modules/Day Planner/schedule_visualizations.R
# ---- module ----------------------------------------------
# id:           schedule_visualizations
# name:         Visualizations
# icon:         chart-bar
# description:  Itinerary timeline visualization with time-allocation chart
# packages:     shiny, shinydashboard, DT, plotly
# -----------------------------------------------------------

# ---- UI ----
schedule_visualizations_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "Select a Day to Visualize", status = "primary", solidHeader = TRUE, width = 12,
          p("Filter by Type of Day and Country to find the planned day you want, then load its itinerary."),
          fluidRow(
            column(3, selectInput(ns("viz_day_type"), "Type of Day:", choices = NULL)),
            column(3, selectInput(ns("viz_country"), "Country:", choices = NULL)),
            column(3, selectInput(ns("select_date"), "Date:", choices = NULL)),
            column(3, selectInput(ns("filter_row_type"), "Filter by Row Type (Optional):", choices = c("All Rows" = "all")))
          ),
          fluidRow(column(12, actionButton(ns("load_viz"), "Load Visualizations",
                                          class = "btn-success btn-lg", icon = icon("chart-bar"), style = "width: 100%;"))),
          hr(), htmlOutput(ns("status"))
      )
    ),

    fluidRow(
      box(title = "Day Overview", status = "info", solidHeader = TRUE, width = 12, collapsible = TRUE,
          htmlOutput(ns("day_header")),
          fluidRow(
            column(3, valueBoxOutput(ns("total_locations"), width = 12)),
            column(3, valueBoxOutput(ns("total_transport"), width = 12)),
            column(3, valueBoxOutput(ns("total_time"), width = 12)),
            column(3, valueBoxOutput(ns("total_entries"), width = 12))
          )
      )
    ),

    fluidRow(
      box(title = "Itinerary Timeline", status = "success", solidHeader = TRUE, width = 12, collapsible = TRUE,
          htmlOutput(ns("timeline_html")))
    ),

    fluidRow(
      box(title = "Time Allocation Trends", status = "warning", solidHeader = TRUE, width = 12, collapsible = TRUE,
          plotlyOutput(ns("time_chart"), height = "500px"))
    ),

    generic_export_box_ui(ns, title = "Save This Day's Itinerary", ics = TRUE,
                          ics_extra_ui = checkboxInput(ns("ics_include_transport"), "Include transport legs", value = TRUE)),
    drive_export_ui(ns)
  )
}

# Chart data for the time-allocation chart: one row per timed stop. Shared by the in-app chart and the Drive diagram.
schedule_chart_data <- function(d) {
  plot_rows <- d[d$row_type %in% c("Location", "Transport"), ]
  chart_data <- data.frame(stop = character(), row_type = character(), minutes = numeric(), stringsAsFactors = FALSE)
  for (i in seq_len(nrow(plot_rows))) {
    row <- plot_rows[i, ]
    mins <- schedule_parse_duration_minutes(row$recommended_time)
    if (!is.na(mins)) {
      chart_data <- rbind(chart_data, data.frame(
        stop = paste0(row$row_sequence, ". ", row$location_name), row_type = row$row_type, minutes = mins, stringsAsFactors = FALSE))
    }
  }
  chart_data
}

# Diagram of the same chart for the Save-to-Google-Drive box (R/utils_diagram.R).
schedule_diagram_time <- function(d) {
  cd <- schedule_chart_data(d)
  labs <- unique(cd$stop)
  series <- lapply(c("Location", "Transport"), function(rt) {
    vals <- vapply(labs, function(l) { m <- cd$minutes[cd$stop == l & cd$row_type == rt]; if (length(m)) m[1] else 0 }, numeric(1))
    list(name = rt, values = unname(vals), color = if (rt == "Location") "#008A82" else "#E67E22")
  })
  dg_bar(paste0("Estimated minutes per stop - ", d$schedule_date[1]), labs, series,
         subtitle = paste0(d$day_type[1], " | ", length(labs), " timed stops"),
         stacked = TRUE, y_title = "Minutes", table = cd)
}

# ---- Server ----
schedule_visualizations_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    ns <- session$ns
    viz_data <- reactiveVal(NULL)

    viz_taxonomy <- reactive({
      api_manager$tab_gate("schedule_visualizations")     # loads when this tab is first opened, not before
      api_manager$state_trigger_schedule()
      if (!api_manager$bq_authenticated) return(data.frame(day_type = character(), country = character(), city = character(), stringsAsFactors = FALSE))
      tryCatch(api_manager$bq_get_schedule_taxonomy(), error = function(e) data.frame(day_type = character(), country = character(), city = character(), stringsAsFactors = FALSE))
    })

    observeEvent(viz_taxonomy(), {
      tax <- viz_taxonomy()
      day_types <- sort(unique(tax$day_type[nchar(trimws(tax$day_type)) > 0]))
      if (length(day_types) == 0) {
        updateSelectInput(session, "viz_day_type", choices = c("(no schedules yet)" = ""))
      } else {
        current <- isolate(input$viz_day_type)
        selected <- if (!is.null(current) && current %in% day_types) current else day_types[1]
        updateSelectInput(session, "viz_day_type", choices = setNames(day_types, day_types), selected = selected)
      }
    }, ignoreNULL = FALSE)

    observeEvent(input$viz_day_type, {
      tax <- viz_taxonomy()
      if (is.null(input$viz_day_type) || input$viz_day_type == "") {
        updateSelectInput(session, "viz_country", choices = c("(select a type first)" = ""))
        return()
      }
      countries <- sort(unique(tax$country[tax$day_type == input$viz_day_type & nchar(trimws(tax$country)) > 0]))
      if (length(countries) == 0) updateSelectInput(session, "viz_country", choices = c("N/A" = "N/A"))
      else updateSelectInput(session, "viz_country", choices = setNames(countries, countries))
    }, ignoreInit = TRUE)

    observeEvent(input$viz_country, {
      tax <- viz_taxonomy()
      if (is.null(input$viz_day_type) || is.null(input$viz_country) || input$viz_day_type == "" || input$viz_country == "") {
        updateSelectInput(session, "select_date", choices = c("(select a country first)" = ""))
        return()
      }
      subset_rows <- tax[tax$day_type == input$viz_day_type & tax$country == input$viz_country, ]
      dates <- sort(unique(if ("schedule_date" %in% names(subset_rows)) subset_rows[["schedule_date"]] else character()), decreasing = TRUE)
      if (length(dates) == 0) {
        # Fallback: taxonomy doesn't carry schedule_date in this suite's
        # 3-column taxonomy (day_type, country, city), so pull dates
        # directly for the selected day_type/country combo instead.
        dates <- tryCatch({
          safe_dt <- safe_sql_escape(input$viz_day_type)
          safe_c  <- safe_sql_escape(input$viz_country)
          r <- api_manager$bq_query(sprintf(
            "SELECT DISTINCT schedule_date FROM `%s` WHERE day_type = '%s' AND country = '%s' ORDER BY schedule_date DESC",
            api_manager$bq_full_table_schedule, safe_dt, safe_c))
          r$schedule_date
        }, error = function(e) character())
      }
      if (length(dates) == 0) updateSelectInput(session, "select_date", choices = c("(no dates found)" = ""))
      else updateSelectInput(session, "select_date", choices = setNames(dates, dates))
    }, ignoreInit = TRUE)

    observeEvent(input$select_date, {
      if (!api_manager$bq_authenticated || is.null(input$select_date) || input$select_date == "") return()
      tryCatch({
        safe_date <- safe_sql_escape(input$select_date)
        query <- sprintf("SELECT DISTINCT row_type FROM `%s` WHERE schedule_date = '%s' ORDER BY row_type",
                         api_manager$bq_full_table_schedule, safe_date)
        row_types <- api_manager$bq_query(query)
        if (nrow(row_types) > 0) {
          updateSelectInput(session, "filter_row_type", choices = c("All Rows" = "all", setNames(row_types$row_type, row_types$row_type)))
        }
      }, error = function(e) {})
    })

    observeEvent(input$load_viz, {
      if (!api_manager$bq_authenticated) { showNotification("Please authenticate with BigQuery first!", type = "error"); return() }
      if (is.null(input$select_date) || input$select_date == "") { showNotification("Please select a date!", type = "warning"); return() }

      output$status <- renderUI({ tags$div(class = "status-info", tags$i(class = "fa fa-spinner fa-spin"), " Loading visualization data...") })

      tryCatch({
        safe_date <- safe_sql_escape(input$select_date)
        query <- if (input$filter_row_type == "all") {
          sprintf("SELECT * FROM `%s` WHERE schedule_date = '%s' ORDER BY row_sequence", api_manager$bq_full_table_schedule, safe_date)
        } else {
          sprintf("SELECT * FROM `%s` WHERE schedule_date = '%s' AND row_type = '%s' ORDER BY row_sequence",
                  api_manager$bq_full_table_schedule, safe_date, safe_sql_escape(input$filter_row_type))
        }
        data <- api_manager$bq_query(query)

        if (nrow(data) == 0) {
          output$status <- renderUI({ tags$div(class = "status-warning", tags$i(class = "fa fa-exclamation-triangle"), " No data found") })
          return()
        }

        viz_data(data)

        location_line <- if (identical(data$day_type[1], "Travel") && !is.na(data$city[1]) && data$city[1] != "N/A") {
          paste0(data$city[1], ", ", data$country[1])
        } else data$day_type[1]

        output$day_header <- renderUI({
          tags$div(class = "book-header", tags$h2(data$schedule_date[1]),
                   tags$div(class = "author", tags$i(class = "fa fa-tag"), " ", location_line))
        })

        output$total_locations <- renderValueBox({ valueBox(sum(data$row_type == "Location"), "Locations", icon = icon("map-pin"), color = "aqua") })
        output$total_transport <- renderValueBox({ valueBox(sum(data$row_type == "Transport"), "Transport Legs", icon = icon("route"), color = "blue") })

        summary_row <- data[data$row_type == "Summary", ]
        total_time_val <- if (nrow(summary_row) > 0) summary_row$recommended_time[1] else "—"
        output$total_time <- renderValueBox({ valueBox(total_time_val, "Total Day Time", icon = icon("clock"), color = "yellow") })
        output$total_entries <- renderValueBox({ valueBox(nrow(data), "Total Entries", icon = icon("database"), color = "green") })

        output$timeline_html <- renderUI({
          d <- viz_data(); req(!is.null(d))
          html_parts <- c('<div class="viz-card">')
          html_parts <- c(html_parts, sprintf('<div class="chapter-title"><i class="fa fa-calendar-day"></i> %s Itinerary</div>', as.character(d$schedule_date[1])))

          row_icon <- function(rt) switch(rt, "Location" = "fa fa-map-pin", "Transport" = "fa fa-route", "Summary" = "fa fa-flag-checkered", "fa fa-circle")

          for (i in seq_len(nrow(d))) {
            row <- d[i, ]
            html_parts <- c(html_parts, sprintf('<div class="section-tag"><i class="%s"></i> %s: %s</div>',
                                                row_icon(as.character(row$row_type)), as.character(row$row_type), as.character(row$location_name)))
            html_parts <- c(html_parts, sprintf('<div class="details-text">%s</div>', as.character(row$location_details)))

            if (row$row_type == "Location" && has_real_value(row$opening_hours)) {
              html_parts <- c(html_parts, sprintf(
                '<div class="metric-box"><div class="metric-label">Opening Hours</div><div class="metric-value" style="font-size: 1em;">%s</div></div>',
                as.character(row$opening_hours)))
            }
            if (has_real_value(row$recommended_time)) {
              html_parts <- c(html_parts, sprintf(
                '<div class="metric-box"><div class="metric-label">Recommended / Expected Time</div><div class="metric-value" style="font-size: 1em;">%s</div></div>',
                as.character(row$recommended_time)))
            }
            if (has_real_value(row$observations)) {
              html_parts <- c(html_parts, '<div class="reference-box">')
              html_parts <- c(html_parts, sprintf('<h5><i class="fa fa-lightbulb"></i> %s</h5>', if (row$row_type == "Summary") "Key Insights" else "What to Expect"))
              html_parts <- c(html_parts, sprintf('<p style="margin-top: 8px; color: #555;">%s</p>', as.character(row$observations)))
              html_parts <- c(html_parts, '</div>')
            }
            if (i < nrow(d)) html_parts <- c(html_parts, '<hr style="margin: 20px 0; border-top: 1px solid #e0e0e0;">')
          }
          html_parts <- c(html_parts, '</div>')
          HTML(paste(html_parts, collapse = ""))
        })

        output$time_chart <- renderPlotly({
          d <- viz_data(); req(!is.null(d))
          chart_data <- schedule_chart_data(d)

          if (nrow(chart_data) == 0) return(plot_ly() %>% layout(title = "No parsable durations available"))

          chart_data$stop <- factor(chart_data$stop, levels = chart_data$stop)
          plot_ly(chart_data, x = ~stop, y = ~minutes, color = ~row_type, type = 'bar') %>%
            layout(title = "Estimated Minutes per Stop", xaxis = list(title = "", tickangle = -35), yaxis = list(title = "Minutes"))
        })

        output$status <- renderUI({
          tags$div(class = "status-success", tags$i(class = "fa fa-check-circle"),
                   sprintf(" Loaded visualizations for %s (%d entries)", data$schedule_date[1], nrow(data)))
        })
        showNotification("✓ Visualizations loaded!", type = "message")

      }, error = function(e) {
        output$status <- renderUI({ tags$div(class = "status-error", tags$i(class = "fa fa-times-circle"), " Error: ", e$message) })
        showNotification(paste("Error:", e$message), type = "error")
      })
    })

    output$status <- renderUI({ tags$div() })
    output$day_header <- renderUI({ tags$div() })
    output$timeline_html <- renderUI({ tags$div() })
    output$time_chart <- renderPlotly({ plot_ly() })
    output$total_locations <- renderValueBox({ valueBox(0, "Locations", icon = icon("map-pin"), color = "aqua") })
    output$total_transport <- renderValueBox({ valueBox(0, "Transport Legs", icon = icon("route"), color = "blue") })
    output$total_time <- renderValueBox({ valueBox("—", "Total Day Time", icon = icon("clock"), color = "yellow") })
    output$total_entries <- renderValueBox({ valueBox(0, "Total Entries", icon = icon("database"), color = "green") })

    # ── Save as HTML/PDF (shared generic exporter, see R/utils_export.R) ──
    output$export_download <- downloadHandler(
      filename = function() {
        d <- viz_data()
        base_name <- if (!is.null(d) && nrow(d) > 0) paste0("day_planner_", d$schedule_date[1]) else "day_planner_export"
        paste0(base_name, if (identical(input$export_format, "pdf")) ".pdf" else ".html")
      },
      content = function(file) {
        tryCatch({
          d <- viz_data()
          if (is.null(d) || nrow(d) == 0) {
            writeLines("<html><body><p>No data loaded - load a day's itinerary first.</p></body></html>", file)
            return()
          }

          cols <- c("row_type", "location_name", "location_details", "recommended_time", "observations")
          labels <- c("Type", "Location", "Details", "Time", "Observations")
          subtitle <- sprintf("%s - %s | %d entries", d$schedule_date[1], d$day_type[1], nrow(d))

          if (identical(input$export_format, "pdf")) {
            ok <- generate_generic_pdf(file, paste0("Day Planner - ", d$schedule_date[1]), subtitle, d, cols, labels)
            if (!isTRUE(ok)) stop("PDF generation failed internally - see console log above for the real cause")
          } else {
            result <- generate_generic_html(paste0("Day Planner - ", d$schedule_date[1]), subtitle, d, cols, labels)
            writeLines(result$content, file)
          }
        }, error = function(e) {
          cat("\u274c [schedule_visualizations export] Error:", e$message, "\n")
          writeLines(c("<html><body>", "<h2>Export failed</h2>",
                       paste0("<p>", htmltools::htmlEscape(e$message), "</p>"),
                       "<p>Check the Debug Console (API Configuration group) for full detail.</p>",
                       "</body></html>"), file)
        })
      }
    )
    output$export_status <- renderUI({ tags$div() })

    # ── Add to Calendar (.ics) - engine in R/utils_ics.R ──
    ics_result <- reactive({
      ics_safe_build(ics_events_day_planner, viz_data(),
                     include_transport = isTRUE(input$ics_include_transport),
                     alarms = isTRUE(input$ics_alarms))
    })
    output$export_ics_status <- renderUI({ ics_status_html(ics_result(), loaded = !is.null(viz_data())) })
    output$export_ics <- downloadHandler(
      filename = function() { d <- viz_data(); ics_filename("day_planner", if (!is.null(d) && nrow(d) > 0) d$schedule_date[1]) },
      content = function(file) {
        d <- viz_data()
        ics_write_safe(function() ics_result()$events,
                       paste("Day Planner", if (!is.null(d) && nrow(d) > 0) as.character(d$schedule_date[1]) else ""), file)
      },
      contentType = "text/calendar"
    )

    # Titan calendar buttons (".ics load to calendar" / "Load events into calendar")
    drive_export_server(input, output, session, api_manager, group = "Day Planner", tab = "Visualizations",
      specs = reactive({
        d <- viz_data()
        if (is.null(d) || nrow(d) == 0) return(list())
        list(time_allocation = schedule_diagram_time(d))
      }),
      subject = function() { d <- viz_data(); if (is.null(d) || nrow(d) == 0) "general" else as.character(d$schedule_date[1]) })

    titan_viz_hook(input, output, session, api_manager, ics_result, "Day Planner")

    session$onSessionEnded(function() {})
  })
}
