# modules/Events Scheduling/browse_events.R
# ---- module ----------------------------------------------
# id:           browse_events
# name:         Browse Events
# icon:         table
# description:  Browse and download all stored events
# packages:     shiny, shinydashboard, DT
# -----------------------------------------------------------

# ---- UI ----
browse_events_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(
        title = "Browse All Events", status = "primary", solidHeader = TRUE, width = 12,

        fluidRow(
          column(2, actionButton(ns("refresh"), "Refresh Data",   class = "btn-primary", icon = icon("sync"))),
          column(2, downloadButton(ns("download"), "Download CSV", class = "btn-info")),
          column(2, downloadButton(ns("download_calendar"), "📅 Calendar", class = "btn-success")),
          column(2, selectInput(ns("filter_city"),     "Filter by City:",     choices = c("All" = ""))),
          column(2, selectInput(ns("filter_category"), "Filter by Category:", choices = c("All" = "")))
        ),

        br(),
        fluidRow(
          column(6, numericInput(ns("max_rows"), "Max Rows:", value = 200, min = 10, max = 2000, step = 50)),
          column(6, htmlOutput(ns("status")))
        ),

        br(),
        DT::dataTableOutput(ns("table"))
      )
    )
  )
}

# ---- Server ----
browse_events_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    all_data   <- reactiveVal(NULL)
    filter_data <- reactiveVal(NULL)

    load_data <- function() {
      if (!api_manager$bq_authenticated) {
        showNotification("Please authenticate with BigQuery first!", type = "error")
        return()
      }

      output$status <- renderUI({
        tags$div(class = "status-info", tags$i(class = "fa fa-spinner fa-spin"), " Loading data...")
      })

      tryCatch({
        query <- sprintf(
          "SELECT event_name, organiser, city, country, category, subcategory,
                  event_date, event_time, venue_name, address, latitude, longitude,
                  description, ticket_url, price_range, source_url, scan_date, created_at%s
           FROM `%s` ORDER BY event_date ASC, created_at DESC LIMIT %d",
          if (isTRUE(api_manager$bq_time_zone_ready[["events"]])) ", time_zone" else "",
          api_manager$bq_full_table_events, input$max_rows
        )
        data <- api_manager$bq_query(query)
        all_data(data)

        # Populate filter dropdowns
        if (nrow(data) > 0) {
          cities <- sort(unique(data$city[nchar(trimws(data$city)) > 0]))
          updateSelectInput(session, "filter_city",
                            choices = c("All" = "", setNames(cities, cities)),
                            selected = "")

          cats <- sort(unique(data$category[nchar(trimws(data$category)) > 0]))
          updateSelectInput(session, "filter_category",
                            choices = c("All" = "", setNames(cats, cats)),
                            selected = "")
        }

        apply_filters(data)

        output$status <- renderUI({
          tags$div(class = "status-success",
                   tags$i(class = "fa fa-check-circle"),
                   sprintf(" Loaded %d events", nrow(data)))
        })
        showNotification(sprintf("✓ Loaded %d events", nrow(data)), type = "message")

      }, error = function(e) {
        output$status <- renderUI({
          tags$div(class = "status-error",
                   tags$i(class = "fa fa-times-circle"), " Error: ", e$message)
        })
      })
    }

    apply_filters <- function(data = all_data()) {
      if (is.null(data)) return()
      filtered <- data

      if (!is.null(input$filter_city) && input$filter_city != "") {
        filtered <- filtered[filtered$city == input$filter_city, ]
      }
      if (!is.null(input$filter_category) && input$filter_category != "") {
        filtered <- filtered[filtered$category == input$filter_category, ]
      }

      filter_data(filtered)

      display_cols <- c("event_name", "city", "category", "subcategory",
                        "event_date", "event_time", "venue_name", "price_range", "ticket_url")
      display_cols <- intersect(display_cols, names(filtered))

      output$table <- DT::renderDataTable({
        DT::datatable(
          filtered[, display_cols],
          options   = list(pageLength = 25, scrollX = TRUE, dom = "Bfrtip"),
          rownames  = FALSE,
          escape    = FALSE,
          callback  = DT::JS("table.on('click', 'td', function(){});")
        )
      })
    }

    observeEvent(input$refresh, { load_data() })

    observeEvent(list(api_manager$state_trigger_events(), api_manager$tab_open("browse_events")), {
      if (api_manager$tab_open("browse_events") && api_manager$bq_authenticated) load_data()   # on first open + on refresh triggers
    }, ignoreInit = TRUE)

    observeEvent(input$filter_city,     { apply_filters() }, ignoreInit = TRUE)
    observeEvent(input$filter_category, { apply_filters() }, ignoreInit = TRUE)

    output$download <- downloadHandler(
      filename = function() paste0("events_", format(Sys.Date(), "%Y%m%d"), ".csv"),
      content  = function(file) {
        d <- if (!is.null(filter_data())) filter_data() else all_data()
        if (!is.null(d)) {
          cat("📥 [browse_events] Downloading CSV:", nrow(d), "rows →", file, "\n")
          write.csv(d, file, row.names = FALSE)
          cat("✅ [browse_events] CSV written\n")
        } else {
          cat("⚠️  [browse_events] No data to download\n")
        }
      }
    )

    output$download_calendar <- downloadHandler(
      filename = function() paste0("events_", format(Sys.Date(), "%Y%m%d"), ".ics"),
      content = function(file) {
        tryCatch({
          data <- if (!is.null(filter_data())) filter_data() else all_data()
          if (is.null(data) || nrow(data) == 0) {
            showNotification("No events to export", type = "warning")
            return()
          }

          # Rename columns for calendar export
          cal_data <- data
          if ("event_date" %in% names(cal_data)) names(cal_data)[names(cal_data) == "event_date"] <- "date"
          if ("event_time" %in% names(cal_data)) names(cal_data)[names(cal_data) == "event_time"] <- "time"
          if ("event_name" %in% names(cal_data)) names(cal_data)[names(cal_data) == "event_name"] <- "name"
          if ("venue_name" %in% names(cal_data)) names(cal_data)[names(cal_data) == "venue_name"] <- "location"

          ics_lines <- generate_calendar_ics(
            title = "Events Calendar",
            items = cal_data,
            date_col = "date",
            time_col = if ("time" %in% names(cal_data)) "time" else NULL,
            duration_minutes = 120,
            description = "Event - Exported from Business Operations Suite",
            location = if ("location" %in% names(cal_data)) cal_data$location[1] else "",
            item_col = if ("name" %in% names(cal_data)) "name" else "event_name"
          )

          export_calendar_file(ics_lines, file)
          showNotification("✓ Events calendar exported successfully", type = "message")

        }, error = function(e) {
          showNotification(paste("Error exporting calendar:", e$message), type = "error")
        })
      }
    )

    output$status <- renderUI({ tags$div() })
    output$table  <- DT::renderDataTable({})
    session$onSessionEnded(function() {})
  })
}
