# modules/Contact Manager/contacts_explore.R
# ---- module ----------------------------------------------
# id:           contacts_explore
# name:         Explore Contacts
# icon:         search
# description:  Browse, filter, and manage contacts
# packages:     shiny, shinydashboard, DT
# -----------------------------------------------------------

# ---- UI ----
contacts_explore_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "Filter Contacts", status = "info", solidHeader = TRUE, width = 12,
          fluidRow(
            column(2, selectInput(ns("filter_industry"), "Industry:", choices = c("All" = ""), selected = "")),
            column(2, selectInput(ns("filter_country"), "Country:", choices = c("All" = ""), selected = "")),
            column(2, selectInput(ns("filter_location"), "Location:", choices = c("All" = ""), selected = "")),
            column(2, selectInput(ns("filter_university"), "University:", choices = c("All" = ""), selected = "")),
            column(2, selectInput(ns("filter_company"), "Company:", choices = c("All" = ""), selected = "")),
            column(2, br(), actionButton(ns("refresh_data"), "Refresh Data", class = "btn-info", icon = icon("sync"), style = "width: 100%;"))
          ),
          br(),
          actionButton(ns("apply_filters"), "Apply Filters", class = "btn-primary", icon = icon("filter")),
          actionButton(ns("clear_filters"), "Clear Filters", class = "btn-warning", icon = icon("times"))
      )
    ),
    fluidRow(
      box(title = "Contacts Table", status = "primary", solidHeader = TRUE, width = 12,
          p("Click on a row to select it. Double-click a cell to edit inline."),
          DT::dataTableOutput(ns("contacts_table")),
          br(),
          htmlOutput(ns("table_status"))
      )
    ),
    fluidRow(
      box(title = "Actions for Selected Contact", status = "success", solidHeader = TRUE, width = 12,
          p("Select a contact and choose an action below."),
          fluidRow(
            column(4, actionButton(ns("customise_comm"), "Customise Communication", class = "btn-primary", icon = icon("comments"), style = "width: 100%;")),
            column(4, actionButton(ns("update_record"), "Update Modified Record", class = "btn-success", icon = icon("save"), style = "width: 100%;")),
            column(4, actionButton(ns("delete_record"), "Delete Selected Record", class = "btn-danger", icon = icon("trash"), style = "width: 100%;"))
          ),
          br(),
          htmlOutput(ns("update_status"))
      )
    ),

    generic_export_box_ui(ns, title = "Save Contacts")
  )
}

# ---- Server ----
contacts_explore_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {

    all_contacts <- reactiveVal(data.frame())
    edited_contacts <- reactiveVal(data.frame())

    load_contacts <- function() {
      if (!api_manager$bq_authenticated) return(invisible(NULL))
      data <- tryCatch(api_manager$bq_get_contacts(), error = function(e) data.frame())
      all_contacts(data)
      edited_contacts(data)
      if (nrow(data) > 0) {
        updateSelectInput(session, "filter_industry", choices = c("All" = "", sort(unique(data$industry[nchar(trimws(data$industry)) > 0]))))
        updateSelectInput(session, "filter_country", choices = c("All" = "", sort(unique(data$country[nchar(trimws(data$country)) > 0]))))
        updateSelectInput(session, "filter_location", choices = c("All" = "", sort(unique(data$location[nchar(trimws(data$location)) > 0]))))
        updateSelectInput(session, "filter_university", choices = c("All" = "", sort(unique(data$university[nchar(trimws(data$university)) > 0]))))
        updateSelectInput(session, "filter_company", choices = c("All" = "", sort(unique(data$company[nchar(trimws(data$company)) > 0]))))
      }
      output$table_status <- renderUI({
        tags$div(class = "status-success", tags$i(class = "fa fa-check-circle"), sprintf(" Loaded %d contact(s)", nrow(data)))
      })
    }

    observeEvent(input$refresh_data, { load_contacts() })
    observeEvent(list(api_manager$state_trigger_contacts(), api_manager$tab_open("contacts_explore")),
                 { if (api_manager$tab_open("contacts_explore") && api_manager$bq_authenticated) load_contacts() }, ignoreInit = TRUE)   # on first open + on refresh triggers

    filtered <- reactive({
      d <- edited_contacts()
      if (nrow(d) == 0) return(d)
      if (nchar(input$filter_industry %||% "") > 0) d <- d[d$industry == input$filter_industry, ]
      if (nchar(input$filter_country %||% "") > 0) d <- d[d$country == input$filter_country, ]
      if (nchar(input$filter_location %||% "") > 0) d <- d[d$location == input$filter_location, ]
      if (nchar(input$filter_university %||% "") > 0) d <- d[d$university == input$filter_university, ]
      if (nchar(input$filter_company %||% "") > 0) d <- d[d$company == input$filter_company, ]
      d
    })

    observeEvent(input$clear_filters, {
      updateSelectInput(session, "filter_industry", selected = "")
      updateSelectInput(session, "filter_country", selected = "")
      updateSelectInput(session, "filter_location", selected = "")
      updateSelectInput(session, "filter_university", selected = "")
      updateSelectInput(session, "filter_company", selected = "")
    })

    output$contacts_table <- DT::renderDataTable({
      input$apply_filters; input$clear_filters
      DT::datatable(filtered(), selection = "single", editable = TRUE,
                    options = list(scrollX = TRUE, pageLength = 10), rownames = FALSE)
    })

    observeEvent(input$contacts_table_cell_edit, {
      info <- input$contacts_table_cell_edit
      d <- filtered()
      d[info$row, info$col + 1] <- info$value
      # Write the edit back into the full (unfiltered) working copy, keyed by contact_id
      full <- edited_contacts()
      full[full$contact_id == d$contact_id[info$row], ] <- d[info$row, ]
      edited_contacts(full)
    })

    observeEvent(input$customise_comm, {
      sel <- input$contacts_table_rows_selected
      if (is.null(sel)) { showNotification("Please select a contact first.", type = "warning"); return() }
      contact <- filtered()[sel, ]
      api_manager$set_contacts_selected_contact(as.list(contact))
      nav_goto(session, "contacts_customise_communication")
    })

    observeEvent(input$update_record, {
      sel <- input$contacts_table_rows_selected
      if (is.null(sel)) { showNotification("Please select a contact first.", type = "warning"); return() }
      if (!api_manager$bq_authenticated) { showNotification("Please authenticate with BigQuery first!", type = "error"); return() }

      tryCatch({
        contact <- filtered()[sel, ]
        updatable_cols <- setdiff(names(contact), c("contact_id", "created_at", "updated_at"))
        updates <- as.list(contact[updatable_cols])
        api_manager$bq_update_contact(contact$contact_id, updates)

        output$update_status <- renderUI({
          tags$div(class = "status-success", tags$i(class = "fa fa-check-circle"), " Contact updated successfully!")
        })
        showNotification("✓ Contact updated!", type = "message")

      }, error = function(e) {
        output$update_status <- renderUI({ tags$div(class = "status-error", tags$i(class = "fa fa-times-circle"), " Error: ", e$message) })
        showNotification(paste("Error:", e$message), type = "error")
      })
    })

    observeEvent(input$delete_record, {
      sel <- input$contacts_table_rows_selected
      if (is.null(sel)) { showNotification("Please select a contact first.", type = "warning"); return() }
      contact <- filtered()[sel, ]

      showModal(modalDialog(
        title = "Confirm Delete",
        sprintf("Are you sure you want to delete '%s'? This cannot be undone.", contact$full_name),
        footer = tagList(modalButton("Cancel"),
                         actionButton(session$ns("confirm_delete"), "Delete", class = "btn-danger"))
      ))
      session$userData$pending_delete_id <- contact$contact_id
    })

    observeEvent(input$confirm_delete, {
      removeModal()
      if (!api_manager$bq_authenticated) { showNotification("Please authenticate with BigQuery first!", type = "error"); return() }
      tryCatch({
        api_manager$bq_delete_contact(session$userData$pending_delete_id)
        output$update_status <- renderUI({
          tags$div(class = "status-warning", tags$i(class = "fa fa-trash"), " Contact deleted.")
        })
        showNotification("Contact deleted", type = "warning")
      }, error = function(e) {
        showNotification(paste("Error:", e$message), type = "error")
      })
    })

    output$table_status <- renderUI({ tags$div("Click Refresh Data to load contacts.") })
    output$update_status <- renderUI({ tags$div() })

    # ── Save as HTML/PDF (shared generic exporter, see R/utils_export.R) ──
    output$export_download <- downloadHandler(
      filename = function() {
        paste0("contacts_export_", format(Sys.Date(), "%Y%m%d"), if (identical(input$export_format, "pdf")) ".pdf" else ".html")
      },
      content = function(file) {
        tryCatch({
          d <- filtered()
          if (is.null(d) || nrow(d) == 0) {
            writeLines("<html><body><p>No contacts loaded - click Refresh Data first.</p></body></html>", file)
            return()
          }

          cols <- c("full_name", "company", "job_title", "industry", "email", "phone", "location")
          labels <- c("Name", "Company", "Title", "Industry", "Email", "Phone", "Location")
          subtitle <- sprintf("%d contact(s)", nrow(d))

          if (identical(input$export_format, "pdf")) {
            ok <- generate_generic_pdf(file, "Contacts", subtitle, d, cols, labels)
            if (!isTRUE(ok)) stop("PDF generation failed internally - see console log above for the real cause")
          } else {
            result <- generate_generic_html("Contacts", subtitle, d, cols, labels)
            writeLines(result$content, file)
          }
        }, error = function(e) {
          cat("\u274c [contacts_explore export] Error:", e$message, "\n")
          writeLines(c("<html><body>", "<h2>Export failed</h2>",
                       paste0("<p>", htmltools::htmlEscape(e$message), "</p>"),
                       "<p>Check the Debug Console (API Configuration group) for full detail.</p>",
                       "</body></html>"), file)
        })
      }
    )
    output$export_status <- renderUI({ tags$div() })

    session$onSessionEnded(function() {})
  })
}
