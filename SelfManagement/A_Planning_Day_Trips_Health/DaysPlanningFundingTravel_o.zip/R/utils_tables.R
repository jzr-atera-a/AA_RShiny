# R/utils_tables.R
# ON-DEMAND TABLE CHECKS
# Start-up only connects (one quick round trip). Each tab group verifies its own BigQuery tables the first time
# it is opened, and the sidebar shows what is being checked right under the Claude / BigQuery lights.
#
#   tab group (registry id)  -> unit        tables
#   day_planner              -> planner     day_scheduler, day_prep_steps, monthly_commitments
#   diet_planner             -> diet        diet_log
#   exercise_tracker         -> exercise    exercise_log      (the four Muscle tabs use their own unit below)
#   (muscle_* tabs)          -> muscle      muscle_programmes, muscle_diagrams, muscle_set_log, muscle_targets
#   events_scheduling        -> events      city_events (+ schema compatibility)
#   funding_programmes       -> funding     funding_programmes
#   gantt_tickets            -> gantt       gantt_tasks, gantt_contacts
#   contact_manager          -> contacts    business_contacts, contact_communications
# Groups without BigQuery tables (API Configuration, Travel, Online Collaboration) check nothing.
# Safety net: every data method in APIManager also calls bq_need(), so a table is never used unverified.

TABLE_GROUP_UNITS <- c(day_planner = "planner", diet_planner = "diet", exercise_tracker = "exercise", events_scheduling = "events",
                       funding_programmes = "funding", gantt_tickets = "gantt", contact_manager = "contacts")
TABLE_MODULE_UNITS <- c(muscle_programme = "muscle", muscle_log = "muscle", muscle_map = "muscle", muscle_progress = "muscle")

# tab name -> unit, built from the registry (a module listed in TABLE_MODULE_UNITS overrides its group's unit)
tables_tab_units <- function(registry_groups, enabled_modules) {
  tabs <- list()
  ids <- vapply(enabled_modules, function(m) m$module$id, "")
  for (g in registry_groups) {
    for (mid in intersect(g$modules, ids)) {
      m <- enabled_modules[[which(ids == mid)[1]]]
      u <- if (mid %in% names(TABLE_MODULE_UNITS)) TABLE_MODULE_UNITS[[mid]] else TABLE_GROUP_UNITS[g$id]
      if (!is.null(u) && !is.na(u)) tabs[[m$module$menu$tabname]] <- unname(u)
    }
  }
  tabs
}

tables_status_box <- function() tagList(
  tags$div(style = "padding:10px; margin:6px 10px; background:rgba(0,0,0,.18); border-radius:8px;",
           tags$div(style = "color:#b2e0db; font-size:11px; font-weight:700; margin-bottom:4px;", "TABLES"),
           uiOutput("tables_status")))

# Wires the sidebar clicks to the table checks. `session` is the ROOT session (inputs of the sidebar live there).
tables_wire <- function(api, session, tab_units) {
  rv <- shiny::reactiveVal(0)
  bump <- function() rv(shiny::isolate(rv()) + 1)
  pending <- new.env(); pending$busy <- FALSE

  run_unit <- function(unit) {
    if (isTRUE(api$bq_units_ready[[unit]]) && isTRUE(api$bq_units_opened[[unit]])) return(invisible())   # already done
    st <- api$bq_unit_status[[unit]]
    if (!isTRUE(api$bq_authenticated)) {            # not connected yet: remember the click, the check runs after connecting
      api$bq_units_opened[[unit]] <- TRUE
      api$bq_note_status(unit, "waiting", "waiting for the BigQuery connection")
      bump(); return(invisible())
    }
    if (isTRUE(api$bq_units_ready[[unit]])) { api$bq_units_opened[[unit]] <- TRUE; api$bq_fire_unit(unit); return(invisible()) }
    api$bq_note_status(unit, "checking", "checking tables...")
    bump()
    # the "checking" note is sent to the browser FIRST (flush), then the blocking check runs
    session$onFlushed(function() {
      shiny::withReactiveDomain(session, shiny::isolate({
        tryCatch(api$bq_open_unit(unit), error = function(e) api$bq_note_status(unit, "failed", conditionMessage(e)))
        bump()
      }))
    }, once = TRUE)
  }

  shiny::observeEvent(session$input$sidebarItemExpanded, {          # a tab group was expanded
    g <- session$input$sidebarItemExpanded
    u <- TABLE_GROUP_UNITS[g]; if (!is.null(u) && !is.na(u)) run_unit(unname(u))
  }, ignoreNULL = TRUE, ignoreInit = TRUE)
  shiny::observeEvent(session$input$sidebar_menu, {                 # a tab was opened (also covers links between tabs)
    u <- tab_units[[session$input$sidebar_menu]]; if (!is.null(u)) run_unit(u)
  }, ignoreNULL = TRUE, ignoreInit = FALSE)
  # when the connection arrives later (manual key), run the checks for groups already opened
  shiny::observe({
    shiny::invalidateLater(1500)
    if (isTRUE(api$bq_authenticated)) for (u in names(api$bq_unit_status))
      if (identical(api$bq_unit_status[[u]]$state, "waiting")) run_unit(u)
  })

  session$output$tables_status <- shiny::renderUI({
    rv(); shiny::invalidateLater(3000)
    stt <- api$bq_unit_status
    if (!length(stt)) return(tags$div(style = "font-size:11px; color:#b2e0db;",
                                      "Tables are checked the first time you open a tab group."))
    stt <- stt[order(vapply(stt, function(x) as.numeric(x$at), 0), decreasing = TRUE)]
    tagList(lapply(utils::head(stt, 5), function(x) {
      col <- switch(x$state, ready = "#22c55e", checking = "#fbbf24", waiting = "#fbbf24", "#ef4444")
      txt <- switch(x$state, checking = "checking tables...", waiting = "waiting for BigQuery", ready = x$detail,
                    paste0("check failed: ", substr(x$detail, 1, 80)))
      tags$div(style = "display:flex; gap:6px; margin:3px 0; font-size:11.5px; color:#ecf0f1;",
               if (x$state == "checking") icon("spinner", class = "fa-spin", style = "color:#fbbf24; margin-top:2px; flex:none;")
               else tags$span(style = sprintf("display:inline-block; width:10px; height:10px; border-radius:50%%; background:%s; margin-top:3px; flex:none;", col)),
               tags$span(tags$b(x$label, ": "), txt))
    }))
  })
  invisible(rv)
}
