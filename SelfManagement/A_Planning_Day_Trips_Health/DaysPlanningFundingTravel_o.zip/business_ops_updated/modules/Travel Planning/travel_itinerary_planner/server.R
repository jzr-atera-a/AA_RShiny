# modules/Travel Planning/travel_itinerary_planner/server.R
# Travel Itinerary Planner Server Logic with Claude API


# ==================
# MAP HELPER FUNCTIONS
# ==================

extract_itinerary_data <- function(itinerary_text) {
  tryCatch({
    json_start <- regexpr("```json", itinerary_text, fixed = TRUE)[1]
    json_end <- regexpr("```", substr(itinerary_text, json_start + 7, nchar(itinerary_text)), fixed = TRUE)[1]
    
    if (json_start > 0 && json_end > 0) {
      json_text <- substring(itinerary_text, json_start + 7, json_start + 7 + json_end - 2)
      itinerary_data <- jsonlite::fromJSON(json_text)
      return(itinerary_data$itinerary)
    }
    return(NULL)
  }, error = function(e) NULL)
}

prepare_map_data <- function(itinerary_list) {
  tryCatch({
    map_data <- data.frame()
    if (is.null(itinerary_list) || length(itinerary_list) == 0) return(data.frame())
    
    for (day_idx in seq_along(itinerary_list)) {
      day_obj <- itinerary_list[[day_idx]]
      day_num <- if (!is.null(day_obj$day)) day_obj$day else day_idx
      activities <- day_obj$activities
      if (!is.list(activities)) next
      
      for (act_idx in seq_along(activities)) {
        activity <- activities[[act_idx]]
        lat <- suppressWarnings(as.numeric(activity$latitude))
        lon <- suppressWarnings(as.numeric(activity$longitude))
        if (is.na(lat) || is.na(lon)) next
        
        day_label <- if (!is.null(activity$day_label)) activity$day_label else 
                     if (!is.null(day_obj$day_label)) day_obj$day_label else 
                     paste0("Day ", day_num)
        
        map_data <- rbind(map_data, data.frame(
          day = day_num,
          day_label = day_label,
          order = if (!is.null(activity$order)) activity$order else act_idx,
          name = if (!is.null(activity$name)) activity$name else "Unnamed",
          time_start = if (!is.null(activity$time_start)) activity$time_start else "00:00",
          time_end = if (!is.null(activity$time_end)) activity$time_end else "00:00",
          description = if (!is.null(activity$description)) activity$description else "",
          latitude = lat,
          longitude = lon,
          marker_label = paste0(if (!is.null(activity$order)) activity$order else act_idx),
          stringsAsFactors = FALSE
        ))
      }
    }
    return(map_data)
  }, error = function(e) data.frame())
}

travel_itinerary_planner_server <- function(id, api_manager) {
  moduleServer(id, function(input, output, session) {
    
    ns <- session$ns
    
    # ==================
    # Reactive Values
    # ==================
    rv <- reactiveValues(
      discovered_places = NULL,
      selected_places = character(0),
      generated_itinerary = NULL,
      places_data = NULL,
      itinerary_data = NULL,
      map_data = NULL,
      selected_attraction = NULL
    )
    
    # ==================
    # DATE HANDLING
    # ==================
    
    # Calculate duration when dates change
    observeEvent(input$trip_start_date, {
      if (!is.null(input$trip_end_date)) {
        duration <- as.numeric(difftime(input$trip_end_date, input$trip_start_date, units = "days")) + 1
        duration <- max(1, min(duration, 7))  # Constrain to 1-7 days
        
        # Update the slider
        updateSliderInput(session, "num_days", value = duration)
      }
    })
    
    observeEvent(input$trip_end_date, {
      if (!is.null(input$trip_start_date)) {
        duration <- as.numeric(difftime(input$trip_end_date, input$trip_start_date, units = "days")) + 1
        duration <- max(1, min(duration, 7))  # Constrain to 1-7 days
        
        # Update the slider
        updateSliderInput(session, "num_days", value = duration)
      }
    })
    
    # Display calculated duration
    output$duration_display <- renderText({
      if (!is.null(input$trip_start_date) && !is.null(input$trip_end_date)) {
        duration <- as.numeric(difftime(input$trip_end_date, input$trip_start_date, units = "days")) + 1
        duration <- max(1, min(duration, 7))
        start_str <- format(input$trip_start_date, "%b %d, %Y")
        end_str <- format(input$trip_end_date, "%b %d, %Y")
        paste0(" <strong style='color: #27ae60;'>", duration, " day", 
               if(duration != 1) "s" else "", 
               "</strong> (", start_str, " to ", end_str, ")")
      } else {
        " (Select dates to calculate)"
      }
    })
    
    # ==================
    # STEP 1: DISCOVER PLACES
    # ==================
    observeEvent(input$discover_places, {
      req(input$destination, input$num_places)
      
      # Show loading spinner
      shinyjs::hide("places_checkboxes", anim = TRUE)
      shinyjs::show("loading_spinner", anim = TRUE)
      output$discovery_status <- renderUI({
        tags$div(class = "alert alert-info",
                tags$strong("Status: "), "Discovering attractions in ", input$destination, "...")
      })
      
      tryCatch({
        # Build prompt for Claude
        prompt <- paste0(
          "Please provide the top ", input$num_places, " places to visit in ", input$destination, 
          " according to TripAdvisor and other reputable tourism sources.\n\n",
          "Format your response EXACTLY as follows - one place per line, numbered:\n",
          "1. Attraction Name (Category)\n",
          "2. Another Attraction (Category)\n",
          "... and so on\n\n",
          "Categories can be: Museum, Park, Landmark, Restaurant, Historical Site, Shopping, ",
          "Entertainment, Nature, Cultural Site, etc.\n\n",
          "Only provide the numbered list with no additional text or explanations."
        )
        
        # Call Claude API
        if (!is.null(api_manager)) {
          response <- api_manager$call_claude_api(prompt)
        } else {
          stop("API Manager not available. Please configure Claude API credentials first.")
        }
        
        # Parse response into places
        lines <- strsplit(response, "\n")[[1]]
        places_list <- grep("^\\d+\\.", lines, value = TRUE)
        places_list <- trimws(places_list)
        places_list <- places_list[places_list != ""]
        
        if (length(places_list) == 0) {
          stop("No places found in response. Please try again.")
        }
        
        # Store places data
        rv$places_data <- data.frame(
          id = seq_along(places_list),
          name = places_list,
          selected = FALSE,
          stringsAsFactors = FALSE
        )
        
        rv$discovered_places <- places_list
        rv$selected_places <- character(0)
        
        # Hide loading, show places
        shinyjs::hide("loading_spinner", anim = TRUE)
        shinyjs::show("places_checkboxes", anim = TRUE)
        
        output$discovery_status <- renderUI({
          tags$div(class = "alert alert-success",
                  tags$strong("✓ Success! "), "Found ", length(places_list), " attractions in ", 
                  input$destination, ". Select the ones you want to visit.")
        })
        
        # Render checkboxes
        output$places_checkboxes <- renderUI({
          if (is.null(rv$places_data)) return(NULL)
          
          lapply(1:nrow(rv$places_data), function(i) {
            div(
              style = "margin-bottom: 10px;",
              checkboxInput(ns(paste0("place_", i)), 
                          rv$places_data$name[i],
                          value = FALSE),
              tags$small(class = "text-muted", style = "margin-left: 20px;")
            )
          })
        })
        
      }, error = function(e) {
        shinyjs::hide("loading_spinner", anim = TRUE)
        output$discovery_status <- renderUI({
          tags$div(class = "alert alert-danger",
                  tags$strong("Error: "), e$message)
        })
        showNotification(paste("Error discovering places:", e$message), type = "error", duration = 10)
      })
    })
    
    # Update selected places count
    output$places_counter <- renderUI({
      req(rv$places_data)
      selected_count <- sum(sapply(1:nrow(rv$places_data), function(i) {
        isTRUE(input[[paste0("place_", i)]])
      }))
      tags$span(tags$strong("Selected: "), selected_count, " / ", nrow(rv$places_data))
    })
    
    # Select all places
    observeEvent(input$select_all_places, {
      if (!is.null(rv$places_data)) {
        for (i in 1:nrow(rv$places_data)) {
          shinyjs::runjs(paste0("$('#", ns(paste0("place_", i)), "').prop('checked', true).change();"))
        }
      }
    })
    
    # Deselect all places
    observeEvent(input$deselect_all_places, {
      if (!is.null(rv$places_data)) {
        for (i in 1:nrow(rv$places_data)) {
          shinyjs::runjs(paste0("$('#", ns(paste0("place_", i)), "').prop('checked', false).change();"))
        }
      }
    })
    
    # Reset discovery
    observeEvent(input$reset_discovery, {
      rv$discovered_places <- NULL
      rv$selected_places <- character(0)
      rv$places_data <- NULL
      output$places_checkboxes <- renderUI(NULL)
      output$discovery_status <- renderUI(NULL)
      shinyjs::show("places_checkboxes", anim = TRUE)
      shinyjs::hide("loading_spinner", anim = TRUE)
    })
    
    # ==================
    # STEP 2 & 3: GENERATE ITINERARY
    # ==================
    observeEvent(input$generate_itinerary, {
      req(input$destination, input$num_days)
      
      # Get selected places
      if (!is.null(rv$places_data)) {
        selected_indices <- which(sapply(1:nrow(rv$places_data), function(i) {
          isTRUE(input[[paste0("place_", i)]])
        }))
        
        if (length(selected_indices) == 0) {
          showNotification("Please select at least one place to visit!", type = "warning")
          return()
        }
        
        selected_places_list <- rv$places_data$name[selected_indices]
      } else {
        showNotification("Please discover places first!", type = "warning")
        return()
      }
      
      # Show loading spinner
      shinyjs::show("itinerary_loading_spinner", anim = TRUE)
      shinyjs::hide("itinerary_content", anim = TRUE)
      output$itinerary_status <- renderUI({
        tags$div(class = "alert alert-info",
                tags$strong("Status: "), "Generating your personalized itinerary...")
      })
      
      tryCatch({
        # Build comprehensive prompt for itinerary generation
        selected_places_text <- paste(sprintf("- %s", selected_places_list), collapse = "\n")
        
        constraints_text <- if (input$constraints == "") {
          "No specific constraints."
        } else {
          paste("User constraints:\n", input$constraints)
        }
        
        prompt <- paste0(
          "Create a detailed ", input$num_days, "-day itinerary for visiting ", input$destination, ".\\n\\n",
          "TRIP DATES:\\n",
          "- Start Date: ", format(input$trip_start_date, "%A, %B %d, %Y"), "\\n",
          "- End Date: ", format(input$trip_end_date, "%A, %B %d, %Y"), "\\n",
          "- Total Days: ", input$num_days, "\\n\\n",
          "SELECTED ATTRACTIONS (must include all of these):\\n",
          selected_places_text, "\\n\\n",
          "TRIP PARAMETERS:\\n",
          "- Location: ", input$destination, "\\n",
          "- Daily start time: ", input$start_time, "\\n",
          "- Daily end time: ", input$end_time, "\\n\\n",
          "CONSTRAINTS & PREFERENCES:\\n", constraints_text, "\\n\\n",
          "REQUIREMENTS FOR YOUR RESPONSE:\\n",
          "1. Create a day-by-day breakdown for each day from ", format(input$trip_start_date, "%B %d"), " to ", format(input$trip_end_date, "%B %d"), "\\n",
          "2. Include exact times for each activity (e.g., 9:00-11:00 AM: CN Tower)\\n",
          "3. Include travel time between attractions using public transit estimates\\n",
          "4. Include 1-2 meal breaks per day at appropriate times\\n",
          "5. Group nearby attractions to minimize travel\\n",
          "6. Provide realistic visit durations based on the attraction type\\n",
          "7. Include transit details (subway lines, streetcars, walking time)\\n",
          "8. Format as clear text with day headers (e.g., 'DAY 1: ", format(input$trip_start_date, "%A, %B %d"), "')\\\\
",
          "9. Include opening hours verification and seasonal considerations\\n",
          "10. Add weather-appropriate tips for each day (umbrella, sunscreen, etc.)\\n",
          "11. Consider weather patterns for ", input$destination, " during ", format(input$trip_start_date, "%B"), "\\n\\n",
          "12. CRITICAL: Include ACCURATE GPS coordinates (latitude/longitude) for EVERY single attraction\\n",
          "13. CRITICAL: After your human-readable itinerary, add a JSON block at the very end (wrapped in ```json and ```) with this exact structure:\\n\\n",
          "```json\\n",
          "{\\n",
          "  \"itinerary\": [\\n",
          "    {\\n",
          "      \"day\": 1,\\n",
          "      \"day_label\": \"Monday, September 15, 2026\",\\n",
          "      \"activities\": [\\n",
          "        {\\n",
          "          \"order\": 1,\\n",
          "          \"name\": \"Attraction Name\",\\n",
          "          \"time_start\": \"09:00\",\\n",
          "          \"time_end\": \"11:00\",\\n",
          "          \"description\": \"Brief description\",\\n",
          "          \"latitude\": 43.6426,\\n",
          "          \"longitude\": -79.3871\\n",
          "        }\\n",
          "      ]\\n",
          "    }\\n",
          "  ]\\n",
          "}\\n",
          "```\\n\\n",
          "Please create the itinerary now, optimized for minimum travel distance between attractions and maximum enjoyment."
        )
        # Call Claude API
        if (!is.null(api_manager)) {
          itinerary_response <- api_manager$call_claude_api(prompt)
        } else {
          stop("API Manager not available. Please configure Claude API credentials first.")
        }
        
        # Store generated itinerary
        rv$generated_itinerary <- itinerary_response
        
        # Extract and process map data
        rv$itinerary_data <- extract_itinerary_data(itinerary_response)
        rv$map_data <- prepare_map_data(rv$itinerary_data)
        
        # Hide loading, show content
        shinyjs::hide("itinerary_loading_spinner", anim = TRUE)
        shinyjs::show("itinerary_content", anim = TRUE)
        
        output$itinerary_html <- renderUI({
          # Format the itinerary with better readability
          itinerary_formatted <- gsub("\\n", "<br/>", itinerary_response)
          itinerary_formatted <- gsub("DAY (\\d+)", "<h3 style='color: #27ae60; margin-top: 20px;'>DAY \\1</h3>", 
                                     itinerary_formatted)
          
          HTML(paste0(
            "<div style='background-color: #f9f9f9; padding: 20px; border-radius: 4px; ",
            "border-left: 4px solid #27ae60;'>",
            itinerary_formatted,
            "</div>"
          ))
        })
        
        output$itinerary_status <- renderUI({
          tags$div(class = "alert alert-success",
                  tags$strong("✓ Itinerary Generated! "),
                  "Your ", input$num_days, "-day plan is ready. ",
                  "You can refine it, download it, or start a new search.",
                  style = "margin-top: 20px;")
        })
        
      }, error = function(e) {
        shinyjs::hide("itinerary_loading_spinner", anim = TRUE)
        output$itinerary_status <- renderUI({
          tags$div(class = "alert alert-danger",
                  tags$strong("Error: "), e$message)
    
    # ==================
    # MAP RENDERING
    # ==================
    
    output$trip_map <- plotly::renderPlotly({
      req(rv$map_data)
      md <- rv$map_data
      
      if (nrow(md) == 0) {
        return(plotly::plot_ly() %>% plotly::layout(title = "No location data"))
      }
      
      day_colors <- c("#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8", "#F7DC6F", "#BB8FCE")
      
      p <- plotly::plot_ly(source = "trip_map_click")
      
      for (day_val in unique(md$day)) {
        day_data <- md[md$day == day_val, ]
        day_color <- day_colors[(day_val - 1) %% length(day_colors) + 1]
        
        p <- p %>%
          plotly::add_trace(
            data = day_data,
            type = "scattermapbox",
            lon = ~longitude,
            lat = ~latitude,
            mode = "markers+text",
            text = ~marker_label,
            textposition = "middle center",
            textfont = list(color = "white", size = 14, family = "Arial Black"),
            marker = list(size = 35, color = day_color, opacity = 0.85,
                         line = list(color = "white", width = 2)),
            customdata = ~paste0(day, "|", order),
            hovertemplate = "<b>Stop #%{text}</b><br>%{customdata}<extra></extra>",
            name = paste0("Day ", day_val),
            showlegend = TRUE
          )
      }
      
      center_lat <- mean(md$latitude, na.rm = TRUE)
      center_lon <- mean(md$longitude, na.rm = TRUE)
      lat_range <- max(md$latitude) - min(md$latitude)
      lon_range <- max(md$longitude) - min(md$longitude)
      max_range <- max(lat_range, lon_range)
      zoom <- if (max_range > 2) 11 else if (max_range > 0.5) 12 else 13
      
      p %>%
        plotly::layout(
          mapbox = list(style = "open-street-map",
                       center = list(lon = center_lon, lat = center_lat),
                       zoom = zoom),
          margin = list(l = 0, r = 0, t = 0, b = 0),
          showlegend = TRUE,
          legend = list(orientation = "v", x = 0.02, y = 0.98)
        ) %>%
        plotly::config(displaylogo = FALSE, responsive = TRUE)
    })
    
    # ==================
    # MAP CLICK HANDLER
    # ==================
    
    observeEvent(plotly::event_data("plotly_click", source = "trip_map_click"), {
      click <- plotly::event_data("plotly_click", source = "trip_map_click")
      if (!is.null(click) && !is.null(click$customdata)) {
        parts <- strsplit(click$customdata[1], "\\|")[[1]]
        if (length(parts) == 2) {
          selected_day <- as.numeric(parts[1])
          selected_order <- as.numeric(parts[2])
          rv$selected_attraction <- paste0(selected_day, "_", selected_order)
        }
      }
    })
    
    # ==================
    # ATTRACTION DETAIL
    # ==================
    
    output$attraction_detail <- renderUI({
      if (is.null(rv$selected_attraction) || is.null(rv$map_data) || nrow(rv$map_data) == 0) {
        return(tags$p("Click on a marker", class = "text-muted"))
      }
      
      parts <- strsplit(rv$selected_attraction, "_")[[1]]
      if (length(parts) != 2) return(tags$p("Click on marker", class = "text-muted"))
      
      attraction <- rv$map_data[rv$map_data$day == as.numeric(parts[1]) & 
                                rv$map_data$order == as.numeric(parts[2]), ]
      
      if (nrow(attraction) == 0) return(tags$p("No data", class = "text-muted"))
      
      att <- attraction[1, ]
      tagList(
        tags$h4(icon("map-pin"), " ", att$name, style = "color: #27ae60;"),
        tags$hr(),
        tags$div(
          tags$strong("Date: "), tags$span(att$day_label), tags$br(),
          tags$strong("Stop #: "), tags$span(att$order), tags$br(),
          tags$strong("Time: "), tags$span(att$time_start, " - ", att$time_end), tags$br(),
          tags$strong("Location: "), tags$br(),
          tags$span(style = "font-family: monospace; font-size: 0.9em;",
            "Lat: ", round(att$latitude, 4), tags$br(),
            "Lon: ", round(att$longitude, 4)
          ), tags$br(),
          tags$br(),
          tags$strong("Description:"), tags$br(),
          tags$p(att$description, style = "font-size: 0.95em; line-height: 1.6;")
        )
      )
    })

        })
        showNotification(paste("Error generating itinerary:", e$message), type = "error", duration = 10)
      })
    })
    
    # ==================
    # DOWNLOAD ITINERARY
    # ==================
    output$download_itinerary <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.txt")
      },
      content = function(file) {
        if (!is.null(rv$generated_itinerary)) {
          writeLines(rv$generated_itinerary, file)
        }
      }
    )
    
    # ==================
    # EXPORT FORMATS: HTML, PDF, CALENDAR
    # ==================
    
    # HTML Export (with map placeholder)
    output$download_html <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.html")
      },
      content = function(file) {
        if (!is.null(rv$generated_itinerary)) {
          # Format itinerary for HTML
          itinerary_html_content <- gsub("\\n", "</p><p>", rv$generated_itinerary)
          itinerary_html_content <- gsub("DAY (\\d+)", "<h2 style='color: #27ae60; page-break-before: avoid; margin-top: 30px;'>DAY \\1</h2>", 
                                        itinerary_html_content)
          
          html_content <- paste0(
            "<!DOCTYPE html>",
            "<html lang='en'>",
            "<head>",
            "  <meta charset='UTF-8'>",
            "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
            "  <title>", input$destination, " - ", input$num_days, " Day Itinerary</title>",
            "  <style>",
            "    * { margin: 0; padding: 0; box-sizing: border-box; }",
            "    body { font-family: 'Segoe UI', Tahoma, Geneva, sans-serif; line-height: 1.6; color: #333; }",
            "    .container { max-width: 900px; margin: 0 auto; padding: 20px; }",
            "    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 8px; margin-bottom: 30px; text-align: center; }",
            "    .header h1 { font-size: 2.5em; margin-bottom: 10px; }",
            "    .header p { font-size: 1.1em; opacity: 0.9; }",
            "    .trip-info { background: #f0f7ff; border-left: 4px solid #667eea; padding: 15px; margin-bottom: 30px; border-radius: 4px; }",
            "    .trip-info p { margin: 8px 0; }",
            "    h2 { color: #27ae60; margin-top: 40px; margin-bottom: 15px; border-bottom: 2px solid #27ae60; padding-bottom: 10px; }",
            "    p { margin-bottom: 12px; text-align: justify; }",
            "    .map-section { margin: 40px 0; padding: 30px; background: #f5f5f5; border: 2px dashed #ccc; border-radius: 8px; text-align: center; }",
            "    .map-section h3 { color: #667eea; margin-bottom: 10px; }",
            "    .map-section p { color: #999; font-size: 0.95em; }",
            "    .footer { text-align: center; margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 0.9em; }",
            "    @media print { .map-section { page-break-inside: avoid; } }",
            "    @media (max-width: 768px) { .header { padding: 20px; } .header h1 { font-size: 1.8em; } .container { padding: 15px; } }",
            "  </style>",
            "</head>",
            "<body>",
            "  <div class='container'>",
            "    <div class='header'>",
            "      <h1>🌍 ", input$destination, " Itinerary</h1>",
            "      <p>", input$num_days, "-Day Travel Plan</p>",
            "    </div>",
            "    <div class='trip-info'>",
            "      <p><strong>Destination:</strong> ", input$destination, "</p>",
            "      <p><strong>Duration:</strong> ", input$num_days, " day(s)</p>",
            "      <p><strong>Daily Hours:</strong> ", input$start_time, " - ", input$end_time, "</p>",
            "      <p><strong>Generated:</strong> ", format(Sys.time(), '%B %d, %Y at %H:%M'), "</p>",
            "    </div>",
            "    <div class='itinerary-content'>",
            "      <p>", itinerary_html_content, "</p>",
            "    </div>",
            "    <div class='map-section'>",
            "      <h3>📍 Interactive Map</h3>",
            "      <p>Map visualization showing all attractions and suggested routes.</p>",
            "      <p style='margin-top: 20px; padding: 20px; background: white; border-radius: 4px;'>[Map will be displayed here - optimized for your preferred map library]</p>",
            "    </div>",
            "    <div class='footer'>",
            "      <p>Generated by AI Travel Itinerary Planner | Print-friendly format</p>",
            "      <p>Open in any web browser or print to PDF for offline access</p>",
            "    </div>",
            "  </div>",
            "</body>",
            "</html>"
          )
          
          writeLines(html_content, file)
        }
      }
    )
    
    # PDF Export (mobile-friendly)
    output$download_pdf <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.pdf")
      },
      content = function(file) {
        if (!is.null(rv$generated_itinerary)) {
          tryCatch({
            # Create temporary markdown file for conversion
            temp_md <- tempfile(fileext = ".md")
            
            pdf_content <- paste0(
              "---\n",
              "title: '", input$destination, " - ", input$num_days, " Day Itinerary'\n",
              "author: 'AI Travel Planner'\n",
              "date: '", format(Sys.time(), '%B %d, %Y'), "'\n",
              "geometry: margin=0.5in\n",
              "mainfont: 'Arial'\n",
              "fontsize: 11pt\n",
              "---\n\n",
              "# 🌍 ", input$destination, " Itinerary\n\n",
              "**Duration:** ", input$num_days, " day(s)  \n",
              "**Daily Hours:** ", input$start_time, " - ", input$end_time, "  \n",
              "**Generated:** ", format(Sys.time(), '%B %d, %Y at %H:%M'), "\n\n",
              "---\n\n",
              rv$generated_itinerary, "\n\n",
              "---\n\n",
              "## 📍 Map & Transportation\n\n",
              "An interactive map showing all attractions and suggested routes will be displayed in the HTML version.\n",
              "For this PDF version, refer to Google Maps with the listed attractions for detailed directions.\n\n",
              "---\n\n",
              "*Generated by AI Travel Itinerary Planner*  \n",
              "*Mobile-optimized PDF format - readable on all devices*\n"
            )
            
            writeLines(pdf_content, temp_md)
            
            # Try using rmarkdown if available
            if (requireNamespace("rmarkdown", quietly = TRUE)) {
              rmarkdown::render(
                temp_md,
                output_format = rmarkdown::pdf_document(
                  highlight = "default",
                  toc = TRUE,
                  toc_depth = 2
                ),
                output_file = file,
                quiet = TRUE
              )
            } else {
              # Fallback: write markdown-formatted text
              writeLines(pdf_content, file)
            }
            
            unlink(temp_md)
          }, error = function(e) {
            # Fallback to text-based PDF content
            pdf_lines <- c(
              paste0("ITINERARY: ", input$destination, " - ", input$num_days, " DAYS"),
              paste0("Daily Hours: ", input$start_time, " - ", input$end_time),
              paste0("Generated: ", format(Sys.time(), '%B %d, %Y at %H:%M')),
              "",
              "---------------------------------------------",
              "",
              rv$generated_itinerary,
              "",
              "---------------------------------------------",
              "",
              "Mobile-friendly PDF format",
              "Readable on all devices",
              "",
              "Generated by AI Travel Itinerary Planner"
            )
            writeLines(pdf_lines, file)
          })
        }
      }
    )
    
    # Calendar (.ics) Export for Outlook, Google Calendar, etc.
    output$download_calendar <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", input$num_days, "days.ics")
      },
      content = function(file) {
        if (!is.null(rv$generated_itinerary)) {
          tryCatch({
            # Parse itinerary to extract activities with times
            lines <- strsplit(rv$generated_itinerary, "\n")[[1]]
            
            # Create iCalendar format
            ics_content <- c(
              "BEGIN:VCALENDAR",
              "VERSION:2.0",
              "PRODID:-//AI Travel Planner//Travel Itinerary//EN",
              "CALSCALE:GREGORIAN",
              paste0("X-WR-CALNAME:", input$destination, " Itinerary"),
              paste0("X-WR-TIMEZONE:UTC"),
              paste0("DESCRIPTION:", input$destination, " - ", input$num_days, " Day Travel Plan"),
              ""
            )
            
            # Extract date for calendar (assume starting today)
            start_date <- Sys.Date()
            
            # Parse days and create events
            day_num <- 0
            current_time <- paste0(gsub(":", "", input$start_time), "00")
            
            for (i in seq_along(lines)) {
              line <- trimws(lines[i])
              
              # Check if line starts a new day
              if (grepl("^DAY\\s+\\d+", line, ignore.case = TRUE)) {
                day_num <- day_num + 1
                event_date <- format(start_date + (day_num - 1), "%Y%m%d")
              }
              
              # Look for time entries (HH:MM format)
              if (grepl("^\\d{1,2}:\\d{2}", line) && day_num > 0) {
                # Extract time and activity
                time_match <- regexpr("^\\d{1,2}:\\d{2}[AP]M", line)
                if (time_match != -1) {
                  time_str <- regmatches(line, time_match)
                  activity <- trimws(sub("^\\d{1,2}:\\d{2}[AP]M\\s*-?\\s*", "", line))
                  
                  if (activity != "" && nchar(activity) > 0) {
                    # Convert time to 24hr format for iCal
                    time_24 <- convert_to_24hr(time_str)
                    
                    # Create event
                    event_start <- paste0(event_date, "T", time_24, "00Z")
                    event_end <- paste0(event_date, "T", 
                                       add_minutes_to_time(time_24, 120), "00Z")
                    
                    ics_content <- c(
                      ics_content,
                      "BEGIN:VEVENT",
                      paste0("UID:travel-", day_num, "-", i, "@travelplanner.local"),
                      paste0("DTSTAMP:", format(Sys.time(), "%Y%m%dT%H%M%SZ")),
                      paste0("DTSTART:", event_start),
                      paste0("DTEND:", event_end),
                      paste0("SUMMARY:", activity),
                      paste0("DESCRIPTION:Activity in ", input$destination, " itinerary"),
                      "STATUS:CONFIRMED",
                      "SEQUENCE:0",
                      "END:VEVENT",
                      ""
                    )
                  }
                }
              }
            }
            
            ics_content <- c(ics_content, "END:VCALENDAR")
            writeLines(ics_content, file)
            
          }, error = function(e) {
            # Fallback: create basic calendar with full itinerary as single event
            event_date <- format(Sys.Date(), "%Y%m%d")
            event_start <- paste0(event_date, "T090000Z")
            event_end <- paste0(event_date, "T170000Z")
            
            ics_lines <- c(
              "BEGIN:VCALENDAR",
              "VERSION:2.0",
              "PRODID:-//AI Travel Planner//Travel Itinerary//EN",
              "CALSCALE:GREGORIAN",
              paste0("X-WR-CALNAME:", input$destination, " Itinerary"),
              "BEGIN:VEVENT",
              paste0("UID:travel-main@travelplanner.local"),
              paste0("DTSTAMP:", format(Sys.time(), "%Y%m%dT%H%M%SZ")),
              paste0("DTSTART:", event_start),
              paste0("DTEND:", event_end),
              paste0("SUMMARY:", input$destination, " - ", input$num_days, " Day Trip"),
              paste0("DESCRIPTION:", gsub("\n", "\\n", rv$generated_itinerary)),
              "STATUS:CONFIRMED",
              "END:VEVENT",
              "END:VCALENDAR"
            )
            
            writeLines(ics_lines, file)
          })
        }
      }
    )

    # ==================
    # KML EXPORT (Google Maps)
    # ==================
    output$download_kml <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", format(Sys.Date(), "%Y%m%d"), ".kml")
      },
      content = function(file) {
        if (is.null(rv$map_data) || nrow(rv$map_data) == 0) {
          writeLines("", file)
          return()
        }
        
        md <- rv$map_data
        
        kml_lines <- c(
          "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
          "<kml xmlns=\"http://www.opengis.net/kml/2.2\">",
          "  <Document>",
          paste0("    <name>", input$destination, " Trip Itinerary</name>"),
          paste0("    <description>", input$num_days, "-day trip from ", 
                 format(input$trip_start_date, "%B %d"), " to ", 
                 format(input$trip_end_date, "%B %d"), "</description>",
          "    <Style id=\"day1\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/red-dot.png</href></Icon></IconStyle>",
          "    </Style>",
          "    <Style id=\"day2\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/blue-dot.png</href></Icon></IconStyle>",
          "    </Style>",
          "    <Style id=\"day3\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/green-dot.png</href></Icon></IconStyle>",
          "    </Style>",
          "    <Style id=\"day4\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/yellow-dot.png</href></Icon></IconStyle>",
          "    </Style>",
          "    <Style id=\"day5\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/orange-dot.png</href></Icon></IconStyle>",
          "    </Style>",
          "    <Style id=\"day6\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/purple-dot.png</href></Icon></IconStyle>",
          "    </Style>",
          "    <Style id=\"day7\">",
          "      <IconStyle><Icon><href>http://maps.google.com/mapfiles/ms/icons/pink-dot.png</href></Icon></IconStyle>",
          "    </Style>"
        )
        
        # Add placemarks for each attraction
        for (i in 1:nrow(md)) {
          day_num <- md$day[i]
          style_id <- paste0("day", day_num)
          
          kml_lines <- c(kml_lines,
            "    <Placemark>",
            paste0("      <name>Stop #", md$order[i], ": ", md$name[i], "</name>"),
            paste0("      <description><![CDATA[",
                   "<strong>", md$name[i], "</strong><br/>",
                   "Date: ", md$day_label[i], "<br/>",
                   "Time: ", md$time_start[i], " - ", md$time_end[i], "<br/>",
                   "Stop Order: #", md$order[i], "<br/>",
                   "Coordinates: ", md$latitude[i], ", ", md$longitude[i], "<br/><br/>",
                   md$description[i],
                   "]]></description>"),
            paste0("      <styleUrl>#", style_id, "</styleUrl>"),
            "      <Point>",
            paste0("        <coordinates>", md$longitude[i], ",", md$latitude[i], ",0</coordinates>"),
            "      </Point>",
            "    </Placemark>"
          )
        }
        
        # Add folder for route (LineString connecting all points)
        if (nrow(md) > 1) {
          kml_lines <- c(kml_lines,
            "    <Placemark>",
            "      <name>Suggested Route</name>",
            "      <description>Path connecting all attractions in suggested order</description>",
            "      <LineString>",
            "        <coordinates>"
          )
          
          for (i in 1:nrow(md)) {
            kml_lines <- c(kml_lines,
              paste0("          ", md$longitude[i], ",", md$latitude[i], ",0")
            )
          }
          
          kml_lines <- c(kml_lines,
            "        </coordinates>",
            "      </LineString>",
            "    </Placemark>"
          )
        }
        
        kml_lines <- c(kml_lines,
          "  </Document>",
          "</kml>"
        )
        
        writeLines(kml_lines, file)
      }
    )
    
    # ==================
    # GPX EXPORT (GPS/Navigation Apps)
    # ==================
    output$download_gpx <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_itinerary_", format(Sys.Date(), "%Y%m%d"), ".gpx")
      },
      content = function(file) {
        if (is.null(rv$map_data) || nrow(rv$map_data) == 0) {
          writeLines("", file)
          return()
        }
        
        md <- rv$map_data
        
        gpx_lines <- c(
          "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
          "<gpx version=\"1.1\" creator=\"Travel Planning App\"",
          "  xmlns=\"http://www.topografix.com/GPX/1/1\"",
          "  xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"",
          "  xsi:schemaLocation=\"http://www.topografix.com/GPX/1/1",
          "  http://www.topografix.com/GPX/1/1/gpx.xsd\">",
          paste0("  <metadata>"),
          paste0("    <name>", input$destination, " Trip</name>"),
          paste0("    <desc>", input$num_days, "-day itinerary</desc>"),
          paste0("    <time>", format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ"), "</time>"),
          paste0("  </metadata>")
        )
        
        # Add waypoints for each attraction
        for (i in 1:nrow(md)) {
          gpx_lines <- c(gpx_lines,
            paste0("  <wpt lat=\"", md$latitude[i], "\" lon=\"", md$longitude[i], "\">"),
            paste0("    <name>Stop #", md$order[i], ": ", md$name[i], "</name>"),
            paste0("    <desc>", md$day_label[i], " (", md$time_start[i], " - ", md$time_end[i], ")</desc>"),
            paste0("    <sym>Pin</sym>"),
            paste0("    <type>Waypoint</type>"),
            "  </wpt>"
          )
        }
        
        # Add track (route through all waypoints)
        if (nrow(md) > 1) {
          gpx_lines <- c(gpx_lines,
            "  <trk>",
            paste0("    <name>", input$destination, " Route</name>"),
            paste0("    <desc>Suggested path through all attractions</desc>"),
            "    <trkseg>"
          )
          
          for (i in 1:nrow(md)) {
            gpx_lines <- c(gpx_lines,
              paste0("      <trkpt lat=\"", md$latitude[i], "\" lon=\"", md$longitude[i], "\">"),
              paste0("        <name>", md$name[i], "</name>"),
              "      </trkpt>"
            )
          }
          
          gpx_lines <- c(gpx_lines,
            "    </trkseg>",
            "  </trk>"
          )
        }
        
        gpx_lines <- c(gpx_lines, "</gpx>")
        
        writeLines(gpx_lines, file)
      }
    )
    
    # ==================
    # GOOGLE MAPS URL EXPORT
    # ==================
    output$download_google_maps_url <- downloadHandler(
      filename = function() {
        paste0(input$destination, "_google_maps_link.txt")
      },
      content = function(file) {
        if (is.null(rv$map_data) || nrow(rv$map_data) == 0) {
          writeLines("No data available", file)
          return()
        }
        
        md <- rv$map_data
        
        # Create Google Maps URL with multiple waypoints
        # Format: https://www.google.com/maps/dir/place1/place2/place3...
        waypoints <- paste(md$latitude, md$longitude, sep = ",")
        waypoints_url <- paste(waypoints, collapse = "/")
        
        google_maps_url <- paste0(
          "https://www.google.com/maps/dir/",
          waypoints_url
        )
        
        # Create readable text file
        url_content <- c(
          paste0("GOOGLE MAPS LINK - ", input$destination, " TRIP"),
          paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
          "",
          "IMPORTANT INFORMATION:",
          "- Click the link below to open in Google Maps",
          "- All attractions are marked as waypoints",
          "- Google Maps will show directions between points",
          "- You can customize the route in Google Maps",
          "",
          "SHORT LINK (may need formatting):",
          google_maps_url,
          "",
          "INSTRUCTIONS:",
          "1. Copy the link above",
          "2. Paste into your browser or Google Maps app",
          "3. Google Maps will open with all waypoints",
          "4. Use the app to navigate turn-by-turn",
          "",
          "ATTRACTIONS IN ORDER:",
          ""
        )
        
        for (i in 1:nrow(md)) {
          url_content <- c(url_content,
            paste0("Stop #", md$order[i], ": ", md$name[i]),
            paste0("  Date: ", md$day_label[i]),
            paste0("  Time: ", md$time_start[i], " - ", md$time_end[i]),
            paste0("  Lat: ", md$latitude[i], ", Lon: ", md$longitude[i]),
            paste0("  Description: ", md$description[i]),
            ""
          )
        }
        
        writeLines(url_content, file)
      }
    )

    
    # Helper function: Convert 12-hour time to 24-hour format
    convert_to_24hr <- function(time_str) {
      time_str <- trimws(time_str)
      is_pm <- grepl("PM|pm", time_str)
      time_clean <- gsub("[APap][Mm]", "", time_str)
      parts <- strsplit(time_clean, ":")[[1]]
      
      if (length(parts) == 2) {
        hour <- as.numeric(parts[1])
        min <- as.numeric(parts[2])
        
        if (is_pm && hour != 12) {
          hour <- hour + 12
        } else if (!is_pm && hour == 12) {
          hour <- 0
        }
        
        return(sprintf("%02d%02d", hour, min))
      }
      return("090000")
    }
    
    # Helper function: Add minutes to time
    add_minutes_to_time <- function(time_str, minutes) {
      hour <- as.numeric(substr(time_str, 1, 2))
      min <- as.numeric(substr(time_str, 3, 4))
      
      total_min <- hour * 60 + min + minutes
      new_hour <- (total_min %/% 60) %% 24
      new_min <- total_min %% 60
      
      sprintf("%02d%02d", new_hour, new_min)
    }
    
    # ==================
    # SHARE & REFINE
    # ==================
    observeEvent(input$share_itinerary, {
      showNotification("Share functionality coming soon! Copy-paste the itinerary or download it.",
                      type = "info")
    })
    
    observeEvent(input$refine_itinerary, {
      showNotification("Refinement options will allow you to adjust timing, add/remove places, or change constraints.",
                      type = "info")
    })
    
    # Start over
    observeEvent(input$start_over, {
      rv$discovered_places <- NULL
      rv$selected_places <- character(0)
      rv$places_data <- NULL
      rv$generated_itinerary <- NULL
      output$places_checkboxes <- renderUI(NULL)
      output$discovery_status <- renderUI(NULL)
      output$itinerary_html <- renderUI(NULL)
      output$itinerary_status <- renderUI(NULL)
      shinyjs::hide("itinerary_content", anim = TRUE)
      shinyjs::hide("itinerary_loading_spinner", anim = TRUE)
      shinyjs::show("places_checkboxes", anim = TRUE)
    })
    
    # Initialize
    output$discovery_status <- renderUI(NULL)
    output$places_checkboxes <- renderUI(NULL)
    output$itinerary_status <- renderUI(NULL)
    shinyjs::hide("loading_spinner", anim = TRUE)
    shinyjs::hide("itinerary_loading_spinner", anim = TRUE)
  })
}
