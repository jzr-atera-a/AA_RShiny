# modules/Day Planner/schedule_about/ui.R

schedule_about_ui <- function(id) {
  ns <- NS(id)

  tagList(
    fluidRow(
      box(title = "About Day Planner", status = "info", solidHeader = TRUE, width = 12,

        h3("Day Planner"),
        p("AI-powered day/trip schedule generation, part of the Business Operations Suite."),

        hr(),
        h4("Table: atera-2.business_strategy.day_scheduler"),
        tags$pre("Fields:\n  - id (INTEGER)\n  - created_at (TIMESTAMP)\n  - schedule_date (STRING)\n  - day_type (STRING)\n  - country (STRING)\n  - city (STRING)\n  - trip_details (STRING)\n  - row_type (STRING) - Location | Transport | Summary\n  - row_sequence (INTEGER)\n  - location_name (STRING)\n  - location_details (STRING)\n  - opening_hours (STRING)\n  - recommended_time (STRING)\n  - observations (STRING)"),

        hr(),
        h4("Weather-Aware Planning"),
        p("Before planning, Claude searches the web for the real weather forecast for the date and location ",
          "you provide, and factors it into the route (indoor/outdoor choices, timing around rain, what to ",
          "bring). No schema change was needed - the forecast is woven into the existing ", tags$code("observations"),
          " field: a one-line \"Weather Forecast: ...\" summary opens the Summary row's observations, and any ",
          "weather-sensitive Location/Transport row gets a practical tip in its own observations."),
        p(tags$em("Country/City are optional for non-Travel days too - fill them in if you want weather-aware ",
                  "planning for a Work/Conference/Research day; leave blank to skip weather research entirely.")),

        hr(),
        h4("Row Structure"),
        tags$ul(
          tags$li(tags$strong("Location"), " row - one per place visited"),
          tags$li(tags$strong("Transport"), " row - follows every location except the last"),
          tags$li(tags$strong("Summary"), " row - one per day, at the end")
        ),
        p(tags$em("recommended_time and observations are reused across all three row types - see Generate Schedule for details.")),

        hr(),
        p("Part of the Business Operations Suite: Day Planner + Events Scheduling + Funding Programmes",
          style = "text-align: center; color: #999; font-size: 12px;")
      )
    )
  )
}
