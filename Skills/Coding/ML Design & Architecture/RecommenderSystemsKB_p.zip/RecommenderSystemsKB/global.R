# global.R
# Practical Recommender Systems Knowledge Base — Utility Functions

library(shiny)
library(shinydashboard)
library(plotly)
library(ggplot2)

# Helper function to create chapter cards
chapter_card <- function(num, title, desc, topics) {
  tags$div(class="chapter-card",
           tags$div(
             tags$span(class="chapter-num", num),
             tags$span(class="chapter-title", title)
           ),
           tags$div(class="chapter-desc", desc),
           tags$div(class="chapter-topics",
                    lapply(topics, function(t) tags$span(class="topic-tag", t))
           )
  )
}

# Helper function to create timeline entries
timeline_entry <- function(badge, title, desc) {
  tags$div(class="timeline-item",
           tags$div(class="timeline-badge", badge),
           tags$div(class="timeline-content",
                    tags$h6(title),
                    tags$p(desc)
           )
  )
}

# Helper function to create algorithm comparison tables
algo_table <- function(data) {
  tagList(
    tags$table(class="algo-table",
               tags$thead(
                 tags$tr(lapply(names(data), function(n) tags$th(n)))
               ),
               tags$tbody(
                 lapply(1:nrow(data), function(i) {
                   tags$tr(lapply(data[i,], function(val) tags$td(val)))
                 })
               )
    )
  )
}

# Plotly theme for dark mode
plotly_dark_theme <- function(p) {
  p %>% layout(
    paper_bgcolor = 'rgba(0,0,0,0)',
    plot_bgcolor = 'rgba(0,0,0,0)',
    font = list(color = '#8a9bb0', family = 'Inter, sans-serif', size = 11),
    xaxis = list(
      gridcolor = 'rgba(255,255,255,0.08)',
      zerolinecolor = 'rgba(255,255,255,0.1)',
      color = '#8a9bb0'
    ),
    yaxis = list(
      gridcolor = 'rgba(255,255,255,0.08)',
      zerolinecolor = 'rgba(255,255,255,0.1)',
      color = '#8a9bb0'
    )
  )
}
