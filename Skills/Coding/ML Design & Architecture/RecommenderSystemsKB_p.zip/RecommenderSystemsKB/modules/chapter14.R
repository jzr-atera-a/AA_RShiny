# modules/chapter14.R
# Chapter 14: The Future of Recommender Systems

chapter14_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 14: The Future of Recommender Systems"),
        tags$h2("Emerging Trends and Next-Generation Approaches"),
        div(
          span(class="hero-badge","Deep Learning"),
          span(class="hero-badge","Context-Aware"),
          span(class="hero-badge","Reinforcement Learning"),
          span(class="hero-badge","Real-Time")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "DL"), span(class="metric-label","Deep Learning Era"))),
            column(3, div(class="metric-card", span(class="metric-value", "Context"), span(class="metric-label","Beyond User-Item"))),
            column(3, div(class="metric-card", span(class="metric-value", "Real-Time"), span(class="metric-label","Millisecond Latency"))),
            column(3, div(class="metric-card", span(class="metric-value", "RL"), span(class="metric-label","Long-Term Value")))
          )
      )
    ),

    fluidRow(
      box(title="🧠 Deep Learning Revolution", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Paradigm Shift:</strong> Deep learning replaces hand-crafted features with learned representations. Neural networks now power YouTube, TikTok, Netflix.")),
          br(),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("Why Deep Learning?"),
                       tags$ul(
                         tags$li(HTML("<strong>Feature learning:</strong> No manual engineering")),
                         tags$li(HTML("<strong>Non-linear patterns:</strong> Captures complex interactions")),
                         tags$li(HTML("<strong>Multi-modal:</strong> Text + images + video")),
                         tags$li(HTML("<strong>Transfer learning:</strong> Pre-trained models"))
                       )
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Popular Architectures"),
                       tags$ul(
                         tags$li(HTML("<strong>NCF:</strong> Neural Collaborative Filtering")),
                         tags$li(HTML("<strong>Two-tower:</strong> Separate user/item networks")),
                         tags$li(HTML("<strong>Transformers:</strong> BERT4Rec, SASRec")),
                         tags$li(HTML("<strong>GNNs:</strong> Graph neural networks"))
                       )
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Industry Adoption"),
                       tags$ul(
                         tags$li(HTML("<strong>YouTube:</strong> Two-tower DNN")),
                         tags$li(HTML("<strong>TikTok:</strong> Deep ranking model")),
                         tags$li(HTML("<strong>Alibaba:</strong> Deep Interest Network")),
                         tags$li(HTML("<strong>Pinterest:</strong> PinSage (GNN)"))
                       )
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🌍 Context-Aware Recommendations", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Beyond User and Item"),
          div(class="framework-card",
              tags$h5("Contextual Factors"),
              tags$p(HTML("<strong>Time:</strong> Morning vs evening, weekday vs weekend")),
              tags$p(HTML("<strong>Location:</strong> Home vs work vs traveling")),
              tags$p(HTML("<strong>Device:</strong> Mobile vs desktop vs TV")),
              tags$p(HTML("<strong>Weather:</strong> Rainy day → comfort movies")),
              tags$p(HTML("<strong>Social:</strong> Alone vs with family"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Implementation"),
              tags$p(HTML("<strong>Features:</strong> Add context to input vector")),
              tags$p(HTML("<strong>Example:</strong> [user, item, time_of_day, device, location]")),
              tags$p(HTML("<strong>Model:</strong> Neural network or tensor factorization")),
              tags$p(HTML("<strong>Result:</strong> Different recs for same user in different contexts"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Spotify Example:</strong> Workout playlists at 6am, chill music at 10pm. Same user, different context."))
      ),

      box(title="🎮 Reinforcement Learning", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Optimizing Long-Term Engagement"),
          div(class="framework-card",
              tags$h5("The Problem with Supervised Learning"),
              tags$p(HTML("<strong>Myopic:</strong> Optimizes immediate click")),
              tags$p(HTML("<strong>Feedback loop:</strong> User clicks → more similar recs → filter bubble")),
              tags$p(HTML("<strong>No exploration:</strong> Never shows diverse content"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("RL Approach"),
              tags$p(HTML("<strong>Agent:</strong> Recommender system")),
              tags$p(HTML("<strong>State:</strong> User history + context")),
              tags$p(HTML("<strong>Action:</strong> Which items to recommend")),
              tags$p(HTML("<strong>Reward:</strong> Long-term engagement (session length, retention)")),
              tags$p(HTML("<strong>Goal:</strong> Maximize cumulative reward"))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ YouTube Example:</strong> RL model balances clicks with watch time and diversity. Prevents rabbit holes."))
      )
    ),

    fluidRow(
      box(title="📱 Session-Based Recommendations", status="primary", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Capturing Sequential Patterns"),
          div(class="info-box-plain",
              HTML("<strong>💡 Key Insight:</strong> User behavior within a session reveals intent. 'Movie → Popcorn → Soda' sequence predicts next action better than overall history.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("RNNs and Transformers"),
                       tags$p(HTML("<strong>Input:</strong> Sequence of clicked items in session")),
                       tags$p(HTML("<strong>Model:</strong> LSTM, GRU, or Transformer")),
                       tags$p(HTML("<strong>Output:</strong> Probability distribution over next item")),
                       tags$p(HTML("<strong>Advantage:</strong> Captures short-term intent")),
                       tags$p(HTML("<strong>Used by:</strong> Amazon, eBay, Alibaba"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("BERT4Rec & SASRec"),
                       tags$p(HTML("<strong>Approach:</strong> Masked language model for sequences")),
                       tags$p(HTML("<strong>Training:</strong> Mask random items, predict them")),
                       tags$p(HTML("<strong>Attention:</strong> Self-attention captures dependencies")),
                       tags$p(HTML("<strong>Result:</strong> State-of-the-art on benchmarks"))
                   ))
          ),
          br(),
          plotlyOutput(ns("session_example"))
      )
    ),

    fluidRow(
      box(title="🚀 Real-Time Personalization", status="info", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Millisecond Inference"),
          div(class="framework-card",
              tags$h5("The Challenge"),
              tags$p(HTML("<strong>Latency budget:</strong> <100ms end-to-end")),
              tags$p(HTML("<strong>Scale:</strong> Millions of users, billions of items")),
              tags$p(HTML("<strong>Freshness:</strong> Update model hourly with new data")),
              tags$p(HTML("<strong>Cost:</strong> Must be economical at scale"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Solutions"),
              tags$ul(
                tags$li(HTML("<strong>Pre-computation:</strong> Cache top-K for each user")),
                tags$li(HTML("<strong>Approximate NN:</strong> FAISS, ScaNN for fast search")),
                tags$li(HTML("<strong>Model distillation:</strong> Compress large model")),
                tags$li(HTML("<strong>Two-stage:</strong> Fast retrieval → slow ranking"))
              )
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 TikTok Example:</strong> Pre-compute 500 candidates, then rank top 10 in real-time using user's last 5 interactions."))
      ),

      box(title="🔮 Multi-Armed Bandits", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Explore-Exploit Trade-off"),
          div(class="framework-card",
              tags$h5("The Problem"),
              tags$p(HTML("<strong>Exploit:</strong> Show items we know user likes")),
              tags$p(HTML("<strong>Explore:</strong> Try new items to learn preferences")),
              tags$p(HTML("<strong>Trade-off:</strong> Too much exploit → filter bubble, too much explore → bad UX"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Bandit Algorithms"),
              tags$p(HTML("<strong>ε-greedy:</strong> Exploit 90%, explore 10%")),
              tags$p(HTML("<strong>UCB:</strong> Upper confidence bound balancing")),
              tags$p(HTML("<strong>Thompson Sampling:</strong> Bayesian approach")),
              tags$p(HTML("<strong>Contextual:</strong> Use user/item features"))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ News Apps:</strong> Use bandits to balance trending stories (exploit) with personalized discovery (explore)."))
      )
    ),

    fluidRow(
      box(title="🌟 Emerging Trends", status="success", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "What's Coming Next"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(
                tags$th("Trend"),
                tags$th("Description"),
                tags$th("Status"),
                tags$th("Examples")
              )
            ),
            tags$tbody(
              tags$tr(
                tags$td(HTML("<strong>Multimodal</strong>")),
                tags$td("Images + text + video + audio"),
                tags$td("Production"),
                tags$td("Pinterest, Instagram, TikTok")
              ),
              tags$tr(
                tags$td(HTML("<strong>Conversational</strong>")),
                tags$td("Chat-based recommendations"),
                tags$td("Early stage"),
                tags$td("ChatGPT plugins, Google SGE")
              ),
              tags$tr(
                tags$td(HTML("<strong>Causal inference</strong>")),
                tags$td("Unbiased from observational data"),
                tags$td("Research"),
                tags$td("Netflix experiments")
              ),
              tags$tr(
                tags$td(HTML("<strong>Federated learning</strong>")),
                tags$td("Privacy-preserving training"),
                tags$td("Early stage"),
                tags$td("Apple, Google on-device")
              ),
              tags$tr(
                tags$td(HTML("<strong>Explainability</strong>")),
                tags$td("Why this recommendation?"),
                tags$td("Production"),
                tags$td("Spotify 'Because you listened to'")
              ),
              tags$tr(
                tags$td(HTML("<strong>Large language models</strong>")),
                tags$td("LLMs as recommenders"),
                tags$td("Emerging"),
                tags$td("ChatGPT, Claude for recommendations")
              )
            )
          )
      )
    ),

    fluidRow(
      box(title="⚠️ Challenges Ahead", status="warning", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Unsolved Problems"),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("1. Filter Bubbles & Echo Chambers"),
                       tags$p(HTML("<strong>Problem:</strong> Recs reinforce existing views")),
                       tags$p(HTML("<strong>Impact:</strong> Political polarization, narrow worldview")),
                       tags$p(HTML("<strong>Challenge:</strong> Balance relevance with diversity"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("2. Privacy & Data Ethics"),
                       tags$p(HTML("<strong>Problem:</strong> Recs require personal data")),
                       tags$p(HTML("<strong>Regulations:</strong> GDPR, CCPA restrictions")),
                       tags$p(HTML("<strong>Challenge:</strong> Personalization without tracking"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("3. Manipulation & Addiction"),
                       tags$p(HTML("<strong>Problem:</strong> Maximize engagement → addictive patterns")),
                       tags$p(HTML("<strong>Example:</strong> YouTube autoplay rabbit holes")),
                       tags$p(HTML("<strong>Challenge:</strong> Ethical optimization goals"))
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Responsibility:</strong> As recommenders get more powerful, the ethical implications grow. We must build systems that benefit users, not just metrics."))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Deep learning is standard:</strong> Neural networks power modern systems")),
                     tags$li(HTML("<strong>Context matters:</strong> Time, location, device shape recommendations")),
                     tags$li(HTML("<strong>RL for long-term:</strong> Beyond immediate clicks")),
                     tags$li(HTML("<strong>Ethics essential:</strong> Responsibility comes with power"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Future Directions"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Multimodal models (vision + language)"),
                     tags$li("Conversational recommendations"),
                     tags$li("Privacy-preserving approaches"),
                     tags$li("Explainable and ethical AI")
                   ))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Final Thought:</strong> Recommender systems are everywhere. They shape what we watch, read, buy, and believe. Building them well is one of the most impactful problems in tech."))
      )
    )
  )
}

chapter14_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$session_example <- renderPlotly({
      actions <- data.frame(
        step = 1:7,
        action = c("Browse", "Click Sci-Fi", "View Matrix", "Add to List", "Click Similar", "View Inception", "Purchase"),
        confidence = c(0.3, 0.5, 0.7, 0.85, 0.6, 0.9, 1.0)
      )
      
      p <- plot_ly(actions, x = ~step, y = ~confidence, type = 'scatter', mode = 'lines+markers',
                   text = ~action, textposition = 'top',
                   line = list(color = '#008A82', width = 3),
                   marker = list(size = 12, color = '#008A82')) %>%
        layout(title = list(text = "User Intent Grows During Session",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "Session Step", color = '#2c3e50'),
               yaxis = list(title = "Purchase Confidence", color = '#2c3e50', range = c(0, 1.1)),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'),
               annotations = lapply(1:nrow(actions), function(i) {
                 list(x = actions$step[i], y = actions$confidence[i] + 0.08,
                      text = actions$action[i], showarrow = FALSE,
                      font = list(size = 9, color = '#2c3e50'))
               }))
      
      p
    })
  })
}
