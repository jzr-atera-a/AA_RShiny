# modules/chapter1.R
# Chapter 1: What is a Recommender?

chapter1_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 1: What is a Recommender?"),
        tags$h2("Understanding Recommendation Systems and Their Impact"),
        div(
          span(class="hero-badge","Foundations"),
          span(class="hero-badge","Long Tail"),
          span(class="hero-badge","Netflix Prize"),
          span(class="hero-badge","Real-World Examples")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "3"),   span(class="metric-label","Main Sections"))),
            column(3, div(class="metric-card", span(class="metric-value", "5"),  span(class="metric-label","Key Concepts"))),
            column(3, div(class="metric-card", span(class="metric-value", "$1M"),    span(class="metric-label","Netflix Prize"))),
            column(3, div(class="metric-card", span(class="metric-value", "80%"), span(class="metric-label","Netflix Watches from Recs")))
          )
      )
    ),

    fluidRow(
      box(title="📚 Real-Life Recommendations", status="info", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "How Recommendations Work in Everyday Life"),
          div(class="framework-card",
              tags$h5("The Restaurant Analogy"),
              tags$p("When a friend recommends a restaurant, they consider:"),
              tags$p(HTML("<strong>Your preferences:</strong> Vegetarian? Spicy food lover?")),
              tags$p(HTML("<strong>Context:</strong> Casual lunch or romantic dinner?")),
              tags$p(HTML("<strong>Their experience:</strong> What they know about the place")),
              tags$p(HTML("<strong>Trust:</strong> Their track record of good recommendations"))),
          
          div(class="success-box",
              HTML("<strong>✅ Key Insight:</strong> Recommender systems automate this process at scale. Instead of one friend, you have millions of users providing signals about what's good.")),
          
          div(class="section-heading-dark", "From Human to Algorithmic Recommendations"),
          tags$p(style="color: #8a9bb0; font-size: 12px; line-height: 1.65;",
            "Traditional recommendations relied on experts (critics, friends, salespeople). Digital recommender systems democratized this by:",
            tags$ul(
              tags$li(HTML("<strong>Aggregating wisdom of crowds:</strong> Millions of user ratings")),
              tags$li(HTML("<strong>Finding patterns:</strong> People who liked X also liked Y")),
              tags$li(HTML("<strong>Personalizing at scale:</strong> Unique recommendations per user")),
              tags$li(HTML("<strong>Real-time adaptation:</strong> Learning from every interaction"))
            ))
      ),

      box(title="🌐 Recommender Systems on the Internet", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Where Recommenders Are Used"),
          tags$table(class="algo-table",
            tags$tr(tags$td(HTML("<strong>E-commerce:</strong>")), tags$td("Amazon product recommendations")),
            tags$tr(tags$td(HTML("<strong>Streaming:</strong>")), tags$td("Netflix movies, Spotify playlists")),
            tags$tr(tags$td(HTML("<strong>Social Media:</strong>")), tags$td("Facebook friends, LinkedIn connections")),
            tags$tr(tags$td(HTML("<strong>Content:</strong>")), tags$td("YouTube videos, news articles")),
            tags$tr(tags$td(HTML("<strong>Travel:</strong>")), tags$td("Booking.com hotels, TripAdvisor")),
            tags$tr(tags$td(HTML("<strong>Dating:</strong>")), tags$td("Match.com, Tinder matches"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Business Impact:</strong> Amazon reports that 35% of their revenue comes from recommendations. Netflix estimates 80% of watched content is discovered through their recommendation engine.")),
          br(),
          div(class="section-heading-dark", "Why Companies Invest in RecSys"),
          tags$ul(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
            tags$li(HTML("<strong>Increased engagement:</strong> Users stay longer when content is relevant")),
            tags$li(HTML("<strong>Higher conversion:</strong> Relevant products = more purchases")),
            tags$li(HTML("<strong>Customer satisfaction:</strong> Better experience = loyalty")),
            tags$li(HTML("<strong>Discovery:</strong> Surface long-tail content users wouldn't find"))
          )
      )
    ),

    fluidRow(
      box(title="📊 The Long Tail Phenomenon", status="success", solidHeader=TRUE, width=12,
          div(class="info-box-plain",
              HTML("<strong>The Long Tail Theory:</strong> Chris Anderson's concept that online businesses can profit from selling small quantities of many niche items, rather than just popular hits. Recommender systems are the key technology enabling the long tail.")),
          br(),
          plotlyOutput(ns("long_tail_plot")),
          br(),
          div(class="framework-card",
              tags$h5("Understanding the Distribution"),
              tags$p(HTML("<strong>The Head (Popular Items):</strong> Blockbuster movies, bestselling books, hit songs. In physical retail, limited shelf space forces focus on these.")),
              tags$p(HTML("<strong>The Tail (Niche Items):</strong> Obscure documentaries, indie music, specialized books. Infinite digital shelf space makes these accessible.")),
              tags$p(HTML("<strong>Recommenders' Role:</strong> Without recommendations, users only find popular items. Recommenders surface the tail, creating value from previously invisible inventory."))
          ),
          br(),
          fluidRow(
            column(4,
                   div(class="metric-card", 
                       span(class="metric-value", "20%"), 
                       span(class="metric-label","Popular Items Generate"))),
            column(4,
                   div(class="metric-card", 
                       span(class="metric-value", "80%"), 
                       span(class="metric-label","Long Tail Items"))),
            column(4,
                   div(class="metric-card", 
                       span(class="metric-value", "∞"), 
                       span(class="metric-label","Digital Shelf Space")))
          )
      )
    ),

    fluidRow(
      box(title="🏆 The Netflix Prize: A Watershed Moment", status="primary", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "The Competition That Changed RecSys"),
          div(class="framework-card",
              tags$h5("Competition Details (2006-2009)"),
              tags$p(HTML("<strong>Challenge:</strong> Beat Netflix's existing algorithm (Cinematch) by 10% RMSE improvement")),
              tags$p(HTML("<strong>Prize:</strong> $1 million to the winning team")),
              tags$p(HTML("<strong>Dataset:</strong> 100 million ratings from 480,000 users on 17,770 movies")),
              tags$p(HTML("<strong>Metric:</strong> Root Mean Squared Error (RMSE) on held-out test set")),
              tags$p(HTML("<strong>Winner:</strong> BellKor's Pragmatic Chaos team (2009)"))
          ),
          div(class="success-box",
              HTML("<strong>✅ Impact:</strong> The Netflix Prize popularized collaborative filtering, matrix factorization, and ensemble methods. It showed that incremental improvements matter at scale.")),
          br(),
          div(class="section-heading-dark", "Key Learnings from the Prize"),
          tags$ul(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
            tags$li(HTML("<strong>Ensemble methods win:</strong> Combining multiple algorithms beats single approaches")),
            tags$li(HTML("<strong>Matrix factorization:</strong> SVD and variants became dominant techniques")),
            tags$li(HTML("<strong>Temporal dynamics:</strong> User preferences change over time")),
            tags$li(HTML("<strong>The last 1% is hard:</strong> Diminishing returns on accuracy improvements"))
          ),
          br(),
          plotlyOutput(ns("netflix_prize_plot"))
      ),

      box(title="🎬 Types of Recommendations", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Classification of Recommender Systems"),
          
          div(class="framework-card",
              tags$h5("1. Non-Personalized Recommendations"),
              tags$p("Same recommendations for all users. Based on popularity, trends, or editorial curation."),
              tags$p(HTML("<strong>Examples:</strong> Trending Now, Top Rated, Editor's Picks")),
              tags$p(HTML("<strong>Pros:</strong> Simple, no cold-start issues, explains why (it's popular)")),
              tags$p(HTML("<strong>Cons:</strong> Not tailored, misses user preferences"))
          ),
          
          div(class="framework-card",
              tags$h5("2. Content-Based Filtering"),
              tags$p("Recommend items similar to what user liked before. Based on item features/metadata."),
              tags$p(HTML("<strong>Examples:</strong> More like this, Same genre/artist")),
              tags$p(HTML("<strong>Pros:</strong> No data from other users needed, explains recommendations")),
              tags$p(HTML("<strong>Cons:</strong> Limited discovery, feature engineering required"))
          ),
          
          div(class="framework-card",
              tags$h5("3. Collaborative Filtering"),
              tags$p("Recommend based on similar users' preferences. Learns patterns from collective behavior."),
              tags$p(HTML("<strong>Examples:</strong> Users who liked X also liked Y")),
              tags$p(HTML("<strong>Pros:</strong> Discovers unexpected matches, no item features needed")),
              tags$p(HTML("<strong>Cons:</strong> Cold-start for new users/items, scalability challenges"))
          ),
          
          div(class="framework-card",
              tags$h5("4. Hybrid Systems"),
              tags$p("Combine multiple approaches for better performance. The state-of-the-art."),
              tags$p(HTML("<strong>Examples:</strong> Netflix, Amazon, Spotify")),
              tags$p(HTML("<strong>Pros:</strong> Leverages strengths of each approach")),
              tags$p(HTML("<strong>Cons:</strong> Complexity, harder to explain"))
          ),
          
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Real-World Practice:</strong> Production systems almost always use hybrids. Pure content-based or collaborative filtering is rare."))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways from Chapter 1", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Recommenders automate discovery</strong> by leveraging collective wisdom and patterns")),
                     tags$li(HTML("<strong>The long tail</strong> represents value in niche items that recommenders help surface")),
                     tags$li(HTML("<strong>Business impact is massive:</strong> 35%+ of revenue for major platforms")),
                     tags$li(HTML("<strong>Multiple approaches exist:</strong> popularity, content-based, collaborative, hybrid")),
                     tags$li(HTML("<strong>Netflix Prize</strong> established modern RecSys techniques and metrics"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Practical Implications"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Start simple:</strong> Non-personalized recs work well for cold-start")),
                     tags$li(HTML("<strong>Measure impact:</strong> Track engagement, conversion, satisfaction")),
                     tags$li(HTML("<strong>Plan for hybrid:</strong> No single algorithm solves all problems")),
                     tags$li(HTML("<strong>Consider context:</strong> User intent, time, device all matter")),
                     tags$li(HTML("<strong>Evaluation is critical:</strong> Offline metrics ≠ online success"))
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Common Misconception:</strong> More accuracy doesn't always mean better recommendations. Diversity, serendipity, and explainability matter too. The Netflix Prize winning algorithm was never deployed because it was too complex for production."))
      )
    )
  )
}

chapter1_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    # Long tail visualization
    output$long_tail_plot <- renderPlotly({
      # Generate long tail distribution data
      items <- 1:1000
      popularity <- 10000 / (items^1.5)  # Power law distribution
      
      df <- data.frame(
        rank = items,
        views = popularity
      )
      
      p <- plot_ly(df, x = ~rank, y = ~views, type = 'scatter', mode = 'lines',
                   line = list(color = '#e8410a', width = 3),
                   fill = 'tozeroy', fillcolor = 'rgba(232,65,10,0.2)',
                   hovertemplate = paste('<b>Rank:</b> %{x}<br>',
                                        '<b>Views:</b> %{y:.0f}<extra></extra>')) %>%
        layout(title = list(text = "The Long Tail: Item Popularity Distribution", 
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "Item Rank (sorted by popularity)", 
                           gridcolor = 'rgba(255,255,255,0.08)',
                           color = '#8a9bb0'),
               yaxis = list(title = "Number of Views/Sales", 
                           gridcolor = 'rgba(255,255,255,0.08)',
                           color = '#8a9bb0'),
               annotations = list(
                 list(x = 100, y = max(df$views) * 0.8,
                      text = "The HEAD<br>(Popular Items)",
                      showarrow = TRUE, arrowcolor = '#ffb49a',
                      font = list(color = '#ffb49a', size = 11)),
                 list(x = 600, y = max(df$views) * 0.15,
                      text = "The TAIL<br>(Niche Items)",
                      showarrow = TRUE, arrowcolor = '#ffb49a',
                      font = list(color = '#ffb49a', size = 11))
               )) %>%
        plotly_dark_theme()
      
      p
    })
    
    # Netflix Prize progress visualization
    output$netflix_prize_plot <- renderPlotly({
      # Simulated progress of top teams
      timeline <- data.frame(
        year = rep(seq(2006.5, 2009.5, by = 0.25), 3),
        team = rep(c("BellKor", "Dinosaur Planet", "Gravity"), each = 14),
        rmse_improvement = c(
          c(0, 1.2, 2.5, 3.8, 5.1, 6.3, 7.2, 8.1, 8.7, 9.2, 9.5, 9.8, 10.0, 10.06),
          c(0, 0.8, 1.9, 3.2, 4.5, 5.6, 6.5, 7.3, 7.9, 8.4, 8.8, 9.1, 9.4, 9.7),
          c(0, 0.5, 1.3, 2.4, 3.7, 4.8, 5.7, 6.4, 7.0, 7.5, 7.9, 8.3, 8.6, 8.9)
        )
      )
      
      p <- plot_ly() %>%
        add_trace(data = timeline[timeline$team == "BellKor",], 
                 x = ~year, y = ~rmse_improvement, type = 'scatter', mode = 'lines+markers',
                 name = 'BellKor (Winner)', line = list(color = '#e8410a', width = 3),
                 marker = list(size = 6)) %>%
        add_trace(data = timeline[timeline$team == "Dinosaur Planet",], 
                 x = ~year, y = ~rmse_improvement, type = 'scatter', mode = 'lines+markers',
                 name = 'Dinosaur Planet', line = list(color = '#3b82f6', width = 2),
                 marker = list(size = 5)) %>%
        add_trace(data = timeline[timeline$team == "Gravity",], 
                 x = ~year, y = ~rmse_improvement, type = 'scatter', mode = 'lines+markers',
                 name = 'Gravity', line = list(color = '#10b981', width = 2),
                 marker = list(size = 5)) %>%
        layout(title = list(text = "Netflix Prize: Race to 10% RMSE Improvement",
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "Year", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               yaxis = list(title = "RMSE Improvement (%)", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               shapes = list(
                 list(type = "line", x0 = 2006.5, x1 = 2009.5, y0 = 10, y1 = 10,
                      line = list(color = '#fbbf24', width = 2, dash = 'dash'))
               ),
               annotations = list(
                 list(x = 2009, y = 10.5, text = "10% Target",
                      showarrow = FALSE, font = list(color = '#fbbf24', size = 11))
               ),
               legend = list(font = list(color = '#8a9bb0'))) %>%
        plotly_dark_theme()
      
      p
    })
  })
}
