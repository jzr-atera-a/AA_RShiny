# modules/chapter3.R
# Chapter 3: Monitoring the System

chapter3_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 3: Monitoring the System"),
        tags$h2("Building Analytics and Dashboards for RecSys"),
        div(
          span(class="hero-badge","Web Analytics"),
          span(class="hero-badge","Dashboards"),
          span(class="hero-badge","A/B Testing"),
          span(class="hero-badge","Metrics")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "3"), span(class="metric-label","Dashboard Types"))),
            column(3, div(class="metric-card", span(class="metric-value", "10+"), span(class="metric-label","Key Metrics"))),
            column(3, div(class="metric-card", span(class="metric-value", "Real-time"), span(class="metric-label","Monitoring"))),
            column(3, div(class="metric-card", span(class="metric-value", "A/B"), span(class="metric-label","Testing")))
          )
      )
    ),

    fluidRow(
      box(title="📊 Why Monitor Recommender Systems?", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Core Principle:</strong> You can't improve what you don't measure. Monitoring tells you if recommendations are working and how to make them better.")),
          br(),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("Business Metrics"),
                       tags$p(HTML("<strong>CTR:</strong> Click-through rate")),
                       tags$p(HTML("<strong>Conversion:</strong> Purchase rate")),
                       tags$p(HTML("<strong>Engagement:</strong> Time spent"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Algorithmic Metrics"),
                       tags$p(HTML("<strong>Precision:</strong> % relevant")),
                       tags$p(HTML("<strong>Recall:</strong> % found")),
                       tags$p(HTML("<strong>Diversity:</strong> Variety"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("System Metrics"),
                       tags$p(HTML("<strong>Latency:</strong> Response time")),
                       tags$p(HTML("<strong>Throughput:</strong> Requests/sec")),
                       tags$p(HTML("<strong>Cache hits:</strong> Pre-computed %"))
                   ))
          ),
          br(),
          plotlyOutput(ns("metrics_dashboard"))
      )
    ),

    fluidRow(
      box(title="📈 Dashboard Types", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "1. Real-Time Operational"),
          div(class="framework-card",
              tags$p(HTML("<strong>Purpose:</strong> Monitor system health")),
              tags$p(HTML("<strong>Frequency:</strong> Every 1-60 seconds")),
              tags$p(HTML("<strong>Users:</strong> DevOps engineers"))
          ),
          br(),
          div(class="section-heading-dark", "2. Business Performance"),
          div(class="framework-card",
              tags$p(HTML("<strong>Purpose:</strong> Track business impact")),
              tags$p(HTML("<strong>Frequency:</strong> Hourly or daily")),
              tags$p(HTML("<strong>Users:</strong> Product managers"))
          ),
          br(),
          div(class="section-heading-dark", "3. Algorithm Analysis"),
          div(class="framework-card",
              tags$p(HTML("<strong>Purpose:</strong> Algorithm performance")),
              tags$p(HTML("<strong>Frequency:</strong> Daily")),
              tags$p(HTML("<strong>Users:</strong> Data scientists"))
          )
      ),

      box(title="🧪 A/B Testing", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Experimentation Framework"),
          div(class="framework-card",
              tags$h5("How to Run A/B Tests"),
              tags$p(HTML("<strong>1. Hypothesis:</strong> New algorithm improves CTR")),
              tags$p(HTML("<strong>2. Split traffic:</strong> 50/50 control vs treatment")),
              tags$p(HTML("<strong>3. Run:</strong> 2-4 weeks minimum")),
              tags$p(HTML("<strong>4. Measure:</strong> CTR, conversion, engagement")),
              tags$p(HTML("<strong>5. Statistical test:</strong> t-test for significance")),
              tags$p(HTML("<strong>6. Decision:</strong> Ship if significantly better"))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Common Pitfalls:</strong> Small sample size, testing too short, ignoring guardrail metrics")),
          br(),
          plotlyOutput(ns("ab_test_plot"))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Three dashboard types:</strong> Operational, business, algorithm")),
                     tags$li(HTML("<strong>A/B testing is essential</strong> to prove improvements")),
                     tags$li(HTML("<strong>Guardrail metrics</strong> prevent regression")),
                     tags$li(HTML("<strong>Start simple</strong> with basic logging and CTR"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li("Log all recommendations and interactions"),
                     tags$li("Pre-compute metrics, don't calculate on load"),
                     tags$li("Automate daily reporting"),
                     tags$li("Run experiments continuously")
                   ))
          )
      )
    )
  )
}

chapter3_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$metrics_dashboard <- renderPlotly({
      days <- seq(as.Date("2024-01-01"), as.Date("2024-01-30"), by = "day")
      metrics <- data.frame(
        date = days,
        ctr = 0.08 + rnorm(30, 0, 0.005),
        conversion = 0.12 + rnorm(30, 0, 0.008)
      )
      
      p <- plot_ly(metrics) %>%
        add_trace(x = ~date, y = ~ctr*100, name = "CTR (%)", 
                 type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#e8410a', width = 2)) %>%
        add_trace(x = ~date, y = ~conversion*100, name = "Conversion (%)",
                 type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#3b82f6', width = 2)) %>%
        layout(title = list(text = "Business Metrics - January 2024",
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "Date", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               yaxis = list(title = "Percentage (%)", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               legend = list(font = list(color = '#8a9bb0'))) %>%
        plotly_dark_theme()
      
      p
    })
    
    output$ab_test_plot <- renderPlotly({
      results <- data.frame(
        variant = c("Control", "Treatment"),
        ctr = c(7.2, 8.5),
        conversion = c(11.5, 13.2)
      )
      
      p <- plot_ly(results, x = ~variant, y = ~ctr, type = 'bar',
                   name = 'CTR (%)', marker = list(color = '#e8410a')) %>%
        add_trace(y = ~conversion, name = 'Conversion (%)', 
                 marker = list(color = '#3b82f6')) %>%
        layout(title = list(text = "A/B Test Results",
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               yaxis = list(title = "Percentage (%)", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               barmode = 'group',
               legend = list(font = list(color = '#8a9bb0'))) %>%
        plotly_dark_theme()
      
      p
    })
  })
}
