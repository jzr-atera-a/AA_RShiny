# modules/overview.R
# Tab: Overview & Book Guide — Practical Recommender Systems

overview_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Practical Recommender Systems"),
        tags$h2("Learning to Build RecSys from Scratch — Kim Falk · Manning 2019"),
        div(
          span(class="hero-badge","Netflix-Style Algorithms"),
          span(class="hero-badge","Python Implementation"),
          span(class="hero-badge","Real-World Examples"),
          span(class="hero-badge","MovieGEEKs Project")
        )
    ),

    fluidRow(
      box(title="📊 Book Statistics", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(2, div(class="metric-card", span(class="metric-value", "14"),   span(class="metric-label","Total Chapters"))),
            column(2, div(class="metric-card", span(class="metric-value", "432"),  span(class="metric-label","Pages"))),
            column(2, div(class="metric-card", span(class="metric-value", "2"),    span(class="metric-label","Main Parts"))),
            column(2, div(class="metric-card", span(class="metric-value", "⭐⭐⭐⭐⭐"), span(class="metric-label","8/10 Rating"))),
            column(2, div(class="metric-card", span(class="metric-value", "2019"), span(class="metric-label","Publication Year"))),
            column(2, div(class="metric-card", span(class="metric-value", "Python"), span(class="metric-label","Language")))
          )
      )
    ),

    fluidRow(
      box(title="📚 Complete Book Structure", status="primary", solidHeader=TRUE, width=7,
          div(class="success-box",
              HTML("<strong>✅ Book Overview:</strong> Kim Falk teaches recommender systems through a practical, hands-on approach using the MovieGEEKs project—a complete movie recommendation platform built throughout the book.")),
          br(),
          div(class="scroll-pane",
            tags$div(style="margin-bottom: 18px;",
                     tags$div(class="section-heading-dark", "PART 1: GETTING READY FOR RECOMMENDER SYSTEMS")),
            chapter_card("CH 1","What is a Recommender?","Real-life recommendations, internet recommenders, the long tail phenomenon, Netflix Prize, recommendation types",c("Foundations","Long Tail","Types")),
            chapter_card("CH 2","User Behavior and How to Collect It","Understanding user behavior, data collection methods, tracking visitors, implicit vs explicit feedback",c("Data Collection","Tracking","Behavior")),
            chapter_card("CH 3","Monitoring the System","Web analytics implementation, dashboards, tracking recommender performance, A/B testing setup",c("Analytics","Dashboards","Monitoring")),
            chapter_card("CH 4","Ratings and How to Calculate Them","Transforming behavioral data into ratings, explicit vs implicit ratings, rating prediction",c("Ratings","Prediction","Transformations")),
            chapter_card("CH 5","Non-Personalized Recommendations","Popularity-based recommendations, trending items, most viewed, seeded recommendations",c("Popularity","Trending","Basic RecSys")),
            chapter_card("CH 6","The User (and Content) Who Came in from the Cold","Cold-start problem, new users and items, association rules, bootstrapping recommendations",c("Cold Start","Bootstrapping","Association Rules")),
            tags$div(style="margin: 18px 0;",
                     tags$div(class="section-heading-dark", "PART 2: RECOMMENDER ALGORITHMS")),
            chapter_card("CH 7","Finding Similarities Among Users and Among Content","Similarity metrics, cosine similarity, Euclidean distance, k-means clustering",c("Similarity","Clustering","Distance Metrics")),
            chapter_card("CH 8","Collaborative Filtering in the Neighborhood","User-based CF, item-based CF, neighborhood selection, Amazon's algorithm, predicted ratings",c("Collaborative Filtering","Neighborhoods","Amazon")),
            chapter_card("CH 9","Evaluating and Testing Your Recommender","Offline evaluation metrics, precision/recall, RMSE, online A/B testing, statistical significance",c("Evaluation","A/B Testing","Metrics")),
            chapter_card("CH 10","Content-Based Filtering","TF-IDF, Latent Dirichlet Allocation, content similarity, genre-based recommendations",c("TF-IDF","LDA","Content Features")),
            chapter_card("CH 11","Finding Hidden Genres with Matrix Factorization","SVD, Funk SVD, latent factors, dimensional reduction, explicit vs implicit feedback",c("Matrix Factorization","SVD","Latent Factors")),
            chapter_card("CH 12","Taking the Best of All Algorithms: Hybrid Recommenders","Monolithic hybrids, mixed hybrids, ensemble methods, FWLS, combining algorithms",c("Hybrid Systems","Ensemble","Combination")),
            chapter_card("CH 13","Ranking and Learning to Rank","Learning to rank, Bayesian Personalized Ranking (BPR), re-ranking strategies, Foursquare case study",c("LTR","BPR","Ranking")),
            chapter_card("CH 14","Future of Recommender Systems","Future trends, topics to study next, context-aware recommendations, deep learning approaches",c("Future","Trends","Next Steps"))
          )
      ),

      box(title="🎯 Learning Path & Approach", status="info", solidHeader=TRUE, width=5,
          div(class="section-heading-dark","The MovieGEEKs Project"),
          div(class="framework-card",
              tags$h5("Hands-On Learning"),
              tags$p("Throughout the book, you'll build a complete movie recommendation platform called MovieGEEKs. This Django-based website includes:"),
              tags$p(HTML("<strong>Frontend:</strong> User-facing movie browsing and recommendations")),
              tags$p(HTML("<strong>Backend:</strong> Analytics dashboards for data scientists")),
              tags$p(HTML("<strong>Database:</strong> Real MovieLens dataset with thousands of ratings")),
              tags$p(HTML("<strong>Algorithms:</strong> Progressive implementation of all major RecSys techniques"))),
          div(class="warn-box",
              HTML("<strong>⚠️ Prerequisites:</strong> The book assumes intermediate programming skills in Python or Java, understanding of SQL queries, and basic higher math/statistics.")),
          br(),
          div(class="section-heading-dark","Recommended Study Timeline"),
          timeline_entry("1-2", "Ch.1-2 — Foundations", "Understand what recommenders are and how to collect user data."),
          timeline_entry("3-4", "Ch.3-4 — Infrastructure",  "Set up monitoring and learn rating calculations."),
          timeline_entry("5-6", "Ch.5-6 — Basic Systems", "Implement non-personalized recs and solve cold-start."),
          timeline_entry("7-9", "Ch.7-9 — Core Algorithms", "Master similarity, collaborative filtering, and evaluation."),
          timeline_entry("10-12", "Ch.10-12 — Advanced", "Content-based filtering, matrix factorization, hybrids."),
          timeline_entry("13-14", "Ch.13-14 — Production", "Learning to rank and future directions."),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Pro Tip:</strong> Code along with each chapter using the MovieGEEKs repository. The practical implementation solidifies theoretical concepts."))
      )
    ),

    fluidRow(
      box(title="🔑 Key Concepts Covered", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark","Core Recommendation Techniques"),
          tags$ul(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
            tags$li(HTML("<strong>Collaborative Filtering:</strong> User-based and item-based approaches, neighborhood selection")),
            tags$li(HTML("<strong>Content-Based Filtering:</strong> TF-IDF, LDA, genre and metadata analysis")),
            tags$li(HTML("<strong>Matrix Factorization:</strong> SVD, Funk SVD, latent factor models")),
            tags$li(HTML("<strong>Hybrid Systems:</strong> Combining multiple algorithms for better accuracy")),
            tags$li(HTML("<strong>Learning to Rank:</strong> BPR, pairwise and listwise ranking")),
            tags$li(HTML("<strong>Cold-Start Solutions:</strong> Association rules, content-based bootstrapping"))
          ),
          br(),
          div(class="section-heading-dark","Practical Implementation Topics"),
          tags$ul(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
            tags$li(HTML("<strong>Data Collection:</strong> Tracking user behavior, implicit vs explicit feedback")),
            tags$li(HTML("<strong>Monitoring & Analytics:</strong> Dashboards, metrics, A/B testing")),
            tags$li(HTML("<strong>Evaluation:</strong> Offline metrics (RMSE, precision, recall), online testing")),
            tags$li(HTML("<strong>Scalability:</strong> Optimizations for production systems")),
            tags$li(HTML("<strong>Real-World Examples:</strong> Amazon, Netflix, Foursquare case studies"))
          )
      ),
      
      box(title="🎓 Who This Book Is For", status="warning", solidHeader=TRUE, width=6,
          div(class="info-box-plain",
              HTML("<strong>Perfect for:</strong> Data scientists, ML engineers, and developers who want to understand and implement recommender systems from scratch.")),
          br(),
          div(class="section-heading-dark","Skill Requirements"),
          tags$table(class="algo-table",
            tags$tr(tags$td(HTML("<strong>Programming:</strong>")), tags$td("Intermediate Python or Java")),
            tags$tr(tags$td(HTML("<strong>Databases:</strong>")), tags$td("Basic SQL knowledge")),
            tags$tr(tags$td(HTML("<strong>Math/Stats:</strong>")), tags$td("Basic understanding required")),
            tags$tr(tags$td(HTML("<strong>ML Background:</strong>")), tags$td("Helpful but not required"))
          ),
          br(),
          div(class="section-heading-dark","What You'll Gain"),
          tags$ul(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
            tags$li("Build production-ready recommender systems"),
            tags$li("Understand algorithms used by Amazon, Netflix, Spotify"),
            tags$li("Implement both offline and online evaluation"),
            tags$li("Handle real-world challenges: cold-start, scalability, diversity"),
            tags$li("Create hybrid systems combining multiple approaches")
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>📖 Book Resources:</strong> Source code available on GitHub, active community forum on Manning's website, downloadable MovieLens dataset included."))
      )
    )
  )
}

overview_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # No reactive components in overview
  })
}
