# modules/chapter2.R
# Chapter 2: User Behavior and How to Collect It

chapter2_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 2: User Behavior and How to Collect It"),
        tags$h2("Understanding Users Through Data Collection"),
        div(
          span(class="hero-badge","Implicit Feedback"),
          span(class="hero-badge","Explicit Ratings"),
          span(class="hero-badge","Tracking"),
          span(class="hero-badge","Data Engineering")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "2"), span(class="metric-label","Main Data Types"))),
            column(3, div(class="metric-card", span(class="metric-value", "5+"), span(class="metric-label","Collection Methods"))),
            column(3, div(class="metric-card", span(class="metric-value", "✓"), span(class="metric-label","Privacy Compliant"))),
            column(3, div(class="metric-card", span(class="metric-value", "Events"), span(class="metric-label","Core Data Unit")))
          )
      )
    ),

    fluidRow(
      box(title="📊 Explicit vs Implicit Feedback", status="info", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Understanding the Two Types of User Signals"),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Explicit Feedback"),
                       tags$p(HTML("<strong>Definition:</strong> Direct user input expressing preference")),
                       tags$p(HTML("<strong>Examples:</strong> Star ratings, thumbs up/down, reviews")),
                       tags$p(HTML("<strong>Pros:</strong> Clear intent, easier to interpret")),
                       tags$p(HTML("<strong>Cons:</strong> Sparse data, most users don't rate"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Implicit Feedback"),
                       tags$p(HTML("<strong>Definition:</strong> Inferred from behavior without direct input")),
                       tags$p(HTML("<strong>Examples:</strong> Clicks, purchases, watch time")),
                       tags$p(HTML("<strong>Pros:</strong> Abundant data, no user effort")),
                       tags$p(HTML("<strong>Cons:</strong> Ambiguous, no negative feedback"))
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ The Sparsity Problem:</strong> In Netflix's dataset, only 0.01% of user-item pairs had ratings. Implicit feedback helps fill the gaps.")),
          br(),
          plotlyOutput(ns("explicit_vs_implicit_plot"))
      )
    ),

    fluidRow(
      box(title="🔍 How Netflix Gathers Evidence", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Data Collection Methods"),
          div(class="framework-card",
              tags$h5("Browsing Events Tracked"),
              tags$p(HTML("<strong>1. Page Views:</strong> Which titles appear on screen")),
              tags$p(HTML("<strong>2. Watch Duration:</strong> How long user watches (key signal)")),
              tags$p(HTML("<strong>3. Clicks:</strong> User clicks to see details")),
              tags$p(HTML("<strong>4. Rating Actions:</strong> Thumbs up/down"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Key Insight:</strong> Watch duration is Netflix's most important signal."))
      ),

      box(title="📝 Types of User Events", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Event Taxonomy"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(tags$th("Event"), tags$th("Signal"), tags$th("Example"))
            ),
            tags$tbody(
              tags$tr(tags$td("Purchase"), tags$td("Very High"), tags$td("Bought product")),
              tags$tr(tags$td("Complete"), tags$td("High"), tags$td("Finished movie")),
              tags$tr(tags$td("Click"), tags$td("Medium"), tags$td("Clicked item")),
              tags$tr(tags$td("View"), tags$td("Low"), tags$td("Saw item"))
            )
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Implicit feedback</strong> provides abundant data")),
                     tags$li(HTML("<strong>Explicit feedback</strong> is clear but sparse")),
                     tags$li(HTML("<strong>Watch duration</strong> is the most honest signal")),
                     tags$li(HTML("<strong>Event weighting</strong> matters for quality"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li("Track all user interactions"),
                     tags$li("Use event streaming (Kafka)"),
                     tags$li("Weight events appropriately"),
                     tags$li("Ensure privacy compliance")
                   ))
          )
      )
    )
  )
}

chapter2_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$explicit_vs_implicit_plot <- renderPlotly({
      comparison <- data.frame(
        metric = c("Data Volume", "Signal Clarity", "User Effort", "Sparsity", "Coverage"),
        explicit = c(2, 9, 8, 9, 2),
        implicit = c(9, 5, 1, 2, 9)
      )
      
      p <- plot_ly(comparison, x = ~metric, y = ~explicit, type = 'bar', 
                   name = 'Explicit Feedback', marker = list(color = '#e8410a')) %>%
        add_trace(y = ~implicit, name = 'Implicit Feedback', 
                 marker = list(color = '#3b82f6')) %>%
        layout(title = list(text = "Explicit vs Implicit Feedback Characteristics",
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               yaxis = list(title = "Score (1-10)", gridcolor = 'rgba(255,255,255,0.08)', 
                           color = '#8a9bb0', range = c(0, 10)),
               barmode = 'group',
               legend = list(font = list(color = '#8a9bb0'))) %>%
        plotly_dark_theme()
      
      p
    })
  })
}
