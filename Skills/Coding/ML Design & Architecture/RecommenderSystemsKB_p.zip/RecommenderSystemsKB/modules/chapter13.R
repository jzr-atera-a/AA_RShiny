# modules/chapter13.R
# Chapter 13: Learning to Rank

chapter13_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 13: Learning to Rank"),
        tags$h2("Optimizing the Order of Recommendations"),
        div(
          span(class="hero-badge","BPR"),
          span(class="hero-badge","Pairwise"),
          span(class="hero-badge","Re-Ranking"),
          span(class="hero-badge","Position Bias")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "Order"), span(class="metric-label","Matters"))),
            column(3, div(class="metric-card", span(class="metric-value", "BPR"), span(class="metric-label","Pairwise Loss"))),
            column(3, div(class="metric-card", span(class="metric-value", "Top-10"), span(class="metric-label","Optimize Ranking"))),
            column(3, div(class="metric-card", span(class="metric-value", "Foursquare"), span(class="metric-label","Case Study")))
          )
      )
    ),

    fluidRow(
      box(title="📊 Why Ranking Matters", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Critical Insight:</strong> Predicting ratings is not the goal. The goal is ranking items correctly. User clicks top results, not bottom.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Rating Prediction vs Ranking"),
                       tags$p(HTML("<strong>Rating prediction:</strong> Minimize RMSE")),
                       tags$p(HTML("<strong>Goal:</strong> Predict 4.2 vs 4.5 correctly")),
                       tags$p(HTML("<strong>Problem:</strong> User doesn't care about 0.3 difference")),
                       tags$p(HTML("<strong>What matters:</strong> Is it in top-10 or not?"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Position Bias"),
                       tags$p(HTML("<strong>Fact:</strong> 80% of clicks go to top 3 positions")),
                       tags$p(HTML("<strong>Effect:</strong> Position 1 vs 5 = 5x CTR difference")),
                       tags$p(HTML("<strong>Implication:</strong> Order matters more than absolute score")),
                       tags$p(HTML("<strong>Goal:</strong> Optimize top-K precision, not RMSE"))
                   ))
          ),
          br(),
          plotlyOutput(ns("position_bias_plot"))
      )
    ),

    fluidRow(
      box(title="🎯 BPR: Bayesian Personalized Ranking", status="success", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "The Pairwise Ranking Approach"),
          div(class="info-box-plain",
              HTML("<strong>💡 Key Idea:</strong> Don't predict ratings. Just learn: is item i ranked higher than item j for user u?")),
          br(),
          div(class="framework-card",
              tags$h5("The BPR Criterion"),
              tags$p(HTML("<strong>Assumption:</strong> User prefers item i over item j if they interacted with i but not j")),
              tags$p(HTML("<strong>Objective:</strong> Maximize P(i >ᵤ j) for all (u, i, j) triples")),
              tags$p(HTML("<strong>Loss:</strong> -Σ ln σ(r̂ᵤᵢ - r̂ᵤⱼ)")),
              tags$p(HTML("<strong>Where:</strong> σ = sigmoid function, r̂ = predicted score"))
          ),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Training Data Generation"),
                       tags$p(HTML("<strong>Positive:</strong> Items user clicked/bought")),
                       tags$p(HTML("<strong>Negative:</strong> Random unobserved items")),
                       tags$p(HTML("<strong>Triple:</strong> (user, positive_item, negative_item)")),
                       tags$p(HTML("<strong>Example:</strong> (Alice, Matrix, random_unclicked_movie)")),
                       tags$p(HTML("<strong>Result:</strong> Millions of training triples"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Optimization"),
                       tags$p(HTML("<strong>Model:</strong> Matrix factorization, neural network, etc.")),
                       tags$p(HTML("<strong>Update:</strong> SGD on pairwise loss")),
                       tags$p(HTML("<strong>Regularization:</strong> L2 penalty on parameters")),
                       tags$p(HTML("<strong>Learning rate:</strong> 0.001-0.01")),
                       tags$p(HTML("<strong>Epochs:</strong> Until convergence (20-50)"))
                   ))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Why BPR Works:</strong> Directly optimizes ranking metric (AUC) instead of rating prediction (RMSE). Perfect for implicit feedback."))
      )
    ),

    fluidRow(
      box(title="🔄 Re-Ranking Strategies", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Post-Processing for Better Results"),
          div(class="framework-card",
              tags$h5("1. Diversity Re-Ranking"),
              tags$p(HTML("<strong>Problem:</strong> Top-10 all similar (e.g., all action movies)")),
              tags$p(HTML("<strong>Solution:</strong> MMR (Maximal Marginal Relevance)")),
              tags$p(HTML("<strong>Formula:</strong> Select item that maximizes relevance - similarity to already selected")),
              tags$p(HTML("<strong>Result:</strong> Mix of genres/types in top-10"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("2. Freshness Boosting"),
              tags$p(HTML("<strong>Problem:</strong> Old popular items dominate")),
              tags$p(HTML("<strong>Solution:</strong> Boost recent items (released <30 days)")),
              tags$p(HTML("<strong>Formula:</strong> score × (1 + 0.2 if recent)")),
              tags$p(HTML("<strong>Result:</strong> Users discover new content"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("3. Personalized Diversity"),
              tags$p(HTML("<strong>Insight:</strong> Some users want variety, others want consistency")),
              tags$p(HTML("<strong>Solution:</strong> Learn diversity preference per user")),
              tags$p(HTML("<strong>Implementation:</strong> Track genre spread in past clicks"))
          )
      ),

      box(title="📍 Case Study: Foursquare", status="primary", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Location-Based Recommendations"),
          div(class="framework-card",
              tags$h5("The Challenge"),
              tags$p(HTML("<strong>Context:</strong> Recommend restaurants/venues")),
              tags$p(HTML("<strong>Data:</strong> Check-ins (implicit feedback)")),
              tags$p(HTML("<strong>Sparsity:</strong> Millions of venues, sparse visits")),
              tags$p(HTML("<strong>Cold-start:</strong> New venues constantly added"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("The Solution"),
              tags$p(HTML("<strong>Base model:</strong> BPR with MF")),
              tags$p(HTML("<strong>Features:</strong> Location, category, time of day")),
              tags$p(HTML("<strong>Re-ranking:</strong> Boost nearby venues")),
              tags$p(HTML("<strong>Diversity:</strong> Mix categories (food, nightlife, shops)")),
              tags$p(HTML("<strong>Result:</strong> 30% CTR improvement"))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Lesson:</strong> BPR + context features + re-ranking = production-grade system"))
      )
    ),

    fluidRow(
      box(title="🧮 Listwise vs Pairwise vs Pointwise", status="info", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Three Ranking Paradigms"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(
                tags$th("Approach"),
                tags$th("What It Optimizes"),
                tags$th("Training Data"),
                tags$th("Examples")
              )
            ),
            tags$tbody(
              tags$tr(
                tags$td(HTML("<strong>Pointwise</strong>")),
                tags$td("Predict rating for each item"),
                tags$td("(user, item, rating)"),
                tags$td("Matrix Factorization, Regression")
              ),
              tags$tr(
                tags$td(HTML("<strong>Pairwise</strong>")),
                tags$td("Compare pairs of items"),
                tags$td("(user, item_i, item_j)"),
                tags$td("BPR, RankNet")
              ),
              tags$tr(
                tags$td(HTML("<strong>Listwise</strong>")),
                tags$td("Optimize entire ranking"),
                tags$td("(user, ranked_list)"),
                tags$td("LambdaMART, ListNet")
              )
            )
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Trade-off:</strong> Pointwise is easiest but optimizes wrong metric. Listwise is best but hardest to train. Pairwise (BPR) is the sweet spot."))
      )
    ),

    fluidRow(
      box(title="⚡ Advanced: Neural Ranking Models", status="warning", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Deep Learning for Ranking"),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Neural Collaborative Filtering"),
                       tags$p(HTML("<strong>Architecture:</strong> User/item embeddings → deep network → score")),
                       tags$p(HTML("<strong>Loss:</strong> BPR pairwise loss")),
                       tags$p(HTML("<strong>Advantage:</strong> Learn non-linear interactions")),
                       tags$p(HTML("<strong>Used by:</strong> YouTube, Pinterest"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Two-Tower Models"),
                       tags$p(HTML("<strong>User tower:</strong> DNN on user features")),
                       tags$p(HTML("<strong>Item tower:</strong> DNN on item features")),
                       tags$p(HTML("<strong>Scoring:</strong> Dot product of tower outputs")),
                       tags$p(HTML("<strong>Advantage:</strong> Fast inference, pre-compute item tower"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Ranking > rating prediction:</strong> Top-K precision is what matters")),
                     tags$li(HTML("<strong>BPR is gold standard:</strong> Pairwise ranking for implicit feedback")),
                     tags$li(HTML("<strong>Re-ranking adds value:</strong> Diversity, freshness, personalization")),
                     tags$li(HTML("<strong>Position bias is real:</strong> Top 3 get 80% of clicks"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Use BPR loss for implicit feedback"),
                     tags$li("Generate (user, pos_item, neg_item) triples"),
                     tags$li("Add re-ranking for diversity and freshness"),
                     tags$li("Monitor ranking metrics (MAP, NDCG) not RMSE")
                   ))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Production Reality:</strong> Modern systems use neural ranking models with BPR loss, trained on billions of interactions."))
      )
    )
  )
}

chapter13_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$position_bias_plot <- renderPlotly({
      positions <- data.frame(
        rank = 1:10,
        ctr = c(35, 18, 12, 8, 5, 3.5, 2.5, 1.8, 1.2, 0.8)
      )
      
      p <- plot_ly(positions, x = ~rank, y = ~ctr, type = 'bar',
                   marker = list(color = '#008A82'),
                   text = ~paste0(ctr, "%"),
                   textposition = 'outside') %>%
        layout(title = list(text = "Position Bias: CTR by Ranking Position",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "Rank Position", color = '#2c3e50'),
               yaxis = list(title = "Click-Through Rate (%)", color = '#2c3e50'),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'),
               annotations = list(
                 list(x = 1, y = 35, text = "Top position gets 35% CTR",
                      showarrow = FALSE, yanchor = 'bottom',
                      font = list(color = '#008A82', size = 11))
               ))
      
      p
    })
  })
}
