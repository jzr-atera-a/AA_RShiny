# modules/chapter8.R
# Chapter 8: Collaborative Filtering

chapter8_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 8: Collaborative Filtering"),
        tags$h2("The Core Algorithm Behind Modern Recommendations"),
        div(
          span(class="hero-badge","User-Based"),
          span(class="hero-badge","Item-Based"),
          span(class="hero-badge","Neighborhoods"),
          span(class="hero-badge","Amazon's Algorithm")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "35%"), span(class="metric-label","Amazon Revenue"))),
            column(3, div(class="metric-card", span(class="metric-value", "80%"), span(class="metric-label","Netflix Watches"))),
            column(3, div(class="metric-card", span(class="metric-value", "2"), span(class="metric-label","Main Approaches"))),
            column(3, div(class="metric-card", span(class="metric-value", "Winner"), span(class="metric-label","Item-Based")))
          )
      )
    ),

    fluidRow(
      box(title="🤝 What is Collaborative Filtering?", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Core Principle:</strong> 'People who agreed in the past will agree in the future.' Find users with similar tastes, recommend what they liked.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("The Magic"),
                       tags$ul(
                         tags$li(HTML("<strong>No content needed:</strong> Pure behavior patterns")),
                         tags$li(HTML("<strong>Discovers hidden patterns:</strong> Beyond obvious similarities")),
                         tags$li(HTML("<strong>Serendipity:</strong> Finds unexpected connections")),
                         tags$li(HTML("<strong>Proven at scale:</strong> Amazon, Netflix, YouTube"))
                       )
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("The Challenges"),
                       tags$ul(
                         tags$li(HTML("<strong>Sparsity:</strong> Most users rate few items")),
                         tags$li(HTML("<strong>Scalability:</strong> N×M matrix grows huge")),
                         tags$li(HTML("<strong>Cold start:</strong> Needs interaction data")),
                         tags$li(HTML("<strong>Popularity bias:</strong> Popular items dominate"))
                       )
                   ))
          )
      )
    ),

    fluidRow(
      box(title="👥 User-Based Collaborative Filtering", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Find Similar Users"),
          div(class="framework-card",
              tags$h5("Algorithm"),
              tags$p(HTML("<strong>1.</strong> Find K most similar users to target user")),
              tags$p(HTML("<strong>2.</strong> Collect items they liked")),
              tags$p(HTML("<strong>3.</strong> Weight by similarity score")),
              tags$p(HTML("<strong>4.</strong> Recommend top-N items"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Example"),
              tags$p(HTML("<strong>User A</strong> liked: Matrix, Inception, Interstellar")),
              tags$p(HTML("<strong>Similar users</strong> also liked: Blade Runner, Ex Machina")),
              tags$p(HTML("<strong>Recommend:</strong> Blade Runner (seen by 80% of similar users)"))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Problem:</strong> User tastes change. Matrix recomputation expensive. Doesn't scale to billions of users."))
      ),

      box(title="📦 Item-Based Collaborative Filtering", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Find Similar Items (Amazon's Secret)"),
          div(class="framework-card",
              tags$h5("Algorithm"),
              tags$p(HTML("<strong>1.</strong> Pre-compute item-item similarity matrix")),
              tags$p(HTML("<strong>2.</strong> For each item user liked, find K similar items")),
              tags$p(HTML("<strong>3.</strong> Aggregate similarity scores")),
              tags$p(HTML("<strong>4.</strong> Recommend top-N items"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Why It's Better"),
              tags$ul(
                tags$li(HTML("<strong>Stable:</strong> Item relationships change slowly")),
                tags$li(HTML("<strong>Scalable:</strong> Pre-compute once, use millions of times")),
                tags$li(HTML("<strong>Explainable:</strong> 'Because you watched X'")),
                tags$li(HTML("<strong>Amazon:</strong> 35% of sales from item-based CF"))
              )
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Industry Standard:</strong> Item-based CF is the workhorse of production recommender systems."))
      )
    ),

    fluidRow(
      box(title="🧮 The Math: Prediction Formula", status="primary", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Weighted Average of Similar Items"),
          div(class="framework-card",
              tags$h5("Item-Based Prediction"),
              tags$p(HTML("<strong>pred(u,i) = Σ(sim(i,j) × r_uj) / Σ|sim(i,j)|</strong>")),
              tags$p(HTML("<strong>Where:</strong> j = items user u has rated, sim(i,j) = similarity between items i and j, r_uj = user u's rating for item j"))
          ),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Example Calculation"),
                       tags$p(HTML("Predict rating for 'Inception'")),
                       tags$p(HTML("User rated: Matrix=5 (sim=0.8), Interstellar=4 (sim=0.6)")),
                       tags$p(HTML("Prediction = (0.8×5 + 0.6×4) / (0.8+0.6) = 6.4/1.4 = 4.57"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Normalization"),
                       tags$p(HTML("<strong>Bias adjustment:</strong> pred = user_mean + weighted_avg")),
                       tags$p(HTML("<strong>Why:</strong> Accounts for harsh vs generous raters")),
                       tags$p(HTML("<strong>Result:</strong> More accurate predictions"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="⚡ Neighborhoods: Filtering Noise", status="info", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Don't Use All Similar Items"),
          div(class="info-box-plain",
              HTML("<strong>💡 Key Insight:</strong> Using too many neighbors adds noise. Use only top-K most similar items (typically K=20-50).")),
          br(),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("Top-K Selection"),
                       tags$p(HTML("<strong>K=20:</strong> Fast, works for most")),
                       tags$p(HTML("<strong>K=50:</strong> Better quality, slower")),
                       tags$p(HTML("<strong>Threshold:</strong> sim > 0.3 minimum"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Significance Weighting"),
                       tags$p(HTML("<strong>Problem:</strong> 1-overlap = unreliable")),
                       tags$p(HTML("<strong>Solution:</strong> Weight by # co-raters")),
                       tags$p(HTML("<strong>Formula:</strong> sim × min(overlap, 50)/50"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Diversity"),
                       tags$p(HTML("<strong>Issue:</strong> Similar items = redundant")),
                       tags$p(HTML("<strong>Fix:</strong> Penalize similar neighbors")),
                       tags$p(HTML("<strong>MMR:</strong> Max marginal relevance"))
                   ))
          ),
          br(),
          plotlyOutput(ns("neighborhood_plot"))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Item-based > user-based</strong> for production")),
                     tags$li(HTML("<strong>Pre-compute similarity:</strong> Don't calculate on demand")),
                     tags$li(HTML("<strong>Neighborhoods matter:</strong> Top-K filtering essential")),
                     tags$li(HTML("<strong>Normalize ratings:</strong> Account for user bias"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Build item-item similarity matrix offline"),
                     tags$li("Use cosine or Pearson similarity"),
                     tags$li("Store top-50 neighbors per item"),
                     tags$li("Update similarity matrix weekly/monthly")
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Amazon's Lesson:</strong> Item-based CF drove 35% of revenue because it scales, it's stable, and it's explainable."))
      )
    )
  )
}

chapter8_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$neighborhood_plot <- renderPlotly({
      k_values <- data.frame(
        k = c(5, 10, 20, 30, 50, 100),
        rmse = c(0.95, 0.88, 0.82, 0.81, 0.80, 0.81),
        time_ms = c(2, 4, 8, 12, 20, 40)
      )
      
      p <- plot_ly(k_values) %>%
        add_trace(x = ~k, y = ~rmse, type = 'scatter', mode = 'lines+markers',
                 name = 'RMSE (lower better)', yaxis = 'y',
                 line = list(color = '#008A82', width = 2),
                 marker = list(size = 10)) %>%
        add_trace(x = ~k, y = ~time_ms/50, type = 'scatter', mode = 'lines+markers',
                 name = 'Response Time (scaled)', yaxis = 'y',
                 line = list(color = '#e74c3c', width = 2),
                 marker = list(size = 10)) %>%
        layout(title = list(text = "Neighborhood Size vs Quality & Speed",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "K (Neighborhood Size)", color = '#2c3e50'),
               yaxis = list(title = "Score", color = '#2c3e50'),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'),
               annotations = list(
                 list(x = 30, y = 0.81, text = "Sweet spot: K=20-30",
                      showarrow = TRUE, arrowhead = 2, ax = 30, ay = -40,
                      font = list(color = '#008A82', size = 11))
               ))
      
      p
    })
  })
}
