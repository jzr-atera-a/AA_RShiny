# modules/chapter11.R
# Chapter 11: Matrix Factorization

chapter11_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 11: Matrix Factorization"),
        tags$h2("Latent Factors and the Netflix Prize Winner"),
        div(
          span(class="hero-badge","SVD"),
          span(class="hero-badge","Funk SVD"),
          span(class="hero-badge","Latent Factors"),
          span(class="hero-badge","Netflix Prize")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "Winner"), span(class="metric-label","Netflix Prize"))),
            column(3, div(class="metric-card", span(class="metric-value", "50-200"), span(class="metric-label","Latent Factors"))),
            column(3, div(class="metric-card", span(class="metric-value", "SGD"), span(class="metric-label","Training Method"))),
            column(3, div(class="metric-card", span(class="metric-value", "Scalable"), span(class="metric-label","Billions of Ratings")))
          )
      )
    ),

    fluidRow(
      box(title="🧮 The Core Idea", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Breakthrough Concept:</strong> Instead of storing full user×item matrix, decompose it into two smaller matrices: user factors × item factors. Reduces from millions of values to thousands.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("The Problem"),
                       tags$p(HTML("<strong>Rating matrix:</strong> 100K users × 10K movies = 1 billion cells")),
                       tags$p(HTML("<strong>Sparsity:</strong> 99% empty (users rate <1% of movies)")),
                       tags$p(HTML("<strong>Storage:</strong> Can't store or compute with full matrix")),
                       tags$p(HTML("<strong>Neighborhood CF:</strong> Doesn't scale to millions"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("The Solution"),
                       tags$p(HTML("<strong>Factorization:</strong> R ≈ P × Q^T")),
                       tags$p(HTML("<strong>P:</strong> Users × k latent factors (100K × 50)")),
                       tags$p(HTML("<strong>Q:</strong> Items × k latent factors (10K × 50)")),
                       tags$p(HTML("<strong>Result:</strong> 5.5M values instead of 1B (99.5% reduction)"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🔍 What Are Latent Factors?", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Hidden Dimensions of Taste"),
          div(class="framework-card",
              tags$h5("Movie Example"),
              tags$p(HTML("<strong>Factor 1:</strong> Action-ness (0.9 for Die Hard, 0.1 for Titanic)")),
              tags$p(HTML("<strong>Factor 2:</strong> Romance-ness (0.1 for Die Hard, 0.9 for Titanic)")),
              tags$p(HTML("<strong>Factor 3:</strong> Blockbuster-ness (0.8 for both)")),
              tags$p(HTML("<strong>Factor 4:</strong> Intellectual-ness (0.3 for Die Hard, 0.6 for Titanic)"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("User Factors"),
              tags$p(HTML("<strong>User A:</strong> [0.8, 0.2, 0.5, 0.3] — loves action")),
              tags$p(HTML("<strong>User B:</strong> [0.1, 0.9, 0.4, 0.7] — loves romance")),
              tags$p(HTML("<strong>Prediction:</strong> dot product of user × movie vectors"))
          ),
          br(),
          div(class="info-box-plain",
              HTML("<strong>💡 The Magic:</strong> Factors are learned automatically from data. Algorithm discovers hidden patterns humans never explicitly labeled."))
      ),

      box(title="📐 SVD: Singular Value Decomposition", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Classic Matrix Factorization"),
          div(class="framework-card",
              tags$h5("The Math"),
              tags$p(HTML("<strong>R = U Σ V^T</strong>")),
              tags$p(HTML("<strong>U:</strong> User latent vectors")),
              tags$p(HTML("<strong>Σ:</strong> Singular values (strength of factors)")),
              tags$p(HTML("<strong>V:</strong> Item latent vectors"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("The Problem with Classic SVD"),
              tags$ul(
                tags$li(HTML("<strong>Requires dense matrix:</strong> Can't handle missing values")),
                tags$li(HTML("<strong>Computationally expensive:</strong> O(n³) complexity")),
                tags$li(HTML("<strong>Overfits sparse data:</strong> Too many parameters")),
                tags$li(HTML("<strong>Not practical:</strong> Netflix had 99% missing values"))
              )
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Why Classic SVD Failed:</strong> Rating matrix is 99% empty. Can't fill in missing values without biasing the factorization."))
      )
    ),

    fluidRow(
      box(title="🏆 Funk SVD: The Netflix Prize Winner", status="primary", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Simon Funk's Breakthrough (2006)"),
          div(class="success-box",
              HTML("<strong>✅ Innovation:</strong> Only factorize observed ratings. Use gradient descent to learn factors, ignoring missing values entirely.")),
          br(),
          div(class="framework-card",
              tags$h5("The Algorithm"),
              tags$p(HTML("<strong>Prediction:</strong> r̂_ui = μ + b_u + b_i + p_u · q_i")),
              tags$p(HTML("<strong>Where:</strong> μ = global mean, b_u = user bias, b_i = item bias, p_u · q_i = latent factor interaction")),
              tags$p(HTML("<strong>Loss:</strong> Minimize Σ(r_ui - r̂_ui)² + λ(||p||² + ||q||² + b²)")),
              tags$p(HTML("<strong>Training:</strong> Stochastic gradient descent (SGD)"))
          ),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Training Process"),
                       tags$p(HTML("<strong>1. Initialize:</strong> Random p_u, q_i, biases")),
                       tags$p(HTML("<strong>2. For each rating:</strong> Compute error e = r - r̂")),
                       tags$p(HTML("<strong>3. Update:</strong> p_u += α(e·q_i - λ·p_u)")),
                       tags$p(HTML("<strong>4. Update:</strong> q_i += α(e·p_u - λ·q_i)")),
                       tags$p(HTML("<strong>5. Repeat:</strong> 20-100 epochs"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Hyperparameters"),
                       tags$p(HTML("<strong>k:</strong> # latent factors (20-200, typically 50)")),
                       tags$p(HTML("<strong>α:</strong> Learning rate (0.001-0.01)")),
                       tags$p(HTML("<strong>λ:</strong> Regularization (0.01-0.1)")),
                       tags$p(HTML("<strong>epochs:</strong> Iterations over data (20-50)"))
                   ))
          ),
          br(),
          plotlyOutput(ns("training_curve"))
      )
    ),

    fluidRow(
      box(title="⚙️ Implementation: MovieGEEKs Example", status="info", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Python Implementation"),
          div(class="framework-card",
              tags$h5("Core Training Loop"),
              tags$p(HTML("<strong>Libraries:</strong> NumPy, Pandas (no special libraries needed)")),
              tags$p(HTML("<strong>Data:</strong> User ID, Movie ID, Rating")),
              tags$p(HTML("<strong>Initialize:</strong> Random normal(0, 0.1) for p, q")),
              tags$p(HTML("<strong>Iterate:</strong> SGD updates for each rating")),
              tags$p(HTML("<strong>Monitor:</strong> RMSE on validation set"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Performance Tip:</strong> Vectorize updates using NumPy. Process mini-batches (100-1000 ratings) instead of one-by-one for 10x speedup."))
      )
    ),

    fluidRow(
      box(title="🚀 Advanced: ALS and Implicit Feedback", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Alternating Least Squares"),
          div(class="framework-card",
              tags$h5("ALS Algorithm"),
              tags$p(HTML("<strong>1. Fix Q, optimize P:</strong> Closed-form solution")),
              tags$p(HTML("<strong>2. Fix P, optimize Q:</strong> Closed-form solution")),
              tags$p(HTML("<strong>3. Alternate:</strong> Until convergence")),
              tags$p(HTML("<strong>Advantage:</strong> Parallelizable, good for implicit data"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Implicit Feedback MF"),
              tags$p(HTML("<strong>Data:</strong> Clicks, views, purchases (no ratings)")),
              tags$p(HTML("<strong>Confidence:</strong> # views = strength of preference")),
              tags$p(HTML("<strong>Used by:</strong> Spotify, YouTube"))
          )
      ),

      box(title="📊 Results: Netflix Prize", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Impact on Industry"),
          div(class="framework-card",
              tags$h5("Improvement Over Baseline"),
              tags$p(HTML("<strong>Netflix baseline:</strong> RMSE = 0.9514")),
              tags$p(HTML("<strong>Funk SVD:</strong> RMSE = 0.8914 (6.3% improvement)")),
              tags$p(HTML("<strong>Ensemble winner:</strong> RMSE = 0.8567 (10% improvement)")),
              tags$p(HTML("<strong>Prize:</strong> $1 million for <10% improvement"))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Legacy:</strong> Matrix factorization became standard. Used by Netflix, Spotify, Amazon, YouTube for billions of users."))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Latent factors = hidden dimensions</strong> of user taste and item characteristics")),
                     tags$li(HTML("<strong>Funk SVD solves sparsity:</strong> Only factorize observed ratings")),
                     tags$li(HTML("<strong>SGD is key:</strong> Gradient descent learns factors incrementally")),
                     tags$li(HTML("<strong>Won Netflix Prize:</strong> Beat neighborhood CF by large margin"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Start with k=50 factors, α=0.005, λ=0.02"),
                     tags$li("Train with SGD for 20-50 epochs"),
                     tags$li("Monitor RMSE on validation set"),
                     tags$li("Use ALS for implicit feedback (clicks, views)")
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Production Reality:</strong> Matrix factorization is the engine, but modern systems ensemble it with many other signals."))
      )
    )
  )
}

chapter11_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$training_curve <- renderPlotly({
      epochs <- 1:30
      train_rmse <- 1.05 * exp(-epochs/10) + 0.85
      val_rmse <- 1.08 * exp(-epochs/12) + 0.88
      
      df <- data.frame(epoch = epochs, train = train_rmse, validation = val_rmse)
      
      p <- plot_ly(df, x = ~epoch) %>%
        add_trace(y = ~train, name = 'Training RMSE', type = 'scatter', mode = 'lines',
                 line = list(color = '#008A82', width = 2)) %>%
        add_trace(y = ~validation, name = 'Validation RMSE', type = 'scatter', mode = 'lines',
                 line = list(color = '#e74c3c', width = 2)) %>%
        layout(title = list(text = "Funk SVD Training Curve",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "Epoch", color = '#2c3e50'),
               yaxis = list(title = "RMSE", color = '#2c3e50'),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'),
               annotations = list(
                 list(x = 20, y = 0.88, text = "Convergence around epoch 20",
                      showarrow = TRUE, arrowhead = 2, ax = 40, ay = -30,
                      font = list(color = '#008A82', size = 11))
               ))
      
      p
    })
  })
}
