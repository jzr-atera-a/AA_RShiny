# modules/chapter9.R
# Chapter 9: Evaluation and Testing

chapter9_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 9: Evaluation and Testing"),
        tags$h2("Measuring Recommendation Quality"),
        div(
          span(class="hero-badge","RMSE"),
          span(class="hero-badge","Precision/Recall"),
          span(class="hero-badge","A/B Testing"),
          span(class="hero-badge","Offline vs Online")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "2"), span(class="metric-label","Eval Types"))),
            column(3, div(class="metric-card", span(class="metric-value", "10+"), span(class="metric-label","Metrics"))),
            column(3, div(class="metric-card", span(class="metric-value", "A/B"), span(class="metric-label","Gold Standard"))),
            column(3, div(class="metric-card", span(class="metric-value", "Critical"), span(class="metric-label","Production Test")))
          )
      )
    ),

    fluidRow(
      box(title="📊 Offline vs Online Evaluation", status="info", solidHeader=TRUE, width=12,
          div(class="warn-box",
              HTML("<strong>⚠️ Critical Distinction:</strong> Offline metrics predict algorithm quality. Online metrics measure business impact. You need both.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Offline Evaluation"),
                       tags$p(HTML("<strong>Data:</strong> Historical ratings/interactions")),
                       tags$p(HTML("<strong>Process:</strong> Train/test split, compute metrics")),
                       tags$p(HTML("<strong>Metrics:</strong> RMSE, MAE, precision, recall")),
                       tags$p(HTML("<strong>Pros:</strong> Fast, cheap, repeatable")),
                       tags$p(HTML("<strong>Cons:</strong> Doesn't measure real user impact"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Online Evaluation"),
                       tags$p(HTML("<strong>Data:</strong> Live user interactions")),
                       tags$p(HTML("<strong>Process:</strong> A/B test, measure business KPIs")),
                       tags$p(HTML("<strong>Metrics:</strong> CTR, conversion, engagement, revenue")),
                       tags$p(HTML("<strong>Pros:</strong> Measures real impact")),
                       tags$p(HTML("<strong>Cons:</strong> Slow, expensive, risky"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="📐 Rating Prediction Metrics", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Accuracy Measures"),
          div(class="framework-card",
              tags$h5("RMSE (Root Mean Squared Error)"),
              tags$p(HTML("<strong>Formula:</strong> √(Σ(actual - predicted)² / N)")),
              tags$p(HTML("<strong>Range:</strong> 0 to ∞ (lower better)")),
              tags$p(HTML("<strong>Use:</strong> Most common, penalizes large errors")),
              tags$p(HTML("<strong>Netflix Prize:</strong> RMSE < 0.857 to win"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("MAE (Mean Absolute Error)"),
              tags$p(HTML("<strong>Formula:</strong> Σ|actual - predicted| / N")),
              tags$p(HTML("<strong>Range:</strong> 0 to ∞ (lower better)")),
              tags$p(HTML("<strong>Use:</strong> More robust to outliers than RMSE"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Insight:</strong> Improving RMSE 0.01 = months of work. But does it improve business metrics? Not always!"))
      ),

      box(title="🎯 Ranking Metrics", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Top-N Recommendation Quality"),
          div(class="framework-card",
              tags$h5("Precision @ K"),
              tags$p(HTML("<strong>Formula:</strong> # relevant in top-K / K")),
              tags$p(HTML("<strong>Example:</strong> Recommend 10, user likes 3 → P@10=0.3")),
              tags$p(HTML("<strong>Meaning:</strong> % of recommendations that are good"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Recall @ K"),
              tags$p(HTML("<strong>Formula:</strong> # relevant in top-K / total relevant")),
              tags$p(HTML("<strong>Example:</strong> User likes 20 items total, 3 in top-10 → R@10=0.15")),
              tags$p(HTML("<strong>Meaning:</strong> % of good items we found"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("MAP (Mean Average Precision)"),
              tags$p(HTML("<strong>Combines:</strong> Precision + ranking position")),
              tags$p(HTML("<strong>Use:</strong> Rewards relevant items at top"))
          ),
          br(),
          plotlyOutput(ns("metrics_tradeoff"))
      )
    ),

    fluidRow(
      box(title="🧪 A/B Testing: The Gold Standard", status="primary", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Truth Source:</strong> Only A/B tests tell you if your algorithm actually improves the product. Offline metrics are just proxies.")),
          br(),
          div(class="section-heading-dark", "How to Run A/B Tests"),
          fluidRow(
            column(3,
                   div(class="framework-card",
                       tags$h5("1. Hypothesis"),
                       tags$p("New CF algorithm increases CTR by 5%")
                   )),
            column(3,
                   div(class="framework-card",
                       tags$h5("2. Design"),
                       tags$p("50% control (old algo)"),
                       tags$p("50% treatment (new algo)")
                   )),
            column(3,
                   div(class="framework-card",
                       tags$h5("3. Run"),
                       tags$p("Minimum 2 weeks"),
                       tags$p("Need 1000+ users/variant")
                   )),
            column(3,
                   div(class="framework-card",
                       tags$h5("4. Analyze"),
                       tags$p("Statistical significance"),
                       tags$p("Check guardrail metrics")
                   ))
          ),
          br(),
          div(class="section-heading-dark", "Guardrail Metrics"),
          div(class="info-box-plain",
              HTML("<strong>💡 Don't Break What Works:</strong> Even if CTR increases, check: engagement (time on site), diversity (% niche items shown), freshness (% recent items), user satisfaction (survey scores)")),
          br(),
          plotlyOutput(ns("ab_test_results"))
      )
    ),

    fluidRow(
      box(title="📈 Beyond Accuracy: Diversity, Coverage, Serendipity", status="info", solidHeader=TRUE, width=12,
          div(class="warn-box",
              HTML("<strong>⚠️ Accuracy Isn't Everything:</strong> A highly accurate recommender that only shows blockbusters is boring. Users want discovery.")),
          br(),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(
                tags$th("Metric"),
                tags$th("Measures"),
                tags$th("Formula"),
                tags$th("Target")
              )
            ),
            tags$tbody(
              tags$tr(
                tags$td(HTML("<strong>Diversity</strong>")),
                tags$td("Variety in recommendations"),
                tags$td("Avg pairwise dissimilarity"),
                tags$td("> 0.6")
              ),
              tags$tr(
                tags$td(HTML("<strong>Coverage</strong>")),
                tags$td("% of catalog recommended"),
                tags$td("# items recommended / total items"),
                tags$td("> 20%")
              ),
              tags$tr(
                tags$td(HTML("<strong>Novelty</strong>")),
                tags$td("How unpopular are recs"),
                tags$td("Mean(-log₂(popularity))"),
                tags$td("> 8")
              ),
              tags$tr(
                tags$td(HTML("<strong>Serendipity</strong>")),
                tags$td("Surprising but relevant"),
                tags$td("Relevant AND unexpected"),
                tags$td("> 0.3")
              )
            )
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Offline first, online next:</strong> Use offline to iterate, A/B to validate")),
                     tags$li(HTML("<strong>RMSE is a proxy:</strong> Better RMSE doesn't guarantee better business metrics")),
                     tags$li(HTML("<strong>A/B tests are truth:</strong> Only real users tell you what works")),
                     tags$li(HTML("<strong>Beyond accuracy:</strong> Measure diversity, coverage, novelty"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Set up offline evaluation pipeline first"),
                     tags$li("Track precision@10, recall@10, MAP"),
                     tags$li("Build A/B testing infrastructure"),
                     tags$li("Monitor guardrail metrics (engagement, diversity)")
                   ))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Netflix Lesson:</strong> Improving RMSE 10% increased subscriber engagement 0%. Real engagement came from diversity and fresh content."))
      )
    )
  )
}

chapter9_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$metrics_tradeoff <- renderPlotly({
      k_values <- seq(5, 50, by = 5)
      precision <- 0.6 / sqrt(k_values/5)
      recall <- 0.15 * sqrt(k_values/5)
      
      df <- data.frame(k = k_values, precision = precision, recall = recall)
      
      p <- plot_ly(df, x = ~k) %>%
        add_trace(y = ~precision, name = 'Precision@K', type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#008A82', width = 2),
                 marker = list(size = 8)) %>%
        add_trace(y = ~recall, name = 'Recall@K', type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#3498db', width = 2),
                 marker = list(size = 8)) %>%
        layout(title = list(text = "Precision-Recall Trade-off",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "K (# Recommendations)", color = '#2c3e50'),
               yaxis = list(title = "Score", color = '#2c3e50', range = c(0, 0.7)),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'))
      
      p
    })
    
    output$ab_test_results <- renderPlotly({
      results <- data.frame(
        metric = c("CTR", "Conversion", "Engagement", "Diversity"),
        control = c(7.2, 11.5, 8.3, 0.52),
        treatment = c(8.5, 13.2, 8.1, 0.48)
      )
      
      p <- plot_ly(results, x = ~metric, y = ~control, type = 'bar',
                   name = 'Control (Old Algo)', marker = list(color = '#95a5a6')) %>%
        add_trace(y = ~treatment, name = 'Treatment (New Algo)',
                 marker = list(color = '#008A82')) %>%
        layout(title = list(text = "A/B Test Results",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "", color = '#2c3e50'),
               yaxis = list(title = "Score", color = '#2c3e50'),
               barmode = 'group',
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'),
               annotations = list(
                 list(x = "Diversity", y = 0.48, text = "⚠️ Dropped!",
                      showarrow = TRUE, arrowhead = 2, ax = 0, ay = -40,
                      font = list(color = '#e74c3c', size = 11))
               ))
      
      p
    })
  })
}
