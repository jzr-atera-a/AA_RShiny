# modules/chapter10.R
# Chapter 10: Content-Based Filtering

chapter10_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 10: Content-Based Filtering"),
        tags$h2("Recommending Based on Item Features"),
        div(
          span(class="hero-badge","TF-IDF"),
          span(class="hero-badge","Feature Vectors"),
          span(class="hero-badge","LDA"),
          span(class="hero-badge","Genre Matching")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "No CF"), span(class="metric-label","User Data Needed"))),
            column(3, div(class="metric-card", span(class="metric-value", "Features"), span(class="metric-label","Item Metadata"))),
            column(3, div(class="metric-card", span(class="metric-value", "Profile"), span(class="metric-label","Build User Taste"))),
            column(3, div(class="metric-card", span(class="metric-value", "Cold-Start"), span(class="metric-label","Solution")))
          )
      )
    ),

    fluidRow(
      box(title="📝 What is Content-Based Filtering?", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Core Idea:</strong> Recommend items similar to what the user liked before. Use item features (genre, actors, keywords) instead of user behavior patterns.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("How It Works"),
                       tags$p(HTML("<strong>1. Extract features:</strong> Genre, director, actors, keywords")),
                       tags$p(HTML("<strong>2. Build user profile:</strong> Aggregate features of liked items")),
                       tags$p(HTML("<strong>3. Match candidates:</strong> Find items with similar features")),
                       tags$p(HTML("<strong>4. Rank by similarity:</strong> Cosine similarity of feature vectors"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Advantages vs Collaborative Filtering"),
                       tags$ul(
                         tags$li(HTML("<strong>No cold-start:</strong> Works for new users/items")),
                         tags$li(HTML("<strong>Transparent:</strong> 'Because you liked X genre'")),
                         tags$li(HTML("<strong>No sparsity issues:</strong> Uses metadata, not ratings")),
                         tags$li(HTML("<strong>Niche items work:</strong> Don't need popularity"))
                       )
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🔤 TF-IDF: Extracting Text Features", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Term Frequency - Inverse Document Frequency"),
          div(class="framework-card",
              tags$h5("The Formula"),
              tags$p(HTML("<strong>TF(term, doc) =</strong> # times term appears / total terms")),
              tags$p(HTML("<strong>IDF(term) =</strong> log(total docs / docs with term)")),
              tags$p(HTML("<strong>TF-IDF =</strong> TF × IDF"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Why It Works"),
              tags$p(HTML("<strong>TF:</strong> Important words appear often in document")),
              tags$p(HTML("<strong>IDF:</strong> Downweights common words like 'the', 'a'")),
              tags$p(HTML("<strong>Result:</strong> Captures distinctive keywords")),
              tags$p(HTML("<strong>Example:</strong> Movie plot → ['heist', 'ocean', 'casino'] weighted"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Netflix Example:</strong> Extract keywords from movie descriptions. 'Dark knight detective Gotham' → high TF-IDF for 'knight', 'detective', 'Gotham'"))
      ),

      box(title="🎭 Feature Engineering for Movies", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "What Features to Use"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(tags$th("Feature Type"), tags$th("Examples"), tags$th("Weight"))
            ),
            tags$tbody(
              tags$tr(tags$td("Genre"), tags$td("Action, Sci-Fi, Thriller"), tags$td("High")),
              tags$tr(tags$td("Director"), tags$td("Christopher Nolan"), tags$td("Medium")),
              tags$tr(tags$td("Actors"), tags$td("Top 3 cast members"), tags$td("Medium")),
              tags$tr(tags$td("Keywords"), tags$td("TF-IDF from plot"), tags$td("Medium")),
              tags$tr(tags$td("Year"), tags$td("Decade buckets"), tags$td("Low")),
              tags$tr(tags$td("Rating"), tags$td("PG, PG-13, R"), tags$td("Low"))
            )
          ),
          br(),
          div(class="framework-card",
              tags$h5("Building Feature Vectors"),
              tags$p(HTML("<strong>One-hot encoding:</strong> Genre → [0,1,0,0,1] for Action+Sci-Fi")),
              tags$p(HTML("<strong>Multi-value:</strong> Actors → top 3 get weight 1.0, 0.7, 0.5")),
              tags$p(HTML("<strong>Normalize:</strong> Scale all features to [0,1] range")),
              tags$p(HTML("<strong>Result:</strong> Each movie = vector of 100-500 dimensions"))
          )
      )
    ),

    fluidRow(
      box(title="👤 User Profile Construction", status="primary", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "From Item Features to User Preferences"),
          div(class="info-box-plain",
              HTML("<strong>💡 Strategy:</strong> User profile = weighted average of features from items they liked. If user likes 5 action movies and 2 comedies, profile has high weight on 'Action'.")),
          br(),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("Simple Average"),
                       tags$p(HTML("<strong>Method:</strong> Sum feature vectors of all liked items")),
                       tags$p(HTML("<strong>Pros:</strong> Easy to implement")),
                       tags$p(HTML("<strong>Cons:</strong> All likes weighted equally"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Weighted by Rating"),
                       tags$p(HTML("<strong>Method:</strong> Weight by user's rating (1-5 stars)")),
                       tags$p(HTML("<strong>Pros:</strong> Accounts for strength of preference")),
                       tags$p(HTML("<strong>Cons:</strong> Explicit ratings sparse"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Time Decay"),
                       tags$p(HTML("<strong>Method:</strong> Recent likes weighted higher")),
                       tags$p(HTML("<strong>Pros:</strong> Adapts to changing tastes")),
                       tags$p(HTML("<strong>Cons:</strong> May forget past preferences"))
                   ))
          ),
          br(),
          plotlyOutput(ns("user_profile_plot"))
      )
    ),

    fluidRow(
      box(title="📊 Topic Modeling: LDA", status="info", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Latent Dirichlet Allocation"),
          div(class="framework-card",
              tags$h5("What is LDA?"),
              tags$p(HTML("<strong>Concept:</strong> Find hidden topics in text")),
              tags$p(HTML("<strong>Example:</strong> Movie plots → 20 latent topics")),
              tags$p(HTML("<strong>Topic 1:</strong> 'heist', 'robbery', 'crew', 'vault'")),
              tags$p(HTML("<strong>Topic 7:</strong> 'space', 'alien', 'planet', 'ship'"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("How It Helps"),
              tags$p(HTML("<strong>Dimensionality reduction:</strong> 10,000 words → 20 topics")),
              tags$p(HTML("<strong>Semantic grouping:</strong> 'car chase' and 'vehicle pursuit' same topic")),
              tags$p(HTML("<strong>Better matching:</strong> Captures meaning not just keywords"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Spotify Example:</strong> LDA on song lyrics finds topics like 'love ballad', 'party anthem', 'breakup song'"))
      ),

      box(title="⚖️ Content-Based vs Collaborative", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Strengths and Weaknesses"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(tags$th("Aspect"), tags$th("Content-Based"), tags$th("Collaborative"))
            ),
            tags$tbody(
              tags$tr(tags$td("Cold-start"), tags$td("✅ Works"), tags$td("❌ Fails")),
              tags$tr(tags$td("Serendipity"), tags$td("❌ Limited"), tags$td("✅ High")),
              tags$tr(tags$td("Filter bubble"), tags$td("⚠️ Risk"), tags$td("✅ Diverse")),
              tags$tr(tags$td("Explainability"), tags$td("✅ Clear"), tags$td("⚠️ Opaque")),
              tags$tr(tags$td("Feature quality"), tags$td("⚠️ Critical"), tags$td("N/A")),
              tags$tr(tags$td("Scale"), tags$td("✅ Linear"), tags$td("⚠️ O(N²)"))
            )
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Filter Bubble:</strong> Content-based can trap users in narrow recommendations. User likes action → only sees action → never discovers other genres."))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Feature engineering is critical:</strong> Quality of features = quality of recommendations")),
                     tags$li(HTML("<strong>TF-IDF for text:</strong> Standard approach for extracting keywords")),
                     tags$li(HTML("<strong>User profile = aggregate:</strong> Weighted average of liked items")),
                     tags$li(HTML("<strong>Solves cold-start:</strong> Works with no user data"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Extract features from item metadata"),
                     tags$li("Build TF-IDF vectors for text fields"),
                     tags$li("Create user profile from interaction history"),
                     tags$li("Compute cosine similarity for ranking")
                   ))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Best Practice:</strong> Use content-based as a fallback when collaborative filtering has insufficient data. Hybrid is the gold standard."))
      )
    )
  )
}

chapter10_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$user_profile_plot <- renderPlotly({
      genres <- data.frame(
        genre = c("Action", "Sci-Fi", "Thriller", "Drama", "Comedy", "Romance"),
        weight = c(0.85, 0.72, 0.58, 0.35, 0.15, 0.08)
      )
      
      p <- plot_ly(genres, x = ~genre, y = ~weight, type = 'bar',
                   marker = list(color = '#008A82'),
                   text = ~paste0(round(weight*100), "%"),
                   textposition = 'outside') %>%
        layout(title = list(text = "Example User Profile (Genre Preferences)",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "", color = '#2c3e50'),
               yaxis = list(title = "Weight", color = '#2c3e50', range = c(0, 1)),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'))
      
      p
    })
  })
}
