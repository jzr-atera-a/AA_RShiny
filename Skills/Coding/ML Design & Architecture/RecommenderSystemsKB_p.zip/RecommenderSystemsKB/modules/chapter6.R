# modules/chapter6.R
# Chapter 6: The Cold-Start Problem

chapter6_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 6: The Cold-Start Problem"),
        tags$h2("Handling New Users and New Items"),
        div(
          span(class="hero-badge","New Users"),
          span(class="hero-badge","New Items"),
          span(class="hero-badge","Onboarding"),
          span(class="hero-badge","Bootstrapping")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "0"), span(class="metric-label","User Data"))),
            column(3, div(class="metric-card", span(class="metric-value", "❓"), span(class="metric-label","What to Show?"))),
            column(3, div(class="metric-card", span(class="metric-value", "Critical"), span(class="metric-label","First Impression"))),
            column(3, div(class="metric-card", span(class="metric-value", "Active"), span(class="metric-label","Learning Phase")))
          )
      )
    ),

    fluidRow(
      box(title="❄️ What is the Cold-Start Problem?", status="info", solidHeader=TRUE, width=12,
          div(class="warn-box",
              HTML("<strong>⚠️ The Problem:</strong> Collaborative filtering needs user history. But new users have no history. New items have no ratings. What do you recommend?")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("User Cold Start"),
                       tags$p(HTML("<strong>Scenario:</strong> Brand new user signs up")),
                       tags$p(HTML("<strong>Challenge:</strong> No past behavior to learn from")),
                       tags$p(HTML("<strong>Impact:</strong> First session determines retention")),
                       tags$p(HTML("<strong>Data point:</strong> Netflix: 80% quit if first recs are bad"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Item Cold Start"),
                       tags$p(HTML("<strong>Scenario:</strong> New movie just released")),
                       tags$p(HTML("<strong>Challenge:</strong> No ratings or interactions yet")),
                       tags$p(HTML("<strong>Impact:</strong> Hard to surface without data")),
                       tags$p(HTML("<strong>Risk:</strong> Great content gets buried"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🚀 Solutions for User Cold Start", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "1. Explicit Preference Collection"),
          div(class="framework-card",
              tags$h5("Onboarding Questionnaire"),
              tags$p(HTML("<strong>Netflix approach:</strong> 'Pick 3 shows you like'")),
              tags$p(HTML("<strong>Spotify approach:</strong> Select favorite genres/artists")),
              tags$p(HTML("<strong>Trade-off:</strong> More questions = better recs but higher friction"))
          ),
          br(),
          div(class="section-heading-dark", "2. Demographic Defaults"),
          div(class="framework-card",
              tags$h5("Use What You Know"),
              tags$p(HTML("<strong>Inputs:</strong> Age, location, device type")),
              tags$p(HTML("<strong>Strategy:</strong> Show popular items for similar demographics")),
              tags$p(HTML("<strong>Example:</strong> 25-year-olds in SF get tech content"))
          ),
          br(),
          div(class="section-heading-dark", "3. Fast Learning"),
          div(class="framework-card",
              tags$h5("Active Learning"),
              tags$p(HTML("<strong>Show diverse items first</strong> to learn preferences")),
              tags$p(HTML("<strong>Bandit algorithms:</strong> Explore vs exploit")),
              tags$p(HTML("<strong>Update quickly:</strong> Every click refines the model"))
          )
      ),

      box(title="📦 Solutions for Item Cold Start", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "1. Content-Based Fallback"),
          div(class="framework-card",
              tags$h5("Use Item Metadata"),
              tags$p(HTML("<strong>Movie:</strong> Genre, director, actors, plot keywords")),
              tags$p(HTML("<strong>Strategy:</strong> Find similar items with ratings")),
              tags$p(HTML("<strong>Example:</strong> New Nolan film → recommend Inception fans"))
          ),
          br(),
          div(class="section-heading-dark", "2. Strategic Exposure"),
          div(class="framework-card",
              tags$h5("Bootstrap with Traffic"),
              tags$p(HTML("<strong>Prime position:</strong> Show to sample of users first")),
              tags$p(HTML("<strong>A/B test:</strong> Measure engagement vs baseline")),
              tags$p(HTML("<strong>Snowball:</strong> Early ratings enable CF recommendations"))
          ),
          br(),
          div(class="section-heading-dark", "3. Editorial Curation"),
          div(class="framework-card",
              tags$h5("Human Intervention"),
              tags$p(HTML("<strong>Staff picks:</strong> Curated 'New Releases' section")),
              tags$p(HTML("<strong>Marketing tie-in:</strong> Feature promoted content")),
              tags$p(HTML("<strong>Transition:</strong> Move to algorithmic once data exists"))
          )
      )
    ),

    fluidRow(
      box(title="🧪 Hybrid Approach: Best of Both Worlds", status="primary", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Recommended Strategy:</strong> Combine multiple signals. Start with content + demographics, then transition to collaborative as data accumulates.")),
          br(),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(
                tags$th("Stage"),
                tags$th("User State"),
                tags$th("Primary Method"),
                tags$th("Fallback Method")
              )
            ),
            tags$tbody(
              tags$tr(
                tags$td("1 - Signup"),
                tags$td("0 interactions"),
                tags$td("Onboarding quiz"),
                tags$td("Demographic defaults")
              ),
              tags$tr(
                tags$td("2 - Early"),
                tags$td("1-10 interactions"),
                tags$td("Content-based"),
                tags$td("Trending items")
              ),
              tags$tr(
                tags$td("3 - Growing"),
                tags$td("10-50 interactions"),
                tags$td("Hybrid (CF + content)"),
                tags$td("Content-based")
              ),
              tags$tr(
                tags$td("4 - Mature"),
                tags$td("50+ interactions"),
                tags$td("Collaborative filtering"),
                tags$td("Hybrid")
              )
            )
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Cold start is unavoidable</strong> — every system faces it")),
                     tags$li(HTML("<strong>First impression matters:</strong> 80% retention depends on it")),
                     tags$li(HTML("<strong>No single solution:</strong> Combine multiple strategies")),
                     tags$li(HTML("<strong>Learn fast:</strong> Every interaction is precious early on"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Build onboarding flow (3-5 preference questions)"),
                     tags$li("Use demographics as prior"),
                     tags$li("Fall back to content-based when CF fails"),
                     tags$li("Gradually transition to collaborative filtering")
                   ))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Netflix Strategy:</strong> Ask users to rate 3 shows during signup. This single step reduces cold-start churn by 40%."))
      )
    )
  )
}

chapter6_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # No plots for this chapter
  })
}
