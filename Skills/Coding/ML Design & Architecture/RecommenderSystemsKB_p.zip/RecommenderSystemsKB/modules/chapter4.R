# modules/chapter4.R
# Chapter 4: Ratings and How to Calculate Them

chapter4_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 4: Ratings and How to Calculate Them"),
        tags$h2("Transforming Behavior into Meaningful Signals"),
        div(
          span(class="hero-badge","Explicit Ratings"),
          span(class="hero-badge","Implicit Ratings"),
          span(class="hero-badge","Normalization"),
          span(class="hero-badge","Prediction")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "2"), span(class="metric-label","Rating Types"))),
            column(3, div(class="metric-card", span(class="metric-value", "1-5"), span(class="metric-label","Star Scale"))),
            column(3, div(class="metric-card", span(class="metric-value", "Sparse"), span(class="metric-label","Matrix"))),
            column(3, div(class="metric-card", span(class="metric-value", "Normalize"), span(class="metric-label","User Bias")))
          )
      )
    ),

    fluidRow(
      box(title="⭐ Understanding Ratings", status="info", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "What Are Ratings?"),
          div(class="framework-card",
              tags$h5("The Core Concept"),
              tags$p("A rating is a numerical representation of how much a user likes an item."),
              tags$p(HTML("<strong>Explicit:</strong> User directly states preference (stars)")),
              tags$p(HTML("<strong>Implicit:</strong> Inferred from behavior (watch time)")),
              tags$p(HTML("<strong>Matrix:</strong> Users × Items grid, mostly empty"))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Sparsity Problem:</strong> Netflix's dataset had only 0.01% density. Most cells are empty."))
      ),

      box(title="📊 Rating Systems", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Explicit Mechanisms"),
          div(class="framework-card",
              tags$h5("Star Ratings (1-5)"),
              tags$p(HTML("<strong>Pros:</strong> Clear, rich signal")),
              tags$p(HTML("<strong>Cons:</strong> User effort, sparse")),
              tags$p(HTML("<strong>Used by:</strong> Amazon, Yelp"))
          ),
          div(class="framework-card",
              tags$h5("Binary (Thumbs Up/Down)"),
              tags$p(HTML("<strong>Pros:</strong> Less effort, clearer")),
              tags$p(HTML("<strong>Cons:</strong> Less granular")),
              tags$p(HTML("<strong>Used by:</strong> Netflix, YouTube"))
          )
      )
    ),

    fluidRow(
      box(title="🧮 Converting Behavior to Ratings", status="success", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Implicit Signals to Ratings"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(tags$th("Behavior"), tags$th("Implied Rating"), tags$th("Confidence"))
            ),
            tags$tbody(
              tags$tr(tags$td("Purchased"), tags$td("5"), tags$td("High")),
              tags$tr(tags$td("Watched 100%"), tags$td("5"), tags$td("High")),
              tags$tr(tags$td("Watched 50%"), tags$td("3.5"), tags$td("Medium")),
              tags$tr(tags$td("Clicked"), tags$td("3"), tags$td("Low")),
              tags$tr(tags$td("Page View"), tags$td("2"), tags$td("Very Low"))
            )
          ),
          br(),
          plotlyOutput(ns("behavior_to_rating_plot"))
      )
    ),

    fluidRow(
      box(title="🎚️ Normalizing Ratings", status="primary", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "User Bias Problem"),
          div(class="framework-card",
              tags$p(HTML("<strong>Harsh raters:</strong> Give mostly 1-2 stars")),
              tags$p(HTML("<strong>Generous raters:</strong> Give mostly 4-5 stars")),
              tags$p(HTML("<strong>Impact:</strong> Same rating means different things"))
          ),
          br(),
          div(class="section-heading-dark", "Normalization Techniques"),
          div(class="framework-card",
              tags$h5("Mean Centering"),
              tags$p("Subtract user's average rating"),
              tags$p(HTML("<strong>Formula:</strong> normalized = actual - user_mean"))
          ),
          div(class="framework-card",
              tags$h5("Z-Score"),
              tags$p("Account for mean and variance"),
              tags$p(HTML("<strong>Formula:</strong> normalized = (actual - mean) / std_dev"))
          )
      ),

      box(title="🔮 Predicting Ratings", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "The Core Problem"),
          div(class="success-box",
              HTML("<strong>✅ Goal:</strong> Predict missing ratings. Items with highest predicted ratings get recommended.")),
          br(),
          div(class="framework-card",
              tags$h5("Simple Baseline"),
              tags$p("Predicted rating = global_mean + user_bias + item_bias"),
              tags$p(HTML("<strong>Example:</strong> If global=3.0, user=3.7, item=4.2, then predicted=4.9"))
          ),
          br(),
          plotlyOutput(ns("rating_prediction_plot"))
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Ratings are the foundation</strong> of collaborative filtering")),
                     tags$li(HTML("<strong>Sparsity is the main challenge</strong> - most cells empty")),
                     tags$li(HTML("<strong>User bias is real</strong> - normalize before training")),
                     tags$li(HTML("<strong>Implicit > Explicit</strong> for data volume"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #8a9bb0; font-size: 12px; line-height: 1.75;",
                     tags$li("Convert behavior to ratings (watch time → 1-5)"),
                     tags$li("Weight events appropriately"),
                     tags$li("Normalize to remove bias"),
                     tags$li("Start with baseline prediction")
                   ))
          )
      )
    )
  )
}

chapter4_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$behavior_to_rating_plot <- renderPlotly({
      behaviors <- data.frame(
        action = c("Purchased", "Watched 100%", "Clicked", "Page View"),
        rating = c(5, 5, 3, 2),
        confidence = c(95, 90, 50, 30)
      )
      
      p <- plot_ly(behaviors, x = ~action, y = ~rating, type = 'bar',
                   marker = list(color = '#e8410a'),
                   text = ~paste0("Rating: ", rating, "<br>Confidence: ", confidence, "%"),
                   hovertemplate = '%{text}<extra></extra>') %>%
        layout(title = list(text = "Converting Behavior to Ratings",
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "User Action", gridcolor = 'rgba(255,255,255,0.08)', color = '#8a9bb0'),
               yaxis = list(title = "Implied Rating (1-5)", gridcolor = 'rgba(255,255,255,0.08)', 
                           color = '#8a9bb0', range = c(0, 5.5))) %>%
        plotly_dark_theme()
      
      p
    })
    
    output$rating_prediction_plot <- renderPlotly({
      set.seed(42)
      n <- 50
      actual <- runif(n, 1, 5)
      predicted <- actual + rnorm(n, 0, 0.5)
      predicted <- pmax(1, pmin(5, predicted))
      
      df <- data.frame(actual = actual, predicted = predicted)
      
      p <- plot_ly(df, x = ~actual, y = ~predicted, type = 'scatter', mode = 'markers',
                   marker = list(size = 8, color = '#e8410a', opacity = 0.6)) %>%
        add_trace(x = c(1, 5), y = c(1, 5), type = 'scatter', mode = 'lines',
                 line = list(color = '#10b981', width = 2, dash = 'dash'),
                 name = 'Perfect Prediction',
                 showlegend = FALSE) %>%
        layout(title = list(text = "Rating Prediction Quality",
                           font = list(color = '#ffb49a', size = 14, family = 'Inter')),
               xaxis = list(title = "Actual Rating", gridcolor = 'rgba(255,255,255,0.08)', 
                           color = '#8a9bb0', range = c(0.5, 5.5)),
               yaxis = list(title = "Predicted Rating", gridcolor = 'rgba(255,255,255,0.08)', 
                           color = '#8a9bb0', range = c(0.5, 5.5))) %>%
        plotly_dark_theme()
      
      p
    })
  })
}
