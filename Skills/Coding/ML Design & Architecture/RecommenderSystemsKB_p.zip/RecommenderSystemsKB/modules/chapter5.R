# modules/chapter5.R
# Chapter 5: Non-Personalized Recommendations

chapter5_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 5: Non-Personalized Recommendations"),
        tags$h2("Building Your First Recommender with Simple Approaches"),
        div(
          span(class="hero-badge","Popularity"),
          span(class="hero-badge","Trending"),
          span(class="hero-badge","Association Rules"),
          span(class="hero-badge","Seeded Recs")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "Simple"), span(class="metric-label","Implementation"))),
            column(3, div(class="metric-card", span(class="metric-value", "Fast"), span(class="metric-label","Computation"))),
            column(3, div(class="metric-card", span(class="metric-value", "30%"), span(class="metric-label","Typical CTR"))),
            column(3, div(class="metric-card", span(class="metric-value", "Baseline"), span(class="metric-label","Start Here")))
          )
      )
    ),

    fluidRow(
      box(title="📊 Why Start with Non-Personalized?", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Key Insight:</strong> Non-personalized recommendations are fast to build, easy to explain, and perform surprisingly well. They're the perfect baseline and cold-start solution.")),
          br(),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("Advantages"),
                       tags$ul(
                         tags$li("No user profile needed"),
                         tags$li("Works for new users"),
                         tags$li("Fast to compute"),
                         tags$li("Easy to explain")
                       )
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("When to Use"),
                       tags$ul(
                         tags$li("Homepage recommendations"),
                         tags$li("Cold start scenarios"),
                         tags$li("Initial baseline"),
                         tags$li("Fallback strategy")
                       )
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Limitations"),
                       tags$ul(
                         tags$li("Same for all users"),
                         tags$li("No personalization"),
                         tags$li("May miss niche items"),
                         tags$li("Filter bubble risk")
                       )
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🔥 Popularity-Based Recommendations", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Most Popular Items"),
          div(class="framework-card",
              tags$h5("Simple Popularity"),
              tags$p(HTML("<strong>Algorithm:</strong> Rank by total views/purchases")),
              tags$p(HTML("<strong>Example:</strong> Amazon's 'Best Sellers'")),
              tags$p(HTML("<strong>Metric:</strong> Total count or rating × count"))
          ),
          br(),
          div(class="section-heading-dark", "Trending Items"),
          div(class="framework-card",
              tags$h5("Time-Weighted Popularity"),
              tags$p(HTML("<strong>Algorithm:</strong> Recent activity gets higher weight")),
              tags$p(HTML("<strong>Example:</strong> Netflix 'Trending Now'")),
              tags$p(HTML("<strong>Formula:</strong> count × time_decay_factor"))
          ),
          br(),
          plotlyOutput(ns("popularity_chart"))
      ),

      box(title="🎲 Association Rules", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Market Basket Analysis"),
          div(class="framework-card",
              tags$h5("Frequent Itemsets"),
              tags$p(HTML("<strong>Concept:</strong> Items bought together")),
              tags$p(HTML("<strong>Example:</strong> 'Customers who bought X also bought Y'")),
              tags$p(HTML("<strong>Support:</strong> % of transactions with both items"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Association Metrics"),
              tags$p(HTML("<strong>Confidence:</strong> P(B|A) — if bought A, prob of B")),
              tags$p(HTML("<strong>Lift:</strong> Confidence / P(B) — stronger than random?")),
              tags$p(HTML("<strong>Threshold:</strong> Lift > 1.5 typically used"))
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Amazon's Secret:</strong> 'Frequently bought together' uses association rules with min support 0.01% and lift > 2.0"))
      )
    ),

    fluidRow(
      box(title="🌱 Seeded Recommendations", status="primary", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Starting from Known Context"),
          div(class="info-box-plain",
              HTML("<strong>💡 Concept:</strong> Use a known item or category as the starting point. User just viewed Action movie? Recommend similar Action movies.")),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Content-Based Seeding"),
                       tags$p(HTML("<strong>Input:</strong> Movie user just watched")),
                       tags$p(HTML("<strong>Filter:</strong> Same genre, director, or actors")),
                       tags$p(HTML("<strong>Rank:</strong> By popularity within that category")),
                       tags$p(HTML("<strong>Example:</strong> 'More like The Matrix'"))
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Category-Based Seeding"),
                       tags$p(HTML("<strong>Input:</strong> User browsing category")),
                       tags$p(HTML("<strong>Filter:</strong> Items in that category")),
                       tags$p(HTML("<strong>Rank:</strong> By rating × popularity")),
                       tags$p(HTML("<strong>Example:</strong> 'Top rated in Sci-Fi'"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Start simple:</strong> Popularity works better than you'd expect")),
                     tags$li(HTML("<strong>Trending > static:</strong> Time-weighted popularity captures momentum")),
                     tags$li(HTML("<strong>Association rules:</strong> 'Bought together' drives 35% of Amazon sales")),
                     tags$li(HTML("<strong>Seeding adds context:</strong> Category + popularity beats pure popularity"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Build popularity baseline first"),
                     tags$li("Add time decay for trending"),
                     tags$li("Mine frequent itemsets for associations"),
                     tags$li("Combine with category filtering")
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Common Mistake:</strong> Showing only popular items creates a rich-get-richer dynamic. Mix in diversity and serendipity."))
      )
    )
  )
}

chapter5_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$popularity_chart <- renderPlotly({
      items <- data.frame(
        item = c("The Matrix", "Inception", "Interstellar", "Blade Runner", "Ex Machina"),
        views = c(15000, 12000, 9500, 7200, 5800),
        recent_views = c(800, 2200, 1500, 600, 1100)
      )
      
      p <- plot_ly(items) %>%
        add_trace(x = ~item, y = ~views, type = 'bar', name = 'All-Time Views',
                 marker = list(color = '#008A82')) %>%
        add_trace(x = ~item, y = ~recent_views, type = 'bar', name = 'Last 7 Days',
                 marker = list(color = '#00A39A')) %>%
        layout(title = list(text = "Popularity vs Trending",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "", color = '#2c3e50'),
               yaxis = list(title = "View Count", color = '#2c3e50'),
               barmode = 'group',
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'))
      
      p
    })
  })
}
