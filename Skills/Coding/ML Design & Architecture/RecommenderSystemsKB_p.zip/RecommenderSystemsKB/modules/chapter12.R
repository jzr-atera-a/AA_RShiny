# modules/chapter12.R
# Chapter 12: Hybrid Recommenders

chapter12_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 12: Hybrid Recommenders"),
        tags$h2("Combining Multiple Recommendation Strategies"),
        div(
          span(class="hero-badge","Ensemble"),
          span(class="hero-badge","Weighted"),
          span(class="hero-badge","Switching"),
          span(class="hero-badge","Production Systems")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "Best"), span(class="metric-label","Of All Worlds"))),
            column(3, div(class="metric-card", span(class="metric-value", "7+"), span(class="metric-label","Hybrid Types"))),
            column(3, div(class="metric-card", span(class="metric-value", "Netflix"), span(class="metric-label","Uses Hybrid"))),
            column(3, div(class="metric-card", span(class="metric-value", "Winner"), span(class="metric-label","Production Standard")))
          )
      )
    ),

    fluidRow(
      box(title="🎭 Why Hybrid?", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Core Insight:</strong> Each algorithm has strengths and weaknesses. Hybrids combine strengths while mitigating weaknesses.")),
          br(),
          fluidRow(
            column(4,
                   div(class="framework-card",
                       tags$h5("Collaborative Filtering"),
                       tags$p(HTML("<strong>✅ Strengths:</strong> Serendipity, finds patterns")),
                       tags$p(HTML("<strong>❌ Weaknesses:</strong> Cold-start, sparsity"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Content-Based"),
                       tags$p(HTML("<strong>✅ Strengths:</strong> No cold-start, explainable")),
                       tags$p(HTML("<strong>❌ Weaknesses:</strong> Filter bubble, needs features"))
                   )),
            column(4,
                   div(class="framework-card",
                       tags$h5("Hybrid"),
                       tags$p(HTML("<strong>✅ Combine:</strong> CF for serendipity, CB for cold-start")),
                       tags$p(HTML("<strong>✅ Result:</strong> Better overall performance"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🔀 Hybrid Design Patterns", status="success", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Seven Ways to Combine Recommenders"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(
                tags$th("Type"),
                tags$th("Method"),
                tags$th("Example"),
                tags$th("Complexity")
              )
            ),
            tags$tbody(
              tags$tr(
                tags$td(HTML("<strong>Weighted</strong>")),
                tags$td("Average scores with weights"),
                tags$td("0.7×CF + 0.3×CB"),
                tags$td("Low")
              ),
              tags$tr(
                tags$td(HTML("<strong>Switching</strong>")),
                tags$td("Pick one based on context"),
                tags$td("CF if >10 ratings, else CB"),
                tags$td("Low")
              ),
              tags$tr(
                tags$td(HTML("<strong>Mixed</strong>")),
                tags$td("Show results from both"),
                tags$td("5 from CF, 5 from CB"),
                tags$td("Low")
              ),
              tags$tr(
                tags$td(HTML("<strong>Feature Combination</strong>")),
                tags$td("Use CB features in CF"),
                tags$td("CF with genre as feature"),
                tags$td("Medium")
              ),
              tags$tr(
                tags$td(HTML("<strong>Cascade</strong>")),
                tags$td("Refine with second method"),
                tags$td("CF filters, CB ranks"),
                tags$td("Medium")
              ),
              tags$tr(
                tags$td(HTML("<strong>Meta-level</strong>")),
                tags$td("Use one to build other"),
                tags$td("CB builds user profile for CF"),
                tags$td("High")
              ),
              tags$tr(
                tags$td(HTML("<strong>Ensemble</strong>")),
                tags$td("Machine learning combines"),
                tags$td("Learn optimal weights"),
                tags$td("High")
              )
            )
          )
      )
    ),

    fluidRow(
      box(title="⚖️ Weighted Hybrid", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Simple Linear Combination"),
          div(class="framework-card",
              tags$h5("The Formula"),
              tags$p(HTML("<strong>score =</strong> w₁×CF_score + w₂×CB_score + w₃×Pop_score")),
              tags$p(HTML("<strong>Constraint:</strong> w₁ + w₂ + w₃ = 1")),
              tags$p(HTML("<strong>Example:</strong> 0.5×CF + 0.3×CB + 0.2×Popularity"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("How to Set Weights"),
              tags$ul(
                tags$li(HTML("<strong>Grid search:</strong> Try all combinations")),
                tags$li(HTML("<strong>Optimize on validation:</strong> Pick best RMSE")),
                tags$li(HTML("<strong>Learn from data:</strong> Regression to find weights")),
                tags$li(HTML("<strong>Dynamic:</strong> Vary by user (experienced vs new)"))
              )
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Netflix Example:</strong> New users get 0.2 CF + 0.5 CB + 0.3 Pop. Experienced users get 0.7 CF + 0.2 CB + 0.1 Pop."))
      ),

      box(title="🔄 Switching Hybrid", status="primary", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Context-Based Selection"),
          div(class="framework-card",
              tags$h5("Decision Rules"),
              tags$p(HTML("<strong>User cold-start:</strong> If user has <5 ratings → use CB")),
              tags$p(HTML("<strong>Item cold-start:</strong> If item is new → use popularity")),
              tags$p(HTML("<strong>Confidence threshold:</strong> If CF confidence >0.7 → use CF, else CB")),
              tags$p(HTML("<strong>Category-based:</strong> Books → CF, News → CB"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Advantages"),
              tags$ul(
                tags$li(HTML("<strong>Adaptive:</strong> Uses best method for context")),
                tags$li(HTML("<strong>Efficient:</strong> Only compute one method")),
                tags$li(HTML("<strong>Explainable:</strong> Clear rules")),
                tags$li(HTML("<strong>Fast:</strong> No combining overhead"))
              )
          ),
          br(),
          plotlyOutput(ns("switching_diagram"))
      )
    ),

    fluidRow(
      box(title="🎯 Feature-Weighted Linear Stacking (FWLS)", status="info", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Advanced Ensemble Method"),
          div(class="success-box",
              HTML("<strong>✅ Netflix Prize Winner:</strong> The winning team used FWLS to combine 100+ different models. Each model votes, votes are weighted.")),
          br(),
          div(class="framework-card",
              tags$h5("How FWLS Works"),
              tags$p(HTML("<strong>1. Train base models:</strong> CF, CB, MF, etc. (10-100 models)")),
              tags$p(HTML("<strong>2. For each model:</strong> Generate predictions for validation set")),
              tags$p(HTML("<strong>3. Learn weights:</strong> Use linear regression to find optimal combination")),
              tags$p(HTML("<strong>4. Prediction:</strong> weighted_sum(model_predictions)"))
          ),
          br(),
          fluidRow(
            column(6,
                   div(class="framework-card",
                       tags$h5("Example Model Zoo"),
                       tags$ul(
                         tags$li("Item-based CF (k=20, 50, 100)"),
                         tags$li("User-based CF (k=30, 80)"),
                         tags$li("Matrix Factorization (50, 100, 200 factors)"),
                         tags$li("Content-based (TF-IDF, LDA)"),
                         tags$li("Time-based (trending, recency)"),
                         tags$li("Demographic models")
                       )
                   )),
            column(6,
                   div(class="framework-card",
                       tags$h5("Learned Weights"),
                       tags$p(HTML("<strong>MF-100:</strong> 0.35")),
                       tags$p(HTML("<strong>Item-CF-50:</strong> 0.25")),
                       tags$p(HTML("<strong>Time-weighted CF:</strong> 0.15")),
                       tags$p(HTML("<strong>Content-based:</strong> 0.10")),
                       tags$p(HTML("<strong>Others:</strong> 0.15 total"))
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🏭 Production System Architecture", status="warning", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "How Netflix Actually Does It"),
          div(class="info-box-plain",
              HTML("<strong>💡 Reality Check:</strong> Production recommenders aren't a single algorithm. They're complex pipelines with dozens of components.")),
          br(),
          fluidRow(
            column(3,
                   div(class="framework-card",
                       tags$h5("1. Candidate Generation"),
                       tags$p("Multiple sources:"),
                       tags$p("- Item-based CF"),
                       tags$p("- Popular trending"),
                       tags$p("- Continue watching"),
                       tags$p("Result: 500-1000 candidates")
                   )),
            column(3,
                   div(class="framework-card",
                       tags$h5("2. Feature Engineering"),
                       tags$p("Extract signals:"),
                       tags$p("- User history"),
                       tags$p("- Item metadata"),
                       tags$p("- Context (time, device)"),
                       tags$p("Result: 100-500 features/item")
                   )),
            column(3,
                   div(class="framework-card",
                       tags$h5("3. Ranking"),
                       tags$p("ML model scores:"),
                       tags$p("- Gradient boosting"),
                       tags$p("- Deep learning"),
                       tags$p("- Ensemble of models"),
                       tags$p("Result: Top 20-50 ranked")
                   )),
            column(3,
                   div(class="framework-card",
                       tags$h5("4. Post-processing"),
                       tags$p("Business rules:"),
                       tags$p("- Diversity filter"),
                       tags$p("- Freshness boost"),
                       tags$p("- A/B test variants"),
                       tags$p("Result: Final top-10")
                   ))
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Hybrids beat single algorithms:</strong> Production systems always combine methods")),
                     tags$li(HTML("<strong>Start simple:</strong> Weighted hybrid is easy and effective")),
                     tags$li(HTML("<strong>Context matters:</strong> Switch methods based on data availability")),
                     tags$li(HTML("<strong>Ensemble for max quality:</strong> Netflix Prize won with 100+ models"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Build CF and CB separately first"),
                     tags$li("Start with simple weighted combination"),
                     tags$li("Add switching rules for cold-start"),
                     tags$li("Graduate to learned ensembles as data grows")
                   ))
          ),
          br(),
          div(class="success-box",
              HTML("<strong>✅ Industry Reality:</strong> Every major recommender system (Netflix, Amazon, Spotify, YouTube) is a hybrid. Pure algorithms are for research papers."))
      )
    )
  )
}

chapter12_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$switching_diagram <- renderPlotly({
      user_ratings <- data.frame(
        n_ratings = c(0, 5, 10, 20, 50, 100, 200),
        cf_weight = c(0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.9),
        cb_weight = c(0.7, 0.6, 0.45, 0.3, 0.2, 0.12, 0.08),
        pop_weight = c(0.3, 0.2, 0.15, 0.1, 0.05, 0.03, 0.02)
      )
      
      p <- plot_ly(user_ratings, x = ~n_ratings) %>%
        add_trace(y = ~cf_weight, name = 'Collaborative Filtering', type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#008A82', width = 2),
                 marker = list(size = 8)) %>%
        add_trace(y = ~cb_weight, name = 'Content-Based', type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#3498db', width = 2),
                 marker = list(size = 8)) %>%
        add_trace(y = ~pop_weight, name = 'Popularity', type = 'scatter', mode = 'lines+markers',
                 line = list(color = '#f39c12', width = 2),
                 marker = list(size = 8)) %>%
        layout(title = list(text = "Dynamic Weighting Based on User Experience",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "Number of User Ratings", color = '#2c3e50'),
               yaxis = list(title = "Weight", color = '#2c3e50', range = c(0, 1)),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'))
      
      p
    })
  })
}
