# modules/chapter7.R
# Chapter 7: Similarity Measures

chapter7_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class="meta-hero",
        tags$h1("Chapter 7: Similarity Measures"),
        tags$h2("Measuring Distance Between Users and Items"),
        div(
          span(class="hero-badge","Cosine"),
          span(class="hero-badge","Euclidean"),
          span(class="hero-badge","Pearson"),
          span(class="hero-badge","Jaccard")
        )
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3, div(class="metric-card", span(class="metric-value", "4+"), span(class="metric-label","Similarity Metrics"))),
            column(3, div(class="metric-card", span(class="metric-value", "0-1"), span(class="metric-label","Score Range"))),
            column(3, div(class="metric-card", span(class="metric-value", "Core"), span(class="metric-label","CF Foundation"))),
            column(3, div(class="metric-card", span(class="metric-value", "Fast"), span(class="metric-label","Pre-compute")))
          )
      )
    ),

    fluidRow(
      box(title="📐 Why Similarity Matters", status="info", solidHeader=TRUE, width=12,
          div(class="success-box",
              HTML("<strong>✅ Foundation of Recommendations:</strong> Similarity is the core of collaborative filtering. Find similar users → recommend what they liked. Find similar items → recommend to same users.")),
          br(),
          div(class="info-box-plain",
              HTML("<strong>💡 The Challenge:</strong> High-dimensional sparse data. Most user pairs have no overlap. Need metrics robust to sparsity."))
      )
    ),

    fluidRow(
      box(title="📊 Cosine Similarity", status="success", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Most Popular for CF"),
          div(class="framework-card",
              tags$h5("Formula"),
              tags$p(HTML("<strong>sim(A,B) = (A · B) / (||A|| × ||B||)</strong>")),
              tags$p(HTML("<strong>Range:</strong> -1 to 1 (typically 0 to 1)")),
              tags$p(HTML("<strong>Interpretation:</strong> Angle between vectors"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Why It Works"),
              tags$ul(
                tags$li(HTML("<strong>Magnitude-invariant:</strong> Harsh vs generous raters")),
                tags$li(HTML("<strong>Sparse-friendly:</strong> Only needs overlapping ratings")),
                tags$li(HTML("<strong>Efficient:</strong> Fast dot product computation")),
                tags$li(HTML("<strong>Used by:</strong> Netflix, Amazon, YouTube"))
              )
          ),
          br(),
          div(class="tip-box",
              HTML("<strong>💡 Key Insight:</strong> Cosine ignores magnitude — focuses on direction. Two users rating 1-2-3 and 3-4-5 are similar."))
      ),

      box(title="📏 Euclidean Distance", status="warning", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Geometric Distance"),
          div(class="framework-card",
              tags$h5("Formula"),
              tags$p(HTML("<strong>dist(A,B) = √Σ(A_i - B_i)²</strong>")),
              tags$p(HTML("<strong>Similarity:</strong> 1 / (1 + distance)")),
              tags$p(HTML("<strong>Range:</strong> 0 to ∞ (normalized: 0 to 1)"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("When to Use"),
              tags$ul(
                tags$li(HTML("<strong>Absolute values matter:</strong> Ratings on same scale")),
                tags$li(HTML("<strong>Dense data:</strong> Most users rated most items")),
                tags$li(HTML("<strong>Clustering:</strong> k-means uses Euclidean")),
                tags$li(HTML("<strong>Example:</strong> Product recommendations in e-commerce"))
              )
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Limitation:</strong> Sensitive to rating scale — harsh raters seem far from generous ones even with same preferences."))
      )
    ),

    fluidRow(
      box(title="🔗 Pearson Correlation", status="primary", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Adjusted Cosine"),
          div(class="framework-card",
              tags$h5("Formula"),
              tags$p(HTML("<strong>r = Σ(A_i - Ā)(B_i - B̄) / (σ_A × σ_B)</strong>")),
              tags$p(HTML("<strong>Range:</strong> -1 to 1")),
              tags$p(HTML("<strong>Adjustment:</strong> Mean-centers before computing"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("Advantages"),
              tags$ul(
                tags$li(HTML("<strong>Handles bias:</strong> Adjusts for user's mean rating")),
                tags$li(HTML("<strong>Statistical meaning:</strong> Actual correlation coefficient")),
                tags$li(HTML("<strong>Scale-invariant:</strong> Like cosine but better")),
                tags$li(HTML("<strong>Used in:</strong> Early Netflix Prize submissions"))
              )
          ),
          br(),
          plotlyOutput(ns("similarity_comparison"))
      ),

      box(title="🎲 Jaccard Similarity", status="info", solidHeader=TRUE, width=6,
          div(class="section-heading-dark", "Set-Based Measure"),
          div(class="framework-card",
              tags$h5("Formula"),
              tags$p(HTML("<strong>J(A,B) = |A ∩ B| / |A ∪ B|</strong>")),
              tags$p(HTML("<strong>Range:</strong> 0 to 1")),
              tags$p(HTML("<strong>Use:</strong> Binary data (bought/not bought)"))
          ),
          br(),
          div(class="framework-card",
              tags$h5("When to Use"),
              tags$ul(
                tags$li(HTML("<strong>Implicit feedback:</strong> Clicks, purchases")),
                tags$li(HTML("<strong>No ratings:</strong> Only have binary interactions")),
                tags$li(HTML("<strong>Association rules:</strong> Market basket analysis")),
                tags$li(HTML("<strong>Example:</strong> 'Customers who bought X also bought Y'"))
              )
          ),
          br(),
          div(class="info-box-plain",
              HTML("<strong>💡 Example:</strong> User A bought {1,2,3,5}, User B bought {2,3,4,5}. Intersection={2,3,5} (3 items), Union={1,2,3,4,5} (5 items), Jaccard=3/5=0.6"))
      )
    ),

    fluidRow(
      box(title="⚖️ Choosing the Right Metric", status="success", solidHeader=TRUE, width=12,
          div(class="section-heading-dark", "Decision Guide"),
          tags$table(class="algo-table",
            tags$thead(
              tags$tr(
                tags$th("Metric"),
                tags$th("Best For"),
                tags$th("Pros"),
                tags$th("Cons")
              )
            ),
            tags$tbody(
              tags$tr(
                tags$td(HTML("<strong>Cosine</strong>")),
                tags$td("Sparse ratings, CF"),
                tags$td("Fast, magnitude-invariant"),
                tags$td("Ignores rating scale")
              ),
              tags$tr(
                tags$td(HTML("<strong>Euclidean</strong>")),
                tags$td("Dense data, clustering"),
                tags$td("Intuitive, simple"),
                tags$td("Scale-sensitive")
              ),
              tags$tr(
                tags$td(HTML("<strong>Pearson</strong>")),
                tags$td("Adjusted CF, bias handling"),
                tags$td("Handles user bias well"),
                tags$td("Slower computation")
              ),
              tags$tr(
                tags$td(HTML("<strong>Jaccard</strong>")),
                tags$td("Binary data, implicit feedback"),
                tags$td("Simple, interpretable"),
                tags$td("Loses rating magnitude")
              )
            )
          )
      )
    ),

    fluidRow(
      box(title="🎓 Key Takeaways", status="success", solidHeader=TRUE, width=12,
          fluidRow(
            column(6,
                   div(class="section-heading-dark", "Core Concepts"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li(HTML("<strong>Cosine is king</strong> for sparse rating data")),
                     tags$li(HTML("<strong>Pearson adjusts for bias</strong> — better but slower")),
                     tags$li(HTML("<strong>Euclidean for dense data</strong> and clustering")),
                     tags$li(HTML("<strong>Jaccard for binary</strong> implicit feedback"))
                   )),
            column(6,
                   div(class="section-heading-dark", "Implementation"),
                   tags$ol(style="color: #2c3e50; font-size: 12px; line-height: 1.75;",
                     tags$li("Start with cosine similarity"),
                     tags$li("Pre-compute similarity matrices"),
                     tags$li("Use sparse matrix libraries (scipy, numpy)"),
                     tags$li("Set minimum overlap threshold (e.g., 5 items)")
                   ))
          ),
          br(),
          div(class="warn-box",
              HTML("<strong>⚠️ Performance Tip:</strong> Pre-compute top-K similar items offline. Computing on-the-fly is too slow for production."))
      )
    )
  )
}

chapter7_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    output$similarity_comparison <- renderPlotly({
      users <- data.frame(
        pair = c("A-B", "A-C", "A-D", "B-C", "B-D"),
        cosine = c(0.95, 0.42, 0.18, 0.38, 0.62),
        pearson = c(0.88, 0.35, 0.15, 0.29, 0.58),
        euclidean = c(0.82, 0.28, 0.12, 0.22, 0.51)
      )
      
      p <- plot_ly(users, x = ~pair, y = ~cosine, type = 'scatter', mode = 'lines+markers',
                   name = 'Cosine', line = list(color = '#008A82', width = 2),
                   marker = list(size = 8)) %>%
        add_trace(y = ~pearson, name = 'Pearson',
                 line = list(color = '#00A39A', width = 2),
                 marker = list(size = 8)) %>%
        add_trace(y = ~euclidean, name = 'Euclidean',
                 line = list(color = '#3498db', width = 2),
                 marker = list(size = 8)) %>%
        layout(title = list(text = "Similarity Scores Comparison",
                           font = list(color = '#002C3C', size = 14, family = 'Inter')),
               xaxis = list(title = "User Pair", color = '#2c3e50'),
               yaxis = list(title = "Similarity Score", color = '#2c3e50', range = c(0, 1)),
               plot_bgcolor = '#ffffff',
               paper_bgcolor = '#ffffff',
               font = list(color = '#2c3e50'))
      
      p
    })
  })
}
