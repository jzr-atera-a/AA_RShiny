# modules/chapter12.R
# Chapter 12: Hybrid Recommenders
# Theory + Code Lab: Weighted blend, switching, FWLS
# Mirrors: builder/fwls_calculator.py, recs/fwls_recommender.py

chapter12_ui <- function(id) {
  ns <- NS(id)
  tagList(

    div(class="meta-hero",
        tags$h1("Chapter 12: Hybrid Recommenders"),
        tags$h2("Combining CF and Content-Based with Feature-Weighted Linear Stacking"),
        div(span(class="hero-badge","Weighted Blend"),
            span(class="hero-badge","Switching"),
            span(class="hero-badge","FWLS"),
            span(class="hero-badge","fwls_calculator.py"))
    ),

    fluidRow(
      box(title="🎯 Chapter Overview", status="primary", solidHeader=TRUE, width=12,
          fluidRow(
            column(3,div(class="metric-card",span(class="metric-value","Best"),span(class="metric-label","Of All Worlds"))),
            column(3,div(class="metric-card",span(class="metric-value","3"),  span(class="metric-label","Strategies Built"))),
            column(3,div(class="metric-card",span(class="metric-value","FWLS"),span(class="metric-label","Learned Blend"))),
            column(3,div(class="metric-card",span(class="metric-value","glm"),span(class="metric-label","Blend Learning Method")))
          )
      )
    ),

    fluidRow(
      tabBox(width=12, id=ns("ch12_tabs"),

        # ── THEORY ─────────────────────────────────────────
        tabPanel(title=tagList(icon("book")," Theory"),
          fluidRow(
            box(title="🎭 Why Hybrid?", status="info", solidHeader=TRUE, width=6,
                div(class="success-box",
                    HTML("<strong>✅ Core Insight:</strong> Each algorithm has strengths and
                    weaknesses. Hybrids combine strengths while mitigating weaknesses.")),
                br(),
                div(class="framework-card",
                    tags$h5("CF Strengths / Weaknesses"),
                    tags$p(HTML("<strong>✅ Serendipity:</strong> Finds cross-genre surprises")),
                    tags$p(HTML("<strong>✅ No metadata needed:</strong> Pure behaviour patterns")),
                    tags$p(HTML("<strong>❌ Cold-start:</strong> Fails for new users/items")),
                    tags$p(HTML("<strong>❌ Sparsity:</strong> Breaks when too few ratings"))
                ),
                div(class="framework-card",
                    tags$h5("Content-Based Strengths / Weaknesses"),
                    tags$p(HTML("<strong>✅ New items:</strong> Recommend from day 1")),
                    tags$p(HTML("<strong>✅ Explainable:</strong> 'Because you like Sci-Fi'")),
                    tags$p(HTML("<strong>❌ Filter bubble:</strong> Only recommends same genre")),
                    tags$p(HTML("<strong>❌ Feature quality:</strong> Garbage in → garbage out"))
                )
            ),
            box(title="🔀 Hybrid Design Patterns", status="warning", solidHeader=TRUE, width=6,
                div(class="section-heading-dark","Seven Patterns from the Book"),
                tags$table(class="algo-table",
                           tags$thead(tags$tr(tags$th("Type"),tags$th("Method"),tags$th("Complexity"))),
                           tags$tbody(
                             tags$tr(tags$td(tags$strong("Weighted")), tags$td("α×CF + (1−α)×CB"),tags$td("Low")),
                             tags$tr(tags$td(tags$strong("Switching")),tags$td("CF if >N ratings, else CB"),tags$td("Low")),
                             tags$tr(tags$td(tags$strong("Mixed")),    tags$td("Show both lists together"),tags$td("Low")),
                             tags$tr(tags$td(tags$strong("Cascade")),  tags$td("CB narrows, CF ranks"),tags$td("Medium")),
                             tags$tr(tags$td(tags$strong("FWLS")),     tags$td("Learned weights per feature"),tags$td("High")),
                             tags$tr(tags$td(tags$strong("Ensemble")), tags$td("Stack multiple models"),tags$td("High")),
                             tags$tr(tags$td(tags$strong("Feature Aug")),tags$td("CF outputs as CB features"),tags$td("High"))
                           )),
                br(),
                div(class="tip-box",
                    HTML("<strong>💡 Production Reality:</strong> Netflix uses a cascade:
                    candidate generation (CF), then re-ranking (content + context features).
                    The final step is always a learned blend."))
            )
          ),
          fluidRow(
            box(title="🧮 FWLS: Feature-Weighted Linear Stacking", status="success",
                solidHeader=TRUE, width=12,
                div(class="info-box-plain",
                    HTML("<strong>fwls_calculator.py:</strong> Uses logistic regression to learn
                    optimal weights for blending CF and content-based predictions.
                    The key innovation is that weights can depend on context (user activity level).")),
                fluidRow(
                  column(6,
                    div(class="framework-card",
                        tags$h5("Feature Functions"),
                        tags$p(HTML("<strong>fun1():</strong> Constant 1.0 — global weight for predictor")),
                        tags$p(HTML("<strong>fun2(user_id):</strong> Number of ratings for user → active users may trust CF more")),
                        tags$p(HTML("<strong>Features created:</strong> cb×fun1, cb×fun2, cf×fun1, cf×fun2")),
                        tags$p(HTML("<strong>GLM learns:</strong> β₁,β₂,β₃,β₄ to minimise MSE on training data"))
                    )
                  ),
                  column(6,
                    div(class="framework-card",
                        tags$h5("Prediction"),
                        tags$p(HTML("<strong>score = β₁×(cb×1) + β₂×(cb×n_ratings)</strong>")),
                        tags$p(HTML("<strong>       + β₃×(cf×1) + β₄×(cf×n_ratings)</strong>")),
                        tags$p("n_ratings = how active the user is. Active users' CF predictions get higher weight.")
                    )
                  )
                )
            )
          )
        ), # end Theory

        # ── CODE LAB ───────────────────────────────────────
        tabPanel(title=tagList(icon("code")," Code Lab"),

          code_lab_header(
            title    = "Hybrid Recommenders — R Implementation",
            subtitle = "Three strategies: weighted blend, switching, and FWLS with learned weights. Mirrors fwls_calculator.py. Runs CF + Content side-by-side and blends them.",
            badges   = c("R", "glm", "mirrors: fwls_calculator.py")
          ),

          # ── Step 1: Run base predictors ─────────────────
          fluidRow(
            box(title="Step 1 · Run Base Predictors", status="primary",
                solidHeader=TRUE, width=4,
                div(class="section-heading-dark","Build CF and Content models"),
                div(class="control-panel",
                    div(class="section-heading-dark","CF Settings"),
                    sliderInput(ns("hyb_cf_k"), "CF neighbourhood K",
                                min=3, max=15, value=8),
                    br(),
                    div(class="section-heading-dark","Content Settings"),
                    checkboxGroupInput(ns("hyb_feat"), "Content features:",
                                       choices=c("Genre"="genre","Year"="year"),
                                       selected=c("genre","year")),
                    br(),
                    div(class="section-heading-dark","Train/Test"),
                    sliderInput(ns("hyb_train_pct"), "Training set %",
                                min=50, max=80, value=70, step=10),
                    run_button(ns("run_base_preds"), "▶  Run Base Predictors")
                ),
                br(),
                uiOutput(ns("base_pred_status"))
            ),

            box(title="📊 Prediction Correlation: CF vs Content", status="success",
                solidHeader=TRUE, width=8,
                div(class="tip-box",
                    HTML("<strong>Why correlation matters:</strong> If CF and CB predict almost
                    the same scores, blending won't help much. Low correlation = complementary
                    signals = blending adds value.")),
                plotlyOutput(ns("pred_correlation"), height="360px")
            )
          ),

          # ── Step 2: Hybrid strategies ───────────────────
          fluidRow(
            box(title="Step 2A · Weighted Blend", status="warning",
                solidHeader=TRUE, width=4,
                div(class="control-panel",
                    sliderInput(ns("blend_alpha"), "CF weight (α)  — CB gets (1−α)",
                                min=0, max=1, value=0.5, step=0.05),
                    numericInput(ns("blend_user"), "User ID to recommend for",
                                 value=1, min=1, max=50),
                    run_button(ns("run_weighted"), "▶  Weighted Blend Recs")
                ),
                uiOutput(ns("weighted_result")),
                br(),
                r_code_block(
'# Weighted blend
# Mirrors simplest hybrid pattern

blend_score <- function(cf, cb, alpha) {
  alpha * cf + (1 - alpha) * cb
}

# Get recs from both, merge and blend
recs_blended <- merge(recs_cf, recs_cb,
  by="movie_id", suffixes=c("_cf","_cb")) %>%
  mutate(score = blend_score(
    pred_cf, pred_cb, alpha)) %>%
  arrange(desc(score))'
                )
            ),

            box(title="Step 2B · Switching Hybrid", status="info",
                solidHeader=TRUE, width=4,
                div(class="info-box-plain",
                    HTML("<strong>Logic:</strong> Use CF when user has enough ratings
                    (trust behaviour patterns). Fall back to content-based for users
                    with very few ratings (cold-start).")),
                div(class="control-panel",
                    sliderInput(ns("switch_threshold"), "Min ratings to use CF",
                                min=2, max=15, value=5),
                    run_button(ns("run_switching"), "▶  Switching Recs Distribution")
                ),
                plotlyOutput(ns("switching_plot"), height="260px"),
                br(),
                r_code_block(
'# Switching hybrid
hybrid_recs <- function(user_id, thresh=5) {
  n_rated <- nrow(
    sample_ratings %>%
    filter(user_id==!!user_id))

  if (n_rated >= thresh) {
    recs_cf(user_id)    # trust CF
  } else {
    recs_content(user_id)  # fallback CB
  }
}'
                )
            ),

            box(title="Step 2C · FWLS (Learned Weights)", status="success",
                solidHeader=TRUE, width=4,
                div(class="section-heading-dark","Mirrors fwls_calculator.py"),
                div(class="control-panel",
                    run_button(ns("run_fwls"), "▶  Train FWLS & Get Recs"),
                    numericInput(ns("fwls_user"), "User ID", value=1, min=1, max=50)
                ),
                uiOutput(ns("fwls_coefs")),
                br(),
                r_code_block(
'# FWLS: Feature-Weighted Linear Stacking
# mirrors fwls_calculator.py

# Feature functions
fun1 <- function() 1.0
fun2 <- function(uid) {
  sum(sample_ratings$user_id==uid)
}

# Build training features
train_df <- train_preds %>%
  mutate(
    f_cb1 = cb_pred * fun1(),
    f_cb2 = cb_pred * fun2(user_id),
    f_cf1 = cf_pred * fun1(),
    f_cf2 = cf_pred * fun2(user_id)
  )

# Learn weights
model <- glm(
  actual ~ f_cb1+f_cb2+f_cf1+f_cf2 - 1,
  data=train_df)'
                )
            )
          ),

          # ── Step 3: Comparison ──────────────────────────
          fluidRow(
            box(title="📋 Head-to-Head: All Three Strategies", status="primary",
                solidHeader=TRUE, width=12,
                div(class="section-heading-dark",
                    "Same user, same candidate set — three different ranking decisions"),
                uiOutput(ns("comparison_status")),
                br(),
                DTOutput(ns("hybrid_comparison_table"))
            )
          )
        ) # end Code Lab
      )
    )
  )
}

chapter12_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    # ── Shared helpers ───────────────────────────────────────
    normalize_r <- function(x) {
      v <- !is.na(x); if(sum(v)<=1) return(rep(0,length(x)))
      xm<-mean(x[v]); xr<-max(x[v])-min(x[v])
      if(xr==0) return(rep(0,length(x)))
      res<-(x-xm)/xr; res[!v]<-0; res
    }
    cos_sm <- function(mat) {
      n<-sqrt(rowSums(mat^2)); n[n<1e-10]<-1e-10; tcrossprod(mat/n)
    }

    build_cf_sim <- function(ratings) {
      adj <- ratings %>%
        group_by(user_id) %>%
        mutate(r=normalize_r(rating)) %>% ungroup()
      ov_wide <- ratings %>% mutate(v=1L) %>%
        pivot_wider(id_cols=movie_id,names_from=user_id,values_from=v,values_fill=0L)
      mid_ov <- ov_wide$movie_id; ov_m <- tcrossprod(as.matrix(ov_wide[,-1]))
      rownames(ov_m) <- colnames(ov_m) <- as.character(mid_ov)
      r_wide <- adj %>% select(movie_id,user_id,r) %>%
        pivot_wider(id_cols=movie_id,names_from=user_id,values_from=r,values_fill=0)
      mid_r <- r_wide$movie_id; r_m <- as.matrix(r_wide[,-1])
      sm <- cos_sm(r_m); rownames(sm)<-colnames(sm)<-as.character(mid_r); diag(sm)<-0
      common <- intersect(rownames(sm),rownames(ov_m))
      sm2 <- sm[common,common]; sm2[ov_m[common,common]<2]<-0; diag(sm2)<-0; sm2
    }

    build_cb_sim <- function(feats) {
      types <- feats
      mats <- list()
      if("genre" %in% types) {
        gs <- sort(unique(sample_movies$genre))
        gm <- sapply(gs, function(g) as.integer(sample_movies$genre==g))
        rownames(gm) <- as.character(sample_movies$movie_id); mats[["genre"]] <- gm
      }
      if("year" %in% types) {
        ds <- sort(unique(floor(sample_movies$year/10)*10))
        ym <- sapply(ds, function(d) as.integer(floor(sample_movies$year/10)*10==d))*0.5
        rownames(ym) <- as.character(sample_movies$movie_id); mats[["year"]] <- ym
      }
      if(length(mats)==0) return(NULL)
      all_ids <- as.character(sample_movies$movie_id)
      mats2 <- lapply(mats, function(m) {
        al <- matrix(0, length(all_ids), ncol(m), dimnames=list(all_ids,colnames(m)))
        cm <- intersect(rownames(m),all_ids); al[cm,]<-m[cm,]; al
      })
      fm <- do.call(cbind, mats2); sm <- cos_sm(fm); diag(sm)<-0; sm
    }

    predict_wsum <- function(target_id, sim_mat, user_r) {
      tid  <- as.character(target_id)
      um   <- mean(user_r$rating)
      rid  <- as.character(user_r$movie_id)
      if(!tid %in% rownames(sim_mat)) return(um)
      sv <- sim_mat[tid, intersect(colnames(sim_mat),rid)]
      sv <- sv[sv>0]; if(length(sv)==0) return(um)
      r_j <- user_r$rating[match(as.integer(names(sv)),user_r$movie_id)]
      vld <- !is.na(r_j); if(sum(vld)==0) return(um)
      num <- sum(sv[vld]*(r_j[vld]-um)); den <- sum(abs(sv[vld]))
      if(den==0) um else um+num/den
    }

    # ── Base predictors ──────────────────────────────────────
    base_data <- eventReactive(input$run_base_preds, {
      set.seed(42)
      tp <- input$hyb_train_pct/100
      all_u <- unique(sample_ratings$user_id)
      train_u <- sample(all_u, round(length(all_u)*tp))
      test_u  <- setdiff(all_u, train_u)
      train_r <- sample_ratings[sample_ratings$user_id %in% train_u,]
      test_r  <- sample_ratings[sample_ratings$user_id %in% test_u,]

      cf_sim <- build_cf_sim(train_r)
      cb_sim <- build_cb_sim(input$hyb_feat)
      if(is.null(cb_sim)) return(NULL)

      # Predict for all test ratings
      preds <- lapply(test_u, function(uid) {
        user_test  <- test_r[test_r$user_id==uid,]
        user_train <- train_r[train_r$user_id==uid,]
        if(nrow(user_test)==0 || nrow(user_train)==0) return(NULL)
        n_train <- nrow(user_train)

        lapply(seq_len(nrow(user_test)), function(j) {
          iid <- user_test$movie_id[j]; act <- user_test$rating[j]
          cf_p  <- predict_wsum(iid, cf_sim, user_train)
          cb_p  <- predict_wsum(iid, cb_sim, user_train)
          data.frame(user_id=uid, movie_id=iid, actual=act,
                     cf_pred=round(cf_p,3), cb_pred=round(cb_p,3),
                     n_train=n_train)
        }) %>% do.call(rbind, .)
      })
      preds_df <- do.call(rbind, Filter(Negate(is.null), preds))

      list(preds=preds_df, cf_sim=cf_sim, cb_sim=cb_sim,
           train_r=train_r, test_r=test_r)
    }, ignoreNULL=FALSE)

    output$base_pred_status <- renderUI({
      bd <- base_data(); if(is.null(bd)) return(NULL)
      p  <- bd$preds
      mae_cf <- round(mean(abs(p$actual-p$cf_pred),na.rm=TRUE),4)
      mae_cb <- round(mean(abs(p$actual-p$cb_pred),na.rm=TRUE),4)
      tagList(
        fluidRow(
          column(6,div(class="metric-card",span(class="metric-value",mae_cf),
                       span(class="metric-label","CF MAE"))),
          column(6,div(class="metric-card",span(class="metric-value",mae_cb),
                       span(class="metric-label","CB MAE")))
        ),
        br(),
        div(class="success-box",HTML(paste0("<strong>✅ Ready.</strong> ",
            nrow(p)," test predictions generated from ",length(unique(p$user_id))," users.")))
      )
    })

    output$pred_correlation <- renderPlotly({
      bd <- base_data(); if(is.null(bd)) return(plot_ly()%>%plotly_dark_theme())
      p  <- bd$preds
      cor_val <- round(cor(p$cf_pred,p$cb_pred,use="complete.obs"),3)

      plot_ly(p, x=~cf_pred, y=~cb_pred, type="scatter", mode="markers",
              marker=list(color="#00A39A",size=5,opacity=0.5),
              hovertemplate="CF:%{x:.2f} CB:%{y:.2f}<extra></extra>") %>%
        add_trace(x=c(1,5),y=c(1,5),type="scatter",mode="lines",
                  name="Perfect agreement",line=list(color="#fbbf24",dash="dash",width=1.5)) %>%
        layout(title=list(text=paste0("CF vs CB Predictions (r = ",cor_val,")"),
                          font=list(color="#d0f0ed",size=13)),
               xaxis=list(title="CF Predicted Rating",color="#8a9bb0",range=c(0.5,5.5),
                          gridcolor="rgba(255,255,255,0.08)"),
               yaxis=list(title="CB Predicted Rating",color="#8a9bb0",range=c(0.5,5.5),
                          gridcolor="rgba(255,255,255,0.08)"),
               annotations=list(list(x=4.5,y=1.5,text=paste0("r = ",cor_val),
                                     showarrow=FALSE,font=list(color="#fbbf24",size=14))),
               showlegend=FALSE) %>%
        plotly_dark_theme()
    })

    # ── Weighted blend ───────────────────────────────────────
    weighted_recs <- eventReactive(input$run_weighted, {
      bd <- base_data(); if(is.null(bd)) return(NULL)
      uid   <- input$blend_user; alpha <- input$blend_alpha
      user_r <- bd$train_r[bd$train_r$user_id==uid,]
      rated  <- user_r$movie_id
      cands  <- setdiff(sample_movies$movie_id, rated)

      res <- lapply(cands, function(iid) {
        cf_p <- predict_wsum(iid, bd$cf_sim, user_r)
        cb_p <- predict_wsum(iid, bd$cb_sim, user_r)
        blended <- alpha*cf_p + (1-alpha)*cb_p
        data.frame(movie_id=iid,cf=round(cf_p,3),cb=round(cb_p,3),blend=round(blended,3))
      })
      do.call(rbind,res) %>%
        left_join(sample_movies %>% select(movie_id,title,genre),by="movie_id") %>%
        arrange(desc(blend)) %>% head(8)
    }, ignoreNULL=FALSE)

    output$weighted_result <- renderUI({
      r <- weighted_recs(); if(is.null(r)||nrow(r)==0)
        return(div(class="warn-box",HTML("<strong>Run base predictors first.</strong>")))
      rows <- lapply(seq_len(nrow(r)), function(i)
        tags$tr(tags$td(paste0("#",i)),tags$td(r$title[i]),
                tags$td(r$cf[i]),tags$td(r$cb[i]),tags$td(tags$strong(r$blend[i]))))
      div(class="result-card",
          tags$h5(paste0("Weighted Blend Recs (α=",input$blend_alpha,")")),
          tags$table(class="algo-table",
                     tags$thead(tags$tr(tags$th("#"),tags$th("Movie"),
                                        tags$th("CF"),tags$th("CB"),tags$th("Blend"))),
                     tags$tbody(rows)))
    })

    # ── Switching hybrid ─────────────────────────────────────
    output$switching_plot <- renderPlotly({
      input$run_switching
      bd <- base_data(); if(is.null(bd)) return(plot_ly()%>%plotly_dark_theme())
      thresh <- input$switch_threshold
      user_counts <- sample_ratings %>% count(user_id) %>%
        mutate(strategy=ifelse(n>=thresh,"CF","Content-Based"))
      uc <- user_counts %>% count(strategy)

      plot_ly(uc, labels=~strategy, values=~n, type="pie",
              marker=list(colors=c("CF"="#00A39A","Content-Based"="#3b82f6")),
              textinfo="label+percent",
              hovertemplate="%{label}: %{value} users<extra></extra>") %>%
        layout(title=list(text=paste0("Who gets CF vs CB? (thresh=",thresh," ratings)"),
                          font=list(color="#d0f0ed",size=11)),
               legend=list(font=list(color="#8a9bb0")),
               paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)") %>%
        plotly_dark_theme()
    })

    # ── FWLS ────────────────────────────────────────────────
    fwls_model <- eventReactive(input$run_fwls, {
      bd <- base_data(); if(is.null(bd)) return(NULL)
      p  <- bd$preds %>% filter(!is.na(cf_pred),!is.na(cb_pred))
      if(nrow(p)<10) return(NULL)

      # Feature functions (mirrors fwls_calculator.py)
      p <- p %>% mutate(
        f_cb1 = cb_pred * 1.0,
        f_cb2 = cb_pred * n_train,
        f_cf1 = cf_pred * 1.0,
        f_cf2 = cf_pred * n_train
      )
      m <- lm(actual ~ f_cb1+f_cb2+f_cf1+f_cf2 - 1, data=p)

      # Predict for target user
      uid   <- input$fwls_user
      user_r <- bd$train_r[bd$train_r$user_id==uid,]
      rated  <- user_r$movie_id
      n_tr   <- nrow(user_r)
      cands  <- setdiff(sample_movies$movie_id, rated)

      recs <- lapply(cands, function(iid) {
        cf_p <- predict_wsum(iid, bd$cf_sim, user_r)
        cb_p <- predict_wsum(iid, bd$cb_sim, user_r)
        new_row <- data.frame(f_cb1=cb_p*1.0, f_cb2=cb_p*n_tr,
                              f_cf1=cf_p*1.0, f_cf2=cf_p*n_tr)
        fwls_score <- predict(m, newdata=new_row)
        data.frame(movie_id=iid, cf=round(cf_p,3), cb=round(cb_p,3),
                   fwls=round(fwls_score,3))
      })
      recs_df <- do.call(rbind,recs) %>%
        left_join(sample_movies %>% select(movie_id,title,genre),by="movie_id") %>%
        arrange(desc(fwls)) %>% head(8)

      list(recs=recs_df, coefs=coef(m), r2=round(summary(m)$r.squared,4),
           mae_fwls=round(mean(abs(p$actual-predict(m,p)),na.rm=TRUE),4),
           mae_cf=round(mean(abs(p$actual-p$cf_pred),na.rm=TRUE),4))
    }, ignoreNULL=FALSE)

    output$fwls_coefs <- renderUI({
      r <- fwls_model(); if(is.null(r))
        return(div(class="warn-box",HTML("<strong>Run base predictors first.</strong>")))
      cs <- round(r$coefs, 4)
      tagList(
        div(class="result-card",
            tags$h5("Learned FWLS Coefficients"),
            tags$table(class="algo-table",
                       tags$thead(tags$tr(tags$th("Feature"),tags$th("Weight"))),
                       tags$tbody(lapply(names(cs), function(n)
                         tags$tr(tags$td(n),tags$td(tags$strong(cs[n])))))),
            br(),
            fluidRow(
              column(6,div(class="metric-card",span(class="metric-value",r$mae_fwls),
                           span(class="metric-label","FWLS MAE"))),
              column(6,div(class="metric-card",span(class="metric-value",r$mae_cf),
                           span(class="metric-label","CF MAE")))
            ),
            br(),
            div(class=if(r$mae_fwls<r$mae_cf)"success-box" else "warn-box",
                HTML(if(r$mae_fwls<r$mae_cf)"<strong>✅ FWLS beats CF.</strong>"
                     else "<strong>⚠️ CF still better — try more training data.</strong>"))
        )
      )
    })

    output$comparison_status <- renderUI({
      bd <- base_data(); if(is.null(bd))
        return(div(class="warn-box",HTML("<strong>Run base predictors first to see comparison.</strong>")))
      div(class="success-box",HTML("<strong>✅ All three strategies ready.</strong>
          Showing candidate scores for the selected user side-by-side."))
    })

    output$hybrid_comparison_table <- renderDT({
      bd <- base_data(); if(is.null(bd)) return(datatable(data.frame()))
      uid   <- input$blend_user
      alpha <- input$blend_alpha
      thresh <- input$switch_threshold
      user_r <- bd$train_r[bd$train_r$user_id==uid,]
      n_tr   <- nrow(user_r)
      rated  <- user_r$movie_id
      cands  <- setdiff(sample_movies$movie_id, rated)
      fm_fwls <- fwls_model()

      rows <- lapply(cands, function(iid) {
        cf_p  <- predict_wsum(iid, bd$cf_sim, user_r)
        cb_p  <- predict_wsum(iid, bd$cb_sim, user_r)
        blend <- alpha*cf_p + (1-alpha)*cb_p
        switch_s <- if(n_tr>=thresh) cf_p else cb_p
        fwls_s   <- if(!is.null(fm_fwls)) {
          m_coef <- fm_fwls$coefs
          sum(c(cb_p*1, cb_p*n_tr, cf_p*1, cf_p*n_tr) * m_coef, na.rm=TRUE)
        } else NA_real_
        data.frame(movie_id=iid, CF=round(cf_p,3), CB=round(cb_p,3),
                   Weighted=round(blend,3), Switching=round(switch_s,3),
                   FWLS=round(fwls_s,3))
      })
      all_df <- do.call(rbind,rows) %>%
        left_join(sample_movies %>% select(movie_id,title,genre),by="movie_id") %>%
        arrange(desc(Weighted)) %>% head(15) %>%
        select(Movie=title,Genre=genre,CF,CB,Weighted,Switching,FWLS)

      datatable(all_df, options=list(pageLength=15,scrollX=TRUE,dom="t"),rownames=FALSE)
    })
  })
}
