# modules/stakeholder_judgment.R
# Tab: Stakeholder Judgment (Station 04 of the loop)

stakeholder_judgment_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Stakeholder Judgment"),
        tags$h2("Where signal becomes a decision"),
        div(
          span(class = "hero-badge", icon("users"), " Audience-aware"),
          span(class = "hero-badge", icon("hand"), " \u201cNo, and here's the path\u201d"),
          span(class = "hero-badge", icon("scale-balanced"), " Tradeoffs out loud")
        )
    ),

    fluidRow(
      box(title = "What's Being Tested", status = "primary", solidHeader = TRUE, width = 6,
          p("The JD asks you to \u201cpartner with cross-functional and client-facing teams to translate research progress into clear, credible narratives grounded in evidence,\u201d and \u2014 again \u2014 to \u201cblock claims, pause work, or force scope changes\u201d when needed. This tab is where the result of the Research Signal Judgment tab actually reaches people who'll make decisions with it."),
          success_box("Both halves matter: a hold that isn't communicated well is as costly as no hold at all. Lead with the recommendation, then the reasoning.")
      ),
      box(title = "The Stakeholder Framework", status = "info", solidHeader = TRUE, width = 6,
          timeline_entry("1", "Assess evidence strength", "Start from where Research Signal Judgment left off \u2014 how confident are you, really?"),
          timeline_entry("2", "Identify what's at stake", "A client deck, an internal roadmap call, a model launch \u2014 the evidence bar scales with the stakes."),
          timeline_entry("3", "Tailor the message", "A researcher needs the mechanism and confidence interval; a non-technical stakeholder needs the implication and the recommendation."),
          timeline_entry("4", "Lead with the recommendation", "\u2018Here's what I'd do, and why\u2019 lands better than a list of concerns."),
          timeline_entry("5", "Offer a concrete path forward", "\u2018Not yet\u2019 should come with \u2018here's what would change my mind, and by when.\u2019")
      )
    ),

    fluidRow(
      box(title = "Worked Example \u2014 Same Situation, Two Audiences", status = "warning", solidHeader = TRUE, width = 12,
          p(tags$b("Situation:"), " A client wants to publish a case study based on 5 cherry-picked examples."),
          fluidRow(
            column(6,
              div(class = "section-heading-dark", "To the client (non-technical)"),
              spec_block("\"These 5 examples are promising, but 5 isn't enough to support a published claim. I'd like 1 week to run this against a 100-item sample -- if it holds, we have a much stronger story; if it doesn't, we've avoided a retraction risk.\"")
            ),
            column(6,
              div(class = "section-heading-dark", "To the research team (technical)"),
              spec_block("\"Selection bias risk -- need a stratified sample, not hand-picked wins. Can we get a 100-item eval run by Thursday?\"")
            )
          ),
          tip_box("Notice both messages lead with a recommendation and a timeline \u2014 not just a concern.")
      )
    ),

    fluidRow(
      box(title = "Practice Prompts", status = "success", solidHeader = TRUE, width = 7,
          scenario_card("Prompt 1", "A client wants to publish a case study based on 5 cherry-picked examples. How do you respond in the next stakeholder meeting?"),
          scenario_card("Prompt 2", "A PM wants to ship a feature based on a 5-example demo that looked great. How do you handle this conversation?"),
          scenario_card("Prompt 3", "You need to explain to a non-technical stakeholder why a result that looks like an improvement might not be one \u2014 without sounding like you're saying \u2018no\u2019 for no reason.")
      ),
      box(title = "Strong Answer Shape", status = "danger", solidHeader = TRUE, width = 5,
          tags$ol(
            tags$li("State your read of the evidence in one sentence"),
            tags$li("Name what's at stake if the claim is wrong"),
            tags$li("Give the recommendation"),
            tags$li("Give the concrete condition that would change your mind, with a timeline")
          ),
          warn_box("\u2018I'd just be honest with them\u2019 is the whole-plan trap. Show the actual words you'd use, and the path you'd offer \u2014 not just a refusal.")
      )
    )
  )
}

stakeholder_judgment_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # Static content tab - no server-side logic required
  })
}
