# modules/research_signal.R
# Tab: Research Signal Judgment (Station 03 of the loop)

research_signal_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Research Signal Judgment"),
        tags$h2("Is this result real \u2014 and strong enough to act on?"),
        div(
          span(class = "hero-badge", icon("magnifying-glass-chart"), " Quality gate"),
          span(class = "hero-badge", icon("ban"), " \u201cNot yet\u201d is a valid answer"),
          span(class = "hero-badge", icon("list-check"), " 5-point validation")
        )
    ),

    fluidRow(
      box(title = "What's Being Tested", status = "primary", solidHeader = TRUE, width = 6,
          p("The role asks you to \u201cblock claims, pause work, or force scope changes when signal strength or data integrity is insufficient.\u201d This tab is about the judgment behind that line \u2014 separating a genuine improvement from noise, a confound, or a metric that moved for the wrong reason."),
          success_box("A quality gate is a person, not a metric. The interviewer wants to see whether you'll actually hold a claim back under social or time pressure \u2014 not just whether you know the word \u2018confound\u2019.")
      ),
      box(title = "The 5-Point Validation Checklist", status = "info", solidHeader = TRUE, width = 6,
          timeline_entry("1", "Baseline comparison", "What would \u2018no real change\u2019 look like on this metric? Has the baseline itself been validated?"),
          timeline_entry("2", "Sample size & variance", "Is N large enough that the observed difference exceeds normal run-to-run noise?"),
          timeline_entry("3", "Confound check", "Did anything else change between the two conditions \u2014 data, prompts, infra, eval version?"),
          timeline_entry("4", "Reproducibility", "Does it hold on a held-out slice, or only on the set it was tuned against?"),
          timeline_entry("5", "Failure-mode shift", "Did errors actually decrease \u2014 or just move to a category that isn't being measured?")
      )
    ),

    fluidRow(
      box(title = "Worked Example", status = "warning", solidHeader = TRUE, width = 12,
          p(tags$b("Claim:"), " \u201cThe new model scores 8 points higher on the 100-item rubric set we built last week.\u201d"),
          spec_block(paste(
            "check 1 (baseline): was this rubric set used during model selection? -> if yes, contaminated",
            "check 2 (N): 100 items, +/-8pts -- is that outside historical run-to-run variance (~5pts)?",
            "check 3 (confound): rubric grader model also changed last week -> re-run old model w/ new grader",
            "check 4 (repro): re-test on a fresh 50-item held-out slice",
            "check 5 (shift): compare per-category error rates, not just the aggregate score",
            "",
            "verdict: hold the claim until checks 2-4 are re-run",
            sep = "\n"
          )),
          tip_box("Use specific numbers even when the scenario is hypothetical \u2014 \u2018is +8 outside the ~5pt noise band we've seen historically?\u2019 reads as far stronger than \u2018we'd want to check for variance.\u2019")
      )
    ),

    fluidRow(
      box(title = "Practice Prompts", status = "success", solidHeader = TRUE, width = 7,
          scenario_card("Prompt 1", "An eval shows the new model scoring 8 points higher on a 100-item rubric-graded set you built last week. Walk me through how you'd decide whether to report this as a real improvement."),
          scenario_card("Prompt 2", "A researcher is excited about a result and wants to share it with a client today. You're not convinced it's solid. What do you do in the next hour?"),
          scenario_card("Prompt 3", "How would you tell the difference between \u2018the model got better\u2019 and \u2018the eval got easier\u2019?")
      ),
      box(title = "Strong Answer Shape", status = "danger", solidHeader = TRUE, width = 5,
          tags$ol(
            tags$li("Acknowledge the result is interesting"),
            tags$li("Name 2-3 specific checks you'd run first (contamination, variance, reproducibility)"),
            tags$li("State what would make you confident vs. what would make you hold the claim"),
            tags$li("Describe how you'd communicate the \u2018hold\u2019 without killing momentum (\u2192 see Stakeholder Judgment tab)")
          ),
          warn_box("Avoid pure statistical-rigor-in-the-abstract answers. Anchor every check in the scenario's specifics \u2014 this rubric set, this grader, this sample size.")
      )
    )
  )
}

research_signal_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # Static content tab - no server-side logic required
  })
}
