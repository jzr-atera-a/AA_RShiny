# modules/ops_translation.R
# Tab: Ops -> Research Translation (Station 01 of the loop)

ops_translation_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Ops \u2192 Research Translation"),
        tags$h2("Where messy reality enters the loop"),
        div(
          span(class = "hero-badge", icon("comments"), " Vague \u2192 specific"),
          span(class = "hero-badge", icon("layer-group"), " Pattern, not anecdote"),
          span(class = "hero-badge", icon("file-export"), " Hands off cleanly")
        )
    ),

    fluidRow(
      box(title = "What's Being Tested", status = "primary", solidHeader = TRUE, width = 6,
          p("The JD asks you to \u201ctranslate ambiguous, real-world behavior into structured evaluation frameworks and new data categories\u201d and to do \u201cfailure analysis\u201d that finds \u201croot causes, edge cases, and opportunities for improvement.\u201d This tab is about that translation step \u2014 turning a fuzzy report into something a data-design team can build from."),
          success_box("What's tested isn't problem-solving in the abstract \u2014 it's the discipline of reading enough raw examples to find the real pattern, before naming it.")
      ),
      box(title = "The 5-Step Translation Framework", status = "info", solidHeader = TRUE, width = 6,
          timeline_entry("1", "Collect raw signal", "Read actual transcripts, tickets or logs first \u2014 summaries hide the detail that matters."),
          timeline_entry("2", "Cluster by cause", "Group instances by underlying mechanism, not surface wording."),
          timeline_entry("3", "Name the dimension", "Give it a measurable definition: binary pass/fail, a 1-5 rubric, or a rate."),
          timeline_entry("4", "Scope severity & frequency", "How often it happens, how bad when it does, and who's affected."),
          timeline_entry("5", "Write the hand-off spec", "Concrete enough that a data-design team could build the eval without another conversation with you.")
      )
    ),

    fluidRow(
      box(title = "Worked Example", status = "warning", solidHeader = TRUE, width = 12,
          p(tags$b("Signal:"), " Users say an agent \u201csometimes ignores instructions in long conversations.\u201d"),
          spec_block(paste(
            "spec: long_context_instruction_drift",
            "definition: \"Model fails to apply an instruction given >6 turns earlier\"",
            "measurement: binary pass/fail per conversation, rubric-graded",
            "severity: high (silent failure, no error signal to user)",
            "est. frequency: ~14% of conversations >10 turns (from 40 sampled transcripts)",
            "next step: build 100-conversation eval set, stratified by conversation length",
            sep = "\n"
          )),
          tip_box("Distinguish \u2018this happened once\u2019 from \u2018this is a pattern worth building an eval for\u2019 \u2014 cite a rate (e.g. 6 of 40 transcripts \u2192 ~15%), not just an example.")
      )
    ),

    fluidRow(
      box(title = "Practice Prompts", status = "success", solidHeader = TRUE, width = 7,
          scenario_card("Prompt 1", "Users say an agent \u2018sometimes ignores instructions in long conversations.\u2019 You have 40 transcripts. Walk me through how you'd turn this into something a research team can measure."),
          scenario_card("Prompt 2", "A client says a model \u2018feels less careful than it used to\u2019 after a recent update, but can't point to a specific example. How do you investigate this?"),
          scenario_card("Prompt 3", "You notice three unrelated bug reports might actually share a root cause. How do you confirm that before proposing a new eval category?")
      ),
      box(title = "Strong Answer Shape", status = "danger", solidHeader = TRUE, width = 5,
          tags$ol(
            tags$li("Situation: restate the vague signal as given"),
            tags$li("Action: how you'd sample and read examples, what you'd look for when clustering"),
            tags$li("Result: the resulting eval dimension and its definition"),
            tags$li("Check: how you'd sanity-check this framing is right before handing it off")
          ),
          warn_box("Don't jump straight to \u2018we'd build a benchmark for this\u2019 without grounding the dimension in real examples \u2014 and resist proposing a fix; this station is about framing, not engineering.")
      )
    )
  )
}

ops_translation_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # Static content tab - no server-side logic required
  })
}
