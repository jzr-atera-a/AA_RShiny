# modules/practice_exercise.R
# Tab: Practice & Exercise Prep

practice_exercise_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Practice & Exercise Prep"),
        tags$h2("One structure, applied across all four stations"),
        div(
          span(class = "hero-badge", icon("diagram-project"), " Frame \u2192 Evidence \u2192 Mechanism \u2192 Tradeoffs \u2192 Decision"),
          span(class = "hero-badge", icon("stopwatch"), " ~48 min, AI Interview + Exercise")
        )
    ),

    fluidRow(
      box(title = "Universal Answer Structure", status = "primary", solidHeader = TRUE, width = 7,
          timeline_entry("1", "Frame", "Restate the situation in your own terms \u2014 what's actually being claimed or asked, and what's at stake if you get it wrong."),
          timeline_entry("2", "Evidence", "State what you'd look at first. Be concrete: sample sizes, baselines, who's affected, what data exists."),
          timeline_entry("3", "Mechanism", "Walk through the reasoning step by step \u2014 this is where systems-level thinking gets evaluated."),
          timeline_entry("4", "Tradeoffs", "Name at least one limitation, risk, or alternative reading of the evidence. Don't oversell certainty."),
          timeline_entry("5", "Decision", "End with a concrete recommendation, next step, or \u2018what I'd do by end of week\u2019 \u2014 not just analysis.")
      ),
      box(title = "Exercise-Format Tips", status = "warning", solidHeader = TRUE, width = 5,
          tags$ol(
            tags$li(tags$b("Narrate everything."), " It's an AI interviewer \u2014 it grades what you say, not what you're thinking."),
            tags$li(tags$b("Use the 5-step shape every time."), " Even a 2-minute answer should hit Frame and Decision."),
            tags$li(tags$b("Be specific with numbers."), " Hypothetical figures are fine \u2014 vagueness is not."),
            tags$li(tags$b("It's safe to say \u2018not yet\u2019."), " That's the quality-gate instinct the role wants \u2014 just pair it with a path forward."),
            tags$li(tags$b("Watch the clock."), " ~48 minutes total covers conversation and exercise \u2014 don't let one answer run long.")
          ),
          success_box("Keep one concrete example ready per focus area before you start \u2014 abstract answers score lower than specific, slightly-imperfect ones.")
      )
    ),

    fluidRow(
      box(title = "Mixed Scenario Bank \u2014 Rehearse Out Loud", status = "info", solidHeader = TRUE, width = 12,
          p("Each scenario below is tagged with the station it draws on most. Say your answer out loud using the 5-step structure, then jot the key beats in the notes box \u2014 notes are local to this session only."),

          fluidRow(
            column(6,
              scenario_card("Station 03 \u00b7 Research Signal Judgment", "Your team reports a 12% jump on an internal eval after a prompt change. The eval was last updated two weeks ago. What's your first move?"),
              textAreaInput(ns("notes1"), NULL, placeholder = "Frame / Evidence / Mechanism / Tradeoffs / Decision\u2026", rows = 3, width = "100%")
            ),
            column(6,
              scenario_card("Station 02 \u00b7 ML-Oriented Data Design", "You need a rubric for grading whether a chatbot response is 'over-confident'. Sketch the dimensions and how you'd calibrate raters."),
              textAreaInput(ns("notes2"), NULL, placeholder = "Frame / Evidence / Mechanism / Tradeoffs / Decision\u2026", rows = 3, width = "100%")
            )
          ),
          fluidRow(
            column(6,
              scenario_card("Station 01 \u00b7 Ops \u2192 Research Translation", "A domain expert says an agent's outputs 'don't feel grounded anymore' after a model swap, but has no specific examples yet. What do you do in the next 24 hours?"),
              textAreaInput(ns("notes3"), NULL, placeholder = "Frame / Evidence / Mechanism / Tradeoffs / Decision\u2026", rows = 3, width = "100%")
            ),
            column(6,
              scenario_card("Station 04 \u00b7 Stakeholder Judgment", "Leadership wants a go/no-go decision on a launch by Friday, but your eval suite only covers 60% of the relevant scenarios. How do you frame this for them?"),
              textAreaInput(ns("notes4"), NULL, placeholder = "Frame / Evidence / Mechanism / Tradeoffs / Decision\u2026", rows = 3, width = "100%")
            )
          ),
          fluidRow(
            column(6,
              scenario_card("Cross-station \u00b7 Translation \u2192 Data Design", "Three different teams report 'weird' agent behaviour in tool calls, each describing it differently. How do you decide whether this is one issue or three \u2014 and what would you build to check?"),
              textAreaInput(ns("notes5"), NULL, placeholder = "Frame / Evidence / Mechanism / Tradeoffs / Decision\u2026", rows = 3, width = "100%")
            ),
            column(6,
              scenario_card("Cross-station \u00b7 Signal \u2192 Stakeholder", "A 10-point improvement on your eval doesn't show up in production metrics after rollout. Walk through your investigation and how you'd report it."),
              textAreaInput(ns("notes6"), NULL, placeholder = "Frame / Evidence / Mechanism / Tradeoffs / Decision\u2026", rows = 3, width = "100%")
            )
          )
      )
    ),

    fluidRow(
      box(title = "Final Pre-Interview Recap", status = "success", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4, framework_box("Know the loop", "Translation \u2192 Data Design \u2192 Signal Judgment \u2192 Stakeholder Judgment \u2192 back to ops.", "rotate")),
            column(4, framework_box("Know your checklists", "5-point signal validation, 5-layer data design stack, 5-step translation, 5-step stakeholder framework.", "list-check")),
            column(4, framework_box("Know your structure", "Frame \u2192 Evidence \u2192 Mechanism \u2192 Tradeoffs \u2192 Decision, every time.", "diagram-project"))
          )
      )
    )
  )
}

practice_exercise_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # Notes are session-local (textAreaInput); no persistence needed.
  })
}
