# modules/ch04_evaluate_systems.R
# Ch. 4 — Evaluate AI Systems (Evaluation Criteria, Model Selection, Pipeline Design)

ch04_evaluate_systems_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Ch.4 — Evaluate AI Systems"),
        tags$h2("Evaluation Criteria · Model Selection (Build vs. Buy) · Designing the Evaluation Pipeline"),
        div(
          span(class = "hero-badge", "Build vs Buy"),
          span(class = "hero-badge", "System-Level Eval"),
          span(class = "hero-badge", "Pipeline Design")
        )
    ),

    fluidRow(
      box(title = "🏗️ Build vs. Buy — The Core Decision Framework", status = "primary", solidHeader = TRUE, width = 6,
          div(class = "success-box", HTML("<strong>Huyen's framing:</strong> model selection is not one decision — it's a sequence: (1) hard filters (cost, license, data residency), (2) soft filters (quality on your task via eval), (3) ongoing re-evaluation as new models ship.")),
          div(class = "framework-card", tags$h5("Hard constraints first"), tags$p("Latency SLO, cost per request at expected volume, data privacy/regulatory requirements, and licensing eliminate candidates before quality comparison even starts.")),
          div(class = "framework-card", tags$h5("Then quality, on your task"), tags$p("Run your own eval pipeline (Ch.3 methods) on YOUR data/tasks — public leaderboard rank is a weak proxy once hard filters are applied.")),
          div(class = "framework-card", tags$h5("Build is rarely 'from scratch'"), tags$p("In practice 'build' usually means adapting an open-weight model (finetuning, distillation) rather than pretraining — full pretraining is reserved for cases with a durable, structural advantage.")),
          jobfit_box("This chapter IS the JD bullet 'decide when to design new model architectures versus adapting or leveraging frontier open-source or commercial models' — expect a live build-vs-buy exercise in interview.",
                     c("Model Selection", "Hard Filters"))
      ),

      box(title = "📊 Model Selection Scorecard (Example)", status = "info", solidHeader = TRUE, width = 6,
          tags$table(class = "table table-hover",
            tags$thead(tags$tr(tags$th("Criterion"), tags$th("Frontier API"), tags$th("Open-Weight + Finetune"), tags$th("Custom Architecture"))),
            tags$tbody(
              tags$tr(tags$td("Time to first version"), tags$td(tags$span(class="badge-green","Fast")), tags$td(tags$span(class="badge-amber","Medium")), tags$td(tags$span(class="badge-red","Slow"))),
              tags$tr(tags$td("Marginal cost at scale"), tags$td(tags$span(class="badge-red","High")), tags$td(tags$span(class="badge-amber","Medium")), tags$td(tags$span(class="badge-green","Low (if amortized)"))),
              tags$tr(tags$td("Data control / privacy"), tags$td(tags$span(class="badge-red","Low")), tags$td(tags$span(class="badge-green","High")), tags$td(tags$span(class="badge-green","High"))),
              tags$tr(tags$td("Ceiling capability"), tags$td(tags$span(class="badge-green","Highest")), tags$td(tags$span(class="badge-amber","Task-dependent")), tags$td(tags$span(class="badge-amber","Task-dependent"))),
              tags$tr(tags$td("Team / research investment needed"), tags$td(tags$span(class="badge-green","Low")), tags$td(tags$span(class="badge-amber","Medium")), tags$td(tags$span(class="badge-red","High")))
            )
          ),
          div(class = "tip-box", HTML("<strong>💡 A1-specific read:</strong> a young, high-density startup team most plausibly runs a hybrid: frontier API for ceiling capability + open-weight finetuned/distilled models for cost-sensitive, high-volume sub-tasks (e.g. routing, simple classification steps within a workflow)."))
      )
    ),

    fluidRow(
      box(title = "🔁 Designing an Evaluation Pipeline — End to End", status = "warning", solidHeader = TRUE, width = 12,
          fluidRow(
            column(3, div(class="chapter-card", div(class="chapter-num","1"), div(class="chapter-title","Define criteria & data"), div(class="chapter-desc","Rubric dimensions + a representative, versioned eval set drawn from real (or realistic synthetic) traffic."))),
            column(3, div(class="chapter-card", div(class="chapter-num","2"), div(class="chapter-title","Automate scoring"), div(class="chapter-desc","Exact-match / functional checks where possible; AI-as-judge calibrated against humans elsewhere."))),
            column(3, div(class="chapter-card", div(class="chapter-num","3"), div(class="chapter-title","Wire into CI/CD"), div(class="chapter-desc","Every prompt/model/pipeline change runs the eval suite before shipping — regression gate, not a one-off report."))),
            column(3, div(class="chapter-card", div(class="chapter-num","4"), div(class="chapter-title","Monitor in production"), div(class="chapter-desc","Sample live traffic, track drift in scores over time, feed failures back into the eval set (closes the loop with Ch.10 user feedback).")))
          )
      )
    ),

    fluidRow(
      box(title = "✍️ Practice: Make the Build-vs-Buy Call", status = "success", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4,
                   selectInput(ns("scenario"), "Choose a sub-system to decide on:",
                               choices = c("Top-level assistant reasoning/orchestration model", "Intent routing / task classification (high volume, low complexity)",
                                           "Long-context document summarisation for notes", "Safety/guardrail classifier for tool-call approval")),
                   sliderInput(ns("confidence"), "Confidence (1–10):", 1, 10, 5),
                   actionButton(ns("save_btn"), "Save Assessment", class = "btn-meta", width = "100%")
            ),
            column(8,
                   div(class = "practice-area",
                       tags$b("State your decision and justify it against hard filters, quality-on-task, and cost at scale."),
                       textAreaInput(ns("notes"), label = NULL, rows = 9, width = "100%",
                                     placeholder = "## Hard filters (cost, latency, privacy, licensing)\n\n## Quality-on-task evaluation plan\n\n## Decision: build / buy / hybrid, and why\n\n## What would change your mind"),
                       uiOutput(ns("feedback"))
                   )
            )
          )
      )
    )
  )
}

ch04_evaluate_systems_server <- function(id, prep_manager) {
  moduleServer(id, function(input, output, session) {
    observeEvent(input$save_btn, {
      notes <- input$notes
      conf  <- input$confidence
      score <- 0
      if (grepl("cost|latency|privacy|licens|constraint", notes, ignore.case = TRUE)) score <- score + 25
      if (grepl("eval|quality|task|test|benchmark", notes, ignore.case = TRUE)) score <- score + 25
      if (grepl("decision|build|buy|hybrid|adapt", notes, ignore.case = TRUE)) score <- score + 25
      if (grepl("chang|revisit|reconsider|new model", notes, ignore.case = TRUE)) score <- score + 25

      prep_manager$update_progress("ch04_evaluate_systems", min(score + conf * 2, 100))
      prep_manager$save_note("ch04_notes", notes)
      prep_manager$add_practice_score("ch04_evaluate_systems", score, input$scenario)

      output$feedback <- renderUI({
        div(class = if (score >= 75) "success-box" else "tip-box",
            tags$h5(paste0("Score: ", score, "/100")),
            if (score < 100) tags$p("A strong build-vs-buy answer always names hard filters explicitly, then a quality-on-task eval plan, then a clear decision AND the condition under which you'd revisit it.")
        )
      })
      showNotification("Saved!", type = "message")
    })
  })
}
