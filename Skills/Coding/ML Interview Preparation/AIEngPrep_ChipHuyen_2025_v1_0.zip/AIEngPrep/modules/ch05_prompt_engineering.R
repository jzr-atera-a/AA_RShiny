# modules/ch05_prompt_engineering.R
# Ch. 5 — Prompt Engineering

ch05_prompt_engineering_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Ch.5 — Prompt Engineering"),
        tags$h2("Prompting Fundamentals · Best Practices · Defensive Prompt Engineering (Jailbreaking, Injection, Defenses)"),
        div(
          span(class = "hero-badge", "In-Context Learning"),
          span(class = "hero-badge", "Prompt Injection"),
          span(class = "hero-badge", "Defensive Design")
        )
    ),

    fluidRow(
      box(title = "✏️ Prompting Best Practices", status = "primary", solidHeader = TRUE, width = 6,
          div(class = "framework-card", tags$h5("Be explicit about output structure"), tags$p("Specify format, length, and constraints directly; don't rely on the model inferring intent — this is what makes downstream parsing reliable.")),
          div(class = "framework-card", tags$h5("Give the model room to reason"), tags$p("Chain-of-thought / step-by-step instructions improve complex-task accuracy, at the cost of latency and tokens — a real trade-off for a live assistant.")),
          div(class = "framework-card", tags$h5("Few-shot examples over abstract instructions"), tags$p("Concrete input/output examples often generalize better than a long list of abstract rules, especially for formatting-sensitive tasks.")),
          div(class = "framework-card", tags$h5("Version and test prompts like code"), tags$p("Prompts are part of the system's logic — they need version control, regression tests (Ch.3/4 eval), and rollback plans.")),
          jobfit_box("Prompt design is the cheapest lever for A1's reliability goal — before reaching for finetuning or new architecture, most reliability gains on long workflows come from tighter, tested prompting + structured outputs.",
                     c("Structured Output", "Prompt Versioning"))
      ),

      box(title = "🛡️ Defensive Prompt Engineering", status = "info", solidHeader = TRUE, width = 6,
          tags$table(class = "table table-hover",
            tags$thead(tags$tr(tags$th("Threat"), tags$th("What Happens"), tags$th("Defense"))),
            tags$tbody(
              tags$tr(tags$td(tags$span(class="stage-pill","Jailbreaking")), tags$td("User crafts input to bypass the model's safety training"), tags$td("System-prompt hardening, output filtering, refusal classifiers")),
              tags$tr(tags$td(tags$span(class="stage-pill","Prompt injection")), tags$td("Malicious instructions hidden in retrieved/tool content override intended behaviour"), tags$td("Separate trusted vs untrusted content channels, instruction hierarchy, sanitize tool outputs")),
              tags$tr(tags$td(tags$span(class="stage-pill","Data exfiltration")), tags$td("Attacker gets the model to leak system prompt or private context"), tags$td("Least-privilege context, don't put secrets in the system prompt, output scanning")),
              tags$tr(tags$td(tags$span(class="stage-pill","Tool-call hijack")), tags$td("Injected content tricks the agent into calling a tool with attacker-controlled args"), tags$td("Human confirmation for high-stakes actions, allow-lists, argument validation"))
            )
          ),
          div(class = "warn-box", HTML("<strong>⚠️ A1-critical:</strong> an assistant that reads emails/notes and calls external tools is a textbook prompt-injection surface — untrusted retrieved content (an email body) can contain hidden instructions."))
      )
    ),

    fluidRow(
      box(title = "🔒 Guardrail Layering for an Agentic Assistant", status = "warning", solidHeader = TRUE, width = 12,
          fluidRow(
            column(3, div(class="chapter-card", div(class="chapter-num","LAYER 1"), div(class="chapter-title","Input guardrails"), div(class="chapter-desc","Filter/flag suspicious user or retrieved content before it reaches the model."))),
            column(3, div(class="chapter-card", div(class="chapter-num","LAYER 2"), div(class="chapter-title","Prompt-level defenses"), div(class="chapter-desc","Instruction hierarchy, clear delimiters between trusted instructions and untrusted content."))),
            column(3, div(class="chapter-card", div(class="chapter-num","LAYER 3"), div(class="chapter-title","Action-level guardrails"), div(class="chapter-desc","Allow-lists for tools, argument validation, human confirmation for irreversible actions."))),
            column(3, div(class="chapter-card", div(class="chapter-num","LAYER 4"), div(class="chapter-title","Output guardrails"), div(class="chapter-desc","Post-hoc scanning for leaked secrets, unsafe content, or policy violations before returning to the user.")))
          )
      )
    ),

    fluidRow(
      box(title = "✍️ Practice: Design a Defense Against Injected Instructions", status = "success", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4,
                   selectInput(ns("scenario"), "Choose an attack surface:",
                               choices = c("Hidden instructions inside a retrieved email", "Malicious text in a shared note the assistant summarises",
                                           "A calendar invite description containing a prompt injection", "A web page fetched by a tool call containing adversarial text")),
                   sliderInput(ns("confidence"), "Confidence (1–10):", 1, 10, 5),
                   actionButton(ns("save_btn"), "Save Assessment", class = "btn-meta", width = "100%")
            ),
            column(8,
                   div(class = "practice-area",
                       tags$b("Describe the attack path and a layered defense (input, prompt, action, output)."),
                       textAreaInput(ns("notes"), label = NULL, rows = 9, width = "100%",
                                     placeholder = "## Attack path — how injected content could hijack behaviour\n\n## Layered defenses (input / prompt / action / output)\n\n## What you'd still want a human to confirm"),
                       uiOutput(ns("feedback"))
                   )
            )
          )
      )
    )
  )
}

ch05_prompt_engineering_server <- function(id, prep_manager) {
  moduleServer(id, function(input, output, session) {
    observeEvent(input$save_btn, {
      notes <- input$notes
      conf  <- input$confidence
      score <- 0
      if (grepl("inject|attack|hijack|malicious", notes, ignore.case = TRUE)) score <- score + 25
      if (grepl("trust|untrusted|delimit|hierarchy|instruction", notes, ignore.case = TRUE)) score <- score + 25
      if (grepl("allow.?list|valid|confirm|approve|human", notes, ignore.case = TRUE)) score <- score + 25
      if (grepl("output|scan|filter|leak", notes, ignore.case = TRUE)) score <- score + 25

      prep_manager$update_progress("ch05_prompt_engineering", min(score + conf * 2, 100))
      prep_manager$save_note("ch05_notes", notes)
      prep_manager$add_practice_score("ch05_prompt_engineering", score, input$scenario)

      output$feedback <- renderUI({
        div(class = if (score >= 75) "success-box" else "tip-box",
            tags$h5(paste0("Score: ", score, "/100")),
            if (score < 100) tags$p("Good injection-defense answers cover all four layers: input filtering, prompt-level trust separation, action-level confirmation, and output scanning — not just one.")
        )
      })
      showNotification("Saved!", type = "message")
    })
  })
}
