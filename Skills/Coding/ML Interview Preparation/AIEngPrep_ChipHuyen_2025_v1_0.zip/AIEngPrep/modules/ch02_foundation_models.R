# modules/ch02_foundation_models.R
# Ch. 2 — Understanding Foundation Models

ch02_foundation_models_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Ch.2 — Understanding Foundation Models"),
        tags$h2("Training Data · Architecture & Scale · Post-Training · Sampling · The Probabilistic Nature of AI"),
        div(
          span(class = "hero-badge", "Transformers & MoE"),
          span(class = "hero-badge", "RLHF / DPO"),
          span(class = "hero-badge", "Sampling & Temperature"),
          span(class = "hero-badge", "Non-determinism")
        )
    ),

    fluidRow(
      box(title = "🧬 Training Pipeline: Pretraining → Post-training", status = "primary", solidHeader = TRUE, width = 6,
          div(class = "framework-card",
              tags$h5("Pretraining"),
              tags$p("Self-supervised next-token prediction over massive, broad corpora. Produces a raw base model — strong pattern completion, weak instruction-following.")),
          div(class = "framework-card",
              tags$h5("Supervised Finetuning (SFT)"),
              tags$p("Trains the base model on curated instruction-response pairs to make it follow instructions and adopt a consistent conversational format.")),
          div(class = "framework-card",
              tags$h5("Preference finetuning (RLHF / DPO)"),
              tags$p("Aligns outputs to human preference — helpfulness, harmlessness, honesty — using reward models or direct preference optimization. This is where a lot of \"alignment\" work concretely happens.")),
          jobfit_box("Architecture and MoE decisions (Ch.2) feed directly into the JD's build-vs-buy ask — knowing when scaling laws / MoE sparsity favour adapting a frontier model vs. training bespoke components is exactly the technical judgment being screened for.",
                     c("MoE", "Scaling Laws", "Build vs Buy"))
      ),

      box(title = "🎲 Sampling & the Probabilistic Nature of AI", status = "info", solidHeader = TRUE, width = 6,
          div(class = "section-heading-dark", "Key sampling levers"),
          tags$ul(
            tags$li(tags$b("Temperature:"), " scales logits before softmax — low = deterministic/greedy-like, high = more diverse/riskier."),
            tags$li(tags$b("Top-k / top-p (nucleus):"), " restrict the candidate pool so low-probability, low-quality tokens are excluded."),
            tags$li(tags$b("Greedy / beam search:"), " deterministic decoding strategies, generally more consistent but less creative.")
          ),
          div(class = "warn-box",
              HTML("<strong>⚠️ Engineering implication:</strong> the same prompt can yield different outputs across calls. Systems that assume determinism (retries assuming identical results, strict output parsing) will silently break in production.")),
          div(class = "success-box",
              HTML("<strong>✅ Mitigations:</strong> structured/constrained decoding, lower temperature for tool-calling steps, output validators + automatic retries, and treating variance itself as a monitored metric — not just accuracy.")),
          div(class = "tip-box",
              HTML("<strong>💡 A1 angle:</strong> \"reliability despite non-deterministic model behaviour\" in the JD is a near-verbatim reference to this chapter's core theme."))
      )
    ),

    fluidRow(
      box(title = "⚖️ Architecture / Scale Decision Table", status = "warning", solidHeader = TRUE, width = 12,
          tags$table(class = "table table-hover",
            tags$thead(tags$tr(tags$th("Decision"), tags$th("Favor Frontier API"), tags$th("Favor Own/Adapted Model"))),
            tags$tbody(
              tags$tr(tags$td("Latency/cost at massive scale"), tags$td("Low volume, prototyping fast"), tags$td("High volume — distillation/smaller model amortizes cost")),
              tags$tr(tags$td("Data sensitivity"), tags$td("Vendor has adequate data controls"), tags$td("Strict privacy/on-prem/regulatory requirement")),
              tags$tr(tags$td("Capability ceiling needed"), tags$td("Need frontier reasoning/multimodality now"), tags$td("Narrow task — smaller finetuned/distilled model suffices")),
              tags$tr(tags$td("Team & timeline"), tags$td("Small team, need to ship this quarter"), tags$td("Research-heavy team, long-horizon differentiation bet"))
            )
          )
      )
    ),

    fluidRow(
      box(title = "✍️ Practice: Explain Non-Determinism to a Non-Technical Stakeholder", status = "success", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4,
                   selectInput(ns("scenario"), "Choose a stakeholder scenario:",
                               choices = c("PM asks why the assistant gave two different answers to the same request",
                                           "Exec asks if we can 'just fix' hallucinations with a bigger model",
                                           "Support lead asks why retries sometimes make things worse")),
                   sliderInput(ns("confidence"), "Confidence (1–10):", 1, 10, 5),
                   actionButton(ns("save_btn"), "Save Assessment", class = "btn-meta", width = "100%")
            ),
            column(8,
                   div(class = "practice-area",
                       tags$b("Draft a plain-language explanation plus one concrete engineering mitigation."),
                       textAreaInput(ns("notes"), label = NULL, rows = 8, width = "100%",
                                     placeholder = "## Plain-language explanation of why outputs vary\n\n## Concrete mitigation (sampling, validation, retries, etc.)\n\n## What you would still tell them to expect"),
                       uiOutput(ns("feedback"))
                   )
            )
          )
      )
    )
  )
}

ch02_foundation_models_server <- function(id, prep_manager) {
  moduleServer(id, function(input, output, session) {
    observeEvent(input$save_btn, {
      notes <- input$notes
      conf  <- input$confidence
      score <- 0
      if (grepl("probabilist|sampl|temperature|token|distribution", notes, ignore.case = TRUE)) score <- score + 30
      if (grepl("mitigat|retry|valid|guardrail|constrain|lower temp", notes, ignore.case = TRUE)) score <- score + 40
      if (grepl("expect|monitor|variance|manage", notes, ignore.case = TRUE)) score <- score + 30

      prep_manager$update_progress("ch02_foundation_models", min(score + conf * 2, 100))
      prep_manager$save_note("ch02_notes", notes)
      prep_manager$add_practice_score("ch02_foundation_models", score, input$scenario)

      output$feedback <- renderUI({
        div(class = if (score >= 70) "success-box" else "tip-box",
            tags$h5(paste0("Score: ", score, "/100")),
            if (score < 30) tags$p("⚠️ Ground the explanation in sampling/probabilistic generation, not just 'AI is unpredictable.'"),
            if (score < 70) tags$p("⚠️ Add a concrete engineering mitigation, not just an explanation."),
            if (score >= 70) tags$p("✅ Clear explanation + mitigation — this is the shape interviewers want.")
        )
      })
      showNotification("Saved!", type = "message")
    })
  })
}
