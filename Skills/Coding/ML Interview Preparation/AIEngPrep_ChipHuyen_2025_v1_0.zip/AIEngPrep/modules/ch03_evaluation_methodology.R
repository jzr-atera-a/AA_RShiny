# modules/ch03_evaluation_methodology.R
# Ch. 3 — Evaluation Methodology

ch03_evaluation_methodology_ui <- function(id) {
  ns <- NS(id)

  tagList(
    div(class = "meta-hero",
        tags$h1("Ch.3 — Evaluation Methodology"),
        tags$h2("Challenges of Evaluating Foundation Models · Language Modeling Metrics · Exact Eval · AI-as-Judge · Comparative Eval"),
        div(
          span(class = "hero-badge", "Beyond Leaderboards"),
          span(class = "hero-badge", "AI-as-Judge"),
          span(class = "hero-badge", "Comparative Eval")
        )
    ),

    fluidRow(
      box(title = "🧭 Why Evaluation Is Hard for Foundation Models", status = "primary", solidHeader = TRUE, width = 6,
          div(class = "warn-box", HTML("<strong>⚠️ Core challenge:</strong> open-ended, generative outputs don't have one correct answer — classic accuracy/F1 metrics from discriminative ML don't transfer cleanly.")),
          div(class = "framework-card",
              tags$h5("Public benchmarks ≠ your product"),
              tags$p("Leaderboard scores measure general capability on tasks that may not resemble your actual use case, and are prone to contamination/overfitting by model vendors.")),
          div(class = "framework-card",
              tags$h5("Criteria are multi-dimensional"),
              tags$p("Correctness, relevance, factuality, safety, tone, latency, and cost all need separate — sometimes conflicting — evaluation criteria.")),
          div(class = "framework-card",
              tags$h5("Ground truth is expensive or absent"),
              tags$p("Many tasks (long-running assistant workflows) have no single labeled 'correct' trace to compare against.")),
          jobfit_box("This is the JD's loudest, most explicit ask: 'define evaluation frameworks that measure real-world usefulness... not benchmark vanity.' Be ready to name specific criteria beyond leaderboard scores for A1's assistant.",
                     c("Custom Eval", "Not Benchmark Vanity"))
      ),

      box(title = "🛠️ Evaluation Method Toolkit", status = "info", solidHeader = TRUE, width = 6,
          tags$table(class = "table table-hover",
            tags$thead(tags$tr(tags$th("Method"), tags$th("What It Measures"), tags$th("Limitation"))),
            tags$tbody(
              tags$tr(tags$td(tags$span(class="stage-pill","LM metrics")), tags$td("Perplexity, cross-entropy — model's fit to text distribution"), tags$td("Doesn't measure task usefulness")),
              tags$tr(tags$td(tags$span(class="stage-pill","Exact eval")), tags$td("Exact match, functional correctness (e.g. code passes tests)"), tags$td("Only works for tasks with verifiable outputs")),
              tags$tr(tags$td(tags$span(class="stage-pill","AI-as-judge")), tags$td("A capable model scores outputs against a rubric"), tags$td("Judge bias, cost, needs calibration against humans")),
              tags$tr(tags$td(tags$span(class="stage-pill","Comparative eval")), tags$td("Pairwise/preference comparisons (A vs B), Elo-style ranking"), tags$td("Doesn't give an absolute quality bar")),
              tags$tr(tags$td(tags$span(class="stage-pill","Human eval")), tags$td("Gold standard for nuanced judgment"), tags$td("Slow, expensive, doesn't scale to CI/CD"))
            )
          ),
          div(class = "tip-box", HTML("<strong>💡 In practice:</strong> production systems combine several — cheap automated checks (exact/AI-judge) gate every change, human eval samples periodically to calibrate the judge."))
      )
    ),

    fluidRow(
      box(title = "⚖️ AI-as-Judge — Design Considerations", status = "warning", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4, div(class="chapter-card", div(class="chapter-num","RUBRIC"), div(class="chapter-title","Write explicit, decomposed criteria"), div(class="chapter-desc","Score correctness, safety, tone separately rather than one vague 'quality' score."))),
            column(4, div(class="chapter-card", div(class="chapter-num","CALIBRATE"), div(class="chapter-title","Validate judge against humans"), div(class="chapter-desc","Sample judge outputs, compare to human raters, measure agreement before trusting it in CI."))),
            column(4, div(class="chapter-card", div(class="chapter-num","GUARD"), div(class="chapter-title","Watch for judge bias"), div(class="chapter-desc","Position bias, verbosity bias, self-preference bias (judge favors its own model family's style).")))
          )
      )
    ),

    fluidRow(
      box(title = "✍️ Practice: Design an Eval Rubric for A1's Assistant", status = "success", solidHeader = TRUE, width = 12,
          fluidRow(
            column(4,
                   selectInput(ns("scenario"), "Choose the task to evaluate:",
                               choices = c("Drafting an email reply on the user's behalf", "Booking/confirming a multi-step errand",
                                           "Summarising a week of notes into action items", "Deciding whether to escalate to the human user")),
                   sliderInput(ns("confidence"), "Confidence (1–10):", 1, 10, 5),
                   actionButton(ns("save_btn"), "Save Assessment", class = "btn-meta", width = "100%")
            ),
            column(8,
                   div(class = "practice-area",
                       tags$b("Write 4–6 rubric dimensions plus how you'd automate scoring for each."),
                       textAreaInput(ns("notes"), label = NULL, rows = 9, width = "100%",
                                     placeholder = "## Rubric dimensions (e.g. correctness, safety, tone, latency)\n\n## Automated scoring approach per dimension\n\n## Where human eval is still required"),
                       uiOutput(ns("feedback"))
                   )
            )
          )
      )
    )
  )
}

ch03_evaluation_methodology_server <- function(id, prep_manager) {
  moduleServer(id, function(input, output, session) {
    observeEvent(input$save_btn, {
      notes <- input$notes
      conf  <- input$confidence
      score <- 0
      if (grepl("correctness|accura|factual", notes, ignore.case = TRUE)) score <- score + 20
      if (grepl("safe|guardrail|harm|risk", notes, ignore.case = TRUE)) score <- score + 20
      if (grepl("judge|rubric|automat|score", notes, ignore.case = TRUE)) score <- score + 20
      if (grepl("human|calibrat|sample", notes, ignore.case = TRUE)) score <- score + 20
      if (grepl("latency|cost|tone|relevan", notes, ignore.case = TRUE)) score <- score + 20

      prep_manager$update_progress("ch03_evaluation_methodology", min(score + conf * 2, 100))
      prep_manager$save_note("ch03_notes", notes)
      prep_manager$add_practice_score("ch03_evaluation_methodology", score, input$scenario)

      output$feedback <- renderUI({
        div(class = if (score >= 80) "success-box" else "tip-box",
            tags$h5(paste0("Score: ", score, "/100")),
            if (score < 100) tags$p("Aim for a multi-dimensional rubric (correctness, safety, tone, latency/cost) with a clear automated-vs-human split — vague single scores read as 'benchmark vanity' to an interviewer.")
        )
      })
      showNotification("Saved!", type = "message")
    })
  })
}
